const getters = {
  devType: state => state.app.devType,
  isWeb: state => state.app.isWeb,
  username: state => state.user.username,
  authId: state => state.user.authId,
  password: state => state.user.password,
  pwd: state => state.user.pwd,
  hiddenPage: state => state.app.hiddenPages
}
export default getters
