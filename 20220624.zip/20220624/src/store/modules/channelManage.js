import {
  getCompositeChnCap,
  getSvrChnList,
  getNvrChnList,
  getSrvCap,
  getRtmpParam,
  setRtmpParam
} from '@/api/channelManage.js'

const state = {
  composite: [],
  svrChnList: [],
  nvrChnList: [],
  svrCap: [],
  rtmpParam: []
}

const mutations = {
  GET_COMPOSITE: (state, sipConfig) => {
    state.composite = sipConfig
  },
  GET_SVR_CHN: (state, sipConfig) => {
    state.svrChnList = sipConfig
  },
  GET_NVR_CHN: (state, sipConfig) => {
    state.nvrChnList = sipConfig
  },
  GET_SVR_CAP: (state, sipConfig) => {
    state.svrCap = sipConfig
  },
  GET_RTMP_PARAM: (state, sipConfig) => {
    state.rtmpParam = sipConfig
  }
}

const actions = {
  getCompositeChnCap({
    commit,
    state
  }, params) {
    return new Promise((resolve, reject) => {
      getCompositeChnCap(params).then(response => {
        commit('GET_COMPOSITE', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  getSrvCap({
    commit,
    state
  }, params) {
    return new Promise((resolve, reject) => {
      getSrvCap(params).then(response => {
        commit('GET_SVR_CAP', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  getSvrChnList({
    commit,
    state
  }, params) {
    return new Promise((resolve, reject) => {
      getSvrChnList(params).then(response => {
        commit('GET_SVR_CHN', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  getNvrChnList({
    commit,
    state
  }, params) {
    return new Promise((resolve, reject) => {
      getNvrChnList(params).then(response => {
        commit('GET_NVR_CHN', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  getRtmpParam({
    commit,
    state
  }, params) {
    return new Promise((resolve, reject) => {
      getRtmpParam(params).then(response => {
        commit('GET_RTMP_PARAM', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  setRtmpParam({
    commit,
    state
  }, params) {
    return new Promise((resolve, reject) => {
      setRtmpParam(params).then(response => {
        commit('GET_RTMP_PARAM', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
