import {getVsipAppCfg, getSmssCfg, setSmssCfg, setVsipAppCfg, getGb28181AppCfg,setGb28181AppCfg} from '@/api/registManage.js'
import { getToken, removeToken, setToken } from '@/utils/auth'
import { resetRouter } from '@/router'
import md5 from 'js-md5'


const state = {
  VsipAppCfg: [],
  SmssCfg:[],
  GbAppCfg:[]
}

const mutations = {
  TOGGLE_SIP_CONFIG: (state, sipConfig) => {
    state.VsipAppCfg = sipConfig
  },
  GET_SMSS_CONFIG: (state, sipConfig) => {
    state.SmssCfg = sipConfig
  },
  SET_SMSS_CONFIG:(state, sipConfig) => {
    state.SmssCfg = sipConfig
  },
  GET_GB_APP_CONFIG:(state, sipConfig) => {
    state.GbAppCfg = sipConfig
  }
}

const actions = {
  getVsipAppCfg({ commit,state }, params) {
    return new Promise((resolve, reject) => {
      getVsipAppCfg(params).then(response => {
        commit('TOGGLE_SIP_CONFIG', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  setVsipAppCfg({ commit,state }, params) {
    return new Promise((resolve, reject) => {
      setVsipAppCfg(params).then(response => {
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  getSmssCfg({ commit,state }, params) {
    return new Promise((resolve, reject) => {
      getSmssCfg(params).then(response => {
        commit('GET_SMSS_CONFIG', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  setSmssCfg({ commit,state }, params) {
    return new Promise((resolve, reject) => {
      setSmssCfg(params).then(response => {
        commit('SET_SMSS_CONFIG', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  getGb28181AppCfg({ commit,state }, params) {
    return new Promise((resolve, reject) => {
      getGb28181AppCfg(params).then(response => {
        commit('GET_GB_APP_CONFIG', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  setGb28181AppCfg({ commit,state }, params) {
    return new Promise((resolve, reject) => {
      setGb28181AppCfg(params).then(response => {
        commit('GET_GB_APP_CONFIG', [])
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
