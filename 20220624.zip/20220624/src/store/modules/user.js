import { getAuth, login, pollingState } from '@/api/user'
import { getToken, removeToken, setToken } from '@/utils/auth'
import md5 from 'js-md5'

const getDefaultState = () => {
  return {
    token: getToken(),
    username: '',
    authId: '',
    password: '',
    stateTimer: null,
    pwd: ''
  }
}

const state = getDefaultState()

const mutations = {
  RESET_STATE: (state) => {
    Object.assign(state, getDefaultState())
  },
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_USERNAME: (state, username) => {
    state.username = username
  },
  SET_AUTHID: (state, id) => {
    state.authId = id
  },
  SET_PASSWORD: (state, password) => {
    state.password = password
  },
  SET_TIMER: (state, timer) => {
    state.stateTimer = timer
  },
  SET_PWD: (state, pwd) => {
    state.pwd = pwd
  }
}

const actions = {
  // 登录
  login({ commit, state }, userInfo) {
    userInfo.username = userInfo.username.trim()
    const { username, password } = userInfo
    return new Promise((resolve, reject) => {
      getAuth().then(res => {
        const authId = res.GetAuthenticationidResp.Authenticationid
        commit('SET_AUTHID', authId)
        const encodePsw = window.btoa(md5(`${username},${password},${state.authId}`))
        login({ username: username, password: encodePsw, authenticationid: authId }).then(response => {
          // 加密后的密码
          commit('SET_USERNAME', username)
          commit('SET_PASSWORD', encodePsw)
          commit('SET_TOKEN', authId)
          // 密码明文 rtsp拉流时用来鉴权
          commit('SET_PWD', password)
          setToken(`${username}_${encodePsw}_${authId}_${password}`)
          resolve(response)
        }).catch(error => {
          reject(error)
        })
      }).catch(error => {
        reject(error)
      })
    })
  },

  // 删除token
  resetToken({ commit }) {
    return new Promise(resolve => {
      removeToken() // 首先移除token
      commit('RESET_STATE')
      resolve()
    })
  },

  setUserInfo({ commit }) {
    return new Promise(resolve => {
      const userInfo = getToken()
      const userInfos = userInfo.split('_')
      commit('SET_USERNAME', userInfos[0])
      commit('SET_PASSWORD', userInfos[1])
      commit('SET_AUTHID', userInfos[2])
      commit('SET_PWD', userInfos[3])
      resolve()
    })
  },

  // 轮询保活
  getState({ commit, state }) {
    clearInterval(state.stateTimer)
    return new Promise((resolve, reject) => {
      pollingState().then(() => {
        const timer = setInterval(pollingState, 5000)
        commit('SET_TIMER', timer)
        resolve()
      }).catch(() => {
        reject()
      })
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

