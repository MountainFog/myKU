import {
  getVersionInfo
} from '@/api/deviceInfo'
import {
  getAdvanceParam
} from '@/api/systemConfig.js'

const state = {
  hiddenPages: [],
  devType: '',
  isWeb: true
}

const mutations = {
  setHiddenPage: (state, pages) => {
    state.hiddenPages = pages
  },
  SET_DEV_NAME: (state, type) => {
    state.devType = type
  },
  SET_IS_WEB: (state, isWeb) => {
    state.isWeb = isWeb
  }
}

const actions = {
  getVersionInfo({
    commit
  }) {
    getVersionInfo().then(async res => {
      const DevType = res.GetSysDevInfoResp.DevType
      const hiddenPages = []
      if (DevType.indexOf('-V') < 0) {
        hiddenPages.push('MeetingPlatform', 'Interactive')
      }
      if (DevType.indexOf('SVR2740') > -1) {
        hiddenPages.push('StreamMedia', 'MonitManage')
      }
      await getAdvanceParam({}).then(res => {
        if (res.GetAdvanceParamResp.Mss === 'true') { // 流媒体
          const index = hiddenPages.findIndex(item => item === 'StreamMedia')
          if (index > -1) {
            hiddenPages.splice(index, 1)
          }
        }
        if (res.GetAdvanceParamResp.Vsip === 'true') { // 监控平台
          const idx = hiddenPages.findIndex(item => item === 'MonitManage')
          if (idx > -1) {
            hiddenPages.splice(idx, 1)
          }
        }
      })
      commit('setHiddenPage', hiddenPages)
      commit('SET_DEV_NAME', DevType)
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
