import request from '@/utils/request'
import { formatParams } from '@/utils/dataParse'

export function getVersionInfo(data = {}) {
  return request({
    url: '/nvrcgi/system/GetSysDevInfo',
    method: 'post',
    data: formatParams(data)
  })
}

export function getScene(data = {}) {
  return request({
    url: '/nvrcgi2/svrscene/GetSceneParam',
    method: 'post',
    data: formatParams(data)
  })
}

export function getSvrState(data = {}) {
  return request({
    url: '/nvrcgi2/svrsys/SvrStateEx',
    method: 'post',
    data: formatParams(data)
  })
}

export function setSysSleep(data = {}) {
  return request({
    url: '/nvrcgi2/svrsys/SetSysSleep',
    method: 'post',
    data: formatParams(data)
  })
}
