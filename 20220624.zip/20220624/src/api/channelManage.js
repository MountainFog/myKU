import request from '@/utils/request'
import {
  formatParams
} from '@/utils/dataParse.js'

export function getCompositeChnCap(param) { // nvrcgi/chnmange/GetCompositeChnCap
  return request({
    url: '/nvrcgi/chnmange/GetCompositeChnCap',
    data: formatParams(param),
    method: 'post'
  })
}
export function getSrvCap() {
  return request({
    url: '/nvrcgi/getcap?Active=true&ChnNum=true&GroupNum=true&AlmInNum=true&GB28181=true&Vsip=true&SerialNum=true&GB28181Clt=true&PubSecClt=true&Onvif=true&CloudSrv=true&ZeroChnEnc=true&AisAnalysis=true&Snmp=true&Pcap=true&Broadcast=true&IpFilter=true&SXTServer=true&AudDecVol=true&WirelessVeh=true&AisCtrlLib=true&SnapSup=true&AisSearch=true&Websocket=true&Ddns=true&DragCusCanvas=true&SysHealth=true&PubSec=true&Isp=true&Multicast=true&GpSecurity=true&Https=true&COIAPP=true&PigeonApp=true&PdnsApp=true&AlarmIn=true&AlarmOut=true&PubSecMax=true&ExtIp=true&EPTZPushFrame=true&AisDeal=true&AisEngine=true&AisLargeData=true&BlueTooth=true&Wifi=true&SimNum=true&DevType=true&JumpWebCfg=true&TollCfg=true&CarSnapIll=true&Websocket=true',
    method: 'post'
  })
}
export function getSvrChnList(param) { // 获取svr通道列表
  return request({
    url: '/nvrcgi2/svredu/GetSvrChnList',
    data: formatParams(param),
    method: 'post'
  })
}
export function setSvrChnList(param) { // 获取svr通道列表
  return request({
    url: '/nvrcgi2/svredu/SetSvrChnList',
    data: param,
    method: 'post'
  })
}
export function getNvrChnList(param) { // 获取通道列表
  return request({
    url: '/nvrcgi/chnmange/GetNvrChnList',
    data: formatParams(param),
    method: 'post'
  })
}
export function getRtmpParam(param) { // 获取RTMP参数
  return request({
    url: '/nvrcgi2/svrrtmp/GetRtmpParam',
    data: formatParams(param),
    method: 'post'
  })
}
export function setRtmpParam(param) { // 设置RTMP参数
  return request({
    url: '/nvrcgi2/svrrtmp/SetRtmpParam',
    data: formatParams(param),
    method: 'post'
  })
}
export function addDevParam(param) { // 添加设备信息
  return request({
    url: '/nvrcgi/chnmange/AddDev',
    data: param,
    method: 'post'
  })
}
export function modifyDev(param) { // 修改设备信息
  return request({
    url: '/nvrcgi/chnmange/ModifyDev',
    data: param,
    method: 'post'
  })
}
export function removeDevParam(param) { // 删除设备信息
  return request({
    url: '/nvrcgi/chnmange/RemoveDev',
    data: formatParams(param),
    method: 'post'
  })
}

export function createSearchPuTask(param) { // 开始设备搜索
  return request({
    url: '/nvrcgi/chnmange/CreateSearchPuTask',
    data: param,
    method: 'post'
  })
}

export function getSearchedPuList(param, id) { // 获取设备搜索结果
  return request({
    url: '/nvrcgi/chnmange/GetSearchedPuList/' + id,
    data: formatParams(param),
    method: 'post'
  })
}

export function destroySearchPuTask(param, id) { // 停止设备搜索
  return request({
    url: '/nvrcgi/chnmange/DestroySearchPuTask/' + id,
    data: formatParams(param),
    method: 'post'
  })
}
