import request from '@/utils/request'
import {
  formatParams
} from '@/utils/dataParse.js'

// 获取网卡参数
export function getEthInfo(data) {
  return request({
    url: '/nvrcgi2/svrnetwork/GetEthInfo',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置网卡参数
export function setEthInfo(data) {
  return request({
    url: '/nvrcgi2/svrnetwork/SetEthInfo',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取端口
export function getProtoPort(data) {
  return request({
    url: '/nvrcgi/network/GetProtoPort',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置端口
export function setProtoPort(data) {
  return request({
    url: '/nvrcgi/network/SetProtoPort',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取SNMP参数
export function getSnmpParam(data) {
  return request({
    url: '/nvrcgi2/svrnetwork/GetSnmpParam',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置SNMP参数
export function setSnmpParam(data) {
  return request({
    url: '/nvrcgi2/svrnetwork/SetSnmpParam',
    method: 'post',
    data: formatParams(data)
  })
}

export function getStaticRouteList(param) { // 获取静态路由列表
  return request({
    url: '/nvrcgi2/svrnetwork/GetStaitcRouterList',
    data: formatParams(param),
    method: 'post'
  })
}

export function setStaticRouteList(param) { // 设置静态路由列表
  return request({
    url: '/nvrcgi2/svrnetwork/SetStaitcRouterList',
    data: param,
    method: 'post'
  })
}

export function getHttpsCfg(param) { // 获取https配置
  return request({
    url: '/nvrcgi/network/GetHttpsCfg',
    data: formatParams(param),
    method: 'post'
  })
}

export function setHttpsCfg(param) { // 设置https配置
  return request({
    url: '/nvrcgi/network/SetHttpsCfg',
    data: formatParams(param),
    method: 'post'
  })
}

export function getHttpsCrtDetails(param) { // 获取https证书详情
  return request({
    url: '/nvrcgi/network/GetHttpsCrtDetails',
    data: formatParams(param),
    method: 'post'
  })
}

export function httpsDelCrt(param) { // 删除HTTPS证书
  return request({
    url: '/nvrcgi/network/HttpsDelCrt',
    data: formatParams(param),
    method: 'post'
  })
}

export function httpsImportCrt(param) { // 导入HTTPS证书
  return request({
    url: '/nvrcgi/network/HttpsImportCrt',
    data: formatParams(param),
    method: 'post'
  })
}

export function httpsCreateCrt(param) { // 创建HTTPS证书
  return request({
    url: '/nvrcgi/network/HttpsCreateCrt',
    data: formatParams(param),
    method: 'post'
  })
}

// 获取端口映射表
export function getPortsMap(param = {}) {
  return request({
    url: '/nvrcgi2/svrnetwork/GetPortsMap',
    data: formatParams(param),
    method: 'post'
  })
}

// 设置端口映射表
export function setPortsMap(param = {}) {
  return request({
    url: '/nvrcgi2/svrnetwork/SetPortsMap',
    data: formatParams(param),
    method: 'post'
  })
}
