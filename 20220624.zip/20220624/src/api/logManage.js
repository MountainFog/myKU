
import request from '@/utils/request'
import { formatParams } from '@/utils/dataParse'

export function createQueryTask(data) {
  return request({
    url: '/nvrcgi/log/CreateQueryTask',
    method: 'post',
    data: formatParams(data)
  })
}

export function getQueryResult(data) {
  return request({
    url: '/nvrcgi/log/GetQueryResult',
    method: 'post',
    data: formatParams(data)
  })
}

export function destroyQueryTask(data) {
  return request({
    url: '/nvrcgi/log/DestroyQueryTask',
    method: 'post',
    data: formatParams(data)
  })
}
