import request from '@/utils/request'
import {
  formatParams
} from '@/utils/dataParse.js'

// 创建录播资源查询任务
export function creatVideoQuery(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/QueryMp4RecTask',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取录播资源管理列表
export function getVideoResult(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/GetMp4RecTaskQueryResultEx',
    method: 'post',
    data: formatParams(data)
  })
}

// 删除录播资源管理列表
export function delMp4RecTask(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/DelMp4RecTask',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取录播配置
export function getVideoCfg(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/GetMp4RecPolicyCfg',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置录播配置
export function setVideoCfg(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/SetMp4RecPolicyCfg',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取mp4录制计划
export function getMp4RecSchEx(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/GetMp4RecSchEx',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置mp4录制计划
export function setMp4RecSchEx(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/SetMp4RecSchEx',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取手动配置课程录制选项
export function getMp4ManulRecCfg(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/GetMp4ManulRecCfg',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置手动配置课程录制选项
export function setMp4ManulRecCfg(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/SetMp4ManulRecCfg',
    method: 'post',
    data: formatParams(data)
  })
}

// 录像模块通道月视图查询
export function QuerySvrChnMonthMap(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/QuerySvrChnMonthMap',
    method: 'post',
    data: formatParams(data)
  })
}

// 录像模块通道月视图查询
export function GetSvrMonthMapResult(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/GetSvrMonthMapResult',
    method: 'post',
    data: formatParams(data)
  })
}

// 开启查询录像
export function QuerySvrChnRec(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/QuerySvrChnRec',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取录像查询结果
export function QuerySvrChnRecResult(data = {}) {
  return request({
    url: '/nvrcgi2/svrmp4/QuerySvrChnRecResult',
    method: 'post',
    data: formatParams(data)
  })
}

// 创建回放任务
export function createTask(params) {
  return request({
    url: '/nvrcgi/record/PlayTask/Create',
    data: formatParams(params),
    method: 'post'
  })
}

// 开启录像回放(服务端)
export function startPalyback(params) {
  return request({
    url: '/nvrcgi/record/PlayTask/Start',
    data: formatParams(params),
    method: 'post'
  })
}

// 获取录像回放rtsp协议的url
export function getPlaybackUrl(params) {
  return request({
    url: '/nvrcgi/record/GetRtspUrlReplay',
    data: formatParams(params),
    method: 'post'
  })
}

// 获取录像回放rtsp协议的url
export function vcrCtrlSeek(params) {
  return request({
    url: '/nvrcgi/record/PlayTask/VcrCtrl',
    data: formatParams(params),
    method: 'post'
  })
}

// 获取录像回放进度
export function getVideoProgress(params) {
  return request({
    url: 'nvrcgi/record/PlayTask/QueryProg',
    data: formatParams(params),
    method: 'post'
  })
}

export function getRtspUrlReplay(params) { // 获取rtspurl
  return request({
    url: '/nvrcgi/record/GetRtspUrlReplay',
    data: params,
    method: 'post'
  })
}

export function Create(params) { // 创建回放任务
  return request({
    url: '/nvrcgi/record/PlayTask/Create',
    data: params,
    method: 'post'
  })
}

export function Start(params) { // 开始回放
  return request({
    url: '/nvrcgi/record/PlayTask/Start',
    data: params,
    method: 'post'
  })
}

export function getWebsocketAccess(params) { // websocket进程
  return request({
    url: '/nvrcgi/system/GetWebsocketAccess',
    data: formatParams(params),
    method: 'post'
  })
}

export function queryProg(params) { // 播放时长
  return request({
    url: '/nvrcgi/record/PlayTask/QueryProg',
    data: params,
    method: 'post'
  })
}

export function vcrCtrl(params) { // 拖动跳转
  return request({
    url: '/nvrcgi/record/PlayTask/VcrCtrl',
    data: params,
    method: 'post'
  })
}

export function Destroy(params) { // 销毁回放任务
  return request({
    url: '/nvrcgi/record/PlayTask/Destroy',
    data: formatParams(params),
    method: 'post'
  })
}

export function getSvrChnRecCfgEx(params) { // 录像模块获取录像通道配置
  return request({
    url: '/nvrcgi2/svrmp4/GetSvrChnRecCfgEx',
    data: formatParams(params),
    method: 'post'
  })
}

export function setSvrChnRecCfgEx(params) { // 录像模块获取录像通道配置
  return request({
    url: '/nvrcgi2/svrmp4/SetSvrChnRecCfgEx',
    data: formatParams(params),
    method: 'post'
  })
}

export function copySvrChnRecCfg(params) { // 录像模块复制录像通道配置
  return request({
    url: '/nvrcgi2/svrmp4/CopySvrChnRecCfg',
    data: params,
    method: 'post'
  })
}
