import request from '@/utils/request'
import { formatParams } from '@/utils/dataParse'

// 获取场景模式
export function getSceneParam(data = {}) {
  return request({
    url: '/nvrcgi2/svrscene/GetSceneParam',
    method: 'post',
    data: formatParams(data)
  })
}

// 修改场景模式
export function setSceneParam(data = {}) {
  return request({
    url: '/nvrcgi2/svrscene/SetSceneParam',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取视频输出参数
export function getVmtParam(data = {}) {
  return request({
    url: '/nvrcgi2/svrvmt/GetVmtParam',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置视频输出参数
export function setVmtParam(data = {}) {
  return request({
    url: '/nvrcgi2/svrvmt/SetVmtParam',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取音频矩阵参数
export function getAmtParam(data = {}) {
  return request({
    url: '/nvrcgi2/svramt/GetAmtParam',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取音频矩阵功率参数
export function getAmtPowerAverage(data = {}) {
  return request({
    url: '/nvrcgi2/svramt/GetAmtPowerAverage',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置音频矩阵参数
export function setAmtParam(data = {}) {
  return request({
    url: '/nvrcgi2/svramt/SetAmtParam',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取互动配置
export function getInteractConfig(data = {}) {
  return request({
    url: '/nvrcgi2/svrinteractout/GetInteractOutChnCfg',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置互动配置
export function setInteractConfig(data = {}) {
  return request({
    url: '/nvrcgi2/svrinteractout/SetInteractOutChnCfg',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取NVR通道列表
export function getNvrChnList(data = {}) {
  return request({
    url: '/nvrcgi/chnmange/GetNvrChnList',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取SVR通道列表
export function getSvrChnList(data = {}) {
  return request({
    url: '/nvrcgi2/svredu/GetSvrChnList',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取中控串口监听指令配置
export function getMonitorOrder(data = {}) {
  return request({
    url: '/nvrcgi2/svrccu/GetMonitorOrder',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取监听串口参数
export function getMonitorComParam(data = {}) {
  return request({
    url: '/nvrcgi2/svrccu/GetMonitorComParam',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置监听串口参数
export function setMonitorComParam(data = {}) {
  return request({
    url: '/nvrcgi2/svrccu/SetMonitorComParam',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取基本指令列表
export function getBasicOrderListEx(data = {}) {
  return request({
    url: '/nvrcgi2/svrccu/GetBasicOrderListEx',
    method: 'post',
    data: formatParams(data)
  })
}

// 指令测试
export function listenTest(data = {}) {
  return request({
    url: '/nvrcgi2/svrccu/ListenTest',
    method: 'post',
    data: formatParams(data)
  })
}

// 获取中控指令所有宏指令配置
export function getMacroOrderList(data = {}) {
  return request({
    url: '/nvrcgi2/svrorder/GetMacroOrderList',
    method: 'post',
    data: formatParams(data)
  })
}

// 设置中控指令所有宏指令配置
export function setMacroOrderList(data = {}) {
  return request({
    url: '/nvrcgi2/svrorder/SetMacroOrderList',
    method: 'post',
    data: formatParams(data)
  })
}
