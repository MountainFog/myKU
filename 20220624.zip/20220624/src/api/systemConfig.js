import request from '@/utils/request'
import axios from 'axios'
import {
  formatParams
} from '@/utils/dataParse.js'

export function setSysTimeInfo(param) { // 设置系统时间配置
  return request({
    url: '/nvrcgi/system/SetSysTimeInfo',
    data: formatParams(param),
    method: 'post'
  })
}
export function getSysTimeInfo(param) { // 获取系统时间配置
  return request({
    url: '/nvrcgi/system/GetSysTimeInfo',
    data: formatParams(param),
    method: 'post'
  })
}

export function getMp4DelAllRecResult(param = {}) { // 查询分区结果
  return request({
    url: '/nvrcgi2/svrmp4/GetMp4DelAllRecResult',
    data: formatParams(param),
    method: 'post'
  })
}

export function getSysBasicInfo(param) { // 获取系统基本配置
  return request({
    url: '/nvrcgi/system/GetSysBasicInfo',
    data: formatParams(param),
    method: 'post'
  })
}
export function setSysBasicInfo(param) { // 设置系统基本配置
  return request({
    url: '/nvrcgi/system/SetSysBasicInfo',
    data: formatParams(param),
    method: 'post'
  })
}

export function getTotalUserInfo(param) { // 获取全部用户列表
  return request({
    url: '/nvrcgi/security/GetTotalUserInfo',
    data: formatParams(param),
    method: 'post'
  })
}

export function getUserInfo(param) { // 获取单个用户信息
  return request({
    url: '/nvrcgi/security/GetUserInfo',
    data: formatParams(param),
    method: 'post'
  })
}

export function setUserPwd(param) { // 设置用户密码
  return request({
    url: '/nvrcgi/security/SetUserPwd',
    data: formatParams(param),
    method: 'post'
  })
}

export function getRtspAuthMethod(param) { // 获取rtsp认证方法
  return request({
    url: '/nvrcgi/security/GetRtspAuthMethod',
    data: formatParams(param),
    method: 'post'
  })
}
export function setRtspAuthMethod(param) { // 设置rtsp认证方法
  return request({
    url: '/nvrcgi/security/SetRtspAuthMethod',
    data: formatParams(param),
    method: 'post'
  })
}
export function getSecurityCfg(param) { // 获取安全服务配置
  return request({
    url: '/nvrcgi/security/GetSecurityCfg',
    data: formatParams(param),
    method: 'post'
  })
}
export function setSecurityCfg(param) { // 设置安全服务配置
  return request({
    url: '/nvrcgi/security/SetSecurityCfg',
    data: formatParams(param),
    method: 'post'
  })
}
export function getIpFilterCfg(param) { // 获取ip地址过滤配置
  return request({
    url: '/nvrcgi/security/GetIpFilterCfg',
    data: formatParams(param),
    method: 'post'
  })
}
export function setIpFilterCfg(param) { // 设置ip地址过滤配置
  return request({
    url: '/nvrcgi/security/SetIpFilterCfg',
    data: formatParams(param),
    method: 'post'
  })
}
export function startPing(param) { // 开始ping
  return request({
    url: '/nvrcgi/network/Ping/Start',
    data: formatParams(param),
    method: 'post'
  })
}
export function getPingResult(id) { // 获取ping结果
  return request({
    url: `/nvrcgi/network/Ping/Result/${id}`,
    data: formatParams({}),
    method: 'post'
  })
}
export function stopPing(id) { // 停止ping
  return request({
    url: `/nvrcgi/network/Ping/Stop/${id}`,
    data: formatParams({}),
    method: 'post'
  })
}
export function captureStart(param) { // 开始网络抓包
  return request({
    url: '/nvrcgi/network/Capture/Start',
    data: formatParams(param),
    method: 'post'
  })
}
export function captureState(param) { // 获取网络抓包状态
  return request({
    url: '/nvrcgi/network/Capture/State',
    data: formatParams(param),
    method: 'post'
  })
}
export function captureStop(param) { // 停止网络抓包
  return request({
    url: '/nvrcgi/network/Capture/Stop',
    data: formatParams(param),
    method: 'post'
  })
}

export function getLoad(name) {
  return request({
    url: '/netpack/' + name,
    method: 'get'
  })
}
export function getAdvancedCfg(param) { // 获取高级配置
  return request({
    url: '/nvrcgi/system/GetAdvancedCfg',
    data: formatParams(param),
    method: 'post'
  })
}

export function setAdvancedCfg(param) { // 设置高级配置
  return request({
    url: '/nvrcgi/system/SetAdvancedCfg',
    data: formatParams(param),
    method: 'post'
  })
}

export function getAdvanceParam(param) { // 获取高级配置
  return request({
    url: '/nvrcgi2/svredu/GetAdvanceParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function setAdvanceParam(param) { // 设置高级配置
  return request({
    url: '/nvrcgi2/svredu/SetAdvanceParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function getDevModel(param) { // 获取自定义设备型号配置
  return request({
    url: '/nvrcgi2/svredu/GetDevModel',
    data: formatParams(param),
    method: 'post'
  })
}

export function setDevModel(param) { // 设置自定义设备型号配置
  return request({
    url: '/nvrcgi2/svredu/SetDevModel',
    data: formatParams(param),
    method: 'post'
  })
}

export function getFrpParam(param) { // 获取Frp配置
  return request({
    url: '/nvrcgi2/svrfrp/GetFrpParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function setFrpParam(param) { // 设置Frp配置
  return request({
    url: '/nvrcgi2/svrfrp/SetFrpParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function getAutoMaintainCfg(param) { // 获取自动维护配置
  return request({
    url: '/nvrcgi/system/GetAutoMaintainCfg',
    data: formatParams(param),
    method: 'post'
  })
}

export function setAutoMaintainCfg(param) { // 设置自动维护配置
  return request({
    url: '/nvrcgi/system/SetAutoMaintainCfg',
    data: param,
    method: 'post'
  })
}

export function getReboot(param) { // 系统重启
  return request({
    url: '/nvrcgi/system/Reboot',
    data: formatParams(param),
    method: 'post'
  })
}

export function setFactoryDef(param) { // 系统回复出厂
  return request({
    url: '/nvrcgi/system/FactoryDef',
    data: formatParams(param),
    method: 'post'
  })
}

export function removeDelAllRec(param) { // 清除录像
  return request({
    url: '/nvrcgi2/svrmp4/Mp4DelAllRec',
    data: formatParams(param),
    method: 'post'
  })
}

// 升级

export function getCapabilty(param) { // 获取系统升级能力
  return request({
    url: '/nvrcgi/system/Upgrade/GetCapabilty',
    data: formatParams(param),
    processData: false, // 不转换
    cache: false,
    timeout: 15000,
    headers: {
      'If-Modified-Since': '0'
    },
    method: 'post'
  })
}

export function setUserLoginTimeout(param) { // 修改当前登录的超时时间
  return request({
    url: '/nvrcgi/system/SetUserLoginTimeout',
    data: formatParams(param),
    method: 'post'
  })
}

export function upPrepare(param, options) { // 准备系统升级
  return request({
    url: '/nvrcgi/system/Upgrade/Prepare',
    data: formatParams(param),
    contentType: 'application/xml;charset=utf-8',
    method: 'post',
    dataType: options.dataType,
    timeout: options.timeout
  })
}

export function ftpUpgradeState(param) { // 升级状态查询
  return axios.post(
    process.env.VUE_APP_BASE_API + '/nvrcgi/system/Upgrade/State',
    {
      data: {}
    }, {
      headers: {
        'If-Modified-Since': '0',
        'Content-Type': false
      }
    }
  )
}

export function uploadSegment(param) { // 上传升级文件
  return request({
    url: '/nvrcgi/system/Upgrade/UploadSegment',
    data: formatParams(param),
    processData: false, // 不转换
    cache: false, // 不缓存
    timeout: 300000,
    headers: {
      'If-Modified-Since': '0',
      'Content-Type': false
    },
    method: 'post'
  })
}

export function uploadSegmentAll(param) {
  return request({
    url: '/nvrcgi/system/Upgrade/Upload',
    data: formatParams(param),
    processData: false, // 不转换
    cache: false, // 不缓存
    timeout: 300000,
    headers: {
      'If-Modified-Since': '0'
    },
    method: 'post'
  })
}

export function getFtpParam(param) { // 获取ftp服务器参数
  return request({
    url: '/nvrcgi/network/GetFtpParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function setFtpParam(param) { // 设置ftp服务器参数
  return request({
    url: '/nvrcgi/network/SetFtpParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function ftpUpgradePrepare(param) { // ftp方式升级系统准备
  return request({
    url: '/nvrcgi2/svrsys/FtpUpgradePrepare',
    data: formatParams(param),
    method: 'post'
  })
}

export function getVmtInputStatus(param = {}) { // 信息统计
  return request({
    url: '/nvrcgi2/svrvmt/VmtInputStatus',
    data: formatParams(param),
    method: 'post'
  })
}
