import request from '@/utils/request'
import {formatParams} from '@/utils/dataParse.js'

export function startInteract (params) {//开始互动 呼叫
  return request({
     url: '/nvrcgi2/svrh323/StartInteract',
     data: params,
     method: 'post',
  })
}

export function stopInteract (params) {//停止互动  停止呼叫
  return request({
     url: '/nvrcgi2/svrh323/StopInteract',
     data: formatParams(params),
     method: 'post',
  })
}

export function getInteractList (params) {//获取互动信息
  return request({
     url: '/nvrcgi2/svrh323/GetInteractList',
     data: formatParams(params),
     method: 'post',
  })
}

export function startInteractDStream (params) {//开启互动双流
  return request({
     url: '/nvrcgi2/svrh323/StartInteractDStream',
     data: formatParams(params),
     method: 'post',
  })
}

export function stopInteractDStream (params) {//停止互动双流-
  return request({
     url: '/nvrcgi2/svrh323/StopInteractDStream',
     data: formatParams(params),
     method: 'post',
  })
}

export function getOutChnCfg (params) {//获取互动输出配置信息
  return request({
     url: '/nvrcgi2/svrh323/GetOutChnCfg',
     data: formatParams(params),
     method: 'post',
  })
}

export function setOutChnCfg (params) {//设置互动输出源配置信息
  return request({
     url: '/nvrcgi2/svrh323/SetOutChnCfg',
     data: formatParams(params),
     method: 'post',
  })
}

export function getBookItemList (params) {//获取互动点条目列表
  return request({
     url: '/nvrcgi2/svrh323/GetBookItemList',
     data: formatParams(params),
     method: 'post',
  })
}

export function getQoeStatus (params) {//查询互动会议信息和网络统计信息
  return request({
     url: '/nvrcgi2/svrh323/GetQoeStatus',
     data: formatParams(params),
     method: 'post',
  })
}

export function getRtspUrlRealStream(params) { //获取用于拉取实时码流的rtsp url
  return request({
    url: '/nvrcgi/chnmange/GetRtspUrlRealStream',
    data: params,
    method: 'post'
  })
}

export function getAudSrcCap(params) { //获取音频源能力
  return request({
    url: '/nvrcgi/chnmange/GetAudSrcCap',
    data: params,
    method: 'post'
  })
}
//互动 专递课堂接口
//点对多配置
export function getConfParam(params) { //获取会议控制平台配置
  return request({
    url: '/nvrcgi2/svrconf/GetConfParam',
    data: formatParams(params),
    method: 'post'
  })
}

export function setConfParam(params) { //设置会议控制平台配置
  return request({
    url: '/nvrcgi2/svrconf/SetConfParam',
    data: formatParams(params),
    method: 'post'
  })
}
//点对点配置
export function getP2PCallCfg(params) { //获取点对点呼叫终端配置
  return request({
    url: '/nvrcgi2/svrh323/GetP2PCallCfg',
    data: formatParams(params),
    method: 'post'
  })
}

export function setP2PCallCfg(params) { //设置点对点呼叫终端配置
  return request({
    url: '/nvrcgi2/svrh323/SetP2PCallCfg',
    data: params,
    method: 'post'
  })
}

export function confSwitch1ToMany(params) { //设置点对多呼叫终端配置
  return request({
    url: '/nvrcgi2/svrconf/ConfSwitch1ToMany',
    data: formatParams(params),
    method: 'post'
  })
}

