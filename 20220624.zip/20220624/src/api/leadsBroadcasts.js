// 导播
import request from '@/utils/request'
import {
  formatParams
} from '@/utils/dataParse.js'

// 录制信息

export function getCurCourseInfo(param) { // 获取当前要录制的周期课程信息
  return request({
    url: '/nvrcgi2/svrmp4/GetCurCourseInfo',
    data: formatParams(param),
    method: 'post'
  })
}

export function getCmpChnVidEncParam(param) { // 获取合成通道视频编码参数
  return request({
    url: '/nvrcgi2/svredu/GetCmpChnVidEncParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function setCmpChnVidEncParam(param) { // 设置合成通道视频编码参数
  return request({
    url: '/nvrcgi2/svredu/SetCmpChnVidEncParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function getSvrStateEx(param) { // 获取svr当前状态信息
  return request({
    url: '/nvrcgi2/svrsys/SvrStateEx',
    data: formatParams(param),
    method: 'post'
  })
}

export function getCurMp4RecTaskState(param) { // 获取当前mp4录制任务的状态
  return request({
    url: '/nvrcgi2/svrmp4/GetCurMp4RecTaskState',
    data: formatParams(param),
    method: 'post'
  })
}

// 课件画面

export function getPptChnVidEncParam(param) { // 获取PPT通道视频编码参数
  return request({
    url: '/nvrcgi2/svredu/GetPptChnVidEncParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function setPptChnVidEncParam(param) { // 设置PPT通道视频编码参数
  return request({
    url: '/nvrcgi2/svredu/SetPptChnVidEncParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function getWBChnVidEncParam(param) { // 获取电子白板通道视频编码参数
  return request({
    url: '/nvrcgi2/svredu/GetWBChnVidEncParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function setWBChnVidEncParam(param) { // 设置电子白板通道视频编码参数
  return request({
    url: '/nvrcgi2/svredu/SetWBChnVidEncParam',
    data: formatParams(param),
    method: 'post'
  })
}

// 合成画面

export function getCmpMergeStyleParam(param) { // 获取画面合成配置
  return request({
    url: '/nvrcgi2/svredu/GetCmpMergeStyleParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function setCmpMergeStyleParam(param) { // 设置画面合成配置
  return request({
    url: '/nvrcgi2/svredu/SetCmpMergeStyleParam',
    data: param,
    method: 'post'
  })
}

export function setAmtAudType(param) { // 设置合成通道音频编码参数
  return request({
    url: '/nvrcgi2/svramt/SetAmtAudType',
    data: formatParams(param),
    method: 'post'
  })
}

// 片头片尾

export function getOsdCfg(param) { // 获取字幕叠加配置
  return request({
    url: '/nvrcgi2/svredu/GetOsdCfg',
    data: formatParams(param),
    method: 'post'
  })
}

export function setOsdCfg(param) { // 设置字幕叠加配置
  return request({
    url: '/nvrcgi2/svredu/SetOsdCfg',
    data: param,
    method: 'post'
  })
}

// 导播模式

export function directModeCtrl(param) { // 导播模式控制
  return request({
    url: '/nvrcgi2/svrdirector/DirectModeCtrl',
    data: formatParams(param),
    method: 'post'
  })
}

export function directGetMode(param) { // 获取导播模式
  return request({
    url: '/nvrcgi2/svrdirector/DirectGetMode',
    data: formatParams(param),
    method: 'post'
  })
}

// 录制

export function mp4RecCtrl(param) { // mp4录制控制
  return request({
    url: '/nvrcgi2/svrmp4/Mp4RecCtrl',
    data: formatParams(param),
    method: 'post'
  })
}

// 云台
export function changePtz(param) { // ptz控制
  return request({
    url: '/nvrcgi/chnmange/Ptz',
    data: formatParams(param),
    method: 'post'
  })
}

export function getIntMergeStyleParam(param) { // 获取互动合成配置
  return request({
    url: '/nvrcgi2/svredu/GetIntMergeStyleParam',
    data: formatParams(param),
    method: 'post'
  })
}

export function setIntMergeStyleParam(param) { // 设置互动合成配置
  return request({
    url: '/nvrcgi2/svredu/SetIntMergeStyleParam',
    data: param,
    method: 'post'
  })
}

export function uploadWatermark(param) { // 上传水印
  return request({
    url: '/nvrcgi2/upload/disk/01_02/watermark.bmp',
    data: param,
    method: 'post'
  })
}

export function getWatermark() { // 下载水印
  return request({
    url: '/disk/01_02/watermark.bmp',
    method: 'get'
  })
}
