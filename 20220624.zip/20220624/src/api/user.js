import request from '@/utils/request'
import { formatParams } from '@/utils/dataParse'

// 获取Authenticationid 鉴权
export function getAuth() {
  return request({
    url: '/nvrcgi/system/GetAuthenticationid',
    method: 'get'
  })
}

// 登录
export function login(data) {
  return request({
    url: '/nvrcgi/system/Login',
    method: 'post',
    data: formatParams(data)
  })
}

// 心跳保活
export function pollingState() {
  const data = {
    StateReq: {
      Chn: true,
      Group: true,
      RecentLog: {
        TimeStamp: 11,
        LogParam: ''
      },
      SysStatus: true,
      DiskChg: 'DiskChg',
      NotifyEvt: true,
      NetStatus: true,
      AiuChg: true,
      AlmStatus: true,
      AudCallStatus: true
    }
  }
  return request({
    url: '/nvrcgi/system/State',
    method: 'post',
    data: formatParams(data)
  })
}

export function getSvrState(param) {
  return request({
    url: '/nvrcgi2/svrsys/SvrStateEx',
    method: 'post',
    data: formatParams(param)
  })
}
