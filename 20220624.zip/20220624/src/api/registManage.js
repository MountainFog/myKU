import request from '@/utils/request'
import {
  formatParams
} from '@/utils/dataParse.js'

export function getVsipAppCfg(params) { // 获取监控平台的配置
  return request({
    url: '/nvrcgi/network/GetVsipAppCfg',
    data: formatParams(params),
    method: 'post'
  })
}
export function getSmssCfg(param) { // 获取流媒体服务器的配置
  return request({
    url: '/nvrcgi2/svrsmss/GetSmssCfg',
    data: formatParams(param),
    method: 'post'
  })
}
export function setSmssCfg(param) { // 获取流媒体服务器的配置
  return request({
    url: '/nvrcgi2/svrsmss/SetSmssCfg',
    data: formatParams(param),
    method: 'post'
  })
}
export function setVsipAppCfg(param) { // 设置监控平台的配置
  return request({
    url: '/nvrcgi/network/SetVsipAppCfg',
    data: formatParams(param),
    method: 'post'
  })
}
export function getGb28181AppCfg(param) { // 获取SIP
  return request({
    url: '/nvrcgi/network/GetGb28181AppCfg',
    data: formatParams(param),
    method: 'post'
  })
}
export function setGb28181AppCfg(param) { // 获取SIP
  return request({
    url: '/nvrcgi/network/SetGb28181AppCfg',
    data: formatParams(param),
    method: 'post'
  })
}
export function setH323Info(param) { // 设置会议平台注册配置
  return request({
    url: '/nvrcgi2/svrh323/SetH323Info',
    data: param,
    method: 'post'
  })
}
export function getH323Info(param) { // 查询h323信息
  return request({
    url: '/nvrcgi2/svrh323/GetH323Info',
    data: formatParams(param),
    method: 'post'
  })
}
export function setConfAdvanceCfg(param) { // 设置会议呼叫高级参数: 会议模式、是否端口复用
  return request({
    url: '/nvrcgi2/svrh323/SetConfAdvanceCfg',
    data: formatParams(param),
    method: 'post'
  })
}
export function getConfAdvanceCfg(param) { // 获取会议呼叫高级参数: 会议模式、是否端口复用
  return request({
    url: '/nvrcgi2/svrh323/GetConfAdvanceCfg',
    data: formatParams(param),
    method: 'post'
  })
}

export function getVideoSysConfig(param) { // 获取应用平台配置
  return request({
    url: '/nvrcgi2/svrvideosys/GetVideoSysConfig',
    data: formatParams(param),
    method: 'post'
  })
}

export function setVideoSysConfig(param) { // 获取应用平台配置
  return request({
    url: '/nvrcgi2/svrvideosys/SetVideoSysConfig',
    data: formatParams(param),
    method: 'post'
  })
}

// 获取跟踪主机状态
export function GetTrackHostStatus(param) {
  return request({
    url: '/nvrcgi2/svrdirector/GetTrackHostStatus',
    data: formatParams(param),
    method: 'post'
  })
}

// 设置跟踪主机的注册配置
export function SetTrackHostCfg(param) {
  return request({
    url: '/nvrcgi2/svrdirector/SetTrackHostCfg',
    data: formatParams(param),
    method: 'post'
  })
}

// 获取跟踪主机配置
export function GetTrackHostCfg(param) {
  return request({
    url: '/nvrcgi2/svrdirector/GetTrackHostCfg',
    data: formatParams(param),
    method: 'post'
  })
}
