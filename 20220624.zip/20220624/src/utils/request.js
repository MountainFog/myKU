import axios from 'axios'
import { Message } from 'element-ui'
import { xmlStr2json } from '@/utils/dataParse'
import codeMap from '@/utils/codeMap'
import router from '@/router'

// 创建axios实例
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API,
  // baseURL: 'http://172.18.1.160',
  timeout: 15000 // 超时时间
})
// 请求拦截
service.interceptors.request.use(
  config => {
    return config
  },
  error => {
    // 错误处理
    console.log(error)
    return Promise.reject(error)
  }
)

// 响应拦截
service.interceptors.response.use(

  /**
   * 通过自定义代码确定请求状态
   */
  response => {
    const res = xmlStr2json(response.data, response.url)
    const status = res.responsestatus || {}
    if (status.code && status.code !== 0) {
      Message({
        showClose: true,
        message: status.substatusstring || '请求发生错误',
        type: 'error',
        duration: 5 * 1000
      })

      return Promise.reject(new Error(res.message || '请求发生错误'))
    } else {
      return res
    }
  },
  (error) => {
    // 服务端返回
    const data = xmlStr2json(error.response.data)
    const resp = data.responsestatus || {}
    let messageText = ''
    const errCode = codeMap['code_' + resp.statuscode]

    // 鉴权ID错误，跳转到登录界面
    if (resp.statuscode === '205') {
      router.push('/login')
    }
    // 业务状态码
    if (errCode) {
      messageText = errCode
    } else {
      // http状态码
      const httpStatus = error.response.resp
      if (httpStatus > 399 && httpStatus < 418) {
        messageText = resp.substatusstring || '请求发生错误'
      }
      if (httpStatus >= 500 && httpStatus <= 505) {
        messageText = `服务端错误 ${httpStatus}` || resp.substatusstring || '请求发生错误'
      }
    }
    console.log('err:' + resp.substatusstring)
    // 错误提示
    Message({
      showClose: true,
      message: messageText,
      type: 'error',
      duration: 5 * 1000
    })
    return Promise.reject(data)
  }
)

export default service
