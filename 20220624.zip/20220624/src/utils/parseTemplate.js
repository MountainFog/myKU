export default {
  GetRtmpParamReq: {
    GetRtmpParamResp: {
      RtmpParamList: 'Array'
    }
  }
}
