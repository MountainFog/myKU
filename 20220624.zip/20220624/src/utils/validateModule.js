// 是否必填
export function validateNecessary(tipInfo = '请输入', trigger = 'blur', isNeces = true) {
  return {
    required: isNeces,
    message: tipInfo,
    trigger
  }
}

// 验证最大长度
export function validateLen(len = 20) {
  return {
    max: len,
    message: '最大长度为' + len + '个字符',
    trigger: 'blur'
  }
}

/* 是否合法IP地址*/
export function validateIP(rule, value, callback) {
  if (value === undefined || value === null) {
    callback()
  }
  if (value === '') {
    callback(new Error('不能为空'))
  } else {
    const reg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/
    if ((!reg.test(value)) && value !== '') {
      callback(new Error('IP格式不正确'))
    } else {
      callback()
    }
  }
}
/* 是否合法IP或者域名*/
export function validateIPOrDomain(rule, value, callback) {
  if (value === '') {
    callback(new Error('不能为空'))
    return
  }
  if (value === undefined || value === null) {
    callback()
  }
  const ip = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/
  const domain = /[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+\.?/
  if (ip.test(value) || domain.test(value)) {
    callback()
  } else {
    callback(new Error('请输入正确的IP或者域名'))
  }
}

/* 是否邮箱*/
export function validateEMail(rule, value, callback) {
  const reg = /^([a-zA-Z0-9]+[-_\.]?)+@[a-zA-Z0-9]+\.[a-z]+$/
  if (value === '' || value === undefined || value === null) {
    callback()
  } else {
    if (!reg.test(value)) {
      callback(new Error('请输入正确的邮箱地址'))
    } else {
      callback()
    }
  }
}

/* 合法uri*/
export function validateURL(textval) {
  const urlregex = /^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/
  return urlregex.test(textval)
}

/* 验证端口是否在[0,65535]之间 */
export function isPort(rule, value, callback) {
  if (!value) {
    return callback(new Error('输入不可以为空'))
  }
  setTimeout(() => {
    if (value === '' || typeof (value) === undefined) {
      callback(new Error('请输入端口值'))
    } else {
      const re = /^([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/
      const rsCheck = re.test(value)
      if (!rsCheck) {
        callback(new Error('请输入在[0-65535]之间的端口值'))
      } else {
        callback()
      }
    }
  }, 100)
}

/* 验证端口是否在[0,65535]之间 */
export function isBlank(rule, value, callback) {
  if (!value) {
    return callback(new Error('输入不可以为空'))
  }
}
