import store from '@/store'
import parseTemplate from '@/utils/parseTemplate'
/**
 * xml字符串转换xml对象数据
 * @param {Object} xmlStr
 */
export function xmlStr2XmlObj(xmlStr) {
  var xmlObj = {}
  xmlObj = new DOMParser().parseFromString(xmlStr, 'text/xml')
  return xmlObj
}

/**
 * xml直接转换json数据
 * @param {Object} xml
 */
export function xmlObj2json(xml) {
  try {
    var obj = {}
    if (xml.children.length > 0) {
      for (var i = 0; i < xml.children.length; i++) {
        var item = xml.children.item(i)
        var nodeName = item.nodeName
        if (typeof (obj[nodeName]) === 'undefined') {
          obj[nodeName] = xmlObj2json(item)
        } else {
          if (typeof (obj[nodeName].push) === 'undefined') {
            var old = obj[nodeName]
            obj[nodeName] = []
            obj[nodeName].push(old)
          }
          obj[nodeName].push(xmlObj2json(item))
        }
      }
    } else {
      obj = xml.textContent
    }
    return obj
  } catch (e) {
    console.log(e.message)
  }
}

export function findReqUrl(url) {
  if (!url) return
  const urlList = url.split('/')
  const key = urlList[urlList.length - 1]
  return parseTemplate[key]
}

/**
 * xml字符串转换json数据
 */
export function xmlStr2json(xml, url) {
  const tmp = findReqUrl(url)
  const xmlObj = xmlStr2XmlObj(xml)
  let jsonObj = {}
  if (xmlObj.childNodes.length > 0) {
    jsonObj = xmlToJson(xmlObj, tmp)
  }
  return jsonObj
}

export function xmlToJson(xml, tmp) {
  if (!xml.children.length) return xml.textContent
  const obj = {}
  for (let i = 0; i < xml.children.length; i++) {
    const node = xml.children[i]
    const tagName = node.nodeName
    if (tmp && tmp[tagName] === 'Array') {
      const nodes = xmlObj2json(node)
      obj[tagName] = findNodesArray(nodes)
    } else {
      if (!obj[tagName]) {
        obj[tagName] = xmlToJson(node, tmp ? tmp[tagName] : undefined)
      } else {
        if (!obj[tagName].push) {
          const old = obj[tagName]
          obj[tagName] = []
          obj[tagName].push(old)
        }
        obj[tagName].push(xmlToJson(node))
      }
    }
  }
  return obj
}

export function findNodesArray(nodes) {
  const ary = []
  for (const key in nodes) {
    const value = nodes[key]
    if (value.push) {
      ary.push(...value)
    } else {
      ary.push(value)
    }
  }
  return ary
}
/*
* 解析对象为xml props
* @ props 节点属性
*/
export function parseProps(props) {
  if (typeof props === 'undefined') return ''
  let propsXml = ''
  for (const key in props) {
    const value = props[key]
    propsXml += ` ${key}="${value}"`
  }
  return propsXml
}

/*
* 解析数组为xml
* @ list 目标数组
* @ tagName 节点的标签名称
*/
export function parseArray(list, tagName) {
  // 不是数组
  if (typeof list !== 'object') return ''
  // 数组为空
  if (!list.length) return ''
  let xml = ''
  for (let i = 0; i < list.length; i++) {
    const item = list[i]
    if (typeof item === 'object') {
      // 子节点为对象 解析为对象形式的xml
      xml += `<${tagName}>${jsonToXml(item)}</${tagName}>`
    } else {
      // 子节点为基本数据类型 直接拼接成xml
      xml += `<${tagName}>${item}</${tagName}>`
    }
  }
  return xml
}

/*
* 解析对象为xml
* @ params 目标对象
* @ tagName 节点的标签名称
*/
export function jsonToXml(params, tagName) {
  let node = ''
  if (typeof params === 'object') {
    for (const key in params) {
      const value = params[key]
      // 子节点若是对象，继续写递归解析
      if (typeof value === 'object') {
        const props = parseProps(value.P_R_O_P)
        if (value.K_E_Y) {
          // 包含K_E_Y， 当前对象的解析为数组形式的xml
          node += `<${key}${props}>${parseArray(value.V_A_L_U_E, value.K_E_Y)}</${key}>`
        } else {
          // 不包含K_E_Y, 却包含 P_R_O_P & V_A_L_U_E 当前对象的解析为有属性的xml
          if (value.P_R_O_P && (typeof value.V_A_L_U_E !== 'undefined')) {
            node += `<${key}${props}>${jsonToXml(value.V_A_L_U_E)}</${key}>`
          } else if (value.length !== undefined) {
            node += parseArray(value, key)
          } else {
            // 以上都不包含，解析为正常的xml
            node += `<${key}>${jsonToXml(value, key)}</${key}>`
          }
        }
      } else {
        // 子节点基本数据类型，直接拼接成xml
        node += `<${key}>${value}</${key}>`
      }
    }
  } else {
    // 基本数据类型，直接拼接成xml
    node += (tagName ? `<${tagName}>${params}</${tagName}>` : '')
  }
  return node
}

/*
* 格式化request config
*/
export function formatParams(data = {}) {
  let innerXml = '<contentroot><authenticationinfo type="7.0">'
  const closeXml = ' </authenticationinfo>'
  if (data.username) {
    innerXml += jsonToXml(data)
    innerXml += `${closeXml}<LoginReq></LoginReq>`
  } else {
    const params = {
      username: store.getters.username,
      password: store.getters.password,
      authenticationid: store.getters.authId
    }
    innerXml += jsonToXml(params)
    innerXml += closeXml
    innerXml += jsonToXml(data)
  }
  innerXml += '</contentroot>'
  return innerXml
}
