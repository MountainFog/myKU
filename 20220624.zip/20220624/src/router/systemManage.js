import main from '@/layout/components/main'
export default [
  {
    path: 'channelManage',
    component: main,
    meta: { title: '通道管理' },
    children: [
      {
        path: 'deviceConfig',
        name: 'deviceConfig',
        component: () => import('@/views/channelManage/deviceConfig'),
        meta: { title: '前端配置' }
      },
      {
        path: 'rtmpConfig',
        component: () => import('@/views/channelManage/rtmpConfig'),
        meta: { title: 'RTMP配置' }
      }
    ]
  },
  {
    path: 'registManage',
    component: main,
    meta: { title: '注册管理' },
    children: [
      {
        path: 'monitManage',
        name: 'MonitManage',
        component: () => import('@/views/registManage/monitManage'),
        meta: { title: '监控管理' }
      },
      {
        path: 'streamMedia',
        name: 'StreamMedia',
        component: () => import('@/views/registManage/streamMedia'),
        meta: { title: '流媒体' }
      },
      {
        path: 'sipManage',
        component: () => import('@/views/registManage/sipManage'),
        meta: { title: 'SIP平台' }
      },
      {
        path: 'meetingPlatform',
        name: 'MeetingPlatform',
        component: () => import('@/views/meetingPlatform/index'),
        meta: { title: '会议平台' }
      },
      {
        path: 'applicationPlat',
        name: 'applicationPlat',
        component: () => import('@/views/registManage/applicationPlat'),
        meta: { title: '应用平台' }
      },
      {
        path: 'trakHost',
        name: 'TrakHost',
        component: () => import('@/views/registManage/trakHost.vue'),
        meta: { title: '跟踪主机' }
      }
    ]
  },
  {
    path: 'application',
    component: () => import('@/views/applicationScenarios/index'),
    meta: { title: '应用场景' }
  },

  {
    path: 'networkConfig',
    component: main,
    meta: { title: '网络配置' },
    children: [
      {
        path: 'networkParams',
        name: 'NetworkParams',
        component: () => import('@/views/networkConfig/networkParams'),
        meta: { title: '网卡参数' }
      },
      {
        path: 'staticRouter',
        name: 'staticRouter',
        component: () => import('@/views/networkConfig/staticRouter'),
        meta: { title: '静态路由' }
      },
      {
        path: 'simpleNetworkManage',
        name: 'SimpleNetworkManage',
        component: () => import('@/views/networkConfig/simpleNetworkManage'),
        meta: { title: 'SNMP' }
      },
      {
        path: 'httpsConfig',
        name: 'httpsConfig',
        component: () => import('@/views/networkConfig/httpsConfig'),
        meta: { title: 'HTTPS' }
      },
      {
        path: 'portService',
        name: 'PortService',
        component: () => import('@/views/networkConfig/portService'),
        meta: { title: '端口服务' }
      },
      {
        path: 'channelPortMap',
        name: 'ChannelPortMap',
        component: () => import('@/views/networkConfig/channelPortMap'),
        meta: { title: '通道端口映射' }
      }
    ]
  },

  {
    path: 'systemManage',
    component: main,
    meta: { title: '系统配置' },
    children: [
      {
        path: 'localManage',
        name: 'localManage',
        component: () => import('@/views/systemManage/localManage'),
        meta: { title: '本地配置' }
      },
      {
        path: 'basicParameters',
        name: 'basicParameters',
        component: () => import('@/views/systemManage/basicParameters'),
        meta: { title: '基本参数' }
      },
      {
        path: 'equipmentMaintain',
        name: 'equipmentMaintain',
        component: () => import('@/views/systemManage/equipmentMaintain'),
        meta: { title: '设备维护' }
      },
      {
        path: 'userSecurity',
        name: 'userSecurity',
        component: () => import('@/views/userSecurity/index'),
        meta: { title: '用户安全' }
      },
      {
        path: 'networkMaint',
        name: 'networkMaint',
        component: () => import('@/views/networkMaint/index'),
        meta: { title: '网络维护' }
      },
      {
        path: 'systemState',
        name: 'SystemState',
        component: () => import('@/views/systemManage/systemState'),
        meta: { title: '系统状态' }
      }
    ]
  },
  {
    path: 'logManage',
    component: () => import('@/views/logManage/index'),
    meta: { title: '日志管理' }
  },
  {
    hidden: true,
    path: `modeConfig`,
    name: 'ModeConfig',
    component: () => import('@/views/applicationScenarios/modeConfig.vue')
  }
]
