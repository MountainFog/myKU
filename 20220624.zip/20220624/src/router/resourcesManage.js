export default [
  {
    path: 'videoManage',
    component: () => import('@/views/videoManage'),
    meta: { title: '录像管理' }
  },
  {
    path: 'videoPlayback',
    name: 'VideoPlayback',
    component: () => import('@/views/videoPlayback'),
    meta: { title: '录像回放' }
  },
  {
    path: 'videoConfig',
    component: () => import('@/views/videoConfig'),
    meta: { title: '录像配置' }
  }
]
