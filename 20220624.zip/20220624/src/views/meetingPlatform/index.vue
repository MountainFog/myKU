<template>
  <div class="meet-platform-config">
    <breadCrumb />
    <div class="meet-platform-content">
      <el-form
        ref="meetPlatForm"
        :rules="rules"
        :model="info"
        label-width="150px"
        label-position="left"
      >
        <el-form-item prop="H323Poroto" label="终端别名:">
          <el-input
            v-model="info.H323Alias"
            :disabled="interactiveStatus"
          />
        </el-form-item>
        <el-form-item label="呼叫协议:">
          <el-select
            v-model="info.PriorityProto"
            :disabled="interactiveStatus"
            placeholder="请选择"
          >
            <el-option
              v-for="item in PriorityProtoList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-button
            type="primary"
            @click="advanceSet"
          >设置</el-button>
        </el-form-item>
        <el-form-item v-show="info.PriorityProto === 'SIP'" label="传输协议:" label-width="150px">
          <el-select v-model="info.SipTransType">
            <el-option value="0" label="UDP" />
            <el-option value="1" label="TCP" />
          </el-select>
        </el-form-item>
      </el-form>
      <el-tabs v-model="activeName" @tab-click="handleTabsChange">
        <el-tab-pane label="H323" name="H323" />
        <el-tab-pane label="SIP" name="SIP" />
      </el-tabs>
      <el-form
        v-show="activeName === 'H323'"
        ref="h323Form"
        :model="info"
        :rules="rules"
        label-width="150px"
        label-position="left"
      >
        <el-form-item label="注册状态:">
          <span>{{ registerStatus === 'false' ? '未连接' : '已连接' }}</span>
        </el-form-item>
        <el-form-item label="注册会议平台:">
          <el-radio
            v-model="info.Enable"
            :disabled="interactiveStatus"
            label="true"
          >开启</el-radio>
          <el-radio
            v-model="info.Enable"
            :disabled="interactiveStatus"
            label="false"
          >关闭</el-radio>
        </el-form-item>
        <el-form-item label="服务器类型:">
          <el-select
            v-model="info.ServerType"
            placeholder="请选择"
            :disabled="interactiveStatus"
            @change="handleServerTypeChange"
          >
            <el-option
              v-for="item in serverTypeList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="MCU地址1:" prop="ServerAddr">
          <el-input
            v-model="info.ServerAddr"
            :disabled="interactiveStatus"
          />
          <el-button
            type="primary"
            @click="addHList"
          >添加</el-button>
          <el-button @click="removeHList">删除</el-button>
        </el-form-item>
        <div v-if="SrvGkList.length > 0">
          <el-form-item
            v-for="item in SrvGkList"
            :key="item.count"
            :label="'MCU地址' + item.count + ':'"
          >
            <el-input
              v-model="item.RegAddr"
              :disabled="interactiveStatus"
            />
          </el-form-item>
        </div>
        <el-form-item label="SSL启用:">
          <el-select
            v-model="info.ServerSsl"
            :disabled="interactiveStatus || info.ServerType === 'GKServer'"
            placeholder="请选择"
          >
            <el-option
              v-for="item in ServerSslList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          v-if="!info.ServerSsl || info.ServerType === 'GKServer'"
          label="HTTP端口:"
          prop="HttpPort"
        >
          <el-input
            v-model.number="info.HttpPort"
            :disabled="interactiveStatus || info.ServerType === 'GKServer'"
          />
        </el-form-item>
        <el-form-item
          v-else
          label="HTTPS端口:"
          prop="HttpsPort"
        >
          <el-input
            v-model.number="info.HttpsPort"
            :disabled="interactiveStatus || info.ServerType === 'GKServer'"
          />
        </el-form-item>
        <el-form-item label="终端号码:">
          <el-input
            v-model="info.E164Num"
            :disabled="interactiveStatus"
          />
        </el-form-item>
        <el-form-item label="密码:">
          <el-input
            v-model="info.GKPwd"
            show-password
            :disabled="interactiveStatus"
          />
        </el-form-item>
        <el-form-item label="标准H323:">
          <el-select
            v-model="info.StdH323"
            :disabled="interactiveStatus"
            placeholder="请选择"
          >
            <el-option
              v-for="item in ServerSslList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-form>

      <!-- SIP配置 -->
      <el-form
        v-show="activeName === 'SIP'"
        ref="sipForm"
        :model="info"
        :rules="rules"
        label-width="150px"
        label-position="left"
      >
        <el-form-item label="注册状态:">
          <span>{{ VispRegState === 'false' ? '未连接' : '已连接' }}</span>
        </el-form-item>
        <el-form-item label="注册会议平台:">
          <el-radio
            v-model="info.SipEnable"
            :disabled="interactiveStatus"
            label="true"
          >开启</el-radio>
          <el-radio
            v-model="info.SipEnable"
            :disabled="interactiveStatus"
            label="false"
          >关闭</el-radio>
        </el-form-item>
        <el-form-item label="服务器类型:">
          <el-select
            v-model="info.SipServerType"
            placeholder="请选择"
            :disabled="interactiveStatus"
            @change="handelSipServerTypeChange"
          >
            <el-option
              v-for="item in serverTypeList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="MCU地址:" prop="SipServerAddr">
          <el-input
            v-model="info.SipServerAddr"
            :disabled="interactiveStatus"
          />
        </el-form-item>
        <el-form-item label="SSL启用:">
          <el-select
            v-model="info.SipServerSsl"
            :disabled="interactiveStatus || info.SipServerType === 'GKServer'"
            placeholder="请选择"
          >
            <el-option
              v-for="item in ServerSslList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          v-if="!info.SipServerSsl || info.SipServerType === 'GKServer'"
          label="HTTP端口:"
          prop="SipHttpPort"
        >
          <el-input
            v-model="info.SipHttpPort"
            :disabled="interactiveStatus || info.SipServerType === 'GKServer'"
          />
        </el-form-item>
        <el-form-item
          v-else
          label="HTTPS端口:"
          prop="SipHttpsPort"
        >
          <el-input
            v-model="info.SipHttpsPort"
            :disabled="interactiveStatus || info.SipServerType === 'GKServer'"
          />
        </el-form-item>
        <el-form-item label="终端号码:">
          <el-input
            v-model="info.SipE164Num"
            :disabled="interactiveStatus"
          />
        </el-form-item>
        <el-form-item label="密码:">
          <el-input
            v-model="info.SipRegPwd"
            show-password
            :disabled="interactiveStatus"
          />
        </el-form-item>
      </el-form>
      <el-button
        class="config-submit"
        type="primary"
        @click="setInfo"
      >保存</el-button>
    </div>
    <el-dialog
      :close-on-click-modal="false"
      title="高级配置"
      class="font-title-color"
      :visible.sync="advanceConfig"
    >
      <div class="paddingLeft16">
        <el-form>
          <el-form-item>
            <div class="config-stream-media flex-center">
              <label
                for=""
                class="config-title font-title-table"
              >启用端口复用:</label>
              <el-checkbox v-model="form.PortReuse" />
            </div>
            <div class="font-title-table opear-title">
              与ZOOM厂商对通要启用此功能
            </div>
          </el-form-item>
          <el-form-item>
            <div class="config-stream-media flex-center">
              <label
                for=""
                class="config-title font-title-table"
              >H225呼叫保活启用:</label>
              <el-checkbox v-model="form.H225KeepAlive" />
            </div>
            <div class="font-title-table opear-title">
              与ZOOM厂商对通要启用此功能
            </div>
          </el-form-item>
          <div class="font-title-color meet-module">会议模式</div>
          <el-form-item>
            <div class="config-stream-media flex-center">
              <label
                for=""
                class="config-title font-title-table"
              >带宽:</label>
              <el-input
                v-model="form.MBandWidth"
                type="text"
                class="border-input-default default-border-radius input-width-default"
              />
              <span class="paddingLeft16">kbps</span>
            </div>
          </el-form-item>
          <el-form-item>
            <div class="config-stream-media flex-center">
              <label
                for=""
                class="config-title font-title-table"
              >云模式:</label>
              <el-select
                v-model="form.MCloudMode"
                class="border-select-default input-width-default"
                placeholder="请选择通道号"
              >
                <el-option
                  v-for="item in MCloudModeList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </div>
          </el-form-item>
          <el-form-item>
            <div class="config-stream-media flex-center">
              <label
                for=""
                class="config-title font-title-table"
              >呼叫模式:</label>
              <el-select
                v-model="form.MCallMode"
                class="border-select-default input-width-default"
                placeholder="请选择通道号"
              >
                <el-option
                  v-for="item in MCallModeList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </div>
          </el-form-item>
          <el-form-item>
            <div class="config-stream-media flex-center">
              <label
                for=""
                class="config-title font-title-table"
              >缓冲模式:</label>
              <el-select
                v-model="form.MBufMode"
                class="border-select-default input-width-default"
                placeholder="请选择通道号"
              >
                <el-option
                  v-for="item in MBufModeList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </div>
          </el-form-item>
        </el-form>
      </div>
      <div
        slot="footer"
        class="dialog-footer"
      >
        <input
          type="button"
          class="primary default-border-radius"
          value="保存"
          @click="saveAdvanceSet"
        >
        <input
          type="button"
          class="default default-border-radius font-title-color marginLeft16"
          value="取消"
          @click="advanceConfig = false"
        >
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { validateIPOrDomain, isPort } from '@/utils/validateModule'
import store from '@/store'
import breadCrumb from '../breadCrumb/breadCrumb'
import { getSvrState } from '@/api/user'
import {
  getH323Info,
  setH323Info,
  setConfAdvanceCfg,
  getConfAdvanceCfg
} from '@/api/registManage.js'
import { getInteractList } from '@/api/interactive.js'
export default {
  components: {
    breadCrumb
  },
  data() {
    const checkIsPort = { required: true, trigger: 'change', validator: isPort }
    const checkIsIpDomain = { required: true, trigger: 'change', validator: validateIPOrDomain }
    return {
      rules: {
        ServerAddr: [checkIsIpDomain],
        SipServerAddr: [checkIsIpDomain],
        HttpPort: [checkIsPort],
        HttpsPort: [checkIsPort],
        SipHttpPort: [checkIsPort],
        SipHttpsPort: [checkIsPort]
      },
      interactiveStatus: false,
      timeout: null,
      statusTime: null,
      registerStatus: '',
      VispRegState: '',
      // H323 SIP 标签页切换
      activeName: 'H323',
      formRefs: 'h323Form',
      form: {
        MBandWidth: '',
        MCloudMode: '1',
        MCallMode: '1',
        MBufMode: '1',
        PortReuse: false,
        H225KeepAlive: false,
        IPv6Enable: false
      },
      MCloudModeList: [
        {
          value: '1',
          label: '公有云'
        },
        {
          value: '2',
          label: '私有云'
        },
        {
          value: '3',
          label: '混合云'
        },
        {
          value: '4',
          label: 'IP直连'
        }
      ],
      MCallModeList: [
        {
          value: '1',
          label: '点对点呼叫'
        },
        {
          value: '2',
          label: '点对多呼叫'
        }
      ],
      MBufModeList: [
        {
          value: '1',
          label: '质量优先'
        },
        {
          value: '2',
          label: '速度优先'
        }
      ],
      formLabelWidth: '150px',
      advanceConfig: false, // 高级配置控制
      svrLength: 0,
      SrvGkList: [],
      PriorityProtoList: [
        {
          value: 'H323',
          label: 'H323'
        },
        {
          value: 'SIP',
          label: 'SIP'
        }
      ],
      serverTypeList: [
        {
          value: 'GKServer',
          label: 'GK服务器'
        },
        {
          value: 'APSServer',
          label: '接入服务器'
        }
      ],
      // sip服务器类型
      ServerSslList: [
        {
          value: true,
          label: '是'
        },
        {
          value: false,
          label: '否'
        }
      ],
      info: {
        SipTransType: '0',
        Enable: 'true',
        E164Num: '0', // H323终端号码
        GKPwd: '', // H323 密码
        H323Alias: '', // H323 终端别名
        HttpPort: '60090', // H323 Http端口
        HttpsPort: '60090',
        PriorityProto: 'H323', // 呼叫协议
        RegSucc: 'false', // GK注册状态
        ServerAddr: '0.0.0.0', // H323Mcu地址
        ServerSsl: false, // ssl H323
        ServerType: 'GKServer', // H323服务器类型
        SipAlias: '', // Sip 终端别名
        SipE164Num: '0', // SIP终端号码
        SipEnable: 'false',
        SipHttpPort: '60090', // SIP Http端口
        SipHttpsPort: '60090',
        SipRegPwd: '', // SIP密码
        SipRegSucc: 'false', // SIP GK注册状态
        SipServerAddr: '0.0.0.0', // sipMcu地址
        SipServerSsl: false, // Sip H323
        SipServerType: 'GKServer', // sip服务器类型
        StdH323: true // 是否标准H323
      }
    }
  },
  destroyed() {
    clearTimeout(this.statusTime)
    clearTimeout(this.timeout)
  },
  mounted() {
    this.getSvrStatusInfo()
    this.getInfo()
    this.getIntervalStatus()
  },
  methods: {
    // 切换标签页
    handleTabsChange() {
      // 清除校验错误提示
      this.$refs[this.formRefs].clearValidate()
      this.formRefs = this.activeName === 'H323' ? 'h323Form' : 'sipForm'
    },
    handleServerTypeChange(val) {
      if (val === 'GKServer') { this.info.ServerSsl = false }
    },
    handelSipServerTypeChange(val) {
      if (val === 'GKServer') { this.info.SipServerSsl = false }
    },
    getSvrStatusInfo() {
      getSvrState({}).then((res) => {
        this.registerStatus = res.SvrStateResp.GkState
        this.VispRegState = res.SvrStateResp.SipGkState
        this.statusTime = setTimeout(() => {
          this.getSvrStatusInfo()
        }, 3000)
      })
    },
    getIntervalStatus() {
      const _that = this
      getInteractList({}).then((res) => {
        const interactListInfo = res.GetInteractListResp.InteractList
        if (interactListInfo === '') {
          this.interactiveStatus = false
        } else {
          if (interactListInfo.Status !== 'calling') {
            this.interactiveStatus = true
          } else {
            this.interactiveStatus = false
          }
        }
        this.timeout = setTimeout(function() {
          _that.getIntervalStatus()
        }, 2000)
      })
    },
    addHList() {
      if (this.interactiveStatus) return
      const len = this.SrvGkList.length
      if (len < 3) {
        const obj = {
          RegAddr: '',
          count: this.svrLength + 2
        }
        this.SrvGkList.push(obj)
        this.svrLength = len + 1
      }
    },
    removeHList() {
      if (this.interactiveStatus) return
      const len = this.SrvGkList.length
      if (len > 0) {
        this.SrvGkList.splice(len - 1, 1)
        this.svrLength = len - 1
      }
    },
    advanceSet() {
      if (this.interactiveStatus) return
      getConfAdvanceCfg({}).then((res) => {
        this.form = res.GetConfAdvanceCfgResp
        this.form.PortReuse = this.form.PortReuse !== 'false'
        this.form.H225KeepAlive = this.form.H225KeepAlive !== 'false'
        this.form.IPv6Enable = this.form.IPv6Enable !== 'false'
      })
      this.advanceConfig = true
    },
    saveAdvanceSet() {
      var param = {
        SetConfAdvanceCfgReq: this.form
      }
      setConfAdvanceCfg(param).then((res) => {
        this.advanceConfig = false
      })
    },
    getInfo() {
      getH323Info({}).then((res) => {
        this.info = res.GetH323StatusResp
        this.info.ServerSsl = this.info.ServerSsl === 'true'
        this.info.SipServerSsl = this.info.SipServerSsl === 'true'
        this.info.StdH323 = this.info.StdH323 === 'true'
        this.SrvGkList = []
        if (Array.isArray(this.info.SrvGkList.SrvGkItem)) {
          this.info.SrvGkList.SrvGkItem.forEach((item, index) => {
            item.count = index + 2
            this.SrvGkList.push(item)
          })
        } else {
          this.SrvGkList.push(this.info.SrvGkList.SrvGkItem)
        }
      })
    },
    setInfo() {
      if (this.interactiveStatus) return
      this.$refs[this.formRefs].validate((valid) => {
        if (valid) {
          const len = this.SrvGkList.length
          let szXml = '<contentroot>'
          szXml += '<authenticationinfo type="7.0">'
          szXml += '<username>' + store.getters.username + '</username>'
          szXml += '<password>' + store.getters.password + '</password>'
          szXml +=
            '<authenticationid>' + store.getters.authId + '</authenticationid>'
          szXml += '</authenticationinfo>'
          szXml += '<SetH323InfoReq>'
          szXml += '<SipTransType>' + this.info.SipTransType + '</SipTransType>'
          szXml += '<Enable>' + this.info.Enable + '</Enable>'
          szXml += '<ServerType>' + this.info.ServerType + '</ServerType>'
          szXml += '<ServerAddr>' + this.info.ServerAddr + '</ServerAddr>'
          szXml += '<HttpPort>' + this.info.HttpPort + '</HttpPort>'
          szXml += '<H323Alias>' + this.info.H323Alias + '</H323Alias>'
          szXml += '<E164Num>' + this.info.E164Num + '</E164Num>'
          szXml += '<IpAddr></IpAddr>'
          szXml += '<GKPwd>' + this.info.GKPwd + '</GKPwd>'
          szXml += '<StdH323>' + this.info.StdH323 + '</StdH323>'
          szXml += '<SrvGkList>'
          for (let i = 0; i < len; i++) {
            szXml += '<SrvGkItem><RegAddr>' + this.SrvGkList[i].RegAddr + '</RegAddr></SrvGkItem>'
          }
          szXml += '</SrvGkList>'
          szXml += '<PortReuse></PortReuse>'
          szXml += '<ServerSsl>' + this.info.ServerSsl + '</ServerSsl>'
          szXml += '<HttpsPort>' + this.info.HttpsPort + '</HttpsPort>'
          szXml += '<SipEnable>' + this.info.SipEnable + '</SipEnable>'
          szXml +=
            '<SipServerType>' + this.info.SipServerType + '</SipServerType>'
          szXml +=
            '<SipServerAddr>' + this.info.SipServerAddr + '</SipServerAddr>'
          szXml += '<SipHttpPort>' + this.info.SipHttpPort + '</SipHttpPort>'
          szXml += '<SipAlias>' + this.info.H323Alias + '</SipAlias>'
          szXml += '<SipE164Num>' + this.info.SipE164Num + '</SipE164Num>'
          szXml += '<SipIpAddr></SipIpAddr>'
          szXml += '<SipRegPwd>' + this.info.SipRegPwd + '</SipRegPwd>'
          szXml += '<SipServerSsl>' + this.info.SipServerSsl + '</SipServerSsl>'
          szXml += '<SipHttpsPort>' + this.info.SipHttpsPort + '</SipHttpsPort>'
          szXml +=
            '<PriorityProto>' + this.info.PriorityProto + '</PriorityProto>'
          szXml += '</SetH323InfoReq>'
          szXml += '</contentroot>'
          setH323Info(szXml).then((res) => {
            getSvrState({}).then((res) => {
              this.registerStatus = res.SvrStateResp.GkState
              this.VispRegState = res.SvrStateResp.SipGkState
            })
            this.SrvGkList = []
            this.$message({
              message: '保存成功',
              type: 'success'
            })
            this.getInfo()
          })
        }
      })
    }
  }
}
</script>
<style lang="scss">
.meet-platform-content {
  padding-top: 8px;

  .el-tabs {
    width: 614px;
  }

  // 表单内input select等组件
  .el-input,.el-select {
    width: 312px;
  }

  // 表单内按钮
  .el-form-item .el-button {
    margin-left: 16px;
  }

  // 提交按钮
  .config-submit {
    margin-left: 150px;
  }

  .config-stream-media {
    justify-content: flex-start;
    padding: 4px 0px;

    .config-title {
      width: 150px;
      font-size: 14px;
      color: rgba(255, 255, 255, 0.85);
      font-weight: normal;
    }
  }
}
.el-dialog__wrapper {
  .el-dialog {
    width: 568px;
    .meet-module {
      padding: 16px 0;
      font-size: 16px;
    }
    .opear-title {
      padding: 8px 0 24px 16px;
    }
    .config-stream-media {
      padding: 8px 0px;
      .config-title {
        width: 150px;
        font-size: 14px;
        color: rgba(255, 255, 255, 0.85);
        font-weight: normal;
      }
    }
  }
}
</style>
