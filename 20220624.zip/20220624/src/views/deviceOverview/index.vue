<template>
  <section class="dev-overview-p">
    <div class="dev-overview-title">设备信息</div>
    <div class="dev-overview-main">
      <div class="dev-overview-card">
        <dev-infos :device-info="deviceInfo" />
      </div>
      <div class="dev-overview-card">
        <service-status :service-data="serviceData" />
      </div>
      <div class="dev-overview-card">
        <div class="card-title">当前状态</div>
        <current-status :current-state="currentState" />
      </div>
      <div class="dev-overview-card">
        <div class="card-title">版本信息</div>
        <version-info :device-info="versionInfo" :version="Version" />
      </div>
    </div>
  </section>
</template>
<script>
import DevInfos from './components/devInfos.vue'
import ServiceStatus from './components/serviceStatus.vue'
import VersionInfo from './components/versionInfo.vue'
import CurrentStatus from './components/currentStatus'
import { getVersionInfo, getSvrState } from '@/api/deviceInfo'
import { getDevModel } from '@/api/systemConfig'
export default {
  components: {
    DevInfos,
    ServiceStatus,
    VersionInfo,
    CurrentStatus
  },
  data() {
    return {
      deviceInfo: {
        AppSceneAlias: '',
        Mp4RecState: '',
        InteractState: '',
        SysUptime: ''
      },

      serviceData: {
        // 流媒体服务器
        SmssState: '',
        // 监控平台
        VispRegState: '',
        // 会议平台
        GkState: '',
        // SIP平台
        Gb28181State: ''
      },

      Version: '',
      versionInfo: {
        DevSoftVer: '',
        DevMakeDate: '',
        DevSerialNum: '',
        DevType: ''
      },

      currentState: {
        // 硬盘总容量,单位GB
        DiskCap: '',
        // 硬盘空闲率,百分比
        DiskFree: '',
        // cpu占用率,百分比
        CpuUsed: '',
        // 内存占用率,百分比
        MemUsed: ''
      },
      deviceOverTime: null,
    }
  },
  mounted() {
    getVersionInfo().then(res => {
      if (res) {
        getDevModel().then(resp => {
           if(resp.GetDevModelResp.Enable == 'true') {
             if(resp.GetDevModelResp.DevModel != '') {
               res.GetSysDevInfoResp.DevType = resp.GetDevModelResp.DevModel
             }
           }
           this.formatData(res.GetSysDevInfoResp, this.versionInfo)
        })
      }
    })
    this.initDeviceOverView()
  },
  destroyed() {
    clearTimeout(this.deviceOverTime)
  },
  methods: {
    formatData(data, target) {
      for (const key in target) {
        target[key] = data[key]
      }
    },
    initDeviceOverView() {
      clearTimeout(this.deviceOverTime)
      getSvrState().then(res => {
        this.formatData(res.SvrStateResp, this.deviceInfo)
        this.formatData(res.SvrStateResp, this.currentState)
        this.formatData(res.SvrStateResp, this.serviceData)
        this.Version = res.SvrStateResp.Version
        this.deviceOverTime = setTimeout(() => {
          this.initDeviceOverView()
        },1000)
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.dev-overview-p {
  height: 100%;
  padding: 16px;
  background-color: #1d222c;
}
.dev-overview-title {
  font-size: 18px;
}
.dev-overview-main {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  height: calc(100% - 32px - 20px);
}

.dev-overview-card {
  width: calc(50% - 8px);
  height: 50%;
  margin-top: 16px;
  padding: 24px 32px;
  background-color: #2A313E;
  border-radius: 18px;
}

.card-title {
  height: 32px;
  margin-bottom: 24px;
  font-size: 24px;
  color: #fff;
  line-height: 32px;
}
</style>
