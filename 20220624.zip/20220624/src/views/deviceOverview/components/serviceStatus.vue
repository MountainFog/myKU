<template>
  <div class="service-status">
    <div class="service-status-title">服务器连接状态</div>
    <div class="roll-func">
      <span class="roll-func-left" @click="rollLeft" />
      <span class="roll-func-right" @click="rollRight" />
    </div>
    <div ref="serviceWrap" class="service-status-wrap" :style="{transform: `translateX(${translateX}%)`}">
      <div v-if="$store.getters.devType.indexOf('SVR2730') > -1" class="service-status-item">
        <div class="service-name">流媒体服务器</div>
        <div :class="['service-icon', (smssState ? '' : 'service-icon__err')]" />
        <div class="service-state">{{ `${smssState ? '已' : '未'}连接` }}</div>
      </div>
      <div v-if="$store.getters.devType.indexOf('SVR2730') > -1" class="service-status-item">
        <div class="service-name">监控平台</div>
        <div :class="['service-icon', vispRegState ? '' : 'service-icon__err']" />
        <div class="service-state">{{ `${vispRegState ? '已' : '未'}连接` }}</div>
      </div>
      <div v-if="$store.getters.devType.indexOf('-V') > -1" class="service-status-item">
        <div class="service-name">会议平台 </div>
        <div :class="['service-icon', gkState ? '' : 'service-icon__err']" />
        <div class="service-state">{{ `${gkState ? '已' : '未'}连接` }}</div>
      </div>
      <div class="service-status-item">
        <div class="service-name">SIP平台</div>
        <div :class="['service-icon', gb28181State ? '' : 'service-icon__err']" />
        <div class="service-state">{{ `${gb28181State ? '已' : '未'}连接` }}</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    serviceData: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      index: 0
    }
  },
  computed: {
    // 流媒体服务器
    smssState() {
      return this.serviceData.SmssState === 'true'
    },
    // 监控平台
    vispRegState() {
      return this.serviceData.VispRegState === 'true'
    },
    // 会议平台
    gkState() {
      return this.serviceData.GkState === 'true'
    },
    // SIP平台
    gb28181State() {
      return this.serviceData.Gb28181State === 'true'
    },
    translateX() {
      return 25 * this.index
    }
  },
  methods: {
    // 左滚
    rollLeft() {
      this.index--
      if (this.index < 0) {
        this.index = 0
      }
    },
    // 右滚
    rollRight() {
      this.index++
      if (this.index > 0) {
        this.index = 0
      }
    }
  }
}
</script>
<style lang="scss">
.service-status {
  position: relative;
  height: 100%;
  overflow: hidden;

  // 标题
  &-title {
    height: 32px;
    line-height: 32px;
    color: #fff;
    font-size: 24px;
  }

  // 滚动触发按钮组
  .roll-func {
    position: absolute;
    top: 8px;
    right: 30px;
    border-radius: 2px;
    border: 1px solid #4c5360;

    span {
      display: inline-block;
      width: 16px;
      height: 16px;
      margin: 4px 12px 0;
      background: url("~@/assets/img/roll_arrow.png") no-repeat;
      cursor: pointer;
    }

    &-left {
      transform: rotate(180deg);
    }
  }

  // 列表容器
  &-wrap {
    display: flex;
    flex-wrap: nowrap;
    // title + margin-top = 64px
    height: calc(100% - 64px);
    // height: 100%;
    margin-top: 24px;
    transition: 0.5s all;
  }

  &-item {
    display: flex;
    flex-shrink: 0;
    flex-direction: column;
    justify-content: space-evenly;
    align-items: center;
    width: calc(25% - 18px);
    height: 100%;
    margin-right: 24px;
    padding: 24px 0;
    background-color: #1d222c;
    border-radius: 10px;
    text-align: center;

    // 服务器名称
    .service-name {
      font-size: 18px;
      color: #fff;
    }

    // 服务器状态图标
    .service-icon {
      width: 48px;
      height: 48px;
      background-image: url(~@/assets/img/service_connet.png);
      background-repeat: no-repeat;
      background-size: cover;
    }

    .service-icon__err {
      background-image: url(~@/assets/img/service_notconnet.png);
    }

    // 服务器状态
    .service-state {
      font-size: 16px;
      color: $-fff-65;
    }
  }

  // 滚动条样式
  .el-scrollbar {
    // height: calc(100% - 64px);
    height: 100%;
  }

  .el-scrollbar__wrap {
    overflow-x: hidden;
  }

  .el-scrollbar__view {
    display: flex;
    height: 100%;
  }

  .el-scrollbar__bar.is-vertical {
    display: none;
  }
}
</style>
