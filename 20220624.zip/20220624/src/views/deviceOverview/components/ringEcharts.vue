<template>
  <div class="ring-echarts">
    <div class="echarts-title">{{ name }}</div>
    <div :id="id" class="echarts-wrap" />
  </div>
</template>
<script>
const echarts = require('echarts')
export default {
  props: {
    name: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    },
    value: {
      type: Number,
      default: 0
    },
    color: {
      type: String,
      default: 'rgba(60, 70, 88, 1)'
    },
    id: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    value() {
      this.initCharts()
    }
  },
  mounted() {
    this.initCharts()
  },
  methods: {
    initCharts() {
      if (!this.chart) {
        this.chart = echarts.init(document.getElementById(this.id))
      }
      this.chart.setOption({
        title: {
          text: this.title,
          left: 'center',
          top: 'center',
          textStyle: {
            color: 'rgb(255, 255, 255, 0.65)',
            fontSize: 28,
            align: 'center'
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'],
            radius: ['70%', '90%'],
            itemStyle: {
              color: 'rgba(60, 70, 88, 1)'
            },
            labelLine: {
              show: false
            },
            silent: true,
            data: [0, 100]
          },
          {
            type: 'pie',
            center: ['50%', '50%'],
            radius: ['70%', '90%'],
            labelLine: {
              show: false
            },
            emphasis: {
              scale: false
            },
            data: [
              {
                value: this.value,
                itemStyle: {
                  color: this.color,
                  borderRadius: '50%'
                }
              },
              {
                value: (100 - this.value),
                itemStyle: {
                  color: 'transparent'
                }
              }
            ]
          }
        ]
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.ring-echarts {
  height: 100%;

  .echarts-title {
    color: #fff;
    font-size: 20px;
    text-align: center;
  }

  .echarts-wrap {
    height: 100%;
  }
}
</style>
