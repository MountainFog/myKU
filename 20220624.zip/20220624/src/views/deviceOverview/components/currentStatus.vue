<template>
  <div class="current-status">
    <div class="status-item">
      <myCharts :id="'echartsCpu'" :color="'rgba(116, 95, 252, 1)'" :value="cpuUsed" :name="'CPU'" :title="`${cpuUsed}%`" />
    </div>
    <div class="status-item">
      <myCharts :id="'echartsMem'" :color="'rgba(133, 198, 127, 1)'" :value="memUsed" :name="'内存'" :title="`${memUsed}%`" />
    </div>
    <div class="status-item">
      <myCharts :id="'echartsDisk'" :color="'rgba(250, 117, 76, 1)'" :value="diskUsed" :name="'硬盘'" :title="diskSituate" />
    </div>
  </div>
</template>
<script>
import myCharts from './ringEcharts.vue'
export default {
  components: {
    myCharts
  },
  props: {
    currentState: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      cpuUsed: 0,
      memUsed: 0,
      diskUsed: 0,
      diskSituate: ''
    }
  },
  watch: {
    currentState: {
      deep: true,
      handler() {
        this.extractData()
      }
    }
  },
  created() {
    this.extractData()
  },
  methods: {
    extractData() {
      const diskCap = this.currentState.DiskCap
      this.cpuUsed = Number(this.currentState.CpuUsed)
      this.memUsed = Number(this.currentState.MemUsed)
      this.diskUsed = Number(diskCap) ? 100 - Number(this.currentState.DiskFree) : 0
      let used = diskCap * (this.diskUsed / 100)
      used = used > 1024 ? `${(used / 1024).toFixed(1)}T` : used.toFixed(1) + 'G'
      this.diskSituate = `${used}/${(diskCap / 1024).toFixed(1)}T`
    }
  }
}
</script>
<style lang="scss" scoped>
.current-status {
  display: flex;
  height: calc(100% - 56px);

  .status-item {
    width: 33%;
    height: 100%;
  }
}
</style>
