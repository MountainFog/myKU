<template>
  <div class="version-info">
    <table width="100%">
      <tr>
        <td>设备型号：</td>
        <td>{{ deviceInfo.DevType }}</td>
      </tr>
      <tr>
        <td>设备序列号：</td>
        <td>{{ deviceInfo.DevSerialNum }}</td>
      </tr>
      <tr>
        <td>设备生产日期：</td>
        <td>{{ deviceInfo.DevMakeDate }}</td>
      </tr>
      <tr>
        <td>业务软件版本号：</td>
        <td>
          <el-tooltip effect="dark" :content="`${version}(${deviceInfo.DevSoftVer})`" placement="top">
            <span>
              {{ `${version}(${deviceInfo.DevSoftVer})` }}
            </span>
          </el-tooltip>
        </td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  filters: {
    formatDate(date) {
      const dateObject = new Date(date)
      const year = dateObject.getFullYear()
      const month = dateObject.getMonth()
      const day = dateObject.getDay()
      return `${year} ${month < 10 ? '0' + month : month} ${day < 10 ? '0' + day : day}`
    }
  },
  props: {
    // 设备信息
    deviceInfo: {
      type: Object,
      default() {
        return {}
      }
    },
    // 版本号
    version: {
      type: String,
      default: ''
    }
  },
  watch: {
    deviceInfo: {
      deep: true,
      handler(nv) {
        document.title = '设备概览 ' + nv.DevType
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.version-info {
  height: calc(100% - 56px);

  table {
    table-layout:fixed;
    height: 100%;
  }

  tr:nth-child(odd) {
    background-color: #252C37;
  }

  tr:nth-child(even) {
    background-color: #2E3644;
  }

  td {
    padding-left: 24px;
    font-size: 18px;
    color: $-fff-65;
    vertical-align:middle;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
  }

  tr td:first-child {
    width: 168px;
  }
}
</style>
