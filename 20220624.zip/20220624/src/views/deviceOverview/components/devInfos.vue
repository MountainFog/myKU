<template>
  <div class="dev-info">
    <div class="dev-info-head">
      <div class="dev-info-icon" />
      <div class="dev-info-text">
        <div class="text__name">{{ devName }}</div>
        <div class="text__ip">IP：{{ ip }}</div>
      </div>
      <el-button
        type="primary"
        @click="dormancy"
      >休眠</el-button>
    </div>
    <div class="dev-info-wrap">
      <table width="100%">
        <tr>
          <th>应用场景</th>
          <th>录制状态</th>
          <th>互动状态</th>
          <th>系统运行时间</th>
        </tr>
        <tr>
          <td>{{ deviceInfo.AppSceneAlias }}</td>
          <td :class="recordState">{{ filterRecord(deviceInfo.Mp4RecState) }}</td>
          <td :class="deviceInfo.InteractState === 'true' ? 'status__red' : 'status__green'">{{ deviceInfo.InteractState === 'true' ? '互动中' : '空闲' }}</td>
          <td>{{ deviceInfo.SysUptime | filterDuration }}</td>
        </tr>
      </table>
    </div>
  </div>
</template>
<script>
import { setSysSleep } from '@/api/deviceInfo'
import { getSysBasicInfo } from '@/api/systemConfig'
export default {
  filters: {
    filterDuration(seconds) {
      const h = Math.floor(seconds / 3600)
      const min = Math.floor((seconds / 60) % 60)
      return `${h}小 时 ${min}分`
    }
  },
  props: {
    deviceInfo: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      // 状态图标
      recordState: '',
      // 设备名称
      devName: ''
    }
  },
  computed: {
    ip() {
      return location.hostname
    }
  },
  mounted() {
    getSysBasicInfo().then(res => {
      this.devName = res.GetSysBasicInfoResp.DevName
    })
  },
  methods: {
    dormancy() {
      this.$confirm('是否休眠?', '提示', {
        confirmButtonText: '是',
        cancelButtonText: '否',
        type: 'warning'
      }).then(() => {
        const loading = this.$loading({
          lock: true,
          text: 'Loading',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        })
        setSysSleep()
          .then(() => {
            loading.close()
          })
          .catch(() => {
            loading.close()
          })
      }).catch(() => {})
    },
    filterRecord(data) {
      switch (data) {
        case 'recording':
          this.recordState = 'status__red'
          return '录制中'

        case 'abort':
          this.recordState = ''
          return '异常关闭'

        case 'normal':
          this.recordState = 'status__green'
          return '空闲'

        case 'pause':
          this.recordState = 'status__yellow'
          return '暂停'

        default:
          this.recordState = ''
          return ''
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.dev-info {
  height: 100%;

  &-head {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .el-button {
      width: 88px;
      height: 32px;
      padding: 0;
      border-radius: 2px;
      font-size: 14px;
      line-height: 32px;
    }
  }

  &-text {
    flex-grow: 1;
    height: 64px;
    padding-left: 16px;

    .text__name {
      margin: 8px 0;
      font-size: 28px;
      color: #ffffff;
    }

    .text__ip {
      font-size: 16px;
      color: $-fff-65;
    }
  }

  &-icon {
    width: 64px;
    height: 64px;
    background-image: url(~@/assets/img/dev_icon.png);
    border-radius: 16px;
    background-size: 100%;
  }

  &-wrap {
    display: flex;
    align-items: center;
    // dev-info-head + margin-top = 80px
    height: calc(100% - 80px);
    margin-top: 16px;
    padding: 16px;
    background-color: rgba(0, 0, 0, 0.35);
    border-radius: 8px;

    table {
      height: 128px;
    }

    th {
      color: $-fff-65;
      font-size: 14px;
      font-weight: normal;
      vertical-align: middle;
    }

    td {
      color: #ffffff;
      font-size: 18px;
      text-align: center;
      vertical-align: middle;
    }

    .status__yellow::before {
      content: "";
      display: inline-block;
      margin-right: 8px;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background-color: #FAA23A;
    }

    .status__red::before {
      content: "";
      display: inline-block;
      margin-right: 8px;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background-color: #EE4F4F;
    }

    .status__green::before {
      content: "";
      display: inline-block;
      margin-right: 8px;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background-color: #36D228;
    }
  }
  .el-button.btn__green {
    background-color: #36D228;
    border-color: #36D228;
    // color: #36D228;
    // background: #eaf9f1;
    // border-color: #36D228;
  }
}
</style>
