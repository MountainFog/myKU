<template>
  <div class="tab-item-define">
    <div class="tab-item-list">
      <div class="tab-item font-title-table" :class="{active: tabActive == index}" @click="tabChose(index,item)" v-for="(item,index) in tabList" :key="index"> {{ item.name }} <i class="icon-bottom-line"></i></div>
      <!-- <router-link class="tab-item font-title-table" :class="{active: tabActive == index}" @click="tabChose(index,item)" v-for="(item,index) in tabList" :key="index"> {{ item.name }} <i class="icon-bottom-line"></i></router-link> -->
    </div>
  </div>
</template>

<script>
export default {
  data(){
    return {
      tabActive:0
    }
  },
  props:{
    tabList:{
      type: Array,
      default: []
    }
  },
  methods:{
    tabChose(index,item){
      this.tabActive = index
      this.$emit('active',item)
    }
  }
}
</script>

<style scoped="scoped" lang="scss">
.tab-item-define {
  height: 72px;
  .tab-item-list {
    display: flex;
    padding-top: 30px;
    padding-bottom: 16px;
    border-bottom: 1px solid rgba(216,222,234,0.20);
    .tab-item {
      font-size: 18px;
      line-height: 25px;
      padding: 0px 16px;
      position: relative;
      cursor: pointer;
      .icon-bottom-line {
        position:absolute;
        display: inline-block;
        width: 100%;
        border-bottom: 3px solid transparent;
        left: 0px;
        top: 40px;
      }
    }
    .tab-item+.tab-item {
      margin-left: 40px;
    }
    .active {
      color: #3884FF !important;
      .icon-bottom-line {
        border-color: #1F75FF;
      }
    }
  }
}
</style>
