<template>
  <div class="net-work-caught">
    <el-form
      ref="caughtForm"
      :model="form"
      :rules="rules"
      label-width="150px"
      label-position="left"
    >
      <el-form-item label="抓包网口:">
        <el-select v-model="form.NetAdapterIDs" placeholder="请选择">
          <el-option
            v-for="item in caughtSoList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="数据包类型:">
        <el-select v-model="form.Filter" placeholder="请选择">
          <el-option
            v-for="item in packageTypeList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="地址筛选:" prop="Ip">
        <el-input v-model="form.Ip" />
      </el-form-item>
      <el-form-item label="端口筛选:">
        <el-input v-model="form.Port" />
      </el-form-item>
      <el-form-item label="">
        <el-button v-show="showStartCautch" @click="startCatch">开始抓包</el-button>
        <el-button v-show="!showStartCautch" @click="stopCatch">停止抓包</el-button>
        <el-button @click="downCatch">下载抓包</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import { formatParams, xmlStr2XmlObj } from '@/utils/dataParse'
import { captureStart, captureStop, captureState, getLoad } from '@/api/systemConfig.js'
import axios from 'axios'
import { validateIP } from '@/utils/validateModule'
export default {
  data() {
    const checkAddress = (rule, value, callback) => {
      if (value === '0') {
        callback()
        return
      }
      validateIP(rule, value, callback)
    }
    return {
      showStartCautch: true,
      caughtSoList: [{ label: '全部', value: 'any' }, { label: 'LAN1', value: 'eth0' }],
      packageTypeList: [
        {
          value: 'NoFilter',
          label: '全部'
        },
        {
          value: 'TCP',
          label: 'TCP'
        },
        {
          value: 'UDP',
          label: 'UDP'
        }
      ],
      form: {
        NetAdapterIDs: 'eth0',
        InterFaceList: {
          P_R_O_P: {
            num: 0
          },
          V_A_L_U_E: 'InterFaceList'
        },
        Filter: 'NoFilter',
        Port: '1-65535',
        Ip: '0'
      },
      rules: {
        Ip: [{ validator: checkAddress, message: 'IP格式错误', trigger: 'blur' }]
      },
      packageName: '',
      timer: null
    }
  },
  created() {
    // 查询抓包状态 控制按钮显示/隐藏
    captureState({}).then(res => {
      if (res.CaptureStateResp.Capture === 'true') {
        this.showStartCautch = false
      } else {
        this.stopCatch()
      }
    })
  },
  destroyed() {
    clearTimeout(this.timer)
  },
  methods: {
    // 获取网卡列表
    getInterFaceList() {
      axios.post(`/nvrcgi/network/GetAllInterFaceParam`, formatParams({})).then(res => {
        const xmlDoc = xmlStr2XmlObj(res.data).childNodes[0].childNodes[0].childNodes
        xmlDoc.forEach(item => {
          const node = item.childNodes[0]
          const label = node.attributes.alias.value === 'ALL' ? '全部' : node.attributes.alias.value
          this.caughtSoList.unshift({
            value: node.innerHTML,
            label
          })
        })
      })
    },
    // 深度克隆
    deepClone(obj) {
      const objClone = Array.isArray(obj) ? [] : {}
      if (obj && typeof obj === 'object') {
        for (const key in obj) {
          if (obj[key] && typeof obj[key] === 'object') {
            objClone[key] = this.deepClone(obj[key])
          } else {
            objClone[key] = obj[key]
          }
        }
      }
      return objClone
    },
    // 开始抓包
    startCatch() {
      this.$refs.caughtForm.validate((valid) => {
        if (valid) {
          const capture = this.deepClone(this.form)
          capture.InterFaceList = `<InterFace><Name>${capture.NetAdapterIDs}</Name></InterFace>`
          delete capture.NetAdapterIDs
          if (capture.Ip === '0') {
            delete capture.Ip
          }
          var param = {
            CaptureStartReq: capture
          }
          captureStart(param).then(res => {
            this.showStartCautch = false
            this.getCaptureState()
          })
        }
      })
    },
    // 抓包状态
    getCaptureState() {
      captureState({}).then(res => {
        if (res.CaptureStateResp.Capture === 'true') {
          this.timer = setTimeout(() => {
            this.getCaptureState()
          }, 1000)
        }
      })
    },
    // 停止抓包
    stopCatch() {
      clearTimeout(this.timer)
      captureStop({}).then(res => {
        this.showStartCautch = true
        this.packageName = res.CaptureStopResp.FileName
      })
    },
    // 下载抓包
    downCatch() {
      if (this.showStartCautch) {
        this.getPcap()
      } else {
        this.$message({
          type: 'warning',
          message: '正在抓包中，请先停止抓包'
        })
      }
    },
    // 获取包文件名
    getPcap() {
      if (!this.packageName) {
        this.$message({
          type: 'warning',
          message: '无包'
        })
        return
      }
      getLoad(this.packageName).then(_ => {
        // 执行下载动作
        const alink = document.createElement('a')
        alink.style.display = 'none'
        alink.setAttribute('download', '')
        alink.href = '/netpack/' + this.packageName
        alink.click()
      }).catch(_ => {})
    }
  }
}
</script>

<style lang="scss">
.net-work-caught {
  .el-input {
    width: 312px;
  }
}
</style>
