<template>
  <div class="net-work-test">
    <div class="">
      <el-form ref="netTestForm" :rules="rules" :model="form" label-width="150px" label-position="left">
        <el-form-item label="探测目录:">
          <el-select v-model="form.NvrChnID" placeholder="请选择" @change="changeChn">
            <el-option
              v-for="item in networkDirList"
              :key="item.ChnID"
              :label="labelItem(item)"
              :value="item.ChnID"
            />
          </el-select>
          <span class="paddingLeft16" />
          <el-input v-show="form.NvrChnID == 'DestAddr'" v-model="destAddr" />
        </el-form-item>
        <el-form-item label="探测包长度:" prop="Mtu">
          <el-input v-model.number="form.Mtu" type="text" />
          <span class="paddingLeft16 font-title-table">0-65500</span>
        </el-form-item>
        <el-form-item label="探测次数:" prop="Times">
          <el-input v-model.number="form.Times" type="text" />
          <span class="paddingLeft16 font-title-table">1-254</span>
        </el-form-item>
        <el-form-item label="超时时长:" prop="TimeOut">
          <el-input v-model.number="form.TimeOut" type="text" />
          <span class="paddingLeft16 font-title-table">1-254(秒)</span>
        </el-form-item>
        <el-form-item label="">
          <el-button v-show="detectionStatus" :loading="loading" @click="startDetect">开始探测</el-button>
          <el-button v-show="!detectionStatus" @click="stopDetect">停止探测</el-button>
        </el-form-item>
        <el-form-item label="探测结果:">
          <div class="results-wrap">
            <div v-show="pingResult.length > 0">
              <div v-if="pingResult.length > 0" class="ping-label">ping <span>{{ showPingRes }}</span></div>
              <div v-for="(item,index) in pingResult" :key="index" class="font-title">
                <span class="font-title-table">ping结果:</span>
                <span class="font-title-table paddingLeft4"><span v-if="item.Package">目的主机</span>{{ item.Reply == 'Reply' ? '正常回复' : (item.Reply == 'Timeout' ? '超时' : (item.Reply == 'Error' ? '错误' : '网络不可达' ) ) }}</span>
                <span v-if="item.Package" class="font-title-table paddingLeft4">字节={{ item.Package }}</span>
                <span v-if="item.Delay" class="font-title-table paddingLeft4">时间={{ item.Delay }}(ms)</span>
                <span v-if="item.TTL" class="font-title-table paddingLeft4">TTL={{ item.TTL }}</span>
              </div>
            </div>
          </div>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import { startPing, getPingResult, stopPing } from '@/api/systemConfig.js'
export default {
  data() {
    return {
      rules: {
        Mtu: [{ max: 65500, min: 0, type: 'number', message: '间隔不在要求范围之内', trigger: 'blur' }],
        Times: [{ max: 254, min: 1, type: 'number', message: '间隔不在要求范围之内', trigger: 'blur' }],
        TimeOut: [{ max: 254, min: 1, type: 'number', message: '间隔不在要求范围之内', trigger: 'blur' }]
      },
      networkDir: '',
      networkDirList: [],
      pingResult: [],
      form: {
        Mtu: 32,
        Times: 4,
        TimeOut: 1,
        NvrChnID: ''
      },
      detectionStatus: true,
      compositeSum: 0,
      capSum: 0,
      nvrList: [],
      SvrChnItem: [],
      destAddr: '',
      choseStatus: '下线',
      // 轮询探测定时器
      timer: null,
      // 当前探测任务ID
      currentTaskId: '',
      // 探测中
      loading: false
    }
  },
  computed: {
    labelItem() {
      return function(item) {
        let result
        if (item.ChnID == 'DestAddr') {
          result = '自定义'
        } else {
          result = 'D' + item.ChnID + ' ' + item.svrChnAlias + ' ' + item.ChnState
        }
        return result
      }
    },
    showPingRes() {
      if (this.form.NvrChnID == 'DestAddr') {
        return this.destAddr
      } else {
        var item = this.networkDirList.find(item => item.ChnID == this.form.NvrChnID)
        return 'D' + item.ChnID + ' ' + item.svrChnAlias + ' ' + '(' + item.ChnState + ')'
      }
    }
  },
  created() {
    this.getCap()
  },
  destroyed() {
    clearTimeout(this.timer)
  },
  methods: {
    changeChn(val) {
      const index = this.networkDirList.findIndex(item => item.ChnID == val)
      this.choseStatus = this.networkDirList[index].ChnState
    },
    startDetect() {
      if (this.choseStatus === '空闲') {
        this.$message({
          type: 'warning',
          message: '空闲状态的探测目录，无法完成探测'
        })
        return
      }
      this.$refs.netTestForm.validate((valid) => {
        if (valid) {
          this.pingResult = []
          let param
          if (this.form.NvrChnID == 'DestAddr') {
            param = {
              PingStartReq: {
                DestIP: this.destAddr,
                Mtu: this.form.Mtu,
                Times: this.form.Times,
                TimeOut: this.form.TimeOut
              }
            }
          } else {
            param = {
              PingStartReq: this.form
            }
          }
          this.loading = true
          startPing(param).then(res => {
            this.detectionStatus = false
            this.currentTaskId = res.PingStartResp.TaskID
            this.getPing(this.currentTaskId)
          }).catch(() => {
            this.loading = false
          })
        }
      })
    },
    getPing(id) {
      getPingResult(id).then(res => {
        clearTimeout(this.timer)
        if (res.PingResultResp.ResultList) {
          const result = res.PingResultResp.ResultList.Result
          if (Array.isArray(result)) {
            this.pingResult.push(...result)
          } else {
            this.pingResult.push(result)
          }
        }
        if (res.PingResultResp.Finished === 'false') {
          // 未完全获取
          this.timer = setTimeout(() => {
            this.getPing(id)
          }, 1000)
        } else {
          // 完全获取
          this.stopDetect()
        }
      }).catch(_ => {
        clearTimeout(this.timer)
        this.stopDetect()
      })
    },
    stopDetect() {
      this.detectionStatus = true
      clearTimeout(this.timer)
      stopPing(this.currentTaskId).then(() => {
        this.loading = false
        this.currentTaskId = ''
      }).catch(() => {
        this.currentTaskId = ''
        this.loading = false
      })
    },
    async getCompositeCap() {
      await this.$store.dispatch('channelManage/getCompositeChnCap', {}).then(res => {
        this.compositeSum = res.GetCompositeChnCapResp.ChnList.Chn.length
      })
    },
    getCap() {
      this.$store.dispatch('channelManage/getSrvCap', {}).then(async res => {
        await this.getCompositeCap()
        this.capSum = Number(res.capinfo.GroupNum) - this.compositeSum
        await this.getNvrListC(Number(res.capinfo.GroupNum))
        await this.getSvrChn()
      })
    },
    async getNvrListC(subNum) {
      var param = {
        GetNvrChnListReq: {
          ChnIDStart: 1,
          ChnIDEnd: subNum,
          NeedMask: {
            ChnAlias: true,
            DevSrcID: true,
            ChnState: true,
            DevInfo: true,
            ChnDevCfg: false
          }
        }
      }
      await this.$store.dispatch('channelManage/getNvrChnList', param).then(res => {
        this.nvrList = res.GetNvrChnListResp.ChnList.ChnInfo
      })
    },
    async getSvrChn() {
      await this.$store.dispatch('channelManage/getSvrChnList', {}).then(res => {
        var scrchnItem = res.GetSvrChnListResp.SvrChnItemList.SvrChnItem
        if (Array.isArray(scrchnItem)) {
          this.SvrChnItem = scrchnItem
        } else {
          this.SvrChnItem.push(scrchnItem)
        }
        this.networkDirList = []
        this.SvrChnItem.forEach((val, index) => {
          if (Number(val.NvrChnId) <= this.capSum) {
            this.DevInfo = {
              svrList: {},
              svrChnAlias: '',
              ChnState: '',
              ChnID: ''
            }
            this.DevInfo.svrChnAlias = val.SvrChnAlias
            var svrList = (this.nvrList)[index]
            this.DevInfo.ChnID = svrList.ChnID
            if (svrList.DevInfo) {
              this.DevInfo.svrList = svrList.DevInfo
              this.DevInfo.ChnState = svrList.ChnState.Connect == 'online' ? '在线' : '下线'
            } else {
              this.DevInfo.svrList = {}
              this.DevInfo.ChnState = '空闲'
            }
            if (this.form.NvrChnID === '') {
              this.form.NvrChnID = this.DevInfo.ChnID
            }
            this.networkDirList.push(this.DevInfo)
          }
        })
        this.networkDirList.push({
          svrList: {},
          svrChnAlias: '',
          ChnState: '',
          ChnID: 'DestAddr'
        })
      })
    }
  }
}
</script>

<style lang="scss">
.net-work-test {
  .el-form-item {
    > div {
      line-height: 32px;
    }
  }
}
</style>
<style lang="scss" scoped="scoped">
.net-work-test {

  .el-input {
    width: 312px;
  }

  .results-wrap {
    height: 200px;
    margin-top: 8px;
    padding: 8px;
    overflow-y: auto;
    border: 1px solid rgba(216,222,234,0.20);
    border-radius: 2px;
    width: 624px;
  }
}
</style>
