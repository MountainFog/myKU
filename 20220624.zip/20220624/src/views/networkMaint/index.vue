<template>
  <div class="network-maint-config second-tabs-item">
    <tabItem :tabList="tabList" @active="tabComponent"></tabItem>
    <div class="dynamic-component">
      <component v-bind:is="currentTabComponent"></component>
    </div>
  </div>
</template>

<script>
import tabItem from '../tabs/tabItem'
import networkTest from './components/networkTest'
import networkCaught from './components/networkCaught'
export default {
  data(){
    return {
      tabList:[
        {name:'网络测试',component:'networkTest'},
        {name:'网络抓包',component:'networkCaught'}
      ],
      currentTabComponent:'networkTest'
    }
  },
  components:{
    tabItem,
    networkTest,
    networkCaught
  },
  methods:{
    tabComponent(item){
      this.currentTabComponent = item.component
    }
  }
}
</script>

<style lang="scss">
.network-maint-config {
  .dynamic-component {
    padding-top: 16px;
  }
}
</style>
