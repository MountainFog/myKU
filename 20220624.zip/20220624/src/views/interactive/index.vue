<template>
  <div class="interactive-config">
    <div class="interactive-content-container">
      <div id="record-container" class="interactive-record">
        <div class="interactive-record-container">
          <div class="add-container">
            <div v-if="!interactiveStatus" class="no-interactive">
              <div class="title-container">
                <div class="title-icon">
                  <span class="icon-interactive" />
                </div>
                <div class="title-status">
                  <span class="font-title-table">当前无互动</span>
                </div>
              </div>
              <div class="button-container">
                <input type="button" value="添加互动" class="default" @click="addInteractive">
              </div>
            </div>
            <div v-if="interactiveStatus" class="has-interactive">
              <div class="link-alias">
                <span class="title">{{ interactInfo.Alias }}</span>
              </div>
              <div class="has-time-title" />
              <div class="link-icon">
                <span class="link-icon-hang" @click="stopInter">
                  <i class="icon-hang-up" />
                </span>
              </div>
            </div>
          </div>
          <div class="inter-list">
            <div class="font0"><span class="font-title-color">互动记录</span></div>
            <i class="gap-line" />
            <div class="inter-list-cart-container">
              <el-scrollbar style="height: 100%">
                <div
                  v-for="item in BookItemList"
                  :key="item.CallTime"
                >

                  <el-popover
                    popper-class="bubble-panel"
                    placement="right"
                    title=""
                    width="320"
                    trigger="hover"
                  >
                    <div>
                      <div class="buddle-item">
                        <label for="" class="buddle-label">互动时间:</label>
                        <span class="font-title-table">{{ item.CallTime }}</span>
                      </div>
                      <div class="buddle-item">
                        <label for="" class="buddle-label">呼叫方式:</label>
                        <span class="font-title-table">{{ item.CallType == 'CallIp' ? 'IP' : 'E164' }}</span>
                      </div>
                      <div class="buddle-item">
                        <label for="" class="buddle-label">对端别名:</label>
                        <span class="font-title-table">{{ item.E164Num != '' ? item.E164Num : item.IpAddr }}</span>
                      </div>
                      <div class="buddle-item">
                        <label for="" class="buddle-label">呼叫协议:</label>
                        <span class="font-title-table">{{ item.ProtoType }}</span>
                      </div>
                      <div class="buddle-item">
                        <label for="" class="buddle-label">呼叫码率:</label>
                        <span class="font-title-table">{{ item.CallRate }} kbsp</span>
                      </div>
                      <div class="buddle-item">
                        <label for="" class="buddle-label">是否发送双流:</label>
                        <span class="font-title-table">{{ item.DStream == 'true' ? '是' : '否' }}</span>
                      </div>
                    </div>
                    <div slot="reference" class="inter-list-cart">
                      <span class="img-item"><i class="icon-caller" :class="{caller: item.IsCaller == 'true'}" /></span>
                      <div class="itter-item-con">
                        <div class="inter-item">
                          <div class="call-info">
                            <div class="title font-title-color">{{ item.ItemName }}</div>
                            <div class="title time-title">{{ getDate(item.CallTime) }}</div>
                          </div>
                          <div class="call-button">
                            <span class="right-call" @click="callItemList(item)"><i class="icon-call" /></span>
                          </div>
                        </div>
                        <div class="line-item">
                          <i class="gap-line" />
                        </div>
                      </div>
                    </div>
                  </el-popover>
                </div>
              </el-scrollbar>
            </div>
            <div class="mail-class-config-button">
              <input type="button" class="primary" value="专递课堂配置" @click="mailClassConfig">
            </div>
          </div>
        </div>
      </div>
      <div id="play_container" class="interactive-play-cont">
        <div class="fun-button-container">
          <input v-for="item in switchBut" :key="item.value" type="button" :class="{ 'primary': isPicture == item.value }" class="default default-border-radius" :value="item.label" @click="switchPicture(item.value)">
        </div>
        <div class="foot-opeartion">
          <div class="left-play-operation">
            <div class="volume-control">
              <i class="volume-control-icon" :class="{ 'isMuted': muted }" @click="setMuted" />
              <el-slider v-model="volume" @change="changeVolume" />
            </div>

            <div class="screen-full">
              <i class="full-screen-icon" @click="fullScreen" />
            </div>
          </div>
          <div class="right-play-operation">
            <el-select key="isStream" v-model="isStream" class="border-select-default double-stream-select marginLeft16" placeholder="请选择" @change="changeStreamList">
              <el-option
                v-for="item in streamList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-checkbox v-show="isLocal" key="isCheck" v-model="doubleStream" class="marginLeft16" @change="changeDoubleStreamStatus">双流</el-checkbox>
            <el-select v-show="isLocal" key="isNvr" v-model="nvrChnId" class="border-select-default double-stream-select marginLeft16" placeholder="请选择" @change="channelChange">
              <el-option
                v-for="item in chnInfoList"
                :key="item.value"
                :label="('D' + item.NvrChnId + ' ' + item.SvrChnAlias + '(' + item.ChnState.Connect + ')')"
                :value="('D' + item.NvrChnId + ' ' + item.SvrChnAlias + '(' + item.ChnState.Connect + ')')"
              />
            </el-select>
            <input type="button" class="default default-border-radius font-title-color marginLeft16" value="互动统计" @click="showStatisticsInfo">
          </div>
        </div>
        <div class="play-container">
          <div class="play-local" :class="{'playActive': localOrDistal == 'local'}" @click="switchLocalOrDistal('local')">
            <div v-if="localFlag" id="play_local" @dblclick="dbExit" />
          </div>
          <div v-show="playDistalFlag" class="play-distal" :class="{'playActive': localOrDistal == 'distal','isBottom': isBottom}" @click="switchLocalOrDistal('distal')">
            <div v-if="distalFlag" id="play_distal" />
          </div>
        </div>
      </div>
    </div>
    <el-dialog :close-on-click-modal="false" title="添加互动设备" class="font-title-color add-inter-config" :visible.sync="addInterConfig">
      <el-form ref="addInterList" :model="form" :rules="rules">
        <el-form-item label="设备别名" :label-width="formLabelWidth">
          <el-input v-model="form.ItemName" type="text" class="input-width-default border-input-default default-border-radius" />
        </el-form-item>
        <el-form-item label="呼叫方式" :label-width="formLabelWidth">
          <el-select v-model="form.CallType" class="border-select-default input-width-default" placeholder="请选择协议类型">
            <el-option label="IP" value="CallIp" />
            <el-option label="E164" value="CallE164" />
          </el-select>
        </el-form-item>
        <div v-if="form.CallType == 'CallIp'" key="IP">
          <el-form-item prop="IpAddr" label="对端地址" :label-width="formLabelWidth">
            <el-input v-model="form.IpAddr" type="text" class="input-width-default border-input-default default-border-radius" />
          </el-form-item>
        </div>
        <div v-if="form.CallType == 'CallE164'" key="E164Num">
          <el-form-item label="对端地址" :label-width="formLabelWidth">
            <el-input v-model="form.E164Num" type="text" class="input-width-default border-input-default default-border-radius" />
          </el-form-item>
        </div>
        <div>
          <el-form-item label="码率" :label-width="formLabelWidth">
            <el-input v-model="form.CallRate" type="text" class="input-width-default border-input-default default-border-radius" />
            <span class="paddingLeft16">0-8096(kbps)</span>
          </el-form-item>
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <input type="button" class="primary default-border-radius" value="呼叫" @click="interCall">
        <input type="button" class="default default-border-radius font-title-color marginLeft16" value="取消" @click="addInterConfig = false">
      </div>
    </el-dialog>
    <el-dialog :close-on-click-modal="false" title="统计信息" class="font-title-color statis-info" :visible.sync="interStatisticsConfig">
      <div class="static-content">
        <el-tabs v-model="activeName">
          <el-tab-pane label="互动统计" name="inter">
            <interactiveStatistical :send-statics-list="sendStaticsList" :inter-alias="interAlias" :rec-statics-list="recStaticsList" />
          </el-tab-pane>
          <el-tab-pane label="网络统计" name="network">
            <networkStatistical :network-static-list="networkStaticList" :inter-alias="interAlias" />
          </el-tab-pane>
        </el-tabs>
      </div>
      <div slot="footer" class="dialog-footer">
        <input type="button" class="primary default-border-radius" value="确认" @click="interStatisticsConfig = false">
      </div>
    </el-dialog>

    <el-dialog :close-on-click-modal="false" title="专递课堂" class="font-title-color mail-inter-config" :visible.sync="mailClassConfigs">
      <div class="tip-model">点对点模式</div>
      <el-form ref="pointToPoint" :rules="rules" :model="P2PCallCfg">
        <div class="tip-model-top paddingLeft16">
          <div class="tip-model-top-item">
            <el-form-item label="互动名称:" :label-width="formLabelWidth">
              <el-input v-model="P2PCallCfg.ItemName" type="text" class="input-width-default border-input-default default-border-radius" />
            </el-form-item>
          </div>
          <div class="tip-model-top-item">
            <el-form-item label="呼叫方式:" :label-width="formLabelWidth">
              <el-select v-model="P2PCallCfg.CallType" class="border-select-default input-width-default" placeholder="请选择协议类型">
                <el-option label="IP" value="CallIp" />
                <el-option label="E164" value="CallE164" />
              </el-select>
            </el-form-item>
          </div>
          <div v-show="P2PCallCfg.CallType == 'CallIp'" key="tipIp" class="tip-model-top-item">
            <el-form-item label="对端IP:" :label-width="formLabelWidth" prop="IpAddr">
              <el-input v-model="P2PCallCfg.IpAddr" type="text" class="input-width-default border-input-default default-border-radius" />
            </el-form-item>
          </div>
          <div v-show="P2PCallCfg.CallType == 'CallE164'" key="tipE164" class="tip-model-top-item">
            <el-form-item label="E164号:" :label-width="formLabelWidth">
              <el-input v-model="P2PCallCfg.E164Num" type="text" class="input-width-default border-input-default default-border-radius" />
            </el-form-item>
          </div>
          <div class="tip-model-top-item">
            <el-form-item label="码率:" :label-width="formLabelWidth">
              <el-select v-model="P2PCallCfg.CallRate" class="border-select-default input-width-default" placeholder="请选择协议类型">
                <el-option v-for="videoitem in VideoBitrate" :key="videoitem.value" :label="videoitem.label" :value="videoitem.value" />
              </el-select>kbps
            </el-form-item>
          </div>
        </div>
      </el-form>
      <div class="point-to-point-btngroup">
        <input type="button" class="primary default-border-radius" value="保存" @click="savePoint">
        <input type="button" class="default default-border-radius font-title-color marginLeft16" value="呼叫" @click="callPointToPoint">
      </div>
      <div class="tip-model-more">
        <div class="tip-model">点对多模式</div>
        <div class="paddingLeft16">
          <input type="button" value="添加" class="primary default-border-radius" @click="addMailInfo">
          <input type="button" value="删除" class="default default-border-radius marginLeft16" @click="removeMailInfoList">
        </div>
        <div class="table-list paddingLeft16">
          <pointToMore :point-to-more-list="InviteMtList" @edit="editMailInfo" @deleteInfo="removeMailInfo" />
        </div>
        <div class="paddingLeft16">
          <div class="tip-model">互动参数配置</div>
          <el-form ref="pointToMore" :rules="rules" :model="ConfParam">
            <div class="inte-param-config">
              <div class="inte-param-flex">
                <el-form-item label="视频格式:" :label-width="formLabelWidth">
                  <el-select v-model="ConfParam.ConfVidFormatParam.VideoFormat" class="border-select-default input-width-default" placeholder="请选择协议类型">
                    <el-option label="H264_HP" value="0" />
                    <el-option label="H264_BP" value="1" />
                    <el-option label="H265" value="2" />
                  </el-select>
                </el-form-item>
              </div>
              <div class="inte-param-flex">
                <el-form-item label="视频分辨率:" :label-width="formLabelWidth">
                  <el-select v-model="ConfParam.ConfVidFormatParam.VideoResolution" class="border-select-default input-width-default" placeholder="请选择协议类型">
                    <el-option label="720P(1280*720)" value="0" />
                    <el-option label="1080p(1920*1080)" value="1" />
                  </el-select>
                </el-form-item>
              </div>
              <div class="inte-param-flex">
                <el-form-item label="视频帧率:" :label-width="formLabelWidth">
                  <el-input v-model="ConfParam.ConfVidFormatParam.VideoFrame" type="text" disabled class="input-width-default border-input-default default-border-radius" />fps
                </el-form-item>
              </div>
              <div class="inte-param-flex">
                <el-form-item label="视频码率:" :label-width="formLabelWidth">
                  <el-select v-model="ConfParam.ConfVidFormatParam.VideoBitrate" class="border-select-default input-width-default" placeholder="请选择协议类型">
                    <el-option v-for="videoitem in VideoBitrate" :key="videoitem.value" :label="videoitem.label" :value="videoitem.value" />
                  </el-select>kbps
                </el-form-item>
              </div>
            </div>
            <div class="inte-param-config">
              <div class="inte-param-flex">
                <el-form-item label="会议类型:" :label-width="formLabelWidth">
                  <el-select v-model="ConfParam.ConfType" class="border-select-default input-width-default" placeholder="请选择协议类型">
                    <el-option label="传统会议" value="0" />
                    <el-option label="端口会议" value="1" />
                  </el-select>
                </el-form-item>
              </div>
              <div class="inte-param-flex">
                <el-form-item label="媒体资源:" :label-width="formLabelWidth">
                  <el-select v-model="ConfParam.ConfResource" class="border-select-default input-width-default" placeholder="请选择协议类型">
                    <el-option label="纯转发会议" value="0" />
                    <el-option label="资源预占" value="1" />
                  </el-select>
                </el-form-item>
              </div>
              <div class="inte-param-flex">
                <el-form-item label="KEY:" :label-width="formLabelWidth">
                  <el-input v-model="ConfParam.ApiKey" type="text" class="input-width-default border-input-default default-border-radius" />
                </el-form-item>
              </div>
              <div class="inte-param-flex">
                <el-form-item label="Secret:" :label-width="formLabelWidth">
                  <el-input v-model="ConfParam.ApiSecret" type="password" class="input-width-default border-input-default default-border-radius" />
                </el-form-item>
              </div>
            </div>
            <div class="inte-param-config">
              <div class="inte-param-flex">
                <el-form-item label="API使能:" :label-width="formLabelWidth">
                  <el-checkbox v-model="ConfParam.ApiEnable" />
                </el-form-item>
              </div>
              <div class="inte-param-flex">
                <el-form-item label="API地址:" :label-width="formLabelWidth" prop="ApiAddr">
                  <el-input v-model="ConfParam.ApiAddr" type="text" class="input-width-default border-input-default default-border-radius" :disabled="!ConfParam.ApiEnable" />
                </el-form-item>
              </div>
              <div class="inte-param-flex">
                <el-form-item label="API端口:" :label-width="formLabelWidth" prop="ApiPort">
                  <el-input v-model="ConfParam.ApiPort" type="text" class="input-width-default border-input-default default-border-radius" />
                </el-form-item>
              </div>
              <div class="inte-param-flex">
                <el-form-item label="SSL:" :label-width="formLabelWidth">
                  <el-checkbox v-model="ConfParam.ApiSSL" @change="changeApiSsl" />
                </el-form-item>
              </div>
            </div>
            <div class="inte-param-config">
              <div class="inte-param-flex">
                <el-form-item label="主讲进合成:" :label-width="formLabelWidth">
                  <el-checkbox v-model="ConfParam.LectureComp" />
                </el-form-item>
              </div>
              <div class="inte-param-flex">
                <el-form-item label="上课时长:" :label-width="formLabelWidth">
                  <el-select v-model="ConfParam.ConfDuration" class="border-select-default input-width-default" placeholder="请选择协议类型">
                    <el-option label="1" value="60" />
                    <el-option label="2" value="120" />
                    <el-option label="4" value="240" />
                    <el-option label="8" value="480" />
                  </el-select>小时
                </el-form-item>
              </div>
              <div class="inte-param-flex" />
              <div class="inte-param-flex" />
            </div>
          </el-form>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <input type="button" class="primary default-border-radius" value="保存" @click="saveMail">
        <input type="button" class="default default-border-radius font-title-color marginLeft16" value="呼叫" @click="pointCallMore">
      </div>
    </el-dialog>
    <el-dialog title="专递课堂" :close-on-click-modal="false" class="font-title-color add-inter-config" :visible.sync="addMailConfig">
      <el-form :model="form">
        <el-form-item label="终端别名" :label-width="formLabelWidth">
          <el-input v-model="addMial.MeetTerMinalName" type="text" class="input-width-default border-input-default default-border-radius" />
        </el-form-item>
        <el-form-item label="终端账号" :label-width="formLabelWidth">
          <el-input v-model.trim="addMial.MeetTerminalAccount" type="text" class="input-width-default border-input-default default-border-radius" />
        </el-form-item>
        <div v-show="form.CallType == 'CallIp'" key="IP">
          <el-form-item label="协议类型" :label-width="formLabelWidth">
            <el-select v-model="addMial.CallProtoColType" class="border-select-default input-width-default" placeholder="请选择协议类型">
              <el-option label="H323" value="0" />
              <el-option label="SIP" value="1" />
            </el-select>
          </el-form-item>
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <input type="button" class="primary default-border-radius" value="确认" @click="addOrEditMail">
        <input type="button" class="default default-border-radius font-title-color marginLeft16" value="取消" @click="addMailConfig = false">
      </div>
    </el-dialog>
  </div>
</template>

<script>
import store from '@/store'
import Cookies from 'js-cookie'
import { validateIP, isPort } from '@/utils/validateModule.js'
import interactiveStatistical from './components/interactiveStatistical'
import networkStatistical from './components/networkStatistical'
import pointToMore from './components/pointToMore'
import {
  getAudSrcCap,
  getRtspUrlRealStream,
  startInteract, stopInteract,
  getInteractList,
  getBookItemList,
  getQoeStatus,
  startInteractDStream,
  stopInteractDStream,
  getOutChnCfg,
  setOutChnCfg,
  getP2PCallCfg,
  getConfParam,
  setConfParam,
  setP2PCallCfg,
  confSwitch1ToMany
} from '@/api/interactive'
import { getH323Info } from '@/api/registManage.js'
import { getSvrChnList, getNvrChnList, getSrvCap } from '@/api/channelManage'
import { getWebsocketAccess } from '@/api/resourceManage'
import { getSceneParam } from '@/api/application'
import { KMediaUni } from 'kmedia-uni'
export default {
  components: {
    interactiveStatistical,
    networkStatistical,
    pointToMore
  },
  data() {
    return {
      rules: {
        IpAddr: [{ required: false, trigger: 'blur', validator: validateIP }],
        ApiAddr: [{ required: false, trigger: 'blur', validator: validateIP }],
        ApiPort: [{ required: false, trigger: 'blur', validator: isPort }]
      },
      timeStatus: null,
      isLocal: true,
      volume: 20,
      muted: false,
      isStream: 'main',
      streamList: [
        {
          value: 'main',
          label: '主流'
        },
        {
          value: 'stream',
          label: '双流'
        }
      ],
      switchBut: [
        {
          label: '本地画面',
          value: 'local'
        },
        {
          label: '远端画面',
          value: 'distal'
        },
        {
          label: '双方画面',
          value: 'synthetic'
        }
      ],
      localUrl: '',
      distalUrl: '',
      isPicture: 'local',
      localOrDistal: 'local',
      localFlag: true,
      distalFlag: true,
      kmediaLocal: null, // 本地播放器
      kmediaDistal: null, // 远端播放器
      isFullScreen: false,
      playDistalFlag: false, // 是否双画面
      /* progressBar: false,//进度条展示 */
      capSum: 0,
      isBottom: true,
      InNvrChnId: '10', // 远程输入通道号
      OutNvrChnId: '14', // 远程输出通道号
      inMainInfo: {
        NvrChnId: 10,
        EncId: 0,
        sum: 1
      },
      outMainInfo: {
        NvrChnId: 14,
        EncId: 0,
        sum: 1
      },
      localInfo: {},
      distalInfo: {},
      chnInfoList: [],
      nvrChnList: [],
      svrChnList: [],
      nvrChnId: '', // 通道ID
      nvrEncId: 1,
      doubleStream: false, // 是否选中双流
      activeName: 'inter',
      addInterConfig: false,
      BookItemList: [],
      websocketIp: '',
      form: {
        CallType: 'CallIp',
        CallRate: 2048,
        ItemName: '',
        IpAddr: '0.0.0.0',
        E164Num: '',
        ProtoType: 'H323', // 呼叫协议类型: H323 或 SIP
        DStream: false // 是否发送双流
      },
      formLabelWidth: '86px',
      hoverIndex: -1,
      interactiveStatus: false,
      interactInfo: '',
      timeout: null, // 定时器
      interAlias: '', // 互动别名
      interStatisticsConfig: false, // 互动统计弹框控制
      sendStaticsList: [], // 发送统计列表
      recStaticsList: [], // 接收统计列表
      networkStaticList: [], // 网络统计列表
      CallMode: 0, // 互动模式
      CallFrameRate: 30, // 互动帧率
      CallBitRate: 2048, // 互动码率
      mainInfo: {}, // 主流通道信息
      secInfo: {}, // 双流通道信息
      curNvrInfo: {}, // 当前选中通道信息
      mailClassConfigs: false, // 专递课堂配置
      P2PCallCfg: { // 点对点数据
        ItemName: '',
        CallType: 'CallIp',
        IpAddrType: '',
        IpAddr: '',
        IpAddrString: '',
        E164Num: '',
        H323Alias: '',
        CallRate: '',
        DStream: '',
        ProtoType: ''
      },
      ConfParam: { // 点对多数据
        ApiAddr: '',
        ApiEnable: '',
        ApiKey: '',
        ApiPort: '',
        ApiPortSSL: '',
        ApiSSL: '',
        ApiSecret: '',
        ConfDuration: '',
        ConfResource: '',
        ConfType: '',
        ConfVidFormatParam: {
          VideoBitrate: '',
          VideoFormat: '',
          VideoFrame: '',
          VideoResolution: ''
        },
        InspectMtId: '',
        InviteMtList: {
          InviteMtItem: {
            MeetTerMinalName: '',
            MeetTerminalAccount: '',
            AccountPasswd: '',
            CallProtoColType: ''
          }
        },
        IsStarted: '',
        LectureComp: ''
      },
      VideoBitrate: [
        {
          value: 1024,
          label: 1024
        },
        {
          value: 1356,
          label: 1356
        },
        {
          value: 2048,
          label: 2048
        },
        {
          value: 2560,
          label: 2560
        },
        {
          value: 3072,
          label: 3072
        },
        {
          value: 4096,
          label: 4096
        },
        {
          value: 5120,
          label: 5120
        },
        {
          value: 6144,
          label: 6144
        },
        {
          value: 7168,
          label: 7168
        },
        {
          value: 8192,
          label: 8192
        }
      ],
      InviteMtList: [],
      addMailConfig: false, // 添加专递课堂控制
      addMial: {
        MeetTerMinalName: '',
        MeetTerminalAccount: '',
        CallProtoColType: '0',
        AccountPasswd: ''
      },
      removeMailInfos: [],
      isEdit: false,
      editIndex: -1,
      loadVideoCount: 0,
      audType: 'AACLC_32K',
      abliteTime: null
    }
  },
  beforeRouteLeave(to, from, next) {
    this.kmediaLocal.destroy()
    this.kmediaDistal.destroy()
    this.localFlag = false
    this.distalFlag = false
    next()
  },
  watch: {
    interactiveStatus() {
      this.init()
    },
    $route(to, from) {
      if (to.name == 'interactive') {
        this.initInteractive()
      }
    }
  },
  destroyed() {
    clearTimeout(this.timeout)
    clearTimeout(this.timeStatus)
    clearTimeout(this.abliteTime)
  },
  mounted() {
    this.getStreamAblite()
    this.getInitInfo()
    this.initInteractive()
    this.getChnCfg().then(res => {
      this.secInfo.NvrChnId = Number(res.GetOutChnCfgResp.SecVidSrc.NvrChnId)
      this.secInfo.EncId = res.GetOutChnCfgResp.SecVidSrc.EncId
      this.audType = res.GetOutChnCfgResp.AudType
    })
    this.getAbliteTime()
    this.volume = Cookies.get('defaultVolume', this.volume) || 50
    this.volume = Number(this.volume)
  },
  methods: {
    getAbliteTime() {
      const _that = this
      this.abliteTime = setTimeout(() => {
        _that.getStreamAblite()
        _that.getAbliteTime()
      }, 2000)
    },
    getInitInfo() {
      this.isStream = Cookies.get('mainStream') ? Cookies.get('mainStream') : 'main'
      if (this.isStream == 'main') {
        this.nvrEncId = 1
      } else {
        this.nvrEncId = 2
      }
    },
    initInteractive() {
      this.$nextTick(() => {
        const play_con_height = document.getElementById('play_container')
        const recode_con_height = document.getElementById('record-container')
        const height = play_con_height.offsetHeight
        play_con_height.style.width = (height * 16 / 9) + 'px'
        recode_con_height.style.flex = 1
      })
      this.localPlay() // 初始化播放器
      this.distalPlay() // 初始化播放器
      this.getInterList()
      this.getBookList()
      this.init()
    },
    fullScreen() {
      this.isFullScreen = !this.isFullScreen
      this.kmediaLocal.requestFullscreen()
    },
    dbExit() {
      this.isFullScreen = !this.isFullScreen
      this.kmediaLocal.exitFullscreen()
    },
    changeVolume() {
      if (this.volume != 0) {
        this.muted = false
      } else {
        this.muted = true
      }
      if (this.isPicture == 'local') { // 本地画面
        this.kmediaLocal.volume(this.volume)
      } else if (this.isPicture == 'distal') { // 远端画面
        this.kmediaDistal.volume(this.volume)
      } else if (this.isPicture == 'synthetic') { // 合成画面
        if (this.localOrDistal == 'local') { // 控制本地
          this.kmediaLocal.volume(this.volume)
          this.kmediaDistal.volume(0)
        } else { // 控制远端
          this.kmediaLocal.volume(0)
          this.kmediaDistal.volume(this.volume)
        }
      }
      Cookies.set('defaultVolume', this.volume)
    },
    setMuted() {
      if (this.muted) { // 有静音到非静音
        this.muted = false
        if (this.isPicture == 'synthetic') {
          if (this.localOrDistal == 'local') { // 控制本地
            this.kmediaLocal.volume(this.volume)
            this.kmediaDistal.volume(0)
          } else { // 控制远端
            this.kmediaLocal.volume(0)
            this.kmediaDistal.volume(this.volume)
          }
        } else { // 本地或者远端的情况下都是控制本地播放器
          this.kmediaLocal.volume(this.volume)
          this.kmediaDistal.volume(0)
        }
      } else { // 非静音到静音
        this.muted = true
        this.kmediaLocal.volume(0)
        this.kmediaDistal.volume(0)
      }
    },
    async init() {
      if (this.interactiveStatus) {
        await this.getCap()
        await this.getSrcAudCap()
        await this.getUrlRealStream(this.InNvrChnId).then(res => {
          const rtspUrl = res.GetRtspUrlRealStreamResp.RtspUrl
          this.distalUrl = rtspUrl
          if (this.distalUrl) {
            this.loadDistalVideo(this.distalUrl)
          }
        })
        await this.getUrlRealStream(this.OutNvrChnId).then(res => {
          const rtspUrl = res.GetRtspUrlRealStreamResp.RtspUrl
          /* let websocket = ''
          if (rtspUrl.match(/rtsp:\/\/(.+):/)) websocket = RegExp.$1
          this.websocketIp = websocket */
          this.localUrl = rtspUrl
          if (this.localUrl) {
            if (this.isPicture === 'distal') {
              this.loadLocalVideo(this.distalUrl)
            } else {
              this.loadLocalVideo(this.localUrl)
            }
          }
        })
      }
    },
    getChnCfg() { // 获取互动输出远配置信息
      return new Promise((resolve, reject) => {
        getOutChnCfg({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    setChnCfg(mainNvrId, mainEncId) { // 设置互动输出源配置信息
      return new Promise((resolve, reject) => {
        const param = {
          SetOutChnCfgReq: {
            MainVidSrc: {
              NvrChnId: Number(mainNvrId),
              EncId: Number(mainEncId)
            },
            SecVidSrc: {
              NvrChnId: this.secInfo.NvrChnId,
              EncId: this.secInfo.EncId
            },
            AudType: this.audType,
            IsSendSec: this.doubleStream
          }
        }
        setOutChnCfg(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject()
        })
      })
    },
    localPlay() { // 本地播放
      this.localFlag = true
      const options = {
        selector: document.getElementById('play_local'),
        loading: true,
        control: {
          hideControlsBar: true,
          tools: ['volume', 'requestFullscreen']
        },
        request: {
          restore: 3,
          timeout: 30000
        },
        autoplay: true,
        muted: true,
        FILL_TYPE: 'RATIO_16_9'
      }
      this.kmediaLocal = new KMediaUni(options)
      this.kmediaLocal.addEventListener('loadedmetadata', () => {
        // this.progressBar = true
        this.isBottom = true
        this.loadVideoCount = 0
        this.kmediaLocal.play()
        this.kmediaLocal.volume(this.volume)
      })
      this.kmediaLocal.addEventListener('error', () => {
        // this.progressBar = false
        this.isBottom = true
      })
    },
    loadLocalVideo(url) {
      getWebsocketAccess({}).then(res => {
        const websocket = res.GetWebsocketAccessResp.RtspOverUrl
        let websocketUrl = ''
        if (websocket.match(/(ws+:\/\/(.+):\d{0,4})/)) websocketUrl = RegExp.$1
        this.websocketIp = websocketUrl
        this.kmediaLocal.loadVideo({
          src: {
            websocketUrl: websocketUrl,
            rtspUrl: url,
            username: this.$store.getters.username,
            password: this.$store.getters.pwd
          },
          transport: KMediaUni.MODE.MSE
        })
        this.kmediaLocal.addEventListener('error', (err) => {
          this.loadVideoCount++
          if (loadVideoCount <= 40) {
            this.loadLocalVideo(url)
          }
        })
      })
    },
    loadDistalVideo(url) {
      getWebsocketAccess({}).then(res => {
        const websocket = res.GetWebsocketAccessResp.RtspOverUrl
        let websocketUrl = ''
        if (websocket.match(/(ws+:\/\/(.+):\d{0,4})/)) websocketUrl = RegExp.$1
        this.websocketIp = websocketUrl
        this.kmediaDistal.loadVideo(
          {
            src: {
              websocketUrl: websocketUrl,
              rtspUrl: url,
              username: this.$store.getters.username,
              password: this.$store.getters.pwd
            },
            transport: KMediaUni.MODE.MSE
          }
        )
        this.kmediaDistal.addEventListener('error', (err) => {
          this.loadVideoCount++
          if (loadVideoCount <= 40) {
            this.loadLocalVideo(url)
          }
        })
      })
    },
    distalPlay() { // 远端播放
      this.distalFlag = true
      const options = {
        selector: document.getElementById('play_distal'),
        loading: true,
        control: {
          hideControlsBar: true,
          tools: ['volume', 'requestFullscreen']
        },
        request: {
          restore: 3,
          timeout: 30000
        },
        autoplay: true,
        muted: true,
        FILL_TYPE: 'RATIO_16_9'
      }
      this.kmediaDistal = new KMediaUni(options)
      this.kmediaLocal.addEventListener('loadedmetadata', () => {
        this.isBottom = false
        this.kmediaDistal.play()
        this.kmediaDistal.volume(0)
      })
    },
    switchPicture(swticPic) { // 切换视频画面
      this.isPicture = swticPic
      this.isStream = 'main'
      if (swticPic == 'local') { // 本地画面
        this.playDistalFlag = false
        this.isBottom = true
        this.isLocal = true
        if (this.localUrl) {
          this.loadLocalVideo(this.localUrl)
        }
        this.getStreamAblite().then(res => {
          this.kmediaDistal.volume(0)
        })
      } else if (swticPic == 'distal') { // 远端画面
        this.doubleStream = false
        this.playDistalFlag = false
        this.isBottom = true
        this.isLocal = false
        if (this.distalUrl) {
          this.loadLocalVideo(this.distalUrl)
        }
        this.getStreamAblite().then(res => {
          this.kmediaLocal.volume(this.volume)
          this.kmediaDistal.volume(0)
        })
      } else { // 合成画面
        this.isBottom = true
        this.isLocal = true
        this.doubleStream = false
        this.getStreamAblite().then(res => {
          if (this.localUrl) {
            this.loadLocalVideo(this.localUrl)
            this.kmediaDistal.loadVideo({
              src: {
                websocketUrl: this.websocketIp,
                rtspUrl: this.distalUrl,
                username: this.$store.getters.username,
                password: this.$store.getters.pwd
              },
              transport: KMediaUni.MODE.MSE
            })
          }
          this.playDistalFlag = true
          this.kmediaDistal.volume(0)
        })
      }
    },
    channelChange(val) { // 切换通道
      const chnId = val.substr(1, 1)
      const svrItem = this.chnInfoList.find(item => item.NvrChnId == chnId)
      this.curNvrInfo = svrItem
      this.secInfo = svrItem
      if (this.doubleStream) { // 选中双流切换才有效
        if (this.isPicture == 'local') { // 本地切换
          this.getChnCfg().then(res => {
            this.setChnCfg(res.GetOutChnCfgResp.MainVidSrc.NvrChnId, res.GetOutChnCfgResp.MainVidSrc.NvrChnId.EncId).then(res => {
              if (this.isStream == 'main') {
                this.nvrEncId = 1
              } else {
                this.nvrEncId = 2
              }
              this.getUrlRealStream(this.OutNvrChnId).then(res => {
                this.localUrl = res.GetRtspUrlRealStreamResp.RtspUrl
                this.loadLocalVideo(res.GetRtspUrlRealStreamResp.RtspUrl)
              })
            }).catch(err => {
            })
          })
        } else if (this.isPicture == 'distal') { // 远端切换
        } else { // 双切
          if (this.localOrDistal == 'local') { // 选中大画面
            this.getChnCfg().then(res => {
              this.setChnCfg(res.GetOutChnCfgResp.MainVidSrc.NvrChnId, res.GetOutChnCfgResp.MainVidSrc.NvrChnId.EncId).then(res => {
                if (this.isStream == 'main') {
                  this.nvrEncId = 1
                } else {
                  this.nvrEncId = 2
                }
                this.getUrlRealStream(this.OutNvrChnId).then(res => {
                  this.localUrl = res.GetRtspUrlRealStreamResp.RtspUrl
                  this.loadLocalVideo(this.localUrl)
                })
              })
            })
          } else { // 选中小画面
          }
        }
      }
    },
    changeStreamList() { // 切换主流双流
      this.getStreamAblite().then(res => {
        if (this.isStream == 'stream') {
          if (this.isPicture == 'local') { // 本地
            if (this.outMainInfo.sum == 1) {
              this.$message({
                type: 'warning',
                message: '本地无双流'
              })
              return
            }
          } else if (this.isPicture == 'distal') { // 远端
            if (this.inMainInfo.sum == 1) {
              this.$message({
                type: 'warning',
                message: '远端无双流'
              })
              return
            }
          } else { // 双方
            if (this.localOrDistal == 'local') {
              if (this.outMainInfo.sum == 1) {
                this.$message({
                  type: 'warning',
                  message: '无双流画面'
                })
                return
              }
            } else {
              if (this.inMainInfo.sum == 1) {
                this.$message({
                  type: 'warning',
                  message: '无双流画面'
                })
                return
              }
            }
          }
        }
        if (this.isStream == 'main') {
          this.nvrEncId = 1
          Cookies.set('mainStream', 'main')
        } else {
          this.nvrEncId = 2
          Cookies.set('mainStream', 'stream')
        }
        let chnId
        if (this.isPicture == 'distal') {
          chnId = this.InNvrChnId
        } else {
          if (this.isPicture == 'local') {
            chnId = this.OutNvrChnId
          } else {
            if (this.localOrDistal == 'distal') {
              chnId = this.InNvrChnId
            } else if (this.localOrDistal == 'local') {
              chnId = this.OutNvrChnId
            }
          }
        }
        this.getUrlRealStream(chnId).then(res => {
          // this.localUrl = res.GetRtspUrlRealStreamResp.RtspUrl
          const videoUrl = res.GetRtspUrlRealStreamResp.RtspUrl
          if (this.isPicture == 'synthetic') {
            if (this.localOrDistal == 'local') {
              this.loadLocalVideo(videoUrl)
              this.kmediaDistal.volume(0)
              this.kmediaLocal.volume(this.volume)
            } else {
              this.loadDistalVideo(videoUrl)
              this.kmediaLocal.volume(0)
              this.kmediaDistal.volume(this.volume)
            }
          } else {
            this.loadLocalVideo(videoUrl)
            this.kmediaDistal.volume(0)
          }
        })
      })
    },
    getSrcAudCap() { // 获取音频能力
      let szXml = '<contentroot>'
      szXml += '<authenticationinfo type="7.0">'
      szXml += '<username>' + store.getters.username + '</username>'
      szXml += '<password>' + store.getters.password + '</password>'
      szXml += '<authenticationid>' + store.getters.authId + '</authenticationid>'
      szXml += '</authenticationinfo>'
      szXml += '<GetAudSrcCapReq>'
      szXml += '<ChnList num="1">'
      szXml += '<Chn chnid="14"/>'
      szXml += '</ChnList>'
      szXml += '</GetAudSrcCapReq>'
      szXml += '</contentroot>'
      getAudSrcCap(szXml)
    },
    getUrlRealStream(nvrChnId) { // 获取播放url
      return new Promise((resolve, reject) => {
        let szXml = '<contentroot>'
        szXml += '<authenticationinfo type="7.0">'
        szXml += '<username>' + store.getters.username + '</username>'
        szXml += '<password>' + store.getters.password + '</password>'
        szXml += '<authenticationid>' + store.getters.authId + '</authenticationid>'
        szXml += '</authenticationinfo>'
        szXml += '<GetRtspUrlRealStreamReq>'
        szXml += '<NvrChnID>' + nvrChnId + '</NvrChnID>'
        szXml += '<TransType>' + (Cookies.get('TransType') ? Cookies.get('TransType') : 'tcp') + '</TransType>'
        szXml += '<VideoList num="1">'
        szXml += '<EncID>' + this.nvrEncId + '</EncID>'
        szXml += '</VideoList>'
        szXml += '<AudioList num="1">'
        szXml += '<SrcID>1</SrcID>'
        szXml += '</AudioList>'
        szXml += '</GetRtspUrlRealStreamReq>'
        szXml += '</contentroot>'
        getRtspUrlRealStream(szXml).then(res => {
          resolve(res)
        }).catch(err => {
          reject()
        })
      })
    },
    getCap() { // 获取通道能力
      getSrvCap({}).then(async res => {
        this.capSum = Number(res.capinfo.GroupNum)
        await this.getNvrChnListC(this.capSum)
        await this.getSvrChnListC()
        this.getChnInfoList()
      })
    },
    getChnInfoList() { // 获取通道信息
      const _that = this
      this.nvrChnList.forEach(val => {
        _that.svrChnList.forEach(ele => {
          if (val.ChnID == ele.NvrChnId) {
            const obj = ele
            obj.ChnState = val.ChnState ? val.ChnState : {}
            obj.DevInfo = val.DevInfo ? val.DevInfo : {}
            this.chnInfoList.push(obj)
            return false
          }
        })
      })
      const idx = this.chnInfoList.findIndex(item => this.secInfo.NvrChnId == item.NvrChnId)
      let chnInfoItem
      if (idx > -1) {
        chnInfoItem = this.chnInfoList[idx]
      } else {
        chnInfoItem = this.chnInfoList[0]
      }
      this.mainInfo = chnInfoItem
      this.secInfo = chnInfoItem
      this.nvrChnId = ('D' + chnInfoItem.NvrChnId + ' ' + chnInfoItem.SvrChnAlias + '(' + chnInfoItem.ChnState.Connect + ')')
    },
    async getNvrChnListC(subNum) { // 获取nvr列表
      const param = {
        GetNvrChnListReq: {
          ChnIDStart: 1,
          ChnIDEnd: subNum,
          NeedMask: {
            ChnAlias: true,
            DevSrcID: true,
            ChnState: true,
            DevInfo: true,
            ChnDevCfg: false
          }
        }
      }
      await getNvrChnList(param).then(res => {
        this.nvrChnList = res.GetNvrChnListResp.ChnList.ChnInfo
        const chnList = res.GetNvrChnListResp.ChnList.ChnInfo
        const _that = this
        const chnI = chnList.filter(item => Number(item.ChnID) == _that.InNvrChnId)
        const chnO = chnList.filter(item => Number(item.ChnID) == _that.OutNvrChnId)
        if (chnO[0].DevInfo) {
          this.inMainInfo.sum = Number(chnI[0].DevInfo.EncNum)
          this.outMainInfo.sum = Number(chnO[0].DevInfo.EncNum)
        }
      })
    },
    getStreamAblite() {
      return new Promise((resolve, reject) => {
        getSrvCap({}).then(res => {
          const param = {
            GetNvrChnListReq: {
              ChnIDStart: 1,
              ChnIDEnd: Number(res.capinfo.GroupNum),
              NeedMask: {
                ChnAlias: false,
                DevSrcID: true,
                ChnState: false,
                DevInfo: true,
                ChnDevCfg: false
              }
            }
          }
          getNvrChnList(param).then(res => {
            const chnList = res.GetNvrChnListResp.ChnList.ChnInfo
            const _that = this
            const chnI = chnList.filter(item => Number(item.ChnID) == _that.InNvrChnId)
            const chnO = chnList.filter(item => Number(item.ChnID) == _that.OutNvrChnId)
            if (chnO[0].DevInfo) {
              this.outMainInfo.sum = Number(chnO[0].DevInfo.EncNum)
              this.inMainInfo.sum = Number(chnI[0].DevInfo.EncNum)
              if (Number(chnO[0].DevInfo.EncNum) == 1) {
                this.doubleStream = false
              } else if (Number(chnO[0].DevInfo.EncNum) == 2) {
                this.doubleStream = true
              }
            } else {
              this.doubleStream = false
            }
            resolve(res)
          }).catch(err => {
            reject(err)
          })
        })
      })
    },
    async getSvrChnListC() {
      await getSvrChnList({}).then(res => {
        this.svrChnList = res.GetSvrChnListResp.SvrChnItemList.SvrChnItem
      })
    },
    changeDoubleStreamStatus() { // 是否发送双流
      if (this.doubleStream) { // 开启双流
        const param = {
          StartInteractDStreamReq: {
            ItemName: this.interAlias
          }
        }
        startInteractDStream(param).then(res => {
          this.getChnCfg().then(res => {
            this.setChnCfg(res.GetOutChnCfgResp.MainVidSrc.NvrChnId, res.GetOutChnCfgResp.MainVidSrc.NvrChnId.EncId)
          })
        })
      } else { // 关闭双流
        const param = {
          StopInteractDStreamReq: {
            ItemName: this.interAlias
          }
        }
        stopInteractDStream(param).then(res => {
          this.getChnCfg().then(res => {
            this.setChnCfg(res.GetOutChnCfgResp.MainVidSrc.NvrChnId, res.GetOutChnCfgResp.MainVidSrc.NvrChnId.EncId)
          })
        })
      }
    },
    mouseleaveItem() {
      this.hoverIndex = -1
    },
    mouseoverItem(index) {
      this.hoverIndex = index
    },
    addInteractive() { // 添加呼叫
      this.addInterConfig = true
    },
    stopInter() {
      clearTimeout(this.timeout)
      var param = {
        StopInteractReq: {
          ItemName: this.interAlias
        }
      }
      stopInteract(param).then(res => {
        this.kmediaLocal.destroy()
        this.kmediaDistal.destroy()
        this.localFlg = false
        this.distalFlag = false
        this.localUrl = ''
        this.distalUrl = ''
        this.localPlay() // 初始化播放器
        this.distalPlay() // 初始化播放器
        this.getInterList()
        this.getBookList()
      })
    },
    pointCallMore() {
      if (this.interactiveStatus) {
        this.$message({
          showClose: true,
          message: '当前正在互动中...',
          type: 'error'
        })
        return
      }
      if (!this.ConfParam.ApiEnable) {
        this.$message({
          message: 'API使能必须选中',
          type: 'error'
        })
        return
      }
      if (!this.ConfParam.ApiAddr) {
        this.$message({
          message: 'API地址不能为空',
          type: 'error'
        })
        return
      }
      this.$refs.pointToMore.validate(valid => {
        if (valid) {
          getSceneParam().then(res => {
            if (res.GetSceneParamResp.Mode === 'speak') {
              const param = {
                ConfSwitch1ToManyReq: {
                  Switch: true
                }
              }
              confSwitch1ToMany(param).then(res => {
                this.mailClassConfigs = false
                this.$message({
                  message: '互动成功',
                  type: 'success'
                })
              }).catch(_ => {
                this.$message({
                  message: '互动失败',
                  type: 'error'
                })
              })
            } else {
              this.$message({
                message: '创会失败,主讲模式才能创会',
                type: 'error'
              })
            }
          })
        }
      })
    },
    callPointToPoint() {
      if (this.interactiveStatus) {
        this.$message({
          showClose: true,
          message: '当前正在互动中...',
          type: 'error'
        })
        return
      }
      this.$refs.pointToPoint.validate(valid => {
        if (valid) {
          if (this.P2PCallCfg.CallType) {
            this.P2PCallCfg.E164Num = ''
          }
          this.form = this.P2PCallCfg
          this.callInter()
        }
      })
    },
    interCall() {
      this.$refs.addInterList.validate(valid => {
        if (valid) {
          this.callInter()
        }
      })
    },
    callInter() { // 呼叫
      getH323Info({}).then(res => {
        this.form.ProtoType = res.GetH323StatusResp.PriorityProto
        let szXml = '<contentroot>'
        szXml += '<authenticationinfo type="7.0">'
        szXml += '<username>' + store.getters.username + '</username>'
        szXml += '<password>' + store.getters.password + '</password>'
        szXml += '<authenticationid>' + store.getters.authId + '</authenticationid>'
        szXml += '</authenticationinfo>'
        szXml += '<StartInteractReq>'
        szXml += this.callInteHtml(this.form)
        szXml += '</StartInteractReq>'
        szXml += '</contentroot>'
        startInteract(szXml).then(res => {
          this.addInterConfig = false
          this.mailClassConfigs = false
          this.getInterIsSuccess()
        })
      })
    },
    getInterIsSuccess() {
      getInteractList({}).then(res => {
        const _that = this
        const interactListInfo = res.GetInteractListResp.InteractList
        if (interactListInfo !== '') {
          const status = interactListInfo.InteractItem.Status
          if (status === 'connected') {
            this.$message({
              showClose: true,
              message: '互动成功',
              type: 'success'
            })
            clearTimeout(this.timeStatus)
          } else {
            this.timeStatus = setTimeout(() => {
              _that.getInterIsSuccess()
            }, 1000)
          }
        } else {
          this.$message({
            showClose: true,
            message: '互动失败',
            type: 'error'
          })
          clearTimeout(this.timeStatus)
        }
      })
    },
    callInteHtml(data) {
      let sXml = ''
      sXml += '<ItemName>' + data.ItemName + '</ItemName>'
      sXml += '<CallType>' + data.CallType + '</CallType>'
      if (data.CallType == 'CallIp') {
        sXml += '<IpAddr>' + data.IpAddr + '</IpAddr>'
      } else if (data.CallType == 'CallE164') {
        sXml += '<E164Num>' + data.E164Num + '</E164Num>'
      }
      sXml += '<CallRate>' + data.CallRate + '</CallRate>'
      sXml += '<DStream>' + data.DStream + '</DStream>'
      sXml += '<ProtoType>' + data.ProtoType + '</ProtoType>'
      return sXml
    },
    getInterList() { // 获取互动信息
      getInteractList({}).then(res => {
        const _that = this
        const interactListInfo = res.GetInteractListResp.InteractList
        if (interactListInfo === '') {
          this.interactiveStatus = false
        } else {
          const status = interactListInfo.InteractItem.Status
          if (status === 'connected') {
            this.interactiveStatus = true
          } else {
            this.interactiveStatus = false
          }
          this.interactInfo = interactListInfo.InteractItem
          this.interAlias = interactListInfo.InteractItem.Alias
          this.InNvrChnId = interactListInfo.InteractItem.InNvrChnId
          this.OutNvrChnId = interactListInfo.InteractItem.OutNvrChnId
        }
        this.timeout = setTimeout(function() {
          _that.getInterList()
        }, 1000)
      })
    },
    getBookList() { // 获取互动列别
      getBookItemList({}).then(res => {
        const bookList = res.GetItemListResp.BookItemList.BookItem
        if (bookList) {
          if (Array.isArray(bookList)) {
            this.BookItemList = bookList.reverse()
          } else {
            this.BookItemList.push(bookList)
          }
        } else {
          this.BookItemList = []
        }
      })
    },
    getDate(diff) { // 时间格式处理
      const nowTime = new Date().getTime()
      const diffValue = (nowTime - new Date(diff).getTime()) / 1000
      const minute = 60
      const hour = minute * 60
      const day = hour * 24
      const month = day * 30
      const monthC = diffValue / month
      const weekC = diffValue / (7 * day)
      const dayC = diffValue / day
      const hourC = diffValue / hour
      const minC = diffValue / minute
      let res = ''
      if (monthC >= 12) {
        const date = new Date(diff)
        res = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate()
      } else if (monthC >= 1) {
        res = parseInt(monthC) + '个月前'
      } else if (weekC >= 1) {
        res = parseInt(weekC) + '周前'
      } else if (dayC >= 1) {
        res = parseInt(dayC) + '天前'
      } else if (hourC >= 1) {
        res = parseInt(hourC) + '小时前'
      } else if (minC >= 1) {
        res = parseInt(minC) + '分钟前'
      } else {
        res = '刚刚'
      }
      return res
    },
    callItemList(callInfo) { // 呼叫记录小图标点击呼叫
      if (this.interactiveStatus) {
        this.$message({
          showClose: true,
          message: '当前正在互动中...',
          type: 'error'
        })
        return
      }
      this.form = {
        CallType: callInfo.CallType,
        CallRate: callInfo.CallRate,
        ItemName: callInfo.ItemName,
        IpAddr: callInfo.IpAddr,
        E164Num: callInfo.E164Num,
        ProtoType: callInfo.ProtoType,
        DStream: callInfo.DStream
      }
      this.callInter()
    },
    showStatisticsInfo() {
      if (this.interactiveStatus) { // 互动中
        this.recStaticsList = []
        this.sendStaticsList = []
        this.getInteractiveInformation()
      }
      this.interStatisticsConfig = true
    },
    getInteractiveInformation() { // 获取互动统计信息
      const param = {
        GetQoeStatusReq: {
          InteractAlias: this.interAlias
        }
      }
      getQoeStatus(param).then(res => {
        this.CallMode = res.GetQoeStatusResp.CallMode
        this.CallFrameRate = res.GetQoeStatusResp.CallFrameRate
        this.CallBitRate = res.GetQoeStatusResp.CallBitRate
        const VidRcvChanMain = res.GetQoeStatusResp.VidRcvChan.MainStream // 接收 主流
        const VidRcvChanSecond = res.GetQoeStatusResp.VidRcvChan.SecondStream// 接收 双流

        const VidSendChanMain = res.GetQoeStatusResp.VidSendChan.MainStream // 发送 主流
        const VidSendChanSecond = res.GetQoeStatusResp.VidSendChan.SecondStream // 发送 双流

        const AudRcvChan = res.GetQoeStatusResp.AudRcvChan // 接收 音频

        const AudSendChan = res.GetQoeStatusResp.AudSendChan // 发送 音频

        this.networkStaticList = []
        const { RecvFrameCnt, PackLossCnt, PackLossPercent } = VidRcvChanMain
        this.networkStaticList.push({ RecvFrameCnt, PackLossCnt, PackLossPercent, name: '主流' })
        this.networkStaticList.push({ RecvFrameCnt: VidRcvChanSecond.RecvFrameCnt, PackLossCnt: VidRcvChanSecond.PackLossCnt, PackLossPercent: VidRcvChanSecond.PackLossPercent, name: '双流' })
        this.networkStaticList.push({ RecvFrameCnt: AudRcvChan.RecvFrameCnt, PackLossCnt: AudRcvChan.PackLossCnt, PackLossPercent: AudRcvChan.PackLossPercent, name: '音频' })
        this.sendStaticsList = []
        this.sendStaticsList.push(
          {
            vMediaEncType: VidSendChanMain.MediaEncType, // 视频协议类型
            vResolution: VidSendChanMain.Resolution, // 视频分辨率
            vFrameRate: VidSendChanMain.FrameRate, // 视频帧率
            vBitRate: VidSendChanMain.BitRate, // 视频码率
            aMediaEncType: AudSendChan.MediaEncType, // 音频协议类型
            aBitRate: AudSendChan.BitRate, // 音频码率
            name: '主流'
          },
          {
            vMediaEncType: VidSendChanSecond.MediaEncType, // 视频协议类型
            vResolution: VidSendChanSecond.Resolution, // 视频分辨率
            vFrameRate: VidSendChanSecond.FrameRate, // 视频帧率
            vBitRate: VidSendChanSecond.BitRate, // 视频码率
            /* aMediaEncType: AudSendChan.MediaEncType,//音频协议类型
            aBitRate: AudSendChan.BitRate,//音频码率 */
            aMediaEncType: '', // 音频协议类型
            aBitRate: '', // 音频码率
            name: '双流'
          }
        )
        this.recStaticsList = []
        this.recStaticsList.push(
          {
            vMediaEncType: VidRcvChanMain.MediaEncType, // 视频协议类型
            vResolution: VidRcvChanMain.Resolution, // 视频分辨率
            vFrameRate: VidRcvChanMain.FrameRate, // 视频帧率
            vBitRate: VidRcvChanMain.BitRate, // 视频码率
            aMediaEncType: AudRcvChan.MediaEncType, // 音频协议类型
            aBitRate: AudRcvChan.BitRate, // 音频码率
            name: '主流'
          },
          {
            vMediaEncType: VidRcvChanSecond.MediaEncType, // 视频协议类型
            vResolution: VidRcvChanSecond.Resolution, // 视频分辨率
            vFrameRate: VidRcvChanSecond.FrameRate, // 视频帧率
            vBitRate: VidRcvChanSecond.BitRate, // 视频码率
            /* aMediaEncType: AudRcvChan.MediaEncType,//音频协议类型
            aBitRate: AudRcvChan.BitRate,//音频码率 */
            aMediaEncType: '', // 音频协议类型
            aBitRate: '', // 音频码率
            name: '双流'
          }
        )
        setTimeout(() => {
          this.getInteractiveInformation()
        }, 1000)
      })
    },
    switchLocalOrDistal(isLocal) {
      this.localOrDistal = isLocal
      if (isLocal === 'local') {
        if (this.isPicture !== 'distal') {
          this.isLocal = true
        } else {
          this.isLocal = false
        }
      } else {
        this.isLocal = false
      }
    },
    mailClassConfig() {
      const obj = {
        MeetTerMinalName: '',
        MeetTerminalAccount: '',
        CallProtoColType: '',
        AccountPasswd: ''
      }
      getH323Info({}).then(res => {
        obj.MeetTerMinalName = res.GetH323StatusResp.PriorityProto === 'SIP' ? res.GetH323StatusResp.SipAlias : res.GetH323StatusResp.H323Alias

        obj.MeetTerminalAccount = res.GetH323StatusResp.PriorityProto === 'SIP' ? res.GetH323StatusResp.SipE164Num : res.GetH323StatusResp.E164Num

        obj.CallProtoColType = res.GetH323StatusResp.PriorityProto === 'SIP' ? '1' : '0'
      })
      this.getP2pCallConfig().then(res => {
        this.P2PCallCfg = res.GetP2PCallCfgResp
      })
      this.getP2MCallConfig().then(res => {
        this.ConfParam = res.GetConfParamResp
        this.ConfParam.ApiSSL = this.ConfParam.ApiSSL !== 'false'
        this.ConfParam.ApiEnable = this.ConfParam.ApiEnable !== 'false'
        this.ConfParam.LectureComp = this.ConfParam.LectureComp !== 'false'
        this.ConfParam.ApiPort = res.GetConfParamResp.ApiSSL ? res.GetConfParamResp.ApiPortSSL : res.GetConfParamResp.ApiPort
        this.InviteMtList = res.GetConfParamResp.InviteMtList.InviteMtItem
        // this.InviteMtList.splice(0,0,obj)
        this.InviteMtList = this.InviteMtList.filter(item => item.MeetTerminalAccount != obj.MeetTerminalAccount)
        this.InviteMtList.splice(0, 0, obj)
      })
      this.mailClassConfigs = true
    },
    getP2pCallConfig() { // 获取点对点呼叫配置
      return new Promise((resolve, reject) => {
        getP2PCallCfg({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    getP2MCallConfig() { // 获取点对多呼叫配置
      return new Promise((resolve, reject) => {
        getConfParam({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    setP2pCallConfig() { // 设置点对点配置
      return new Promise((resolve, reject) => {
        this.$refs.pointToPoint.validate(valid => {
          if (valid) {
            let szXml = '<contentroot>'
            szXml += '<authenticationinfo type="7.0">'
            szXml += '<username>' + store.getters.username + '</username>'
            szXml += '<password>' + store.getters.password + '</password>'
            szXml += '<authenticationid>' + store.getters.authId + '</authenticationid>'
            szXml += '</authenticationinfo>'
            szXml += '<SetP2PCallCfgReq>'
            szXml += this.callInteHtml(this.P2PCallCfg)
            szXml += '</SetP2PCallCfgReq>'
            szXml += '</contentroot>'
            setP2PCallCfg(szXml).then(res => {
              resolve(res)
            }).catch(err => {
              reject(err)
            })
          }
        })
      })
    },
    setP2MCallConfig() { // 设置点对多配置
      return new Promise((resolve, reject) => {
        const SetConfParamReq = this.deepClone(this.ConfParam)
        const value = this.deepClone(this.InviteMtList)
        value.splice(0, 1)
        SetConfParamReq.InviteMtList = {
          K_E_Y: 'InviteMtItem',
          P_R_O_P: {
            num: this.InviteMtList.length
          },
          V_A_L_U_E: value
        }
        const param = {
          SetConfParamReq: SetConfParamReq
        }
        setConfParam(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    deepClone(obj) {
      const objClone = Array.isArray(obj) ? [] : {}
      if (obj && typeof obj === 'object') {
        for (const key in obj) {
          if (obj[key] && typeof obj[key] === 'object') {
            objClone[key] = this.deepClone(obj[key])
          } else {
            objClone[key] = obj[key]
          }
        }
      }
      return objClone
    },
    saveMail() {
      this.$refs.pointToMore.validate(valid => {
        if (valid) {
          this.setP2MCallConfig().then(res => {
            this.mailClassConfigs = false
            this.$message({
              message: '保存成功',
              type: 'success'
            })
          })
        }
      })
    },
    savePoint() {
      this.setP2pCallConfig().then(res => {
        this.$message({
          message: '保存成功',
          type: 'success'
        })
        this.mailClassConfigs = false
      })
    },
    addMailInfo() { // 添加专递课堂信息
      this.addMailConfig = true
      this.addMial = {
        MeetTerMinalName: '',
        MeetTerminalAccount: '',
        CallProtoColType: '0',
        AccountPasswd: ''
      }
    },
    removeMailInfo(info) { // 移除专递课堂信息
      this.removeMailInfos = info
    },
    editMailInfo(info) { // 编辑专递课堂信息
      this.addMailConfig = true
      this.isEdit = true
      this.editIndex = this.InviteMtList.findIndex(item => item.MeetTerminalAccount == info.MeetTerminalAccount)
      this.addMial = JSON.parse(JSON.stringify(info))
    },
    addOrEditMail() {
      if (this.addMial.MeetTerMinalName === '') {
        this.$message({
          message: '终端名称不能为空',
          type: 'error'
        })
        return
      } else if (this.addMial.MeetTerminalAccount === '') {
        this.$message({
          message: '终端账号不能为空',
          type: 'error'
        })
        return
      }

      if (this.accountHasRepeat(this.addMial)) {
        this.$message({
          message: '此终端账号已存在',
          type: 'error',
          showClose: true
        })
        return
      }
      // 删除用于校验是否修改自身账号的参数
      delete this.addMial.index
      let index
      let message
      if (this.isEdit) {
        index = this.editIndex
        message = '编辑成功'
      } else {
        index = this.InviteMtList.findIndex(item => item.MeetTerMinalName === '' || item.MeetTerminalAccount == '')
        message = '添加成功'
      }
      const objMain = this.InviteMtList[0]
      this.InviteMtList.splice(index, 1, this.addMial)
      this.InviteMtList.splice(0, 1)
      this.setP2MCallConfig().then(res => {
        this.$message({
          message: message,
          type: 'success'
        })
        this.addMailConfig = false
        this.isEdit = false
        this.editIndex = -1
      })
      this.InviteMtList.splice(0, 0, objMain)
    },
    // 校验终端账号是否重复
    accountHasRepeat(data) {
      const index = this.InviteMtList.findIndex((item) => {
        return item.MeetTerminalAccount === data.MeetTerminalAccount
      })
      // 添加时,当前账号已存在,且不是当前被修改项
      return index > -1 && index !== data.index
    },
    removeMailInfoList() {
      if (this.removeMailInfos.length === 0) {
        this.$message({
          message: '请先选择要删除的元素',
          type: 'warning'
        })
        return
      }
      this.removeMailInfos.forEach(item => {
        const index = this.InviteMtList.findIndex(inviItem => item.MeetTerMinalName == inviItem.MeetTerMinalName)
        this.InviteMtList.splice(index, 1, {
          MeetTerMinalName: '',
          MeetTerminalAccount: '',
          CallProtoColType: '0',
          AccountPasswd: ''
        })
      })
      const objMain = this.InviteMtList[0]
      this.InviteMtList.splice(0, 1)
      this.setP2MCallConfig().then(res => {
        this.$message({
          message: '删除成功',
          type: 'success'
        })
      })
      this.InviteMtList.splice(0, 0, objMain)
    },
    changeApiSsl() {
      if (this.ConfParam.ApiSSL) {
        this.ConfParam.ApiPort = '443'
      } else {
        this.ConfParam.ApiPort = '80'
      }
    }
  }
}
</script>

<style lang="scss">
// 防止出现横向滚动条
.inter-list-cart-container {
  .el-scrollbar__wrap {
    overflow-x: hidden;
  }
}

// 左侧互动记录列表
.bubble-panel {
  background: #373F4F;
  border-color: #373F4F;
  box-shadow: 0 3px 6px -4px rgba(0,0,0,0.48), 0 6px 16px 0 rgba(0,0,0,0.32), 0 9px 28px 8px rgba(0,0,0,0.20);

  // popper弹框箭头
  &[x-placement^=right] .popper__arrow::after{
    border-right-color: #373F4F;
  }

  .buddle-item {
    padding-top: 12px;
    padding-left: 12px;
    display: flex;
    justify-content: flex-start;
    padding-left: 32px;
    align-items: center;

    .buddle-label {
      font-weight: normal;
      font-size: 14px;
      color: rgba(255,255,255,0.45);
    }
    span {
      padding-left: 8px;
      font-size: 14px;
    }
  }
}
.add-inter-config {
  .el-dialog {
    width: 540px;
  }
}
.statis-info {
  .el-dialog {
    width: 860px;
  }
}
.mail-inter-config {
  .el-dialog {
    width: 980px;
  }
}
.el-tabs__item {
  color: rgba(255,255,255,0.85);
}
.el-tabs__nav-wrap::after {
  background-color: rgba(255, 255, 255, 0.12);
}
.double-stream-select {
  width: 150px;
  .el-input {
    input {
      height: 26px;
      line-height: 26px;
    }
  }
}
 #play_local {
  .kmd-controls {
    .kmd-cs-right {
      float: left;
    }
  }
  .kmd-control-container {
    .kmd-shade {
      background: #2A313E;
      opacity: 1;
    }
    .kmd-slot-item {
      background: #2A313E;
    }
  }
}
</style>
<style lang="scss" scoped>
.interactive-content-container {
  display: flex;
  .interactive-record {
    height: calc(100vh - 74px);
    background: rgba(0,0,0,0);
    padding-right: 4px;
    .interactive-record-container {
      background: #2A313E;
      .add-container {
        padding: 12px 20px;
        .no-interactive {
          background: #373F4F;
          .title-container {
            .title-icon {
              display: flex;
              justify-content: center;
              padding-top: 24px;
              .icon-interactive {
                width: 48px;
                height: 48px;
                background: url(../../assets/img/nav_inter.png) no-repeat center center;
              }
            }
            .title-status {
              display: flex;
              justify-content: center;
              padding-bottom: 16px;
              padding-top: 12px;
            }
          }
          .button-container {
            display: flex;
            justify-content: center;
            padding-bottom: 16px;
            .default {
              width: 70%;
            }
          }
        }
        .has-interactive {
          background: #373F4F;
          .link-alias {
            display: flex;
            justify-content: center;
            padding-top: 32px;
            .title {
              font-size: 18px;
              color: #fff;

            }
          }
          .has-time-title {
            height: 56px;
          }
          .link-icon {
            display: flex;
            justify-content: center;
            padding-bottom: 16px;
            .link-icon-hang {
              width: 48px;
              height: 48px;
              background: #FF4A40;
              border-radius: 50%;
              display: flex;
              justify-content: center;
              align-items: center;
              cursor: pointer;
              &:hover {
                background: #F1362C;
              }
              .icon-hang-up {
                width: 24px;
                height: 9px;
                background: url(../../assets/img/interactive_hang_up.png) no-repeat center center;
              }
            }
          }
        }
      }
    }
    .inter-list {
      padding-left: 20px;
      padding-top: 24px;
      .font0 {
        font-size: 0px;
        padding-bottom: 12px;
        span {
          font-size: 20px;
        }
      }
      .gap-line {
        display: block;
        height: 1px;
        width: 100%;
        background: #0E1116;
        box-shadow: 0 1px 0 0 #3B4455;
      }
      .inter-list-cart-container {
        height: calc(100vh - 383px);
        .inter-list-cart {
          display: flex;
          justify-content: center;
          align-items: center;
          position: relative;

          .img-item {
            width: 16px;
            height: 16px;
            .icon-caller {
              display: inline-block;
              width: 16px;
              height: 16px;
              &.caller {
                background: url(../../assets/img/inter_call_no.png) no-repeat center center;
              }
            }
          }
          .itter-item-con {
            flex: 1;
            padding-top: 12px;
            .line-item {
              padding-left: 12px;
            }
            .inter-item {
              display: flex;
              padding-left: 12px;
              padding-bottom: 12px;
              .call-info {
                flex: 1;
                .title {
                  width: 80%;
                  max-width: 80%;
                  overflow:hidden;
                  text-overflow:ellipsis;
                  white-space:nowrap;
                  font-size: 16px;
                  &.time-title {
                    color: rgba(255,255,255,0.45);
                    font-size: 14px;
                    padding-top: 4px;
                  }
                }
              }
              .call-button {
                padding-right: 12px;
                width: 48px;
                .right-call {
                  display: inline-block;
                  width: 36px;
                  height: 36px;
                  background-image: linear-gradient(180deg, #404859 0%, #2A313E 100%);
                  border: 1px solid #151A23;
                  border-radius: 50%;
                  cursor: pointer;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  &:hover {
                    background-image: linear-gradient(180deg, #4F596C 0%, #363F4F 100%);
                  }
                  .icon-call {
                    width: 16px;
                    height: 16px;
                    background: url(../../assets/img/inter_call.png) no-repeat center center;
                  }
                }
              }
            }
          }
        }
      }
      .mail-class-config-button {
        padding: 12px 20px 12px 0;
        background-color: #2A313E;
        .primary {
          width: 100%;
        }
      }
    }
  }
  .interactive-play-cont {
    height: calc(100vh - 74px);
    background: rgba(0,0,0,0);
    position: relative;
    .fun-button-container {
      position: absolute;
      top: 12px;
      left: 50%;
      transform: translateX(-50%);
      padding: 4px 4px;
      background-color: #2A313E;
      border-radius: 2px;
      z-index: 890;
      .default {
        box-sizing: border-box;
        border-color: transparent;
      }
      .primary {
        box-sizing: border-box;
        border-color: transparent;
      }

      .default:hover {
        border: 1px solid #1F75FF;
      }
    }
    .foot-opeartion {
      position: absolute;
      bottom: 1px;
      right: 0px;
      left: 2px;
      height: 40px;
      background: #2A313E;
      width: calc(100% - 4px);
      display: flex;
      justify-content: space-between;
      padding-right: 20px;
      align-items: center;
      z-index: 890;
      .left-play-operation {
        padding-left: 20px;
        display: flex;
        align-items: center;
        .volume-control {
          display: flex;
          align-items: center;
          justify-content: center;
          background: lighten;
          .volume-control-icon {
            width: 16px;
            height: 16px;
            cursor: pointer;
            background: url(../../assets/img/volume.png) no-repeat center center;
            &.isMuted {
              background: url(../../assets/img/muted.png) no-repeat center center;
            }
          }
          .el-slider {
            width: 50px;
            margin-left: 12px;
          }
        }
        .screen-full {
          margin-left: 12px;
          display: flex;
          align-items: center;
          height: 40px;
          width: 32px;
          justify-content: center;
          background: lighten;
          .full-screen-icon {
            width: 16px;
            height: 16px;
            cursor: pointer;
            background: url(../../assets/img/full_screen.png) no-repeat center center;
          }
        }
      }
      .default {
        height: 24px;
        line-height: 22px;
        padding-left: 11px;
        padding-right: 11px;
      }
    }
    .play-container {
      width: 100%;
      height: 100%;
      .play-local {
        height: 100%;
        cursor: pointer;
        border: 1px solid #0E1116;
        &.playActive {
          border: 1px solid skyblue;
        }
        #play_local {
          height: 100%;
          .kmd-controls {
            .kmd-cs-right {
              float: left;
            }
          }
        }
      }
      .play-distal {
        position: absolute;
        width: 432px;
        height: 243px;
        right: 0px;
        bottom: 42px;
        cursor: pointer;
        border: 1px solid #0E1116;
        &.playActive {
          border: 1px solid skyblue;
        }
        #play_distal {
          height: 100%;
        }
      }
    }
  }
}
.mail-inter-config {
    .tip-model {
      padding: 12px 0px;
    }
    .tip-model-top {
      display: flex;
      .tip-model-top-item {
        flex: 1;
        .input-width-default {
          width: 110px;
        }
      }
    }
    .point-to-point-btngroup {
      text-align: right;
      padding: 4px 0;
    }
    .tip-model-more {
      .inte-param-config {
        display: flex;
        .inte-param-flex {
          flex: 1;
          .input-width-default {
            width: 110px;
          }
        }
      }
    }
  }
</style>
