<template>
  <div class="inter-statis-config">
    <div class="static-info">
      <div>
        <label for="" class="font-title-color">互动模式:</label>
        <span class="font-title-color paddingLeft16">{{ CallMode == '0' ? '空闲' : (CallMode == '1' ? '点对点' : '点对多') }}</span>
      </div>
      <div>
        <label for="" class="font-title-color paddingLeft16">互动码率:</label>
        <span class="font-title-color paddingLeft16">{{ CallBitRate }} Kbps</span>
      </div>
      <div>
        <label for="" class="font-title-color paddingLeft16">互动帧率:</label>
        <span class="font-title-color paddingLeft16">{{ CallFrameRate }}</span>
      </div>
    </div>
    <div class="static-list">
      <div class="static-list-row">
        <el-table
          :data="sendStaticsList"
          style="width: 100%">
          <el-table-column
            prop="name"
            label="发送统计"
            width="100">
          </el-table-column>
          <el-table-column
            prop="aMediaEncType"
            label="音频协议"
            width="116">
            <template scope="scope">
              <div>{{ scope.row.aMediaEncType == '' ? '---' : scope.row.aMediaEncType }}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="aBitRate"
            label="音频码率" width="116">
            <template scope="scope">
              <div>{{ scope.row.aBitRate == '' ? '---' : (scope.row.aBitRate + ' Kbps') }}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="vMediaEncType"
            label="视频协议" width="116">
          </el-table-column>
          <el-table-column
            prop="vResolution"
            label="分辨率" width="160">
          </el-table-column>
          <el-table-column
            prop="vBitRate"
            label="视频码率" width="116">
            <template scope="scope">
              <div>{{ scope.row.vBitRate + ' Kbps' }}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="vFrameRate"
            label="视频帧率">
            <template scope="scope">
              <div>{{ scope.row.vFrameRate + ' fps' }}</div>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <div class="static-list-row rec-list">
        <el-table
          :data="recStaticsList"
          style="width: 100%">
          <el-table-column
            prop="name"
            label="接收统计"
            width="100">
          </el-table-column>
          <el-table-column
            prop="aMediaEncType"
            label="音频协议"
            width="116">
            <template scope="scope">
              <div>{{ scope.row.aMediaEncType == '' ? '---' : scope.row.aMediaEncType }}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="aBitRate"
            label="音频码率" width="116">
            <template scope="scope">
              <div>{{ scope.row.aBitRate == '' ? '---' : (scope.row.aBitRate + ' Kbps') }}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="vMediaEncType"
            label="视频协议" width="116">
            <template scope="scope">
              <div>{{ scope.row.vMediaEncType == '' ? '---' : scope.row.vMediaEncType }}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="vResolution"
            label="分辨率" width="160">
            <template scope="scope">
              <div>{{ scope.row.vResolution == '' ? '---' : scope.row.vResolution }}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="vBitRate"
            label="视频码率" width="116">
            <template scope="scope">
              <div>{{ scope.row.vBitRate == '0' ? '---' : (scope.row.vBitRate  + ' Kbps') }}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="vFrameRate"
            label="视频帧率">
            <template scope="scope">
              <div>{{ scope.row.vFrameRate == '0' ? '---' : (scope.row.vFrameRate  + ' fps') }}</div>
            </template>
          </el-table-column>
        </el-table>
      </div>

    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  methods: {
    getInteractiveInformation(){

    }
  },
  props: {
    interAlias: {
      default: '',
      type: String
    },
    CallMode: {
      type: String,
      default: '空闲'
    },
    CallBitRate: {
      type: String,
      default: '2048'
    },
    CallFrameRate: {
      type: String,
      default: '30'
    },
    sendStaticsList: {
      type: Array,
      default: []
    },
    recStaticsList: {
      type: Array,
      default: []
    }
  }
}
</script>
<style lang="scss">
.static-list-row {
  .el-table {
    th {
      text-align: center;
    }
    td {
      text-align: center;
    }
  }
}
</style>
<style lang="scss" scoped>
.inter-statis-config {
  .static-info {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    height: 40px;
    line-height: 40px;
  }
  .static-list-row {
    padding-top: 16px;
    &.rec-list {
      padding-top: 32px;
    }
  }
}
</style>
