<template>
  <div class="point-to-more-list">
    <el-table
      :data="pointToMoreList"
      style="width: 100%"
      @selection-change="selectInfo"
    >
      <el-table-column
        type="selection"
        width="40"
        :selectable="selectable"
      />
      <el-table-column
        prop="name"
        label="编号"
        type="index"
        width="60"
      />
      <el-table-column
        prop=""
        label="终端别名"
        width="200"
      >
        <template
          v-show
          scope="scope"
        >
          <div>{{ scope.row.MeetTerMinalName }}</div>
        </template>
      </el-table-column>
      <el-table-column
        prop=""
        label="终端账号"
        width="200"
      >
        <template slot-scope="scope">
          <div>{{ scope.row.MeetTerminalAccount }}</div>
        </template>
      </el-table-column>
      <el-table-column
        prop=""
        label="教室类型"
        width="100"
      >
        <template scope="scope">
          <div v-show="scope.row.MeetTerminalAccount"> {{ scope.$index == 0 ? '主讲' : '听讲' }}</div>
        </template>
      </el-table-column>
      <el-table-column
        prop=""
        label="协议类型"
        width="100"
      >
        <template scope="scope">
          <div v-show="scope.row.MeetTerminalAccount">{{ scope.row.CallProtoColType == '0' ? 'H323' : 'SIP' }}</div>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template scope="scope">
          <div
            class="table-edit"
            @click="edit(scope.row,scope.$index)"
          >编辑</div>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  props: {
    pointToMoreList: {
      default: [],
      type: Array
    }
  },
  data() {
    return {}
  },
  methods: {
    edit(row, index) {
      if (index === 0) {
        this.$message({
          message: '此条信息无编辑权限',
          type: 'warning'
        })
        return
      } else {
        row.index = index
        this.$emit('edit', row)
      }
    },
    selectInfo(info) {
      this.$emit('deleteInfo', info)
    },
    selectable(row, index) {
      if (index === 0) {
        return false
      } else {
        return true
      }
    }
  }
}
</script>

<style lang="scss">
.point-to-more-list {
  padding-top: 16px;
  .el-table {
    th {
      text-align: center;
    }
    td {
      text-align: center;
    }
    .table-edit {
      cursor: pointer;
    }
  }
}
</style>
