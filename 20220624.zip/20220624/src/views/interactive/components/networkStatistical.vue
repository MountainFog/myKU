<template>
  <div class="network-static-config">
    <div class="device-list">
      <el-table
        :data="networkStaticList"
        style="width: 100%">
        <el-table-column
          prop="name"
          label="网络统计"
          width="205">
        </el-table-column>
        <el-table-column
          prop="RecvFrameCnt"
          label="收到帧数"
          width="205">
        </el-table-column>
        <el-table-column
          prop="PackLossPercent"
          label="网络丢包率" width="205">
          <template scope="scope">
            <div>{{ scope.row.PackLossPercent + '%' }}</div>
          </template>
        </el-table-column>
        <el-table-column
          prop="PackLossCnt"
          label="网络丢包数">
        </el-table-column>
      </el-table>
      </div>
  </div>
</template>

<script>
export default {
  props: {
    networkStaticList: {
      default: [],
      type: Array
    },
    interAlias: {
      default: '',
      type: String
    }
  },
  data() {
    return {
      tableData: []
    }
  },
  methods: {
    getInteractiveInformation(){

    }
  }
}
</script>

<style lang="scss">
.device-list {
  .el-table {
    th {
      text-align: center;
    }
    td {
      text-align: center;
    }
  }
}
</style>
<style lang="scss" scoped>
</style>
