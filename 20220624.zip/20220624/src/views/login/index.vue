<template>
  <div class="login-container">
    <!-- 登录框 -->
    <div class="login-wrapper">
      <!-- 登录框图标 -->
      <div class="login-banner" />
      <div class="login-form">
        <!-- 登录表单 -->
        <el-form ref="loginForm" :model="loginForm" :rules="loginRules" class="el-login-form" auto-complete="on" label-position="left">
          <div class="title-container">
            <p class="title">欢迎回来</p>
          </div>
          <!-- 用户名 -->
          <el-form-item prop="username">
            <el-input
              ref="username"
              v-model="loginForm.username"
              placeholder="Username"
              name="username"
              type="text"
              tabindex="1"
              auto-complete="on"
            />
          </el-form-item>
          <!-- 密码 -->
          <el-form-item prop="password">
            <el-input
              ref="password"
              v-model="loginForm.password"
              placeholder="Password"
              name="password"
              tabindex="2"
              auto-complete="on"
              show-password
              @keyup.enter.native="handleLogin"
            />
          </el-form-item>
          <!-- 登录按钮 -->
          <el-button :loading="loading" type="primary" class="login-btn" @click.native.prevent="handleLogin">登录</el-button>

        </el-form>
        <div class="client-download">
          <a href="/netpack/lbstation_setup.exe">客户端下载</a>
        </div>
      </div>
    </div>
    <div class="login-bgimg" />
  </div>
</template>

<script>
import { validUsername } from '@/utils/validate'
export default {
  name: 'Login',
  data() {
    const validateUsername = (rule, value, callback) => {
      if (!validUsername(value)) {
        callback(new Error('请输入正确的用户名'))
      } else {
        callback()
      }
    }
    const validatePassword = (rule, value, callback) => {
      if (value.length < 6) {
        callback(new Error('密码不能少于6位'))
      } else {
        callback()
      }
    }
    return {
      loginForm: {
        username: '',
        password: ''
      },
      loginRules: {
        username: [{ required: true, trigger: 'blur', validator: validateUsername }],
        password: [{ required: true, trigger: 'blur', validator: validatePassword }]
      },
      loading: false,
      redirect: undefined
    }
  },
  watch: {
    $route: {
      handler: function(route) {
        this.redirect = route.query && route.query.redirect
      },
      immediate: true
    }
  },
  methods: {
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true
          this.$store.dispatch('user/login', this.loginForm).then((res) => {
            this.$router.push({ path: this.redirect || '/' })
            this.loading = false
          }).catch(() => {
            this.loading = false
          })
        }
      })
    }
  }
}
</script>

<style lang="scss">

$bg:#283443;
$light_gray:#fff;
$cursor: #fff;

@supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
  .login-container .el-input input {
    color: $cursor;
  }
}

/* 重置elementui组件样式 */
.login-container {
  .el-input {
    display: inline-block;
    height: 68px;

    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 12px 24px;
      color: $-fff-85;
      height: 68px;
      caret-color: $cursor;
      font-size: 28px;

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
  }

  .el-form-item {
    height: 68px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    color: #454545;

    .el-form-item__error {
      top: 100%;
    }
  }
}
</style>

<style lang="scss" scoped>
$bg:#0D1016;
$dark_gray:#889aa4;
$light_gray:#eee;

.login-container {
  position: relative;
  height: 100%;
  width: 100%;
  min-width: 1366px;
  min-height: 768px;
  background-color: $bg;
  overflow: auto;

  // 登录页背景图
  .login-bgimg {
    position: absolute;
    top: 0;
    right: 0;
    width: 50%;
    height: 100%;
    background-image: url(~@/assets/img/login_bg.png);
    background-repeat: no-repeat;
    background-size: cover;
  }

  // 登录框
  .login-wrapper {
    position: absolute;
    left: 9.2%;
    top: 11.1%;
    width: 81.6%;
    height: 77.8%;
    background-color: #2A313E;
    border-radius: 18px;
    z-index: 1;
  }

  // 登录框图片
  .login-banner {
    position: absolute;
    left: 0;
    top: 0;
    width: 46.8%;
    height: 100%;
    background-image: url(~@/assets/img/login_banner.png);
    background-repeat:  no-repeat;
    background-size: 100% 100%;
  }

  // 登录标题
  .title-container {
    position: relative;
    padding-bottom: 20px;

    .title {
      margin: 0;
      font-family: PingFangSC-Regular;
      font-size: 56px;
      color: $-fff-85;
      text-align: center;
      font-weight: bold;
    }
  }

  // 登录表单
  .login-form {
    position: relative;
    float: right;
    width: 53.2%;
    height: 100%;
    max-width: 100%;
    background-image: url(~@/assets/img/login_title.png);
    background-repeat: no-repeat;
    background-size: 96px 20px;
    background-position: calc(100% - 24px) 24px;
    overflow: hidden;
    vertical-align: middle;
    text-align: center;

    .el-login-form {
      display: inline-block;
      width: 490px;
      vertical-align: middle;
    }

    .el-form-item {
      margin: 40px 0;
    }

    // 登录错误提示
    .login-err-tips {
      height: 20px;
      color: #FF555D;
      line-height: 20px;
      text-align: left;
    }

    // 登录按钮
    .login-btn {
      width: 100%;
      height: 68px;
      background-color: #1F75FF;
      border: none;
      font-size: 32px;
      letter-spacing: 8px;
    }

    &::before {
      content: "";
      display: inline-block;
      height: 100%;
      vertical-align: middle;
    }
  }

  // 显示密码
  .show-pwd {
    position: absolute;
    right: 10px;
    top: 14px;
    font-size: 16px;
    color: $dark_gray;
    cursor: pointer;
    user-select: none;
  }

  // 客户端下载
  .client-download {
    position: absolute;
    right: 32px;
    bottom: 32px;

    a {
      font-size: 24px;
      color: #1F75FF;
      text-decoration: underline;
    }
  }
}
</style>
