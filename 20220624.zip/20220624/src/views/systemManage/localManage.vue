<template>
  <div class="local-manage-config">
    <div class="kd-main-title">系统配置 / 本地配置</div>
    <div class="local-content">
      <div class="font-title-color local-title">播放参数</div>
      <div class="play-config">
        <div class="config-stream-media flex-center">
          <label for="" class="local-config-title">协议类型:</label>
          <div>
            <el-radio v-model="TransType" class="proto-type" label="tcp">TCP</el-radio>
            <el-radio v-model="TransType" class="proto-type" label="udp_unicast">UDP</el-radio>
          </div>
        </div>
        <div class="config-stream-media flex-center">
          <label for="" class="local-config-title">播放性能:</label>
          <div>
            <el-radio v-model="DecMode" class="proto-type" label="Realtime">实时性好</el-radio>
            <el-radio v-model="DecMode" class="proto-type" label="Balanced">均衡</el-radio>
            <el-radio v-model="DecMode" class="proto-type" label="Smooth">流畅</el-radio>
          </div>
        </div>
        <div class="config-stream-media flex-center paddingTop20">
          <label for="" class="local-config-title"></label>
          <div class="basic-btn-container">
            <input type="button" @click="saveLocal" class="primary default-border-radius" value="保存"/>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Cookies from 'js-cookie'
export default {
  data() {
    return {
      DecMode: 'Realtime',
      TransType: 'tcp'
    }
  },
  components: {
    /* breadCrumb */
  },
  methods: {
    saveLocal() {
      Cookies.set('TransType', this.TransType)
      Cookies.set('DecMode', this.DecMode)
      this.$message({
        message: '本地保存成功',
        type: 'success'
      });
    }
  },
  created() {
    this.DecMode = Cookies.get('DecMode') ? Cookies.get('DecMode') : 'Realtime'
    this.TransType = Cookies.get('TransType') ? Cookies.get('TransType') : 'tcp'
  }
}
</script>

<style scoped="scoped" lang="scss">
  .local-content {
    .local-title {
      padding: 16px 0px;
      font-size: 20px;
      line-height: 28px;
    }
    .play-config {
      .config-stream-media {
        padding: 8px 0px;
        &.paddingTop20 {
          padding-top: 20px;
        }
        .local-config-title {
          width: 150px;
          font-size: 14px;
          padding-left: 24px;
          font-weight: normal;
        }
        .proto-type {
          width: 100px;
        }
      }
    }
  }
</style>
