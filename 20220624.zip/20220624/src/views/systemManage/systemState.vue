<template>
  <div class="system-state-page">
    <div class="kd-main-title">系统配置 / 系统状态</div>
    <el-table :data="tableData">
      <el-table-column label="接口名称" prop="name" header-align="center" align="center" />
      <el-table-column label="状态" prop="status" header-align="center" align="center" />
      <el-table-column label="分辨率" prop="resolution" header-align="center" align="center" />
      <el-table-column label="帧率" prop="frameRate" header-align="center" align="center" />
    </el-table>
  </div>
</template>
<script>
import { getVmtInputStatus } from '@/api/systemConfig'
export default {
  name: 'SystemState',
  data() {
    return {
      tableData: []
    }
  },
  mounted() {
    this.getVmtInputStatus()
  },
  methods: {
    getVmtInputStatus() {
      this.tableData = []
      getVmtInputStatus().then(res => {
        let list = res.VmtInputStatusResp.PortList.PortItem
        if (!Array.isArray(list)) {
          list = [list]
        }
        const tableData = []
        list.forEach(item => {
          tableData.push({
            name: item.PortType.replace(/\_/, ' ').toUpperCase(),
            status: item.Width === '0' ? '空闲' : '占用',
            resolution: `${item.Width}*${item.Heigth}(${this.toLogogram(item.ScanType)})`,
            frameRate: item.FrameRate + 'fps'
          })
        })
        this.tableData = tableData
      })
    },
    toLogogram(text) {
      return text.substring(0, 1).toUpperCase()
    }
  }
}
</script>
