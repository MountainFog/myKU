<template>
  <div class="basic-param-config">
    <div class="kd-main-title">系统配置 / 基本参数</div>
    <div class="basic-config">
      <el-form :rules="rules" ref="basicForm" :model="Ntp">
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="basic-config-title">设备名称:</label>
            <div>
              <el-input type="text" v-model="deviceName" class="config-stream-input border-input-default default-border-radius" />
            </div>
          </div>
        </el-form-item>
        <div class="config-stream-media paddingTop16">
          <label for="" class="basic-config-title">时间设置</label>
        </div>
        <div class="paddingTop16">
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="basic-config-title paddingLeft24">设备时区:</label>
            <div>
              <el-select :disabled="disabledDevice" v-model="deviceZone" class="border-select-default" placeholder="请选择">
                <el-option
                  v-for="item in deviceZoneList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </div>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="basic-config-title paddingLeft24">设备时间:</label>
            <div class="synch-time">
              <el-date-picker
                :disabled="disabledDevice"
                class="svr-pick-time"
                v-model="deviceTime"
                :default-value="deviceTime"
                type="datetime"
                value-format="yyyy-MM-dd HH:mm:ss"
                placeholder="选择日期时间">
              </el-date-picker>
              <div class="synch-content">
                <el-checkbox v-model="synchronous" :disabled="recodingStatus" @change="changeTime" class="font-title-table">与计算机时间同步</el-checkbox>
              </div>
            </div>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="basic-config-title paddingLeft24">自动校时:</label>
            <div>
              <el-radio v-model="autoCorrect" :disabled="recodingStatus" :label="true">开启</el-radio>
              <el-radio v-model="autoCorrect" :disabled="recodingStatus" :label="false">关闭</el-radio>
            </div>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="basic-config-title paddingLeft24">校时方式:</label>
            <div>
              <el-select v-model="timeType" class="border-select-default" placeholder="请选择">
                <el-option
                  v-for="item in timeTypeList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </div>
          </div>
        </el-form-item>
        </div>
        <div class="" v-if="timeType == 'NTP'">
          <div class="config-stream-media paddingTop16">
            <label for="" class="basic-config-title">NTP设置:</label>
          </div>
          <el-form-item prop="ServerIP">
            <div class="config-stream-media">
              <label for="" class="basic-config-title paddingLeft24">服务器地址:</label>
              <el-input type="text" v-model="Ntp.ServerIP" class="config-stream-input border-input-default default-border-radius" />
            </div>
          </el-form-item>
          <el-form-item>
            <div class="config-stream-media">
              <label for="" class="basic-config-title paddingLeft24">服务器端口:</label>
              <el-input type="text" disabled="true" v-model="Ntp.ServerPort" class="config-stream-input border-input-default default-border-radius" />
            </div>
          </el-form-item>
          <el-form-item prop="Interval">
            <div class="config-stream-media">
              <label for="" class="basic-config-title paddingLeft24">校时间隔:</label>
              <el-input type="text" v-model.number="Ntp.Interval" class="config-stream-input border-input-default default-border-radius" />
              <span class="font-title-table gap-title">1-1440(分钟)</span>
            </div>
          </el-form-item>
        </div>
      </el-form>
      <div class="config-stream-media">
        <label for="" class="basic-config-title paddingLeft24"></label>
        <div class="basic-btn-container">
          <input type="button" class="primary default-border-radius" @click="saveSysTimeInfo" value="保存"/>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { validateIP } from '@/utils/validateModule'
import Cookies from 'js-cookie'
import {setSysTimeInfo,getSysTimeInfo,getSysBasicInfo,setSysBasicInfo} from '@/api/systemConfig'
import { dateFormat } from '@/utils/dateFormat'
import { getSvrStateEx } from '@/api/leadsBroadcasts.js'
export default {
  data(){
    return {
      rules: {
        ServerIP: [{ required: true, trigger: 'blur', validator: validateIP }],
        Interval: [{ max: 1440, min: 1, type: 'number', message: '间隔不在要求范围之内', trigger: 'blur' }]
      },
      recodingStatus: false,
      recodingTime: null,
      disabledDevice:false,
      synchronous:false,
      deviceName:'',
      GetSysBasicInfoResp:{},
      deviceTime:'',
      deviceZone:'',
      Ntp:{
        Enable:false,
        ServerIP:'0.0.0.0',
        ServerPort:'123',
        Interval:60
      },
      deviceZoneList:[
        {
          label:'(UTC-12:00)日界线西)',
          value:'-12:00'
        },
        {
          label:'(UTC-11:00)中途岛、萨摩亚群岛)',
          value:'-11:00'
        },
        {
          label:'(UTC-10:00)夏威夷)',
          value:'-10:00'
        },
        {
          label:'(UTC-09:00)阿拉斯加)',
          value:'-09:00'
        },
        {
          label:'(UTC-08:00)太平洋时间(美国和加拿大))',
          value:'-08:00'
        },
        {
          label:'(UTC-07:00)山地时间(美国和加拿大))',
          value:'-07:00'
        },
        {
          label:'(UTC-06:00)中部时间(美国和加拿大))',
          value:'-06:00'
        },
        {
          label:'(UTC-05:00)东部时间(美国和加拿大))',
          value:'-05:00'
        },
        {
          label:'(UTC-04:30)加拉加斯)',
          value:'-04:30'
        },
        {
          label:'(UTC-04:00)大西洋时间(加拿大))',
          value:'-04:00'
        },
        {
          label:'(UTC-03:30)纽芬兰)',
          value:'-03:30'
        },
        {
          label:'(UTC-03:00)乔治敦、巴西利亚)',
          value:'-03:00'
        },
        {
          label:'(UTC-02:00)中大西洋)',
          value:'-02:00'
        },
        {
          label:'(UTC-01:00)佛得角群岛、亚速尔群岛)',
          value:'-01:00'
        },
        {
          label:'(UTC+00:00)都柏林、爱丁堡、伦敦)',
          value:'+00:00'
        },
        {
          label:'(UTC+01:00)阿姆斯特丹、柏林、罗马、巴黎)',
          value:'+01:00'
        },
        {
          label:'(UTC+02:00)雅典、耶路撒冷、伊斯坦布尔)',
          value:'+02:00'
        },
        {
          label:'(UTC+03:00)巴格达、科威特、莫斯科)',
          value:'+03:00'
        },
        {
          label:'(UTC+03:30)德黑兰)',
          value:'+03:30'
        },
        {
          label:'(UTC+04:00)高加索标准时间)',
          value:'+04:00'
        },
        {
          label:'(UTC+04:30)喀布尔)',
          value:'+04:30'
        },
        {
          label:'(UTC+05:00)伊斯兰堡、卡拉奇、塔什干)',
          value:'+05:00'
        },
        {
          label:'(UTC+05:30)马德拉斯、孟买、新德里)',
          value:'+05:30'
        },
        {
          label:'(UTC+05:45)加德满都)',
          value:'+05:45'
        },
        {
          label:'(UTC+06:00)阿拉木图、新西伯利亚、达卡)',
          value:'+06:00'
        },
        {
          label:'(UTC+06:30)仰光)',
          value:'+06:30'
        },
        {
          label:'(UTC+07:00)曼谷、河内、雅加达)',
          value:'+07:00'
        },
        {
          label:'(UTC+08:00)北京、乌鲁木齐、新加坡)',
          value:'+08:00'
        },
        {
          label:'(UTC+09:00)首尔、东京、大阪、札幌)',
          value:'+09:00'
        },
        {
          label:'(UTC+09:30)阿德莱德、达尔文)',
          value:'+09:30'
        },
        {
          label:'(UTC+10:00)墨尔本、悉尼、堪培拉)',
          value:'+10:00'
        },
        {
          label:'(UTC+11:00)马加丹、所罗门群岛)',
          value:'+11:00'
        },
        {
          label:'(UTC+12:00)奥克兰、惠灵顿)',
          value:'+12:00'
        },
        {
          label:'(UTC+13:00)努库阿洛法)',
          value:'+13:00'
        }
      ],
      autoCorrect:'false',
      timeType:'auto_adapt',
      timeTypeList:[
        {
          label:'接入协议校时',
          value:'auto_adapt'
        },
        {
          label:'NTP校时',
          value:'NTP'
        }
      ]
    }
  },
  created(){
    this.getRecodedStatus()
    this.timeType = Cookies.get("basicType") != 'NTP' ? 'auto_adapt' : 'NTP'
    this.getDeviceInfo()
    this.getSysInfo().then(res => {
      this.deviceZone = res.GetSysTimeInfoRsp.TimeParam.TimeZone
      this.deviceTime = dateFormat('yyyy-MM-dd hh:mm:ss',new Date(res.GetSysTimeInfoRsp.TimeParam.Time))
      this.Ntp = res.GetSysTimeInfoRsp.Ntp ? res.GetSysTimeInfoRsp.Ntp : {},
      this.autoCorrect = res.GetSysTimeInfoRsp.AutoSyncParam.Enable == 'true' ? true : false
      this.Ntp.Interval = Number(this.Ntp.Interval)
    })
  },
  computed:{
    formatTime(){
      var patt = /\s/;
      var time = this.deviceTime + '.000'
      return time.replace(patt,'T')
    }
  },
  watch:{
    deviceTime() {
      clearTimeout(this.time)
      this.deviceTimeAutoAdd()
    },
    autoCorrect(newAuto,oldAuto) {
      if(newAuto == 'true') {
        this.timeTypeDisable = false
      }else {
        this.timeTypeDisable = true
      }
    },
    deviceZone(newZone,oldZone) {
      let easeEightTime = new Date(this.deviceTime).getTime() - 8 * 60 * 60 * 1000
      let zoneSymbol = newZone.substr(0,1)
      let zoneHour = parseInt(newZone.substr(1,2))
      let zoneMinutes = parseInt(newZone.substr(4,2))
      let date = null
      let diff = zoneHour * 60 * 60 * 1000 + zoneMinutes * 60 * 1000
      if(zoneSymbol == '-') {
        date = new Date( easeEightTime - diff )
      }else {
        date = new Date( easeEightTime + diff )
      }
      if(this.deviceTime != '') {
        this.deviceTime = dateFormat('yyyy-MM-dd hh:mm:ss',date)
      }
    }
  },
  destroyed() {
    clearTimeout(this.recodingTime)
  },
  methods:{
    getRecodedStatus() {
      let _that = this
      getSvrStateEx({}).then(res => {
        if(res.SvrStateResp.Mp4RecState == 'recording' || res.SvrStateResp.Mp4RecState == 'pause') {//录制中
          this.recodingStatus = true
          this.disabledDevice = true
        }else {
          this.recodingStatus = false
          if(!this.synchronous) {
            this.disabledDevice = false
          }
        }
        this.recodingTime = setTimeout(() => {
          _that.getRecodedStatus()
        },1000)
      })
    },
    deviceTimeAutoAdd() {
      if(this.deviceTime != '') {
        this.time = setTimeout(() => {
          let date = new Date(this.deviceTime).getTime() + 1000
          this.deviceTime = dateFormat('yyyy-MM-dd hh:mm:ss',new Date(date))
          clearTimeout(this.time)
          this.deviceTimeAutoAdd()
        },1000)
      }else {
        clearTimeout(this.time)
      }
    },
    changeTime(){
      var date = new Date()
      var zoneTime = (date.getTimezoneOffset() / 60).toFixed(2)
      if(this.synchronous) {
        this.deviceTime = dateFormat('yyyy-MM-dd hh:mm:ss',date)
        if(zoneTime.length == 5) {
          zoneTime = zoneTime.slice(0,1) + '0' + zoneTime.slice(1)
        }
        zoneTime = zoneTime.replace(/\./,':')
        if(zoneTime.indexOf('-') > -1) {
          zoneTime = zoneTime.replace(/-/,'+')
        }else if(zoneTime.indexOf('+') > -1) {
          zoneTime = zoneTime.replace(/\+/,'-')
        }
        this.deviceZone = zoneTime
        this.disabledDevice = true
      }else {
        this.disabledDevice = false
      }
    },
    getDeviceInfo(){
      getSysBasicInfo({}).then(res => {
        this.GetSysBasicInfoResp = res.GetSysBasicInfoResp
        this.deviceName = res.GetSysBasicInfoResp.DevName
      })
    },
    setDeviceInfo(){
      this.GetSysBasicInfoResp.DevName = this.deviceName
      var param = {
        SetSysBasicInfoReq: this.GetSysBasicInfoResp
      }
      setSysBasicInfo(param).then(res => {
        console.log(res)
      })
    },
    getSysInfo() {
      return new Promise((resolve,reject) => {
        let param = {
          GetSysTimeInfoReq:{
            NeedMask:{
              TimeParam: true,
              AutoSyncParam: true,
              AutoSyncDefParam: true,
              Ntp: true,
              SummerParam: true
            }
          }
        }
        getSysTimeInfo(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    saveSysTimeInfo(){
      if(this.recodingStatus) {
        this.$message({
          type: 'error',
          message: '录制过程中禁止修改时间'
        })
        return
      }
      let _that = this
      let zone = _that.deviceZone
      this.$refs.basicForm.validate((valid) => {
        if(valid) {
          let param = {
            SetSysTimeInfoReq:{
              TimeParam:{
                TimeZone:zone,
                Time:_that.formatTime
              },
              AutoSyncParam:{
                Enable:_that.autoCorrect,
                AutoSyncType:'auto_adapt',
                AutoAdapt:{
                  Num:4,
                  AdaptLockTime:60,
                  PriorityList:[
                    {
                      Index:{
                        Type:'ntp',
                        Check:true
                      }
                    },
                    {
                      Index:{
                        Type:'onvif',
                        Check:true
                      }
                    },
                    {
                      Index:{
                        Type:'gb1',
                        Check:true
                      }
                    }
                  ]
                }
              },
              Ntp:_that.Ntp,
              SummerParam:{
                Enable:false,
                OffSet:'60min',
                Begin:{
                  Month:6,
                  WeekIndex:1,
                  Weekday:1,
                  Hour:1
                },
                End:{
                  Month:9,
                  WeekIndex:2,
                  Weekday:7,
                  Hour:23
                }
              }
            }
          }
          setSysTimeInfo(param).then(res => {
            this.$message({
              message: '保存成功',
              type: 'success'
            })
            Cookies.set("basicType",this.timeType)
          })
          this.setDeviceInfo()
        }
      })
    }
  },
  components:{
    /* breadCrumb */
  }
}
</script>

<style lang="scss" scoped>
  .basic-param-config {
    .basic-config {
      padding-top: 8px;
      .config-stream-media {
        display: flex;
        /* padding: 8px 0px; */
        align-items: center;
        .basic-config-title {
          width: 150px;
          font-weight: normal;
        }
        .paddingLeft24 {
          padding-left: 24px;
        }
        .gap-title {
          padding-left: 16px;
          font-size: 14px;
        }
        .synch-time {
          display: flex;
          align-items: center;
          .synch-content {
            padding-left: 16px;
          }
        }
        .config-stream-input {
          width: 312px;
        }
        .border-select-default {
          width: 312px;
        }
        .basic-btn-container {
          padding-top: 16px;
        }
      }
      .paddingTop16 {
        padding-top: 16px;
      }
    }
    .svr-pick-time.el-input {
      width: 312px;
      .el-input__inner {
        height: 32px;
        line-height: 32px;
        width: 312px;
        border-radius: 2px;
        border: 1px solid rgba(216, 222, 234, 0.2);
        background-color: rgba(13, 16, 22, 0.48);
        padding-left: 12px;
      }
      .el-input__prefix {
        right: 8px;
        left: inherit;
        .el-input__icon {
          line-height: 32px;
        }
      }
      .el-input__suffix {
        display: none;
      }
    }
  }
</style>
