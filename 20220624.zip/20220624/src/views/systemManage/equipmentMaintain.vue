<template>
  <div class="equipment-config">
    <div class="kd-main-title">系统配置 / 设备维护</div>
    <div class="equipment-info">
      <div class="config-stream-media flex-center">
        <label for="" class="equipment-config-title font14">设备重启:</label>
        <div>
          <input
            type="button"
            value="重启"
            class="default default-border-radius default-width"
            @click="reboot"
          >
        </div>
      </div>
      <div class="config-stream-media flex-center">
        <label for="" class="equipment-config-title font14">设备升级:</label>
        <div>
          <label
            for="up_grade"
            class="default default-border-radius default-width up-grade-button"
          >升级</label>
          <input id="up_grade" type="file" style="display: none;" @change="changeFile">
        </div>
      </div>
      <div class="config-stream-media flex-center">
        <label for="" class="equipment-config-title font14">格式化分区:</label>
        <div>
          <input
            type="button"
            value="录像分区"
            class="default default-border-radius"
            @click="removeVideo"
          >
        </div>
      </div>
      <div class="config-stream-media flex-center">
        <label for="" class="equipment-config-title font14">高级设置:</label>
        <div>
          <input
            type="button"
            value="高级设置"
            class="default default-border-radius"
            @click="setEquipment"
          >
        </div>
      </div>
      <div class="config-stream-media flex-center">
        <label for="" class="equipment-config-title font14">恢复出厂设置:</label>
        <div class="factory-set flex-center">
          <el-select
            v-model="resetType"
            class="border-select-default input-width-default"
            placeholder="请选择"
            @change="changeReset"
          >
            <el-option
              v-for="item in resetTypeList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <input
            type="button"
            value="恢复出厂"
            class="default default-border-radius marginLeft16"
            @click="restoreFactory"
          >
        </div>
      </div>
      <div class="config-stream-media flex-center">
        <label for="" class="equipment-config-title" />
        <div>
          <el-checkbox-group v-model="resetTypeDefine">
            <el-checkbox :disabled="equipDisable" label="NetCfg">网络管理配置</el-checkbox>
            <el-checkbox :disabled="equipDisable" label="RecCfg">录像管理配置</el-checkbox>
            <el-checkbox :disabled="equipDisable" label="ChnCfg">通道管理配置</el-checkbox>
            <el-checkbox :disabled="equipDisable" label="BaseCfg">系统管理配置</el-checkbox>
          </el-checkbox-group>
        </div>
      </div>
      <div class="config-stream-media paddingTop16">
        <label for="" class="equipment-config-title">维护类型</label>
      </div>
      <div class="">
        <div class="config-stream-media flex-center">
          <label for="" class="equipment-config-title main-type-title">维护类型:</label>
          <div>
            <el-select
              v-model="mainType"
              class="input-width-default border-select-default"
              placeholder="请选择"
            >
              <el-option
                v-for="item in mainTypeList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
        </div>
        <div class="config-stream-media flex-center">
          <label for="" class="equipment-config-title main-type-title">维护时间:</label>
          <div class="maintenance-contain">
            <el-select
              v-model="mainMode"
              :disabled="mainModeDisable"
              class="input-width-default border-select-default"
              placeholder=" "
            >
              <el-option
                v-for="item in mainModeList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <div class="time-cont paddingLeft16">
              <el-time-picker
                v-model="typeTime"
                format="HH:mm"
                start-placeholder="开始时间"
                placeholder="选择时间"
              />
            </div>
          </div>
        </div>
        <div class="config-stream-media flex-center">
          <label for="" class="equipment-config-title main-type-title" />
          <div>
            <input
              type="button"
              value="保存"
              class="primary default-border-radius"
              @click="saveAutoConfig"
            >
          </div>
        </div>
      </div>
    </div>
    <el-dialog
      :close-on-click-modal="false"
      title="用户认证"
      class="font-title-color equipment-dialog"
      :visible.sync="equipConfig"
    >
      <el-form :model="form">
        <el-form-item label="用户名:" :label-width="formLabelWidth">
          <el-input
            v-model="form.Username"
            type="text"
            disabled
            class="input-width-default border-input-default default-border-radius"
          />
        </el-form-item>
        <el-form-item label="密码:" :label-width="formLabelWidth">
          <el-input
            v-model="form.Password"
            type="password"
            class="input-width-default border-input-default default-border-radius"
          />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <input
          type="button"
          class="primary default-border-radius"
          value="确认"
          @click="ensureUserInfo"
        >
        <input
          type="button"
          class="default default-border-radius font-title-color marginLeft16"
          value="取消"
          @click="equipConfig = false"
        >
      </div>
    </el-dialog>
    <el-dialog
      :close-on-click-modal="false"
      title="高级配置"
      class="font-title-color advance-dialog"
      :visible.sync="advanceConfig"
    >
      <el-form :model="form">
        <!-- <el-form-item label="KTCP启用:" :label-width="formLabelWidth">
          <el-checkbox v-model="KTCP"></el-checkbox>
        </el-form-item> -->
        <el-form-item label="设备型号启用:" :label-width="formLabelWidth">
          <el-checkbox v-model="devModel.Enable" />
        </el-form-item>
        <el-form-item label="设备型号:" :label-width="formLabelWidth">
          <el-input
            v-model="devModel.DevModel"
            type="text"
            class="input-width-default border-input-default default-border-radius"
          />
        </el-form-item>
        <el-form-item label="远程调试:" :label-width="formLabelWidth">
          <el-checkbox v-model="serverInfo.enabled" />
        </el-form-item>
        <el-form-item label="服务端地址:" :label-width="formLabelWidth">
          <el-input
            v-model="serverInfo.srvaddr"
            type="text"
            class="input-width-default border-input-default default-border-radius"
          />
        </el-form-item>
        <el-form-item label="服务端端口:" :label-width="formLabelWidth">
          <el-input
            v-model="serverInfo.srvlistenport"
            type="text"
            class="input-width-default border-input-default default-border-radius"
          />
        </el-form-item>
        <el-form-item label="Token:" :label-width="formLabelWidth">
          <el-input
            v-model="serverInfo.token"
            type="text"
            class="input-width-default border-input-default default-border-radius"
          />
        </el-form-item>
        <el-form-item v-show="!isSVR" label="监控平台启用:" :label-width="formLabelWidth">
          <el-checkbox v-model="GetAdvanceParamResp.Vsip" />
        </el-form-item>
        <el-form-item v-show="!isSVR" label="流媒体启用:" :label-width="formLabelWidth">
          <el-checkbox v-model="GetAdvanceParamResp.Mss" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <input
          type="button"
          class="primary default-border-radius"
          value="确认"
          @click="setAdvanceConfig"
        >
        <input
          type="button"
          class="default default-border-radius font-title-color marginLeft16"
          value="取消"
          @click="advanceConfig = false"
        >
      </div>
    </el-dialog>
    <el-dialog
      :close-on-click-modal="false"
      title="提示"
      class="device-status-dialog"
      :visible.sync="deviceStatus"
    >
      <el-form>
        <div>{{ deviceStausTitle }}</div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" :disabled="disableButton" @click="rebootSuccess">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="升级进程"
      :visible.sync="canvasInfo"
      :close-on-click-modal="false"
      class="upgrade-dialog"
      :show-close="false"
    >
      <div style="padding-top: 4px; padding-bottom: 4px;" :style="upgradeFont">
        {{ upgradeState }}
      </div>
      <div v-show="showUpgradeTips" style="padding-top: 4px; padding-bottom: 4px;">
        {{ upgradeTips }}
      </div>
      <canvas id="upgrade_title" ref="upgradeTitle" width="40" height="40" />
    </el-dialog>
  </div>
</template>

<script>
import store from '@/store'
import { getAuth } from '@/api/user'
import {
  getAdvancedCfg,
  setAdvancedCfg,
  getAdvanceParam,
  setAdvanceParam,
  getDevModel,
  setDevModel,
  getReboot,
  getFrpParam,
  setFrpParam,
  removeDelAllRec,
  setFactoryDef,
  getAutoMaintainCfg,
  getCapabilty,
  getMp4DelAllRecResult,
  upPrepare,
  uploadSegment,
  ftpUpgradeState,
  setAutoMaintainCfg
} from '@/api/systemConfig'
import { getVersionInfo } from '@/api/deviceInfo'
import { mapState } from 'vuex'
import { xmlStr2json } from '@/utils/dataParse'
export default {
  data() {
    return {
      upgradeStaus: {
        queryStateID: null, // 正常的查询状态
        queryOverTimeID: null,
        overTime: 300000 // 单位豪秒升5分钟没有任何返回值，提示'升级超时，请检查是否升级成功'
      },
      isSVR: false,
      canvasInfo: false,
      canvasAniTimer: null,
      upgradeState: '',
      upgradeTips: '',
      showUpgradeTips: false,
      upgradeUrl: '/ab',
      time: null,
      equipConfig: false,
      equipDisable: true,
      advanceConfig: false,
      GetAdvanceParamResp: {}, // 高级配置中监控平台和流媒体配置
      resetType: 'All',
      resetTypeList: [
        {
          label: '完全恢复',
          value: 'All'
        },
        {
          label: '自定义恢复',
          value: 'Part'
        }
      ],
      Part: {
        ChnCfg: false, // 通道配置
        RecCfg: false, // 录像配置
        NetCfg: false, // 网络配置
        BaseCfg: false, // 基本配置
        EventCfg: false, // 事件配置
        IntellCfg: false, // 智能配置
        ChnCtrlCfg: false // 通道控制配置
      },
      mainType: 'disable',
      mainTypeList: [
        {
          label: '不维护',
          value: 'disable'
        },
        {
          label: '每日',
          value: 'bydate'
        },
        {
          label: '每周',
          value: 'byweek'
        },
        {
          label: '每月',
          value: 'bymonth'
        }
      ],
      mainModeList: [],
      weekInfo: [
        {
          value: 1,
          label: '周一'
        },
        {
          value: 2,
          label: '周二'
        },
        {
          value: 3,
          label: '周三'
        },
        {
          value: 4,
          label: '周四'
        },
        {
          value: 5,
          label: '周五'
        },
        {
          value: 6,
          label: '周六'
        },
        {
          value: 7,
          label: '周日'
        }
      ],
      monthInfo: [],
      typeTime: '',
      mainMode: '',
      mainModeDisable: false,
      resetTypeDefine: [],
      formLabelWidth: '100px',
      form: {
        // 高级设置用户名和密码信息
        Username: 'admin',
        Password: ''
      },
      devModel: {
        // 设备型号配置
        Enable: false,
        DevModel: ''
      },
      serverInfo: {
        // 服务端配置信息
        enabled: false, // 远程调试控制按钮
        srvaddr: 'eduops.kedacom.com',
        srvlistenport: '7000',
        token: '049a93665124a939'
      },
      advanceInfo: null,
      KTCP: false,
      autoMaintainInfo: {
        Type: 'disable',
        Day: 0,
        Hour: 0,
        Minute: 0,
        Second: 0
      },
      upgradeFont: {
        color: '#fff',
        fontSize: '16px'
      },
      deviceStausTitle: '设备正在重启',
      deviceStatus: false,
      disableButton: true, // 启动按钮禁用
      ktcp: false, // KTCP启动状态
      isWeb: true // 是不是web浏览器
    }
  },
  computed: {
    ...mapState('user', {
      stateTimer: state => state.stateTimer
    })
  },
  watch: {
    mainType(newV) {
      if (newV == 'disable' || newV == 'bydate') {
        this.mainModeDisable = true
        this.mainMode = ''
      } else {
        this.mainModeList = []
        if (newV == 'byweek') {
          this.mainModeList = this.weekInfo
        } else {
          this.mainModeList = this.monthInfo
        }
        this.mainModeDisable = false
      }
    }
  },
  mounted() {
    getVersionInfo().then((res) => {
      // 检查是不是2730设备  isSVR
      if (res.GetSysDevInfoResp.DevType.indexOf('SVR2730') > -1) {
        // 是2730设备
        this.isSVR = true
      }
    })
    this.isWeb = store.getters.isWeb
    // this.getAdvanceConfig()
    this.getAdvanceCon()
    this.buildMonthInfo()
    this.getAutoConfig()
  },
  methods: {
    getMp4DelAllRecResult() {
      getMp4DelAllRecResult().then(res => {
        const status = res.GetMp4DelAllRecResultResp.FormatStatus
        if (status === 'formatting') {
          setTimeout(() => {
            this.getMp4DelAllRecResult()
          }, 1000)
        }
        if (status === 'success') {
          this.$message({
            type: 'success',
            message: '清除完成'
          })
        }
        if (status === 'failed') {
          this.$message({
            type: 'error',
            message: '清除失败'
          })
        }
      })
    },
    getAdvancedParam() {
      return new Promise((resolve, reject) => {
        getAdvanceParam({})
          .then((res) => {
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    setAdvancedParam() {
      return new Promise((resolve, reject) => {
        const param = {
          SetAdvanceParamReq: this.GetAdvanceParamResp
        }
        setAdvanceParam(param)
          .then((res) => {
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    changeFile() {
      const file = document.getElementById('up_grade').files[0]
      let DataStartPos = 0
      let DataBuf = ''
      let DateLen = 1024 * 1024
      let fileContentHeader
      let m_State
      const OriginName = file.name
      const PackageSize = file.size
      const reader = new FileReader()
      const _that = this
      const _upgradeFile = {
        init: function() {
          if (file) {
            reader.onload = function(event) {
              fileContentHeader = event.target.result.replace(/data:(.*);base64,/, '')
              getCapabilty({}).then((res) => {
                _that.upgradeStaus.overTime =
                  parseInt(res.GetSysUpgradeCapResp.UpgradeTimeOut) * 1000
                _upgradeFile.prepareUpgrade()
              })
            }
            reader.readAsDataURL(file.slice(0, 132))
          }
        },
        prepareUpgrade: function() {
          _that.canvasInfo = true
          _that.upgradeState = '准备升级中...'
          if (!fileContentHeader) return
          const preParam = {
            UpgradePrepareReq: {
              Web: {
                CheckInfo: fileContentHeader,
                PackageSize: 41984
              }
            }
          }
          upPrepare(preParam, { type: 'post', dataType: null, timeout: 30000 })
            .then((res) => {
              _that.upgradeStaus.queryStateID = setInterval(_upgradeFile.queryState, 2000)
              _that.upgradeStaus.querySendStatus = setInterval(function() {
                if (m_State === 'Upgrade') {
                  _upgradeFile.prepareUpload()
                  clearInterval(_that.upgradeStaus.querySendStatus)
                  _that.upgradeStaus.querySendStatus = null
                }
              }, 2000)
              _that.showUpgradeTips = true
              _that.upgradeTips = '整个升级过程大概需要几分钟,请不要断电'
            })
            .catch(_ => {
              _that.upgradeFont.color = 'red'
              _that.upgradeState = '升级失败'
              _that.canvasInfo = false
              _that.showUpgradeTips = false
              clearInterval(_that.canvasAniTimer)
            })
        },
        queryState: function() {
          clearInterval(_that.stateTimer)
          // 升级状态查询
          ftpUpgradeState({}).then((res) => {
            const respons = xmlStr2json(res.data)
            m_State = respons.UpgradeStateResp.State
            if (m_State === 'Upgrade') {
              // 升级中
              _that.upgradeFont.color = '#fff'
              _that.upgradeState = '升级中'
              _that.upgradeTips = '整个升级过程大概需要几分钟,请不要断电'
              _that.showUpgradeTips = true
              if (!_that.upgradeStaus.queryOverTimeID) {
                _that.upgradeStaus.queryOverTimeID = setInterval(() => {
                  clearInterval(_that.upgradeStaus.queryStateID)
                  clearInterval(_that.upgradeStaus.queryOverTimeID)
                }, parseInt(_that.upgradeStaus.overTime)) // 发送文件后超时300秒 超时提示"升级超时，请检查是否升级成功"
              }
            } else if (m_State === 'UpgradeSuccess') {
              // 升级成功
              this.$message({
                type: 'success',
                message: '升级完成，请刷新页面~'
              })
              clearInterval(_that.upgradeStaus.queryStateID)
              clearInterval(_that.upgradeStaus.queryOverTimeID)
              clearInterval(_that.canvasAniTimer)
              _that.upgradeState = '升级成功'
              _that.upgradeFont.color = 'blue'
              setTimeout(() => {
                _that.showUpgradeTips = false
                _that.canvasInfo = false
              }, 5000)
            } else if (m_State === 'UpgradeFailure') {
              // 升级失败
              clearInterval(_that.upgradeStaus.queryStateID)
              clearInterval(this.upgradeStaus.queryOverTimeID)
              clearInterval(_that.canvasAniTimer)
              _that.upgradeState = '升级失败'
              _that.upgradeFont.color = 'red'
              setTimeout(() => {
                _that.showUpgradeTips = false
                _that.canvasInfo = false
              }, 5000)
            } else if (m_State === 'UpgradeTimeOut') {
              // '状态：升级超时'
              clearInterval(_that.upgradeStaus.queryStateID)
              clearInterval(_that.upgradeStaus.queryOverTimeID)
              clearInterval(_that.canvasAniTimer)
              _that.upgradeState = '升级超时'
              _that.upgradeFont.color = 'red'
              setTimeout(() => {
                _that.showUpgradeTips = false
                _that.canvasInfo = false
              }, 5000)
            }
          })
        },
        readFileFun: function(DataStartPos) {
          reader.readAsDataURL(file.slice(DataStartPos, DataStartPos + DateLen))
        },
        prepareUpload: function() {
          if (file) {
            reader.onload = function(event) {
              DataBuf = event.target.result.replace(/data:(.*);base64,/, '')
              DateLen = event.loaded // 上传字节大小
              _upgradeFile.upgradeUpload()
            }
            _upgradeFile.readFileFun(DataStartPos)
          }
        },
        upgradeUpload: function() {
          const paramUpload = {
            UpgradeUploadSegmentReq: {
              PackageSize: PackageSize,
              OriginName: OriginName,
              DataStartPos: DataStartPos,
              DataBuf: DataBuf,
              DateLen: DateLen
            }
          }
          uploadSegment(paramUpload)
            .then((res) => {
              DataStartPos = DataStartPos + DateLen
              if (DataStartPos < PackageSize) {
                _upgradeFile.prepareUpload()
              }
            })
            .catch(_ => {
              _that.upgradeState = '升级包传输失败'
              _that.upgradeFont.color = 'red'
            })
        }
      }
      _upgradeFile.init()
    },
    buildMonthInfo() {
      for (let i = 1; i < 32; i++) {
        const obj = {
          label: i,
          value: i
        }
        this.monthInfo.push(obj)
      }
    },
    removeVideo() {
      this.$confirm('此操作执行后课程录像记录和MP4文件将无法恢复，是否继续清除', {
        distinguishCancelAndClose: true,
        confirmButtonText: '是',
        cancelButtonText: '否'
      })
        .then(() => {
          removeDelAllRec({}).then(() => {
            this.getMp4DelAllRecResult()
          })
        })
    },
    changeReset() {
      if (this.resetType == 'All') {
        this.equipDisable = true
      } else {
        this.equipDisable = false
      }
    },
    setEquipment() {
      this.form.Password = ''
      this.equipConfig = true
      this.getAdvanceConfig()
    },
    getAutoConfig() {
      getAutoMaintainCfg({}).then((res) => {
        this.mainType = res.GetAutoMaintainCfgResp.Type
        this.autoMaintainInfo.Type = res.GetAutoMaintainCfgResp.Type
        this.autoMaintainInfo.Hour = res.GetAutoMaintainCfgResp.Hour
        this.autoMaintainInfo.Minute = res.GetAutoMaintainCfgResp.Minute
        this.autoMaintainInfo.Second = res.GetAutoMaintainCfgResp.Second
        this.autoMaintainInfo.Day = res.GetAutoMaintainCfgResp.Day
          ? res.GetAutoMaintainCfgResp.Day
          : ''
        this.mainMode = res.GetAutoMaintainCfgResp.Day ? Number(res.GetAutoMaintainCfgResp.Day) : ''
        const date = new Date()
        const year = date.getFullYear()
        const month = date.getMonth() + 1
        const day = res.GetAutoMaintainCfgResp.Day ? res.GetAutoMaintainCfgResp.Day : date.getDate()
        this.typeTime = new Date(
          year,
          month,
          day,
          this.autoMaintainInfo.Hour,
          this.autoMaintainInfo.Minute
        )
      })
    },
    saveAutoConfig() {
      // 保存维护类型
      if (this.mainType == 'byweek' || this.mainType == 'bymonth') {
        if (this.mainMode == '') {
          this.$message({
            showClose: true,
            message: '维护时间不能为空',
            type: 'error'
          })
          return
        }
      }
      let szXml = '<contentroot>'
      szXml += '<authenticationinfo type="7.0">'
      szXml += '<username>' + store.getters.username + '</username>'
      szXml += '<password>' + store.getters.password + '</password>'
      szXml += '<authenticationid>' + store.getters.authId + '</authenticationid>'
      szXml += '</authenticationinfo>'
      szXml += '<SetAutoMaintainCfgReq>'
      szXml += '<Type>' + this.mainType + '</Type>'
      if (this.mainType == 'byweek' || this.mainType == 'bymonth') {
        szXml += '<Day>' + this.mainMode + '</Day>'
      }
      szXml += '<Hour>' + this.typeTime.getHours() + '</Hour>'
      szXml += '<Minute>' + this.typeTime.getMinutes() + '</Minute>'
      szXml += '<Second>0</Second>'
      szXml += '</SetAutoMaintainCfgReq>'
      szXml += '</contentroot>'
      setAutoMaintainCfg(szXml).then((res) => {
        this.$message({
          showClose: true,
          message: '保存成功',
          type: 'success'
        })
      })
    },
    getAdvanceCon() {
      // 获取高级配置信息
      const param = {
        GetAdvancedCfgReq: {
          NeedMask: {
            NetParam: true,
            SysParam: false
          }
        }
      }
      getAdvancedCfg(param).then((res) => {
        this.advanceInfo = res.GetAdvanceCfgResp
        this.KTCP = res.GetAdvanceCfgResp.NetParam.KtcpParam.Enable != 'false'
      })
    },
    getdeviceTypeConfig() {
      // 获取自定义设备型号配置
      getDevModel({}).then((res) => {
        this.devModel = res.GetDevModelResp
        if (this.devModel.Enable == 'false') {
          this.devModel.Enable = false
        } else {
          this.devModel.Enable = true
        }
      })
    },
    getServerInfo() {
      getFrpParam({}).then((res) => {
        this.serverInfo = res.GetFrpCfg
        if (this.serverInfo.enabled == 'false') {
          this.serverInfo.enabled = false
        } else {
          this.serverInfo.enabled = true
        }
      })
    },
    getAdvanceConfig() {
      this.getdeviceTypeConfig()
      this.getServerInfo()
      this.getAdvancedParam().then((res) => {
        this.GetAdvanceParamResp = res.GetAdvanceParamResp
        this.GetAdvanceParamResp.Mss = this.GetAdvanceParamResp.Mss === 'true'
        this.GetAdvanceParamResp.Vsip = this.GetAdvanceParamResp.Vsip === 'true'
      })
    },
    setAdvanceConfig() {
      // 保存高级配置
      if (this.devModel.DevModel == '') {
        this.$message({
          type: 'warning',
          message: '设备型号不能为空'
        })
        return
      }
      const SetFrpParamReq = this.serverInfo
      const param = {
        SetFrpParamReq: SetFrpParamReq
      }
      const SetDevModelReq = this.devModel
      const paramMode = {
        SetDevModelReq: SetDevModelReq
      }
      const advanceData = this.advanceInfo
      advanceData.NetParam.KtcpParam.Enable = this.KTCP

      const advanceCfg = {
        SetAdvancedCfgReq: advanceData
      }
      const setFrpPromise = setFrpParam(param)

      const setDevPromise = setDevModel(paramMode)

      const advancedCPromise = setAdvancedCfg(advanceCfg)
      const setAdvancedParamVis = this.setAdvancedParam()

      Promise.all([setFrpPromise, setDevPromise, advancedCPromise, setAdvancedParamVis])
        .then((value) => {
          this.advanceConfig = false
          if (!this.isSVR) {
            const hiddenPage = store.getters.hiddenPage // 获取隐藏菜单
            const index = hiddenPage.findIndex((item) => item == 'MonitManage')
            if (this.GetAdvanceParamResp.Vsip) {
              // 不启用监控平台
              if (index > -1) {
                hiddenPage.splice(index, 1)
              }
            } else {
              if (index == -1) {
                hiddenPage.push('MonitManage')
              }
            }
            const idx = hiddenPage.findIndex((item) => item == 'StreamMedia')
            if (this.GetAdvanceParamResp.Mss) {
              // 不启用流媒体
              if (idx > -1) {
                hiddenPage.splice(idx, 1)
              }
            } else {
              if (idx == -1) {
                hiddenPage.push('StreamMedia')
              }
            }
            store.commit('app/setHiddenPage', hiddenPage)
          }
          this.$message({
            message: '保存成功',
            type: 'success'
          })
        })
        .catch((err) => {
          this.$message.error('数据保存失败')
        })
    },
    reboot() {
      this.$confirm('是否重启', {
        distinguishCancelAndClose: true,
        confirmButtonText: '是',
        cancelButtonText: '否'
      })
        .then(() => {
          this.deviceStatus = true
          getReboot()
          this.getDevCap()
        })
        .catch(() => {})
    },
    getDevCap() {
      this.time = setTimeout(() => {
        getAuth()
          .then((res) => {
            if (res.GetAuthenticationidResp.Authenticationid) {
              clearTimeout(this.time)
              this.deviceStausTitle = '设备重启成功'
              this.disableButton = false
            }
          })
        this.getDevCap()
      }, 1000)
    },
    rebootSuccess() {
      // 重启成功
      if (true) {
        // 是不是web端
        this.$router.push({ path: '/login' })
      }
    },
    ensureUserInfo() {
      const usePassword = this.$store.getters.pwd
      if (usePassword == this.form.Password) {
        this.equipConfig = false
        this.advanceConfig = true
      } else {
        this.$message({
          message: '密码输入不正确',
          type: 'warning'
        })
      }
    },
    restoreFactory() {
      // 恢复出厂设置
      this.$confirm('是否确定恢复出厂设置', {
        distinguishCancelAndClose: true,
        confirmButtonText: '是',
        cancelButtonText: '否'
      })
        .then(() => {
          const param = {
            FactoryDefReq: {
              Type: this.resetType,
              Part: {
                ChnCfg: false, // 通道配置
                RecCfg: false, // 录像配置
                NetCfg: false, // 网络配置
                BaseCfg: false, // 基本配置
                EventCfg: false, // 事件配置
                IntellCfg: false, // 智能配置
                ChnCtrlCfg: false // 通道控制配置
              }
            }
          }
          if (this.resetType == 'Part') {
            for (const item of this.resetTypeDefine) {
              this.Part[item] = true
            }
            param.FactoryDefReq.Part = this.Part
          }
          setFactoryDef(param)
        })
        .catch(() => {})
    }
  }
}
</script>

<style lang="scss">
.equipment-config {
  .equipment-info {
    padding-top: 8px;
    .config-stream-media {
      padding: 8px 0px;
      .equipment-config-title {
        width: 150px;
        font-size: 16px;
        font-weight: normal;
        &.font14 {
          font-size: 14px;
        }
      }
      .main-type-title {
        font-size: 14px;
        padding-left: 24px;
      }
      .default-width {
        padding-left: 30px;
        padding-right: 30px;
      }
      .up-grade-button {
        display: inline-block;
        height: 32px;
        line-height: 32px;
        font-weight: normal;
      }
      .el-upload-list {
        display: none;
      }
      .el-button--primary {
        padding: 0 32px;
      }
      .maintenance-contain {
        display: flex;
        align-items: center;
      }
    }
  }
  .equipment-dialog,
  .advance-dialog {
    .el-dialog {
      width: 500px;
    }
  }
  .device-status-dialog {
    .el-dialog {
      width: 500px;
      .el-dialog__headerbtn {
        display: none;
      }
    }
  }
}
.upgrade-dialog {
  .el-dialog {
    width: 400px;
  }
}
</style>
