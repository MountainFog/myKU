<template>
  <div class="log-manage">
    <div class="kd-main-title">日志管理 / 日志查询</div>
    <div class="log-manage-query">
      <div class="query-item">
        <span class="query-title">日志类型：</span>
        <el-select v-model="logType" size="small" placeholder="请选择">
          <el-option
            v-for="item in logTypes"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </div>
      <div class="query-item">
        <span class="query-title">开始时间：</span>
        <el-date-picker
          v-model="startTime"
          type="datetime"
          size="small"
          value-format="yyyy-MM-ddTHH:mm:ss"
          placeholder="选择日期时间"
        />
      </div>
      <div class="query-item">
        <span class="query-title">结束时间：</span>
        <el-date-picker
          v-model="endTime"
          type="datetime"
          size="small"
          value-format="yyyy-MM-ddTHH:mm:ss"
          placeholder="选择日期时间"
        />
      </div>
      <div class="query-item">
        <el-button type="primary" :loading="loading" @click="queryTable(true)">查询</el-button>
        <el-button type="primary" @click="exportFile">导出</el-button>
      </div>
    </div>
    <div class="log-manage-table">
      <el-table
        v-loading="loading"
        :data="tableData"
        style="width: 100%"
        empty-text="暂无数据"
      >
        <el-table-column
          type="index"
          label="编号"
          width="80"
        />
        <el-table-column
          prop="Time"
          label="时间"
          width="180"
        />
        <el-table-column
          prop="Source"
          label="来源"
          width="180"
        />
        <el-table-column
          prop="Type"
          label="日志类型"
        />
        <el-table-column
          prop="Detail"
          label="详细描述"
        />
      </el-table>
      <div class="pages-container">
        <el-pagination
          :current-page="pages.currentPage"
          :page-sizes="[10, 20, 50, 100]"
          :page-size="pages.size"
          layout="total, sizes, prev, pager, next, jumper"
          :total="pages.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
</template>
<script>
import { createQueryTask, getQueryResult, destroyQueryTask } from '@/api/logManage'
import moment from 'moment'
import parseLogxml from './parseLogxml'
let xmlParams = {}
export default {
  data() {
    return {
      // 日志类型
      logType: 'All',
      // 开始时间
      startTime: moment().format('YYYY-MM-DDT00:00:00'),
      // 结束时间
      endTime: moment().format('YYYY-MM-DDTHH:mm:ss'),
      loading: false,
      // 日志查询任务ID
      taskID: '',
      // 日志类型下拉列表
      logTypes: [
        { label: '全部日志', value: 'All' },
        { label: '告警', value: 'Alarm' },
        { label: '系统异常', value: 'SysException' },
        { label: '系统信息', value: 'SysInfo' },
        { label: '用户操作', value: 'UserOprate' }
      ],
      // 表格数据
      tableData: [],
      // 导出数据
      exportData: [],
      // 分页参数
      pages: {
        total: 0,
        size: 10,
        currentPage: 1
      }
    }
  },
  computed: {
    startPos() {
      let num = this.pages.size * (this.pages.currentPage - 1)
      num += 1
      return num
    }
  },
  created() {
    parseLogxml().then(res => {
      xmlParams = res
    })
  },
  mounted() {
    this.queryTable()
  },
  methods: {
    async queryTable(isQuery) {
      if (isQuery) this.pages.currentPage = 1
      this.loading = true
      try {
        await this.createQueryTask()
        await this.getQueryResult()
        this.destroyQueryTask()
        this.loading = false
      } catch {
        this.destroyQueryTask()
        this.loading = false
      }
    },
    async exportFile() {
      try {
        await this.createQueryTask()
        await this.getQueryResult(true)
        this.destroyQueryTask()
        this.createTxt()
      } catch {
        this.destroyQueryTask()
      }
    },
    // 分页器-当前页改变
    handleCurrentChange(current) {
      this.pages.currentPage = current
      this.queryTable()
    },
    // 分页器-每页条数改变
    handleSizeChange(size) {
      this.pages.size = size
      this.queryTable()
    },
    // 创建日志查询任务
    createQueryTask() {
      const params = {
        CreateQueryTaskReq: {
          StartTime: this.startTime,
          EndTime: this.endTime,
          MainType: {
            P_R_O_P: {
              size: '1',
              name: this.logType
            },
            V_A_L_U_E: {
              SubType: `${this.logType}_All`
            }
          },
          Source: '',
          Lang: 'simplified_chinese'
        }
      }
      return new Promise((reslove, reject) => {
        createQueryTask(params).then(res => {
          const total = res.CreateQueryTaskResp.TotalNum
          this.taskID = res.CreateQueryTaskResp.TaskID
          this.pages.total = Number(total)
          reslove()
        }).catch(_ => {
          reject()
        })
      })
    },
    // 查询日志
    getQueryResult(isExport) {
      const params = {
        GetQueryResultReq: {
          TaskID: this.taskID,
          StartPos: isExport ? 1 : this.startPos,
          MaxNum: isExport ? this.pages.total : this.pages.size
        }
      }
      return new Promise((reslove, reject) => {
        getQueryResult(params).then(res => {
          const list = res.GetQueryResultResp.LogList.Log
          const tableAry = []

          // 列表长度判断
          if (typeof list === 'object') {
            if (list.length) {
              tableAry.push(...list)
            } else {
              tableAry.push(list)
            }
          }
          // 格式化日志类型
          for (let i = 0; i < tableAry.length; i++) {
            const type = tableAry[i].Type
            tableAry[i].Type = xmlParams[type]
          }

          // 是否导出
          if (isExport) {
            this.$set(this, 'exportData', tableAry)
          } else {
            this.$set(this, 'tableData', tableAry)
          }
          reslove()
        }).catch(_ => {
          reject()
        })
      })
    },
    // 销毁日志查询任务
    destroyQueryTask() {
      const params = {
        DestroyQueryTaskReq: { TaskID: this.taskID }
      }
      return new Promise((reslove, reject) => {
        destroyQueryTask(params).then(_ => {
          reslove()
        }).catch(_ => {
          reject()
        })
      })
    },
    // 创建txt文件
    createTxt() {
      const txt = this.formatTxt()
      const urlObject = window.URL || window.webkitURL || window
      const export_blob = new Blob([txt], { type: 'application/msword,charset=UTF-8' })
      const save_link = document.createElementNS('http://www.w3.org/1999/xhtml', 'a')
      save_link.href = urlObject.createObjectURL(export_blob)
      save_link.download = 'log.doc'
      save_link.click()
    },
    // 格式化TXT文件
    formatTxt() {
      let txt = ''
      for (let i = 0; i < this.exportData.length; i++) {
        const item = this.exportData[i]
        txt += `时间：${item.Time}\n来源：${item.Source}\n日志类型：${item.Type}\n详细描述：${item.Detail}\n\n`
      }
      return txt
    }
  }
}
</script>
<style lang="scss" scoped>
.log-manage {
  padding: 8px 40px;
  background-color: #1d222c;

  &-query {
    display: flex;
    flex-wrap: wrap;
    font-size: 14px;

    .query-item {
      display: flex;
      align-items: center;
      margin-top: 16px;
      margin-right: 40px;
    }

  .query-item:last-child {
    margin-right: 0;
  }

    .query-title {
      display: inline-block;
      margin-right: 8px;
      // width: 120px;
    }

    .el-input {
      width: 216px;
      height: 32px;
    }
  }

  &-table {
    margin-top: 24px;
  }

  .pages-container {
    padding: 24px 0;
    text-align: right;
  }
}
</style>
