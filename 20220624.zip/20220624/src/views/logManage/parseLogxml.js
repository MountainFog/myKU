import { xmlStr2json } from '@/utils/dataParse'

const getFile = function() {
  let data = {}
  return new Promise(resolve => {
    const xhr = new XMLHttpRequest()
    xhr.open('GET', '/svroperlog.xml')
    xhr.onload = function() {
      data = xmlStr2json(this.response).languagelist
      resolve(data)
    }
    xhr.send()
  })
}

export default getFile
