<template>
  <div class="playback-download">
    <div class="download-channel-list">
      <div class="channel-title">通道列表</div>
      <el-checkbox-group
        v-model="channelSelect"
        class="channel-list"
      >
        <div
          v-for="item in nvrList"
          :key="item.ChnID"
          class="channel-list-item"
        >
          <el-checkbox
            :label="item.ChnID"
          >D{{ item.ChnID + ' ' + item.ChnAlias }}（{{ findState(item.ChnID) }}）</el-checkbox>
        </div>
      </el-checkbox-group>
    </div>
    <div class="download-query-main">
      <div class="download-query-condi">
        <div>
          <span>开始时间：</span>
          <el-date-picker
            v-model="startTime"
            value-format="yyyy/MM/dd HH:mm:ss"
            type="datetime"
            placeholder="选择日期时间"
          />
        </div>
        <div>
          <span>结束时间：</span>
          <el-date-picker
            v-model="endTime"
            value-format="yyyy/MM/dd HH:mm:ss"
            type="datetime"
            placeholder="选择日期时间"
          />
        </div>
        <el-button
          type="primary"
          @click="creatQueryTask"
        >搜索</el-button>
      </div>
      <el-table
        :data="tableData"
        height="530"
      >
        <el-table-column
          prop="ChnID"
          label="通道号"
          width="80"
        >
          <template slot-scope="scope">
            <span>D{{ scope.row.ChnID }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="StartTime"
          label="开始时间"
        />
        <el-table-column
          prop="EndTime"
          label="结束时间"
        />
        <el-table-column
          prop="date"
          label="操作"
          width="80"
        >
          <template slot-scope="scope">
            <el-link
              type="primary"
              :href="scope.row.fileUrl"
              :download="scope.row.fileName"
            >下载</el-link>
          </template>
        </el-table-column>
      </el-table>
      <div class="pages-container">
        <el-pagination
          :current-page.sync="currentPage"
          :page-size="pageSize"
          layout="total, prev, pager, next"
          :total="totalNum"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
</template>
<script>
import {
  QuerySvrChnMonthMap,
  GetSvrMonthMapResult,
  QuerySvrChnRecResult,
  QuerySvrChnRec
} from '@/api/resourceManage'
import { getChannel } from '@/views/applicationScenarios/getChannel'
import moment from 'moment'
export default {
  mixins: [getChannel],
  data() {
    return {
      currentPage: 1,
      pageSize: 30,
      totalNum: 0,
      channelSelect: [],
      startTime: moment().format('YYYY/MM/DD 00:00:00'),
      endTime: moment().format('YYYY/MM/DD HH:mm:ss'),
      tableData: [],
      // 有录像的通道
      haveVideoList: []
    }
  },
  computed: {
    baseUrl() {
      // return 'http://172.18.1.160'
      const origin = window.location.origin
      return origin
    }
  },
  mounted() {
    this.querySvrChnMonthMap()
  },
  methods: {
    handleCurrentChange() {
      this.creatQueryTask()
    },
    // 当月录像状态 是否有录像
    querySvrChnMonthMap() {
      const list = []
      for (let i = 0; i < 17; i++) {
        list.push(i + 1)
      }
      const params = {
        QuerySvrChnMonthMapReq: {
          Year: moment().year(),
          Month: moment().month() + 1,
          ChnList: {
            P_R_O_P: {
              num: 17
            },
            K_E_Y: 'ChnID',
            V_A_L_U_E: list
          }
        }
      }
      this.queryDisabled = true
      QuerySvrChnMonthMap(params).then(res => {
        const sessionID = res.QuerySvrChnMonthMapResp.SessionID
        this.GetSvrMonthMapResult(sessionID)
      }).catch(_ => {
        this.queryDisabled = false
      })
    },
    // 获取月视图查询结果
    GetSvrMonthMapResult(id) {
      GetSvrMonthMapResult({
        GetSvrMonthMapResultReq: {
          SessionID: id
        }
      }).then(res => {
        const state = res.GetSvrMonthMapResultResp.QueryState
        // 准备查询或者正在查询阶段 轮询
        if (state === 'ready' || state === 'operating') {
          setTimeout(() => {
            this.GetSvrMonthMapResult()
          }, 1000)
        } else {
          this.queryDisabled = false
          this.findHaveVideoState(res.GetSvrMonthMapResultResp.ChnList.ChnItem)
        }
      }).catch(_ => {
        this.queryDisabled = false
      })
    },
    findHaveVideoState(data) {
      this.haveVideoList = []
      let list = []
      if (Array.isArray(data)) {
        list = data
      } else {
        list.push(data)
      }
      list.forEach(item => {
        this.haveVideoList.push(item.ChnID)
      })
    },
    findState(id) {
      return this.haveVideoList.indexOf(id) > -1 ? '有录像' : '空'
    },
    creatQueryTask() {
      QuerySvrChnRec({
        QuerySvrChnRecReq: {
          StartTime: this.startTime,
          EndTime: this.endTime,
          ChnList: {
            P_R_O_P: {
              num: this.channelSelect.length,
              max: 17
            },
            K_E_Y: 'ChnID',
            V_A_L_U_E: this.channelSelect
          },
          StartInx: this.currentPage - 1,
          Count: this.pageSize
        }
      }).then(res => {
        this.querySvrChnRecResult(res.QuerySvrChnRecResp.SessionID)
      })
    },
    querySvrChnRecResult(id) {
      QuerySvrChnRecResult({
        QuerySvrChnRecResultReq: {
          SessionID: id
        }
      }).then(res => {
        const data = res.QuerySvrChnRecResultResp
        const state = data.QueryState
        if (state === 'ready' || state === 'operating') {
          setTimeout(() => {
            this.querySvrChnRecResult(id)
          }, 1000)
          return
        }
        let recordList = data.RecordList.RecordItem
        if (!recordList) {
          this.totalNum = 0
          this.tableData = []
          return
        }
        // 对象转数组
        if (!Array.isArray(recordList)) {
          recordList = [recordList]
        }
        this.totalNum = Number(data.RecordList.RecordTotalNum)
        this.tableData = this.formatTableData(recordList)
      })
    },
    // 格式化表格数据
    formatTableData(list) {
      list.forEach(item => {
        item.fileName = this.videoNameFilter(item.FullName)
        item.fileUrl = encodeURI(`${this.baseUrl}/tmp/disk/${item.FullName}`)
      })
      return list
    },
    // 过滤出视频名称
    videoNameFilter(data) {
      let name = ''
      name = data.substring(data.lastIndexOf('/') + 1)
      return name
    }
  }
}
</script>
<style lang="scss">
  .playback-download {
    display: flex;

    .download-channel-list {
      width: 200px;
      height: 600px;

      .channel-list {
        padding-left: 20px;
        border-right: 1px solid #eee;
      }
      .channel-title {
        padding: 16px 8px;
        font-size: 20px;
      }

      .channel-list-item {
        margin-top: 12px;
        font-size: 14px;
      }
    }
    .download-query-main {
      flex-grow: 1;
      margin-left: 16px;
    }

    .download-query-condi {
      display: flex;
      justify-content: space-around;
      align-items: center;
      height: 52px;
    }

    .el-table {
      margin-top: 12px;
    }

    .pages-container {
      text-align: right;
    }
  }
</style>
