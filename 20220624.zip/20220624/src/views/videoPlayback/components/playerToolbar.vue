<template>
  <div
    ref="videoPlayToolbar"
    class="video-play-toolbar"
  >
    <div
      class="timeline-main"
      @mousemove="bindHoverCursor"
    >
      <div
        ref="timelineWrap"
        class="timeline-wrap"
        :style="{left: timelineOffsetLeft}"
        @mousewheel="changeMousewheel"
        @mousedown="dragTimelineEvent"
        @dblclick="handleCursorDbclick"
      >
        <!-- 进度光标 -->
        <div
          class="video-duration-cursor"
          :style="{
            left: durationCursorLeft + '%'
          }"
        >
          <div
            class="duration-text"
          >{{ durationText }}</div>
        </div>
        <!-- hover 光标 -->
        <div
          class="duration-hover-cursor"
          :style="{
            left: hoverCursorLeft + 'px'
          }"
        >
          <div class="duration-text">{{ hoverCursorTime }}</div>
        </div>
        <!-- 录像区间 -->
        <div class="video-section">
          <div
            v-for="(item, index) in recordList"
            :key="item.StartTime"
            :style="renderVideoSection(item, index)"
            class="video-section-item"
          />
        </div>
        <!-- 时间轴刻度 -->
        <div
          v-for="i in lineCount"
          :key="i"
          class="timeline-item"
          :style="{width: timelineWidth + 'px'}"
        ><span class="timeline-text">{{ timelineText(i) }}</span></div>
      </div>
    </div>
    <div class="control-wrap">
      <div class="control-left">
        <!-- 停止 -->
        <div
          class="control-item control-stop"
          @click="stopEvent"
        />
        <!-- 慢进 -->
        <div class="control-item control-rewind" @click="changeTimes(-1)" />
        <!-- 暂停 -->
        <div
          v-if="playStatus === 'play'"
          class="control-item control-pause"
          @click="pauseEvent"
        />
        <!-- 播放 -->
        <div
          v-else
          class="control-item control-play"
          @click="playEvent"
        />
        <!-- 快进 -->
        <div class="control-item control-fast-forward" @click="changeTimes(1)" />
        <!-- 倍速 -->
        <div class="control-times-text">{{ timesData.text }}</div>
      </div>
      <div class="control-right">
        <!-- 下载 -->
        <div
          class="control-item control-download"
          @click="openDownloadDialog"
        />
        <!-- 启音/静音 -->
        <div
          v-if="isMuted"
          class="control-item control-volume-muted"
          @click="mutedEvent"
        />
        <!-- 音量 -->
        <div
          v-else
          class="control-item control-volume"
          @click="mutedEvent"
        />
        <el-slider v-model="volume" @change="changeVolume" />
      </div>
    </div>
  </div>
</template>
<script>
import moment from 'moment'
import eventBus from '@/utils/eventBus'
export default {
  props: {
    date: {
      type: String,
      default: ''
    },
    recordList: {
      type: Array,
      default() {
        return []
      }
    }
  },
  data() {
    return {
      playStatus: 'stop',
      isMuted: false,
      volume: 50,
      // 刻度容器初始定位 timelineWidth * lineCount的4分之1
      timelineOffsetLeft: -64 * 24 + 'px',
      // 缩放等级 0-4
      zoomScale: 0,
      // 刻度间隔
      scaleTime: [30, 20, 10, 5, 5],
      // 进度时间
      durationText: '',
      // 光标定位
      hoverCursorLeft: 0,
      // 光标时间
      hoverCursorTime: '00:00:00',
      durationCursorLeft: 0,
      timesValue: 4,
      // 倍速操作锁定
      timesDisabled: true,
      // 倍数列表
      timesList: [
        {
          text: '1/16X',
          value: '16xslow'
        },
        {
          text: '1/8X',
          value: '8xslow'
        },
        {
          text: '1/4X',
          value: '4xslow'
        },
        {
          text: '1/2X',
          value: '2xslow'
        },
        {
          text: '',
          value: 'normal'
        },
        {
          text: '2X',
          value: '2xfast'
        },
        {
          text: '4X',
          value: '4xfast'
        },
        {
          text: '8X',
          value: '8xfast'
        },
        {
          text: '16X',
          value: '16xfast'
        },
        {
          text: '32X',
          value: '32xfast'
        },
        {
          text: '64X',
          value: '64xfast'
        }
      ]
    }
  },
  computed: {
    lineCount() {
      // 刻度间隔 单位分钟
      const scaleTime = this.scaleTime[this.zoomScale]
      // 刻度数量
      const lineCount = 60 / scaleTime * 48
      return lineCount
    },
    timelineWidth() {
      // 刻度的单位长度 px
      const timelineWidth = 64 + (this.zoomScale * 16)
      return timelineWidth
    },
    timesData() {
      return this.timesList[this.timesValue]
    }
  },
  mounted() {
    eventBus.$on('play-event', this.changeState)
    eventBus.$on('video-progress-api', this.currentTimeApiChange)
    eventBus.$on('current-time-change', this.currentTimeChange)
    eventBus.$on('set-times-res', this.handleTimesResp)
    eventBus.$on('player-active-change', this.playerActiveChange)
  },
  methods: {
    /**
     * 停止事件
     * */
    stopEvent() {
      this.playStatus = 'stop'
      eventBus.$emit('player-stop')
    },
    /**
     * 播放事件
     * */
    playEvent() {
      if (this.playStatus === 'stop') {
        // 开启播放
        eventBus.$emit('player-start-play')
      } else {
        // 恢复播放
        eventBus.$emit('player-play')
      }
      this.playStatus = 'play'
    },
    /**
     * 暂停事件
     * */
    pauseEvent() {
      this.playStatus = 'pause'
      eventBus.$emit('player-pause')
    },
    /**
     * 倍速
     * */
    changeTimes(val) {
      if (this.timesDisabled) return
      this.timesDisabled = true
      this.timesValue += val
      if (this.timesValue < 0) {
        this.timesValue = 4
      }
      if (this.timesValue > 10) {
        this.timesValue = 4
      }
      eventBus.$emit('change-times-event', this.timesData.value)
    },
    /**
     * 处理倍速操作的接口返回
     * */
    handleTimesResp() {
      this.timesDisabled = false
    },
    /**
     * active窗口发生改变
     * */
    playerActiveChange(val) {
      this.timesValue = 4
      this.isMuted = !val
      this.volume = val
    },
    /**
     * 静音/启音事件
     * */
    mutedEvent() {
      this.isMuted = !this.isMuted
      this.volume = this.isMuted ? 0 : 50
      eventBus.$emit('volume-event', this.volume)
    },
    /**
     * 改变按钮状态
     * */
    changeState() {
      this.playStatus = 'play'
    },
    /**
     * 拖拽滑块改变声音
     */
    changeVolume(val) {
      this.isMuted = !val
      eventBus.$emit('volume-event', val)
    },
    // 打开弹框
    openDownloadDialog() {
      this.$emit('open-download')
    },
    // 调用后台接口查询播放进度的改变
    currentTimeApiChange(time) {
      time = time.slice(0, 19)
      const currentTime = moment(new Date(time)).format('YYYY-MM-DD HH:mm:ss')
      const diffSecond = moment(currentTime).unix() - moment(new Date(this.date)).unix()
      this.durationCursorLeft = diffSecond / 172800 * 100 + 25
      this.durationText = currentTime
    },
    // 当前active播放窗口的播放进度发生变化
    currentTimeChange(data) {
      const currentTime = moment(data.startTime).add(data.currentTime, 's').format('YYYY-MM-DD HH:mm:ss')
      const diffSecond = moment(currentTime).unix() - moment(this.date).unix()
      this.durationCursorLeft = diffSecond / 172800 * 100 + 25
      this.durationText = currentTime
    },
    /**
     * 双击进度栏seek 操作
     * */
    handleCursorDbclick() {
      if (this.playStatus === 'play' || this.playStatus === 'pause') {
        const time = this.hoverCursorTime
        eventBus.$emit('seek-event', time)
      }
    },
    /**
     * 时间轴上刻度的时间文字
     * */
    timelineText(i) {
      const totalTime = 24 * 60
      // 刻度节点对应时间 单位分钟
      // 当前节点分钟数 + 偏移的12小时 求余后得出当前节点位于一天中的第多少分钟
      const nodeTime = ((i * this.scaleTime[this.zoomScale]) + (12 * 60)) % totalTime
      // 求余60 得出第多少小时 多少分钟
      const hour = Math.floor(nodeTime / 60)
      const minute = nodeTime % 60
      // 时分补0
      const timeText = (hour < 10 ? '0' + hour : hour) + ':' + (minute < 10 ? '0' + minute : minute)
      return timeText
    },
    /**
     * 鼠标滚动放大缩小时间轴
     * */
    changeMousewheel(e) {
      const zoom = e.wheelDeltaY || e.deltaY
      // 鼠标位于当前元素上的X轴位置 = 鼠标视口距离 - 元素视口距离
      const mouseOffsetX = e.clientX - this.$refs.timelineWrap.getBoundingClientRect().left
      // 当前元素的left的绝对值
      const left = Math.abs(this.$refs.timelineWrap.offsetLeft)
      // 当前元素滚动前的宽度
      const beforeWidth = this.lineCount * this.timelineWidth
      if (zoom > 0) {
        this.zoomScale++
        if (this.zoomScale > 4) {
          this.zoomScale = 4
        }
      } else {
        this.zoomScale--
        if (this.zoomScale < 0) {
          this.zoomScale = 0
        }
      }
      // 当前元素滚动后的宽度
      const afterWidth = this.lineCount * this.timelineWidth
      // 此处计算...自己理解,篇幅过长,无法描述
      // 目的是以鼠标所在点位为中心放大缩小
      this.$refs.timelineWrap.style.left = -(mouseOffsetX / beforeWidth * afterWidth - (mouseOffsetX - left)) + 'px'
    },
    /**
     * 时间轴拖拽事件
     * */
    dragTimelineEvent(e) {
      let lock = false
      const toolbarWidth = this.$refs.videoPlayToolbar.offsetWidth
      const wrapWidth = this.$refs.timelineWrap.offsetWidth
      const diffX = e.clientX - this.$refs.timelineWrap.offsetLeft
      const maxLeft = toolbarWidth - wrapWidth
      document.onmousemove = (e) => {
        if (lock) return
        let moveX = e.clientX - diffX
        if (moveX > 0) moveX = 0
        if (moveX < maxLeft) moveX = maxLeft
        this.timelineOffsetLeft = moveX + 'px'
      }
      document.onmouseup = () => {
        lock = true
      }
    },
    /**
     * 渲染有录像的区间
     * */
    renderVideoSection(data, index) {
      data.StartTime = data.StartTime.replace(/\//g, '-')
      data.EndTime = data.EndTime.replace(/\//g, '-')
      // 进度的尺度总秒数
      const totalSecond = this.lineCount * this.scaleTime[this.zoomScale] * 60
      let start = ''
      const duration = new Date(data.EndTime).getTime() - new Date(data.StartTime).getTime()
      // 开始时间 格式转时分秒
      start = moment(data.StartTime).format('HH:mm:ss')
      // 开始时间 位于一天中的第多少秒
      start = moment.duration(start, 's')._milliseconds / 1000
      // 第一段视频 跨天 则计算出负数
      if (index === 0) {
        // const diffSecond = moment(data.StartTime).unix() - (new Date(this.date + ' 12:00:00').getTime() / 1000 - 86400)
        // this.timelineOffsetLeft = -(diffSecond / 172800 * 100) + '%'
        if (moment(data.StartTime).isBefore(new Date(this.date), 'day')) {
          start = start - 86400
        }
      }
      // 宽度按照尺度总长计算
      // 定位则按照一天的总长计算 加上半天的偏移量
      return {
        width: duration / 1000 / totalSecond * 100 + '%',
        left: (start / totalSecond * 100 + 25) + '%'
      }
    },
    /**
     * hover 光标
     * */
    bindHoverCursor(ev) {
      const left = this.$refs.timelineWrap.getBoundingClientRect().left
      const width = this.$refs.timelineWrap.offsetWidth
      this.hoverCursorLeft = ev.clientX - left
      // 刻度尺标总秒数
      const totalSecond = 86400 * 2
      // hover对应的位置的秒数节点 + 偏移的12小时
      const positionTime = this.hoverCursorLeft / width * totalSecond
      // 刻度尺初始时间
      const initTime = new Date(this.date).getTime() - 43200000
      this.hoverCursorTime = moment(initTime).add(positionTime, 's').format('YYYY-MM-DD HH:mm:ss')
    }
  }
}
</script>
<style lang="scss">
.video-play-toolbar {
  height: 82px;
  overflow: hidden;
  user-select: none;
  background-color: rgba(0, 0, 0, 0.4);

  .timeline-main {
    position: relative;
    height: 42px;

    // 时间轴
    .timeline-wrap {
      display: flex;
      flex-wrap: nowrap;
      align-items: flex-end;
      position: absolute;
      top: 12px;
      left: 0;
      height: 26px;
      text-align: right;

      // 时间轴刻度线
      .timeline-item {
        flex-shrink: 0;
        position: relative;
        height: 24px;
        box-sizing: border-box;

        &::before {
          content: "";
          display: inline-block;
          position: absolute;
          bottom: 0;
          left: 100%;
          width: 1px;
          height: 10px;
          background-color: #0062ff;
        }
      }
      .timeline-text {
        margin-right: -16px;
      }
    }
  }

  .video-duration-cursor {
    position: absolute;
    left: 0;
    top: -10px;
    width: 1px;
    height: 42px;
    color: #00ffee;
    background-color: #00ffee;

  }
  .duration-text {
    width: 120px;
    text-align: left;
  }

  // hover 光标
  .duration-hover-cursor {
    display: none;
    position: absolute;
    left: 10px;
    top: -10px;
    width: 1px;
    height: 42px;
    color: rgb(230, 36, 84);
    background-color: rgb(230, 36, 84);
  }
  .timeline-main:hover .duration-hover-cursor {
    display: block;
  }

  // 有录像的时间区间
  .video-section {
    position: absolute;
    top: 26px;
    width: 100%;
    height: 6px;
    background: #8493b4;

    &-item {
      position: absolute;
      top: 0;
      height: 6px;
      background-color: blue;
    }
  }

  // 播放器控件
  .control-wrap {
    display: flex;
    align-items: center;
    width: 100%;
    height: 40px;

    .control-left,.control-right {
      display: flex;
      align-items: center;
    }

    // 左侧控件
    .control-left {
      flex-grow: 1;
    }

    // 右侧控件
    .control-right {
      margin-right: 16px;
    }

    // 控件通用样式
    .control-item {
      width: 30px;
      height: 30px;
      margin-left: 16px;
      background-image: url(../../../assets/img/playback.png);
      background-repeat: no-repeat;
      cursor: pointer;
    }

    // 停止
    .control-stop {
      background-position: -23px 0px;

      &:hover {
        background-position: -23px -33px;
      }
    }

    // 播放
    .control-play {
      background-position: -130px 1px;

      &:hover {
        background-position: -130px -32px;
      }
    }

    // 暂停
    .control-pause {
      background-position: -471px 1px;

      &:hover {
        background-position: -471px -32px;
      }
    }

    // 倒带
    .control-rewind {
      background-position: -50px 0px;

      &:hover {
        background-position: -50px -33px;
      }
    }

    .control-fast-forward {
      background-position: -238px 0;

      &:hover {
        background-position: -238px -33px;
      }
    }

    // 倍速
    .control-times-text {
      margin-left: 16px;
      line-height: 18px;
      font-size: 16px;
    }

    .control-download {
      background-position: -529px 0;

      &:hover {
        background-position: -529px -33px;
      }
    }

    // 启音
    .control-volume {
      background-position: -436px 0;

      &:hover {
        background-position: -436px -33px;
      }
    }

    // 静音
    .control-volume-muted {
      background-position: -651px 0;

      &:hover {
        background-position: -651px -33px;
      }
    }

    // 音量控制
    .el-slider {
      margin-left: 12px;
      width: 100px;
    }
  }
}
</style>
