<template>
  <div
    :id="'playback_' + channelId"
    class="video-player-item"
    @dblclick="screen"
  />
</template>
<script>
import {
  createTask,
  startPalyback,
  getPlaybackUrl,
  getWebsocketAccess,
  vcrCtrlSeek,
  getVideoProgress,
  Destroy
} from '@/api/resourceManage'
import eventBus from '@/utils/eventBus'
import { KMediaUni } from 'kmedia-uni'
import moment from 'moment'
window.KMediaUni = KMediaUni
export default {
  props: {
    recordList: {
      type: Array,
      default() {
        return []
      }
    },
    channelId: {
      type: String,
      default: ''
    },
    activeChannel: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      player: null,
      taskId: '',
      progressTimer: null,
      lastSeekCurrentTime: 0,
      StartTime: '',
      EndTime: '',
      // 第几段录像
      recordIndex: 0
    }
  },
  watch: {
    activeChannel(nv) {
      this.setToolbarVolume()
      this.changeTimesEvent('normal', true)
    },
    recordList: {
      deep: true,
      handler(nv) {
        this.StartTime = moment(nv[0].StartTime).format('YYYY-MM-DDTHH:mm:ss')
        this.EndTime = moment(nv[0].EndTime).format('YYYY-MM-DDTHH:mm:ss')
        this.loadPlayback()
      }
    }
  },
  mounted() {
    this.initPlayer()
    eventBus.$on('seek-event', this.handleSeekEvent)
    eventBus.$on('volume-event', this.changeVolume)
    eventBus.$on('player-play', this.playerPlayEvent)
    eventBus.$on('player-pause', this.playerPauseEvent)
    eventBus.$on('change-times-event', this.changeTimesEvent)
  },
  destroyed() {
    clearInterval(this.progressTimer)
    // 防止同一组件的重复触发 需要解除监听
    eventBus.$off('volume-event')
    eventBus.$off('seek-event')
    eventBus.$off('player-play')
    eventBus.$off('player-pause')
    eventBus.$off('change-times-event')
    if (this.player) {
      this.player.destroy()
    }
    if (this.taskId) {
      Destroy({
        PlayTaskDestroyReq: {
          TaskID: this.taskId
        }
      })
      this.taskId = ''
    }
  },
  methods: {
    initPlayer() {
      this.player = new KMediaUni({
        selector: document.querySelector('#playback_' + this.channelId),
        loading: true,
        control: {
          hideControlsBar: true
        },
        display: {
          fillType: 'fullup'
        },
        request: {
          restore: 10,
          timeout: 5
        },
        autoplay: true
      })
      this.player.addEventListener('loadedmetadata', () => {
        this.getVideoProgress()
        this.setToolbarVolume()
        eventBus.$emit('set-times-res')
      })
      this.player.addEventListener('error', () => {
        clearInterval(this.progressTimer)
      })
    },
    // 全屏
    screen() {
      if (this.player.isFullscreen()) {
        this.player.exitFullscreen()
      } else {
        this.player.requestFullscreen()
      }
    },
    /**
     * 暂停 操作
     */
    playerPlayEvent() {
      this.player.play()
    },
    /**
     * 暂停 操作
     */
    playerPauseEvent() {
      this.player.pause()
    },
    /**
     * 倍数播放
     */
    changeTimesEvent(val, reset) {
      if (this.channelId !== this.activeChannel && !reset) return
      this.vcrCtrlSeek({
        CmdType: val,
        FrameMode: 'all'
      }).then(() => {
        eventBus.$emit('set-times-res')
      }).catch(() => {
        eventBus.$emit('set-times-res')
      })
    },
    /**
     * 音量控制
     */
    changeVolume(val) {
      if (this.channelId !== this.activeChannel) return
      this.player.volume(val)
    },
    setToolbarVolume() {
      if (this.channelId !== this.activeChannel) return
      const volume = this.player.volume()
      eventBus.$emit('player-active-change', volume)
    },
    /**
     * toolbar的seek 操作
     */
    async handleSeekEvent(time) {
      if (this.channelId !== this.activeChannel) return
      const data = this.recordList.find(item => moment(time).isBetween(item.StartTime, item.EndTime))
      this.recordIndex = this.recordList.indexOf(data)
      console.log(data)
      // seek时刻无录像
      if (!data) {
        this.StartTime = moment(time).format('YYYY-MM-DDTHH:mm:ss')
        clearInterval(this.progressTimer)
        this.player.closeStream()
        this.player.loadVideo()
        return
      }
      // 当前录像时段内seek
      if (moment(this.StartTime).isBetween(data.StartTime, data.EndTime)) {
        this.vcrCtrlSeek({
          CmdType: 'drag',
          SeekTime: moment(time).format('YYYY-MM-DDTHH:mm:ss'),
          FrameMode: 'all'
        })
      } else {
        // seek到其它录像时段
        this.StartTime = moment(time).format('YYYY-MM-DDTHH:mm:ss')
        this.EndTime = moment(data.EndTime).format('YYYY-MM-DDTHH:mm:ss')
        clearInterval(this.progressTimer)
        this.loadPlayback()
      }
    },
    // 调用后台seek接口
    vcrCtrlSeek(params) {
      return new Promise((resolve, reject) => {
        vcrCtrlSeek({
          PlayTaskVcrCtrlReq: {
            TaskID: this.taskId,
            NvrChnID: this.channelId,
            PlyReverse: false,
            CtrlCmd: params
          }
        }).then(_ => {
          resolve()
        }).catch(_ => {
          reject()
        })
      })
    },
    // 调用后台接口获取播放进度
    getVideoProgress() {
      clearInterval(this.progressTimer)
      this.progressTimer = setInterval(() => {
        if (this.channelId === this.activeChannel) {
          getVideoProgress({
            PlayTaskQueryProgReq: {
              TaskID: this.taskId,
              NvrChnID: this.channelId
            }
          }).then(res => {
            const state = res.PlayTaskQueryProgResp.State
            // 一段录像播放完成
            if (state === 'over') {
              clearInterval(this.progressTimer)
              this.recordIndex++
              const data = this.recordList[this.recordIndex]
              if (data) {
                // 如果存在下一段 自动播放
                this.StartTime = data.StartTime
                this.EndTime = data.EndTime
                this.loadPlayback()
              } else {
                // 当日无可播放录像
                this.player.loadVideo()
              }
              return
            }
            //  播放,暂停,单帧 等状态继续查询播放进度
            if (state === 'play' || state === 'pause' || state === 'single') {
              eventBus.$emit('video-progress-api', res.PlayTaskQueryProgResp.Systime)
            } else {
              this.destoryProgressTask()
            }
          }).catch(() => {
            this.destoryProgressTask()
          })
        }
      }, 1000)
    },
    destoryProgressTask() {
      // 清除调用后台接口查询进度的定时器
      clearInterval(this.progressTimer)
      // 释放播放器
      this.player.loadVideo()
      // 销毁播放任务
      Destroy({
        PlayTaskDestroyReq: {
          TaskID: this.taskId
        }
      })
    },
    // 加载录像回放资源
    async loadPlayback() {
      this.taskId = await this.createTask()
      await this.startPalyback(this.taskId)
      const url = await this.getPlaybackUrl(this.taskId)
      this.establishWebsocket(url)
    },
    // 创建任务
    createTask() {
      return new Promise((resolve, reject) => {
        createTask({
          PlayTaskCreateReq: {
            PBType: 'by_time',
            AddChnPlayCondType: 'more'
          }
        }).then(res => {
          resolve(res.PlayTaskCreateResp.TaskID)
        }).catch(_ => {
          reject()
        })
      })
    },
    // 开启录像回放(在服务端)
    startPalyback(id) {
      return new Promise((resolve, reject) => {
        startPalyback({
          PlayTaskStartReq: {
            TaskID: id,
            NvrChnID: this.channelId
          }
        }).then(res => {
          resolve(res)
        }).catch(_ => {
          reject()
        })
      })
    },
    // 获取回放使用的rtsp协议的url
    getPlaybackUrl(id) {
      return new Promise((resolve, reject) => {
        getPlaybackUrl({
          GetRtspUrlReplayReq: {
            TaskID: id,
            NvrChnID: this.channelId,
            StartTime: this.StartTime,
            EndTime: this.EndTime,
            VideoList: {
              P_R_O_P: {
                num: 1
              },
              K_E_Y: 'EncID',
              V_A_L_U_E: [1]
            },
            AudioList: {
              P_R_O_P: {
                num: 1
              },
              K_E_Y: 'SrcID',
              V_A_L_U_E: [1]
            }
          }
        }).then(res => {
          resolve(res.GetRtspUrlReplayResp.RtspUrl)
        }).catch(_ => {
          reject()
        })
      })
    },
    // 使用websocket与服务端建立连接
    establishWebsocket(url) {
      getWebsocketAccess({}).then(res => {
        const rtspUrl = res.GetWebsocketAccessResp.Url
        let websocket = ''
        if (rtspUrl.match(/(ws+:\/\/(.+):\d{0,4})/)) websocket = RegExp.$1
        this.player.loadVideo({
          src: {
            websocketUrl: websocket,
            rtspUrl: url,
            username: this.$store.getters.username,
            password: this.$store.getters.pwd
          },
          transport: KMediaUni.MODE.MSE,
          autoplay: true
        })
      })
    }
  }
}
</script>
<style lang="scss">
.video-player-item {
  height: 100%;
}
</style>
