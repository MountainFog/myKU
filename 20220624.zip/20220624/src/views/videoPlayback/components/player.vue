<template>
  <div class="playback-player-box">
    <div :class="['video-playback-player', 'player-style-' + playerCount]">
      <div
        v-for="(item, index) in playerCount"
        :key="item"
        :class="['player-item', {'player-item__active': channelSelect[index] === activeChannel}]"
      >
        <player-item
          v-if="channelSelect[index]"
          :active-channel="activeChannel"
          :record-list="recordData['channel_' + channelSelect[index]]"
          :channel-id="channelSelect[index]"
          @click.native="changeActive(channelSelect[index])"
        />
      </div>
    </div>
  </div>
</template>
<script>
import PlayerItem from './playerItem.vue'
export default {
  components: {
    PlayerItem
  },
  props: {
    recordData: {
      type: Object,
      default() {
        return {}
      }
    },
    channelSelect: {
      type: Array,
      default() {
        return []
      }
    },
    activeChannel: {
      type: String,
      default: ''
    }
  },
  computed: {
    playerCount() {
      let count = 0
      if (this.channelSelect.length) {
        count = 1
      }
      if (this.channelSelect.length > 1) {
        count = 4
      }
      if (this.channelSelect.length > 4) {
        count = 9
      }
      return count
    }
  },
  methods: {
    changeActive(id) {
      this.$emit('change-active', id)
    }
  }
}
</script>
<style lang="scss">
// 约束播放器比例
.playback-player-box {
  position: relative;
  width: 100%;
  padding-top: 56.25%;

  .video-playback-player {
    display: flex;
    flex-wrap: wrap;
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    background-color: #181b21;
  }
  .player-item {
    background-color: #232325;
    border: 1px solid #333;
  }
  .player-item__active {
    border-color: #00ffee;
  }

  .player-style-1 {
    .player-item {
      width: 100%;
      height: 100%;
    }
  }
  .player-style-4 {
    .player-item {
      width: 50%;
      height: 50%;
    }
  }
  .player-style-9 {
    .player-item {
      width: 33.3%;
      height: 33.3%;
    }
  }
}
</style>
