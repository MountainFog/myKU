<template>
  <div class="video-playback">
    <div class="kd-main-title">资源管理 / 录像回放</div>
    <div class="video-playback-main">
      <div class="video-playback-left">
        <div class="channel-title icon-title">通道列表</div>
        <el-checkbox-group
          v-model="channelSelect"
          :max="9"
          class="channel-list"
          @change="changeChannelActive"
        >
          <div
            v-for="item in nvrList"
            :key="item.ChnID"
            class="channel-list-item"
          >
            <el-checkbox
              :disabled="channleDisabled"
              :label="item.ChnID"
            >D{{ item.ChnID + ' ' + item.ChnAlias }}</el-checkbox>
            <span>({{ item.state || '空' }})</span>
          </div>
        </el-checkbox-group>
        <Calendar
          :future-day-hide="today"
          :mark-date="markDate"
          @choseDay="chooseDate"
        />
        <el-button
          class="search-btn"
          type="primary"
          :disabled="queryDisabled"
          @click="querySvrChnMonthMap"
        >查询</el-button>
      </div>
      <div class="playback-player-wrap">
        <Player
          :record-data="recordData"
          :channel-select="channelSelect"
          :active-channel="activeChannel"
          @change-active="handleChangeActive"
        />
        <player-toolbar
          :record-list="recordList"
          :date="queryDate"
          @open-download="openDownload"
        />
      </div>
    </div>
    <el-dialog
      :visible.sync="downloadShow"
      width="1000px"
      title="录像下载"
    >
      <download />
    </el-dialog>
  </div>
</template>
<script>
import {
  QuerySvrChnMonthMap,
  GetSvrMonthMapResult,
  QuerySvrChnRecResult,
  QuerySvrChnRec
} from '@/api/resourceManage'
import Calendar from './components/calendar.vue'
import Player from './components/player.vue'
import playerToolbar from './components/playerToolbar.vue'
import download from './components/download.vue'
import { isArray } from '@/utils'
import moment from 'moment'
import { getChannel } from '@/views/applicationScenarios/getChannel'
import eventBus from '@/utils/eventBus'
export default {
  name: 'VideoPlayback',
  components: {
    Calendar,
    Player,
    playerToolbar,
    download
  },
  mixins: [getChannel],
  data() {
    return {
      today: moment().unix().toString(),
      // 通道列表选中
      channelSelect: [],
      // 通道禁选
      channleDisabled: false,
      // 选中的窗口 值为对应通道id
      activeChannel: '',
      // 查询条件 月份
      queryYear: moment().year(),
      // 查询条件 日期
      queryMonth: moment().month() + 1,
      queryDate: moment().format('YYYY/MM/DD'),
      queryDisabled: false,
      // 标记的日期 有录像
      markDate: [],

      futureDayHide: new Date().getTime().toString(),
      searchDate: new Date(),
      recordData: {},
      downloadShow: false
    }
  },
  computed: {
    recordList() {
      const list = this.recordData['channel_' + this.activeChannel]
      return list
    }
  },
  mounted() {
    this.querySvrChnMonthMap()
    eventBus.$on('player-start-play', this.handlePlayerPlay)
    eventBus.$on('player-stop', this.handlePlayerStop)
  },
  methods: {
    // 在日期组件上标记有录像的日期
    markDatePicker(dates) {
      this.markDate = []
      const list = Array.from(new Set(dates))
      list.forEach(item => {
        this.markDate.push(`${this.queryYear}-${this.queryMonth}-${item}`)
      })
    },
    // 日期组件选择事件
    chooseDate(val) {
      this.queryDate = val.replace(/-/, '/')
      const dates = val.split('/')
      this.queryYear = dates[0]
      this.queryMonth = dates[1]
    },
    // 创建月视图查询任务
    querySvrChnMonthMap() {
      const list = []
      for (let i = 0; i < 17; i++) {
        list.push(i + 1)
      }
      const params = {
        QuerySvrChnMonthMapReq: {
          Year: this.queryYear,
          Month: this.queryMonth,
          ChnList: {
            P_R_O_P: {
              num: 17
            },
            K_E_Y: 'ChnID',
            V_A_L_U_E: list
          }
        }
      }
      this.queryDisabled = true
      QuerySvrChnMonthMap(params).then(res => {
        this.sessionID = res.QuerySvrChnMonthMapResp.SessionID
        this.GetSvrMonthMapResult()
      }).catch(_ => {
        this.queryDisabled = false
      })
    },
    // 获取月视图查询结果
    GetSvrMonthMapResult() {
      GetSvrMonthMapResult({
        GetSvrMonthMapResultReq: {
          SessionID: this.sessionID
        }
      }).then(res => {
        const state = res.GetSvrMonthMapResultResp.QueryState
        // 准备查询或者正在查询阶段 轮询
        if (state === 'ready' || state === 'operating') {
          setTimeout(() => {
            this.GetSvrMonthMapResult()
          }, 1000)
        } else {
          this.queryDisabled = false
          this.findVideoStateOrDate(res.GetSvrMonthMapResultResp.ChnList.ChnItem)
        }
      }).catch(_ => {
        this.queryDisabled = false
      })
    },
    // 查找对应的设备录像状态和录像日期
    findVideoStateOrDate(data) {
      let list = []
      if (Array.isArray(data)) {
        list = data
      } else {
        list.push(data)
      }
      const dates = []
      const channels = []
      list.forEach(item => {
        const days = item.MonthMap.split(',')
        const day = Math.abs(this.queryDate.split('/')[2]).toString()
        if (days.indexOf(day) > -1) {
          channels.push(item.ChnID)
        }
        dates.push(...days)
      })
      this.nvrList.forEach((item) => {
        if (channels.indexOf(item.ChnID) > -1) {
          item.state = '有录像'
        } else {
          item.state = '空'
        }
      })
      this.markDatePicker(dates)
    },
    // 查询通道录像
    querySvrChnRec() {
      QuerySvrChnRec({
        QuerySvrChnRecReq: {
          StartTime: this.queryDate + ' 00:00:00',
          EndTime: this.queryDate + ' 23:59:59',
          ChnList: {
            P_R_O_P: {
              num: this.channelSelect.length,
              max: 17
            },
            K_E_Y: 'ChnID',
            V_A_L_U_E: this.channelSelect
          },
          StartInx: 0,
          Count: 300
        }
      }).then(res => {
        this.querySvrChnRecResult(res.QuerySvrChnRecResp.SessionID)
      })
    },
    // 获取通道录像的查询结果
    querySvrChnRecResult(id) {
      QuerySvrChnRecResult({
        QuerySvrChnRecResultReq: {
          SessionID: id
        }
      }).then(res => {
        const state = res.QuerySvrChnRecResultResp.QueryState
        if (state === 'ready' || state === 'operating') {
          setTimeout(() => {
            this.querySvrChnRecResult(id)
          }, 1000)
        } else {
          let recordList = res.QuerySvrChnRecResultResp.RecordList.RecordItem
          if (!recordList) return
          // 对象转数组
          if (!isArray(recordList)) recordList = [recordList]
          this.recordData = {}
          recordList.forEach(item => {
            const key = 'channel_' + item.ChnID
            if (this.recordData[key]) {
              this.recordData[key].push(item)
            } else {
              this.recordData[key] = [item]
            }
          })
        }
      })
    },
    changeChannelActive(val) {
      this.activeChannel = val[val.length - 1]
    },
    /**
     * 停止按钮触发事件
     */
    handlePlayerStop() {
      this.channleDisabled = false
      this.channelSelect = []
    },
    /**
     * 开启播放事件
     */
    handlePlayerPlay() {
      this.querySvrChnRec()
      this.channleDisabled = true
    },
    /**
     * 播放窗口点击改变active
     */
    handleChangeActive(id) {
      this.activeChannel = id
    },
    openDownload() {
      this.downloadShow = true
    }
  }
}
</script>
<style lang="scss">
.video-playback {
  padding: 8px 40px;
  height: 100%;
  min-height: 780px;
  background-color: #1d222c;

  &-main {
    height: calc(100% - 57px);
    display: flex;

    // 左侧通道列表
    .video-playback-left {
      display: flex;
      flex-direction: column;
      flex-wrap: nowrap;
      width: 300px;
      height: 100%;

      .channel-title {
        margin: 16px 0 0;
        font-size: 20px;
      }

      .channel-list {
        padding-left: 16px;
        overflow: auto;
      }
      .channel-list-item {
        margin-top: 12px;
        font-size: 14px;

        >span {
          margin-left: 8px;
        }
      }
      .search-btn {
        flex-shrink: 0;
        margin-top: 22px;
        width: 100%;
      }
    }
  }

  // 播放器样式
  .playback-player-wrap {
    // channel-list + margin-left = 320px
    width: calc(100% - 320px - 140px);
    margin-left: 84px;
    margin-top: 20px;
  }

}
</style>
