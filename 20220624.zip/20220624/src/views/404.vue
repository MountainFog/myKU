<template>
  <div class="http404-container">
    <div class="http404">
      <div class="pic-404">
        <img class="pic-404__parent" src="@/assets/404_images/404.png" alt="404">
      </div>
      <div class="bullshit">
        <p>404</p>
        <p>天啊，该页面被外星人抓走啦！尝试刷新找回来吧！</p>
        <el-button
          type="primary"
          @click="$router.push('/')"
        >刷新</el-button>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'Page404'
}
</script>

<style lang="scss" scoped>
.http404-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  background-color: #1d222c;

  .http404 {
    display: flex;

    .pic-404 {
      width: 318px;
      height: 318px;
    }

    .pic-404__parent {
      width: 100%;
      height: 100%;
    }
  }

  .bullshit {
    width: 336px;
    margin-left: 80px;
    color: $-fff-85;

    p:nth-child(1) {
      letter-spacing: 2px;
      font-size: 80px;
      font-weight: 600;
      line-height: 88px;
    }

    p:nth-child(2) {
      margin-bottom: 64px;
      font-size: 24px;
      color: $-fff-65;
      line-height: 36px;
    }

    .el-button {
      width: 126px;
      height: 32px;
      padding: 0;
    }
  }
}
</style>
