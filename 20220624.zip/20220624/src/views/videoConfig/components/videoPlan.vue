<template>
  <div class="video-plan-container">
    <div class="form-item">
      <el-form ref="videoPlanForm" label-width="90px" label-position="left">
        <el-form-item label="选择通道：">
          <el-select v-model="videoPlanInfo.ChnID" class="border-select-default input-video-plan" @change="switchChnInfo">
            <el-option
              v-for="item in nvrList"
              :key="item.ChnID"
              :label="'D' + item.ChnID + ' ' + item.ChnAlias"
              :value="item.ChnID"
            />
          </el-select>
          <input type="button" class="default default-border-radius marginLeft8" value="复制通道" @click="copyChnInfo">
        </el-form-item>
        <el-form-item label="录制音频：">
          <el-select v-model="videoPlanInfo.RecAud" class="border-select-default input-width-default">
            <el-option v-for="item in RecAudList" :key="item.value" :value="item.value" :label="item.label" />
          </el-select>
        </el-form-item>
        <el-form-item label="录制码流：">
          <el-select v-model="videoPlanInfo.RecStream" class="border-select-default input-width-default">
            <el-option value="main_pri" label="主码流" />
            <el-option value="2nd_pri" label="辅码流" />
            <el-option value="3rd_pri" label="其他码流" />
          </el-select>
        </el-form-item>
        <el-form-item label="录像模式：">
          <el-select v-model="videoPlanInfo.RecMode" class="border-select-default input-width-default">
            <el-option value="start" label="始终开启" />
            <el-option value="stop" label="始终关闭" />
            <el-option value="auto" label="按时间计划" />
          </el-select>
        </el-form-item>
      </el-form>
    </div>
    <div class="delete-group-btn">
      <!-- <input type="button" class="default default-border-radius default-delete-spe" value="删除"/> -->
      <input type="button" class="default default-border-radius" value="全部删除" @click.stop="deleteAll">
    </div>
    <div class="timeplan_days" onselectstart="return false;">
      <i v-for="n in 13" :key="classInit(n - 1)" class="icon-gap" :class="classInit(n - 1)" />
      <div class="timeplan_day timeplan_time-title">
        <div class="timeplan_dayname">
          <label />
        </div>
        <div class="timeplan_daydraw timeplan_time_line" />
      </div>
      <div v-for="(timeInfo,idx) in listInfo" :key="idx" class="timeplan_day">
        <div class="timeplan_dayname">
          <label :name="timeInfo.Week">{{ getWeekInfo( timeInfo.Week ) }}</label>
        </div>
        <div class="timeplan_daydraw">
          <div id="videoPlanTime_dayTimePlan1" ref="lineItem" class="timeplan_daytimeplan" @mousedown.self.stop="mouseDownItem($event,timeInfo.Week,idx)" @mouseup.self.stop="mouseupItem($event,timeInfo.Week,idx)">
            <el-tooltip v-for="(item,index) in timeInfo.Seg" v-if="timeInfo.Seg" :key="index" class="item" :hide-after="1000" effect="dark" :content="countTip(item)" placement="top">
              <div ref="drag" v-drag="{&quot;aindex&quot;:index,&quot;week&quot;: timeInfo.Week}" class="timeplan_section" :style="{ width: getLineWidth(item).width,left: getLineWidth(item).left }" @click.self="showCurrentTime(item,index,timeInfo.Week)">
                <i class="timeplan_resizeLeft" />
                <i class="timeplan_resizeRight" />
              </div>
            </el-tooltip>
          </div>
        </div>
        <div class="timeplan_copyto">
          <el-tooltip class="item" effect="dark" content="复制" placement="top">
            <i class="timeplan_copyto_icon" @click="copyInfo(timeInfo.Week,timeInfo.Seg)" />
          </el-tooltip>
        </div>
      </div>
    </div>
    <div class="save-group-btn">
      <input type="button" class="primary default-border-radius" value="保存" @click.stop="saveConfig">
    </div>
    <el-dialog :visible.sync="timeSyn" :close-on-click-modal="false" :close-on-press-escape="false" class="video-plan-time">
      <el-form refs="timeLineForm">
        <el-form-item>
          <el-input v-model="form.beginHour" type="text" class="width-default border-input-default default-border-radius" oninput="value=value.replace(/\D/g,'')" maxlength="2" />
          <span class="gap-span">:</span>
          <el-input v-model="form.beginMinues" type="text" maxlength="2" class="width-default border-input-default default-border-radius" oninput="value=value.replace(/\D/g,'')" />
          <span class="gap-span">-</span>
          <el-input v-model="form.endHour" type="text" maxlength="2" class="width-default border-input-default default-border-radius" oninput="value=value.replace(/\D/g,'')" />
          <span class="gap-span">:</span>
          <el-input v-model="form.endMinues" type="text" maxlength="2" class="width-default border-input-default default-border-radius" oninput="value=value.replace(/\D/g,'')" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <input type="button" class="default default-border-radius font-title-color" value="删除" @click.self="deleteTime">
        <input type="button" class="primary default-border-radius marginLeft16" value="保存" @click.self="addTime">
      </div>
    </el-dialog>
    <el-dialog :visible.sync="copyWeek" class="week-copy-dialog" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false">
      <div class="group-btn-dialog">
        <el-checkbox v-model="checkAll" class="check-all" :indeterminate="isIndeterminate" @change="handleCheckAllChange">全选</el-checkbox>
        <el-checkbox-group
          v-model="checkedWeekList"
          @change="handleItem"
        >
          <el-checkbox v-for="item in weekCheckedList" :key="item.value" :label="item.value" :disabled="isDisabled === item.value">{{ item.label }}</el-checkbox>
        </el-checkbox-group>
      </div>
      <div class="copy-week-container">
        <input type="button" class="primary default-border-radius" value="确定" @click.stop="ensureCopy">
        <input type="button" class="default default-border-radius marginLeft16" value="取消" @click.stop="cancelCopy">
      </div>
    </el-dialog>
    <el-dialog :visible.sync="copyChn" class="copy-chn-dialog" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false" title="复制到">
      <el-scrollbar>
        <div class="el-scrollbar-list">
          <div v-for="item in nvrList" class="chn-info">
            <el-checkbox-group v-model="copyChnList">
              <el-checkbox :key="item.ChnID" :disabled="isChnDisabled === item.ChnID" :label="item.ChnID">{{ 'D' + item.ChnID + ' ' + item.ChnAlias }}</el-checkbox>
            </el-checkbox-group>
          </div>
        </div>
      </el-scrollbar>
      <div class="copy-chn-btn-groups">
        <input type="button" class="primary default-border-radius" value="确定" @click.stop="ensureChnCopy">
        <input type="button" class="default default-border-radius marginLeft16" value="取消" @click.stop="cancelChnCopy">
      </div>
    </el-dialog>
  </div>
</template>

<script>
import store from '@/store'
import { dateFormat } from '@/utils/dateFormat'
import { getSvrChnRecCfgEx, setSvrChnRecCfgEx, copySvrChnRecCfg } from '@/api/resourceManage'
import { getSvrChnList, getNvrChnList, getCompositeChnCap, getSrvCap } from '@/api/channelManage'
export default {
  directives: {
    drag: function(el, binding, vnode) {
      const dragBox = el // 获取当前元素
      const that = vnode.context
      let firstT = 0
      let lastT = 0
      dragBox.onmousedown = e => {
        e.stopPropagation()
        window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty()
        dragBox.setAttribute('data-flag', false)
        // 算出鼠标相对元素的位置
        const disX = e.clientX - dragBox.offsetLeft
        const disY = e.clientY - dragBox.offsetTop
        firstT = new Date().getTime()
        const weekN = binding.value.week // 一周中的那一天的数据接收
        const index = Number(binding.value.aindex) // 在数组中的位置
        const listWeek = that.getCurrentList(weekN)
        const len = listWeek.length // 数组长度
        const isL = !(len - 1 - index) // 最后一个元素
        const sumLineWidth = that.lineWidth
        document.onmousemove = e => {
          e.stopPropagation()
          // 用鼠标的位置减去鼠标相对元素的位置，得到元素的位置
          let left = e.clientX - disX
          const top = e.clientY - disY
          const leftMin = 0
          const leftMax = 0
          if (index == 0) { // 第一个
            if (left <= 0) { // 可以拖动的最最左边位置
              left = 0
            }
            if (isL) { // 是最后一个
              if ((sumLineWidth - dragBox.clientWidth) <= left) { // 最远移动距离
                left = (sumLineWidth - dragBox.clientWidth)
              }
            } else { // 还有其他元素
              const nextEle = that.getElementWidth(listWeek[index + 1], sumLineWidth)
              if ((nextEle.left - dragBox.clientWidth - 0.8) <= left) { // 可以拖动的最右边位置
                left = (nextEle.left - dragBox.clientWidth - 0.8)
              }
            }
          } else if (isL) { // 是最后一个
            if (index !== 0) { // 不是第一个
              const preEle = that.getElementWidth(listWeek[index - 1], sumLineWidth) // 前一个元素
              if ((left - preEle.left - 0.8) <= preEle.width) { // 可以拖动的最左位置
                left = (preEle.left + preEle.width + 0.8)
              }
            }
            if ((sumLineWidth - dragBox.clientWidth) <= left) { // 最远移动距离
              left = sumLineWidth - dragBox.clientWidth
            }
          } else { // 中间元素
            const preE = that.getElementWidth(listWeek[index - 1], sumLineWidth)
            const nextE = that.getElementWidth(listWeek[index + 1], sumLineWidth)
            if ((left - preE.left - 0.8) <= preE.width) { // 拖动的最左位置
              left = (preE.left + preE.width + 0.8)
            }
            if (nextE.left <= (left + dragBox.clientWidth + 0.8)) { // 拖动的最右位置
              left = (nextE.left - dragBox.clientWidth - 0.8)
            }
          }
          if ((sumLineWidth - dragBox.clientWidth) <= left) {
            left = sumLineWidth - dragBox.clientWidth
          }
          dragBox.style.left = left + 'px'
          dragBox.style.top = 0 + 'px'
        }
        document.onmouseup = e => {
          e.stopPropagation()
          lastT = new Date().getTime()
          if ((lastT - firstT) > 200) { // 拖拽
            dragBox.setAttribute('data-flag', true)
            const TimeObj = that.positionGetTime(dragBox, listWeek[index])
            listWeek.splice(index, 1, TimeObj)
            that.setCurrentList(weekN, listWeek)
          }
          // 鼠标弹起来的时候不再移动
          document.onmousemove = null
          // 预防鼠标弹起来后还会循环（即预防鼠标放上去的时候还会移动）
          document.onmouseup = null
        }
      }
    }
  },
  data() {
    return {
      nvrList: [],
      lineWidth: 576,
      listInfo: [], // 周数据信息
      clickWeekInfo: '', // 编辑一周中的那一天
      beginPoint: 0, // 起始点
      beginSecond: 0, // 起始秒数
      timeSyn: false,
      form: { // 弹框展示信息
        beginHour: '00',
        beginMinues: '00',
        endHour: '00',
        endMinues: '00'
      },
      videoPlanInfo: {}, // 数据信息
      RecAudList: [
        {
          value: 'true',
          label: '是'
        },
        {
          value: 'false',
          label: '否'
        }
      ],
      copyWeek: false, // 复制控制
      weekCheckedList: [
        {
          value: 'Mon',
          label: '星期一'
        },
        {
          value: 'Tues',
          label: '星期二'
        },
        {
          value: 'Wed',
          label: '星期三'
        },
        {
          value: 'Thur',
          label: '星期四'
        },
        {
          value: 'Fri',
          label: '星期五'
        },
        {
          value: 'Sat',
          label: '星期六'
        },
        {
          value: 'Sun',
          label: '星期日'
        }/* ,
          {
            value: 'Holiday',
            label: '假日'
          } */
      ],
      checkedWeekList: [],
      copyChnText: '',
      checkAllList: ['Mon', 'Tues', 'Wed', 'Thur', 'Fri', 'Sat', 'Sun'/* ,'Holiday' */],
      isDisabled: '',
      isIndeterminate: true,
      checkAll: false, // 全选
      copyChn: false, // 复制通道
      copyChnList: [],
      isChnDisabled: ''// 被复制通道的通道ID
    }
  },
  mounted() {
    this.init(1)
    this.getNvrList(17).then(res => {
      const nvrList = res.GetNvrChnListResp.ChnList.ChnInfo
      this.getSvrList().then(resp => {
        const svrList = resp.GetSvrChnListResp.SvrChnItemList.SvrChnItem
        nvrList.forEach(item => {
          svrList.forEach(itemSvr => {
            if (item.ChnID === itemSvr.NvrChnId) {
              item.ChnAlias = itemSvr.SvrChnAlias
              return false
            }
          })
        })
        return nvrList
      }).then(nvrList => {
        this.nvrList = nvrList
      })
    })
  },
  methods: {
    switchChnInfo() {
      this.init(Number(this.videoPlanInfo.ChnID))
    },
    getSvrChnConfigEx(nvrId) { // 获取配置
      return new Promise((resolve, reject) => {
        const param = {
          GetSvrChnRecCfgExReq: {
            StartChnID: nvrId,
            EndChnID: nvrId
          }
        }
        getSvrChnRecCfgEx(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    setSvrChnConfigEx() { // 设置配置
      return new Promise((resolve, reject) => {
        this.listInfo.forEach(item => {
          const index = item.Seg.findIndex(val => val.Beg === val.End)
          if (index > -1) {
            item.SegCount = item.SegCount - 1
            item.Seg.splice(index, 1)
          }
        })
        const param = {
          SetSvrChnRecCfgExReq: {
            CfgList: {
              CfgItem: {
                ChnID: this.videoPlanInfo.ChnID,
                RecMode: this.videoPlanInfo.RecMode,
                RecStream: this.videoPlanInfo.RecStream,
                RecAud: this.videoPlanInfo.RecAud,
                TimeList: {
                  K_E_Y: 'TimeItem',
                  P_R_O_P: {
                    num: this.listInfo.length
                  },
                  V_A_L_U_E: this.listInfo
                }
              }
            }
          }
        }
        setSvrChnRecCfgEx(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    setCopyChn() {
      return new Promise((resolve, reject) => {
        let szXml = '<contentroot>'
        szXml += '<authenticationinfo type="7.0">'
        szXml += '<username>' + store.getters.username + '</username>'
        szXml += '<password>' + store.getters.password + '</password>'
        szXml += '<authenticationid>' + store.getters.authId + '</authenticationid>'
        szXml += '</authenticationinfo>'
        szXml += '<CopySvrChnRecCfgReq>'
        szXml += '<SrcChnID>' + this.videoPlanInfo.ChnID + '</SrcChnID>' // 复制的通道id
        szXml += '<DstChnList num="' + (this.copyChnList.length - 1) + '">'
        for (let i = 0, len = this.copyChnList.length; i < len; i++) {
          const id = Number(this.copyChnList[i])
          if (id !== Number(this.videoPlanInfo.ChnID)) {
            szXml += '<ChnID>' + id + '</ChnID>' // 复制到的通道id
          }
        }
        szXml += '</DstChnList>'
        szXml += '</CopySvrChnRecCfgReq>'
        szXml += '</contentroot>'
        copySvrChnRecCfg(szXml).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    getLineWidth(lineInfo) { // 计算时间段位置
      const beginArr = (lineInfo.Beg).split(':')
      const endArr = (lineInfo.End).split(':')
      const beginT = Number(beginArr[0]) * 3600 + Number(beginArr[1]) * 60
      const endT = Number(endArr[0]) * 3600 + Number(endArr[1]) * 60
      const width = ((endT - beginT) * 100 / (24 * 3600)) + '%'
      const left = (beginT * 100 / (24 * 3600)) + '%'
      return {
        width: width,
        left: left
      }
    },
    getElementWidth(lineInfo, sumWidth) {
      const beginArr = lineInfo.Beg.split(':')
      const endArr = lineInfo.End.split(':')
      const beginT = Number(beginArr[0]) * 3600 + Number(beginArr[1]) * 60
      const endT = Number(endArr[0]) * 3600 + Number(endArr[1]) * 60
      const width = ((endT - beginT) / (24 * 3600)) * sumWidth
      const left = (beginT / (24 * 3600)) * sumWidth
      return {
        width: width,
        left: left
      }
    },
    positionGetTime(ele, lineInfo) { // 根据位置计算时间
      const l = ele.offsetLeft
      const w = ele.clientWidth
      const dateStr = '1970-01-01 '
      const begin = new Date((dateStr + lineInfo.Beg)).getTime() // 开始秒数
      const end = new Date((dateStr + lineInfo.End)).getTime() // 结束秒数
      const diffM = (end - begin)
      const sumW = this.lineWidth
      const leftPerc = l / sumW * 24 * 60 * 60 // 开始位置秒数
      const rightPerc = (leftPerc + diffM)
      const leftH = (parseInt(leftPerc / 3600) < 10) ? ('0' + parseInt(leftPerc / 3600)) : parseInt(leftPerc / 3600)
      const leftM = (parseInt(leftPerc % 3600 / 60) < 10) ? ('0' + parseInt(leftPerc % 3600 / 60)) : parseInt(leftPerc % 3600 / 60)
      const beginStr = ('1970-01-01' + ' ' + leftH + ':' + leftM + ':00')
      const BeginDate = new Date(beginStr)
      const endDate = new Date((BeginDate.getTime() + diffM))
      const Beg = dateFormat('hh:mm', BeginDate)
      const End = (l + w) == sumW ? '24' : dateFormat('hh:mm', endDate)
      return {
        'Beg': Beg + ':00',
        'End': End + ':00'
      }
    },
    showCurrentTime(item, index, weekInfo) { // 展示当前时间段弹框
      const flag = this.$refs.drag[index].getAttribute('data-flag')
      if (flag === 'true') return
      this.clickWeekInfo = weekInfo // 当前修改的一周中的那天
      this.editNum = index // 当前修改的元素顺序
      const beginArr = item.Beg.split(':')
      const endArr = item.End.split(':')
      this.form.beginHour = beginArr[0]
      this.form.beginMinues = beginArr[1]
      this.form.endHour = endArr[0]
      this.form.endMinues = endArr[1]
      this.timeSyn = true
    },
    mouseDownItem(event, weekInfo, index) { // 拖动添加时间段
      this.beginPoint = event.clientX
      const sWidth = this.$refs.lineItem[index].offsetWidth
      this.beginSecond = event.layerX / sWidth * 24 * 3600
    },
    mouseupItem(event, weekInfo, index) { // 拖动添加时间段
      const sWidth = this.$refs.lineItem[index].offsetWidth
      const width = (event.clientX - this.beginPoint) / sWidth * 24 * 3600
      const Beg = this.getTimeObj(this.beginSecond)
      const End = this.getTimeObj((this.beginSecond + width))
      this.beginPoint = 0
      const date = '1971-01-01'
      const beginDate = new Date((date + ' ' + Beg)).getTime()
      const endDate = new Date((date + ' ' + End)).getTime()
      if (endDate - beginDate > 1000) {
        this.chooseAddPoint({ 'Beg': Beg, 'End': End }, weekInfo)
      }
    },
    getTimeObj(time) { // 计算时间
      const he = parseInt(time / 3600)
      const m = parseInt(time % 3600 / 60)
      const h = he < 10 ? ('0' + he) : he
      const mm = m < 10 ? ('0' + m) : m
      return h + ':' + mm + ':00'
    },
    chooseAddPoint(obj, weekInfo) { // 按时间顺序排列插入到数组中
      const list = this.getCurrentList(weekInfo)
      const len = list.length
      if (len > 7) return
      const index = list.findIndex(item => item.Beg > obj.End)
      if (index === -1) {
        list.push(obj)
      } else {
        list.splice(index, 0, obj)
      }
      this.setCurrentList(weekInfo, this.deepClone(list), 'add')
    },
    deleteTime() { // 删除
      const list = this.getCurrentList(this.clickWeekInfo)
      list.splice(this.editNum, 1)
      this.setCurrentList(this.clickWeekInfo, this.deepClone(list), 'delete')
      this.timeSyn = false
      this.editNum = -1// 置为默认
      this.clickWeekInfo = '' // 置为默认
    },
    addTime() { // 保存
      const obj = {
        'Beg': this.form.beginHour + ':' + this.form.beginMinues + ':00',
        'End': this.form.endHour + ':' + this.form.endMinues + ':00'
      }
      const date = '1971-01-01'
      const beginDate = new Date((date + ' ' + obj.Beg)).getTime()
      const endDate = new Date((date + ' ' + obj.End)).getTime()
      if ((endDate - beginDate) > 1000) {
        const list = this.getCurrentList(this.clickWeekInfo)
        let replayFlag = false
        list.forEach((item, index) => {
          if (this.editNum !== index) {
            if ((item.Beg < obj.Beg && obj.Beg < item.End) || (item.Beg < obj.End && obj.End < item.End) || (obj.Beg < item.Beg && item.End < obj.End)) {
              replayFlag = true
              return false
            }
          }
        })
        if (replayFlag) {
          this.$message({
            type: 'warning',
            message: '时间段不能有重复'
          })
          return
        }
        list.splice(this.editNum, 1, obj)
        this.setCurrentList(this.clickWeekInfo, this.deepClone(list))
        this.timeSyn = false
        this.editNum = -1
        this.clickWeekInfo = ''
      } else {
        this.$message({
          type: 'warning',
          message: '时间输入不符合要求，请重新输入'
        })
        this.timeSyn = false
        this.editNum = -1
      }
    },
    countTip(item) { // 展示提示信息
      const beg = (item.Beg).split(':')
      const end = (item.End).split(':')
      return beg[0] + ':' + beg[1] + '  -  ' + end[0] + ':' + end[1]
    },
    deepClone(obj) { // 深拷贝
      const objClone = Array.isArray(obj) ? [] : {}
      if (obj && typeof obj === 'object') {
        for (const key in obj) {
          if (obj[key] && typeof obj[key] === 'object') {
            objClone[key] = this.deepClone(obj[key])
          } else {
            objClone[key] = obj[key]
          }
        }
      }
      return objClone
    },
    sortList() { // 列表进行排序，第一条为周一
      const firstList = this.deepClone(this.listInfo[0])
      this.listInfo.splice(0, 1)
      const len = this.listInfo.length
      this.listInfo.splice(len - 1, 1)
      this.listInfo.splice(len - 1, 0, firstList)
    },
    getWeekInfo(info) { // 转化周信息列表
      let weekChina = ''
      switch (info) {
        case 'Mon':
          weekChina = '星期一'
          break
        case 'Tues':
          weekChina = '星期二'
          break
        case 'Wed':
          weekChina = '星期三'
          break
        case 'Thur':
          weekChina = '星期四'
          break
        case 'Fri':
          weekChina = '星期五'
          break
        case 'Sat':
          weekChina = '星期六'
          break
        case 'Sun':
          weekChina = '星期日'
          break
        case 'Holiday':
          weekChina = '假期'
          break
      }
      return weekChina
    },
    copyInfo(weekInfo, copyList) { // 点击copy按钮方法
      this.checkAll = false
      this.isIndeterminate = true
      this.checkedWeekList = [weekInfo]
      this.isDisabled = weekInfo
      this.copyWeek = true
      this.copyChnText = weekInfo
    },
    getCurrentList(weekInfo) { // 获取修改列表
      let index = -1
      index = this.listInfo.findIndex(item => item.Week === weekInfo)
      if (index === -1) return []
      let weekList = []
      weekList = this.deepClone(this.listInfo[index].Seg || [])
      return weekList
    },
    setCurrentList(weekInfo, list, segCount) { // 设置修改列表
      let index = -1
      index = this.listInfo.findIndex(item => item.Week === weekInfo)
      if (index === -1) return
      if (segCount) {
        if (segCount === 'add') {
          this.listInfo[index].SegCount = (Number(this.listInfo[index].SegCount) + 1)
        } else if (segCount === 'delete') {
          this.listInfo[index].SegCount = (Number(this.listInfo[index].SegCount) - 1)
        } else if (segCount === 'copy') {
          this.listInfo[index].SegCount = list.length
        }
      }
      this.listInfo[index].Seg = list
    },
    getNvrList(subNum) { // 获取通道
      return new Promise((resolve, reject) => {
        const param = {
          GetNvrChnListReq: {
            ChnIDStart: 1,
            ChnIDEnd: subNum,
            NeedMask: {
              ChnAlias: true,
              DevSrcID: false,
              ChnState: false,
              DevInfo: false,
              DevCfg: false
            }
          }
        }
        getNvrChnList(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    getSvrList() { //
      return new Promise((resolve, reject) => {
        getSvrChnList({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    getCap() { // 获取能力
      return new Promise((resolve, reject) => {
        getSrvCap().then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    saveConfig() { // 保存配置信息
      const setSvr = this.setSvrChnConfigEx()
      const setCopy = this.setCopyChn()
      Promise.all([setSvr, setCopy]).then(res => {
        this.copyChn = false
        this.copyChnList = []
        this.copyChnText = ''
        this.init(Number(this.videoPlanInfo.ChnID))
        this.$message({
          type: 'success',
          message: '保存成功'
        })
      }).catch(err => {
        this.$message({
          type: 'error',
          message: '保存失败'
        })
      })
    },
    init(svrId) {
      this.getSvrChnConfigEx(svrId).then(res => {
        this.listInfo = []
        this.videoPlanInfo = res.GetSvrChnRecCfgExResp.CfgList.CfgItem
        const list = this.deepClone(this.videoPlanInfo.TimeList.TimeItem)
        list.forEach(item => {
          const obj = this.deepClone(item)
          if (!obj.Seg) {
            obj.Seg = []
          } else {
            if (!Array.isArray(obj.Seg)) { // 不是数组
              const segObj = this.deepClone(obj.Seg)
              obj.Seg = []
              obj.Seg.push(segObj)
            }
          }
          this.listInfo.push(obj)
        })
        this.sortList()
      })
    },
    ensureCopy() { // 确定复制
      const weekList = this.getCurrentList(this.copyChnText)
      const copyIndex = this.checkedWeekList.findIndex(item => item === this.copyChnText)
      this.checkedWeekList.forEach((item, index) => {
        if (index !== copyIndex) {
          this.setCurrentList(item, weekList, 'copy')
        }
      })
      this.copyWeek = false
    },
    cancelCopy() { // 取消复制
      this.copyWeek = false
      this.copyChnText = ''
      this.checkedWeekList = []
    },
    handleCheckAllChange(val) { // 全选
      this.checkedWeekList = val ? this.checkAllList : [this.isDisabled]
      this.isIndeterminate = false
    },
    handleItem(item) {
      const checkedCount = this.checkedWeekList.length
      this.checkAll = checkedCount === this.checkAllList.length
      this.isIndeterminate = checkedCount > 1 && checkedCount < this.checkAllList.length
    },
    copyChnInfo() { // 复制通道
      this.isChnDisabled = this.videoPlanInfo.ChnID
      this.copyChnList = [this.isChnDisabled]
      this.copyChn = true
    },
    ensureChnCopy() { // 确认复制通道
      /* this.setCopyChn().then(res => {
          this.$message({
            type:'success',
            message: '复制通道成功'
          })
          this.copyChn = false
          this.copyChnList = []
        }).catch(err => {
          this.$message({
            type:'error',
            message: '复制通道失败'
          })
        }) */
      this.copyChn = false
    },
    cancelChnCopy() { // 取消复制通道
      this.copyChn = false
      this.copyChnList = []
    },
    deleteAll() { // 全部删除
      this.listInfo.forEach(item => {
        item.SegCount = 0
        item.Seg = []
      })
    },
    classInit(num) {
      return 'icon-' + num
    }
  }
}
</script>

<style lang="scss">
.video-plan-container {
  .el-dialog {
    width: 344px;
  }
  .copy-chn-dialog {
    .el-dialog {
      .el-dialog__body {
        padding: 8px 0px 16px 16px;
        .el-scrollbar__wrap {
          margin-bottom: 0px !important;
          padding-bottom: 8px;
        }
      }
    }
  }
  .video-plan-time {
    .el-dialog {
      .el-dialog__header {
        border-bottom: none;
        .el-dialog__headerbtn {
          top: 8px;
        }
      }
      .el-dialog__body {
        padding: 10px 20px 4px;
      }
    }
  }
}
</style>
<style lang="scss" scoped>
.video-plan-container {
  .form-item {
    padding-bottom: 20px;
    .input-video-plan {
      width: 216px;
    }
    .marginLeft8 {
      margin-left: 6px;
      vertical-align: middle;
    }
  }
  .delete-group-btn {
    padding-bottom: 20px;
    .default-delete-spe {
      background: #FF4A40;
      color: #fff;
      border-color: #FF4A40;
    }
  }
  .timeplan_days {
    position: relative;
    .timeplan_day {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
      &.timeplan_time-title {
        margin-bottom: 4px;
      }
      .timeplan_dayname {
        width: 45px;
        height: 24px;
        line-height: 24px;
        color: #656363;
      }
      .timeplan_daydraw {
        width: 582px;
        height: 24px;
        margin-left: 8px;
        .timeplan_daytimeplan {
          position: relative;
          width: 576px;
          height: 24px;
          background: rgba(0,0,0,0.4);
          .timeplan_section {
            position: absolute;
            height: 24px;
            background: #C36D05;
            .timeplan_resizeLeft,.timeplan_resizeRight {
              position: absolute;
              top: 0px;
              width: 2px;
              border-left: 2px solid dash;
              background: #FFA639;
              height: 24px;
              cursor: w-resize;
              display: none;
              z-index: 999;
            }
            &:hover {
              background: #FFA639;
              .timeplan_resizeLeft,.timeplan_resizeRight {
                display: inline-block;
              }
              .timeplan_resizeLeft {
                left: 0px;
              }
              .timeplan_resizeRight {
                right: 0px;
              }
            }
          }
        }
      }
      .timeplan_copyto {
        width: 24px;
        height: 24px;
        margin: 0px 0 0 5px;
        line-height: 30px;
        text-align: center;
        cursor: pointer;
        display: none;
        .timeplan_copyto_icon {
          display: inline-block;
          width: 16px;
          height: 16px;
          background: url(../../../assets/img/copy_plan.png) no-repeat center center;
        }
      }
      &:hover {
        .timeplan_copyto {
          display: block;
        }
      }
      &.timeplan_time-title {
        .timeplan_time_line {
          background: url(../../../assets/img/time_plan_line.png) no-repeat center center;
          background-size: 100%;
        }
      }
    }
    .icon-gap {
      position: absolute;
      height: 292px;
      border-left: 1px solid #282C36;
      top: 24px;
      left: 52px;
      z-index: 0;
      &.icon-1 {
        left: 100px;
      }
      &.icon-2 {
        left: 148px;
      }
      &.icon-3 {
        left: 196px;
      }
      &.icon-4 {
        left: 244px;
      }
      &.icon-5 {
        left: 292px;
      }
      &.icon-6 {
        left: 340px;
      }
      &.icon-7 {
        left: 388px;
      }
      &.icon-8 {
        left: 436px;
      }
      &.icon-9 {
        left: 484px;
      }
      &.icon-10 {
        left: 532px;
      }
      &.icon-11 {
        left: 580px;
      }
      &.icon-12 {
        left: 628px;
      }
    }
  }
  .el-dialog {
    .width-default {
      width: 60px;
    }
    .gap-span {
      padding-left: 8px;
      padding-right: 8px;
    }
  }
  .week-copy-dialog {
    .el-checkbox {
      margin-top: 12px;
      width: 33.333%;
      margin-right: 0px;
    }
    .group-btn-dialog {
      position: relative;
      .check-all {
        position: absolute;
        bottom: 0px;
        right: 33.33%;
      }
    }
    .copy-week-container {
      padding: 16px 0px 0px;
      display: flex;
      justify-content: flex-end;
    }
  }
  .copy-chn-dialog {
    .el-checkbox {
      margin-top: 12px;
    }
    .copy-chn-btn-groups {
      padding: 16px 0px 0px;
      display: flex;
      justify-content: flex-end;
    }
    .el-scrollbar-list {
      height: 286px;
    }
     padding-bottom: 8px;
     .copy-chn-btn-groups {
       padding-right: 20px;
     }
  }
}
</style>
