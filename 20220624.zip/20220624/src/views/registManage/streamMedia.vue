<template>
  <div>
    <div class="kd-main-title">注册管理 / 流媒体</div>
    <div class="content streamMedia">
      <el-form :rules="rules" :model="dataContiner" ref="streamForm">
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="config-title">注册状态:</label>
            <span class="smssStatus font-title-color">{{VispRegState == 'false' ? '未连接' : '已连接'}}</span>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="config-title">注册流媒体:</label>
            <div>
              <el-radio v-model="dataContiner.Enabled" label="true">开启</el-radio>
              <el-radio v-model="dataContiner.Enabled" label="false">关闭</el-radio>
            </div>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="config-title">登录用户名:</label>
            <el-input type="text" v-model="dataContiner.SmssUserName" class="config-stream-input border-input-default default-border-radius input-width-default" />
          </div>
        </el-form-item>
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="config-title">登录密码:</label>
            <el-input type="password" v-model="dataContiner.SmssPwd" class="config-stream-input border-input-default default-border-radius input-width-default" />
          </div>
        </el-form-item>
        <el-form-item prop="SmmsIp">
          <div class="config-stream-media">
            <label for="" class="config-title">注册地址:</label>
            <el-input type="text" v-model="dataContiner.SmmsIp" class="config-stream-input border-input-default default-border-radius input-width-default" />
          </div>
        </el-form-item>
        <el-form-item prop="SmmsPort">
          <div class="config-stream-media">
            <label for="" class="config-title">接收端口:</label>
            <el-input type="text" v-model.number="dataContiner.SmmsPort" class="config-stream-input border-input-default default-border-radius input-width-default" />
            <span class="paddingLeft16 font-title-table">默认端口号为5500</span>
          </div>
        </el-form-item>
        <el-form-item prop="FtpUploadSpeed">
          <div class="config-stream-media">
            <label for="" class="config-title">上传速率:</label>
            <el-input type="text" v-model.number="dataContiner.FtpUploadSpeed" class="config-stream-input border-input-default default-border-radius input-width-default" />
            <span class="paddingLeft16 font-title-table">128-163840</span>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="config-title">多通道使能:</label>
            <div>
              <el-select v-model="dataContiner.MultiChannel" @change="channelChange" class="border-select-default input-width-default" placeholder="请选择">
                <el-option
                  v-for="item in channel"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </div>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="config-title">设备UUID:</label>
            <el-input type="text" v-model="dataContiner.GbUUID" class="config-stream-input border-input-default default-border-radius input-width-default" />
            <span class="paddingLeft16 font-title-table">SIP注册时需填写</span>
          </div>
        </el-form-item>
      <div class="config-stream-media">
        <label for="" class="config-title"></label>
        <div>
          <input type="button" class="primary default-border-radius" @click="setSmssCfgInfo" value="保存"/>
        </div>
      </div>
      </el-form>
    </div>
  </div>
</template>

<script>
import { validateIP, isPort } from '@/utils/validateModule.js'
import { getSvrState } from '@/api/user'
import { getSmssCfg,setSmssCfg } from '@/api/registManage'
export default {
  data(){
    return {
      rules: {
        FtpUploadSpeed: [{ max: 163840, min: 128, type: 'number', message: '不在可选范围之内', trigger: 'blur' }],
        SmmsIp: [{ required: true, trigger: 'blur', validator: validateIP }],
        SmmsPort: [{ required: true, trigger: 'blur', validator: isPort }]
      },
      streamTime: null,
      channel: [
        {
          value: 'true',
          label: '开启'
        }, {
          value: 'false',
          label: '关闭'
        }
      ],
      VispRegState: 'false',
      dataContiner: {
        SmmsIp: '',
        SmmsPort: '',
        SmssPwd: '',
        SmssUserName: '',
        GbUUID: '',
        FtpUploadSpeed: '',
        MultiChannel: false,
        Enabled: false
      }
    }
  },
  components:{
    /* breadCrumb */
  },
  created(){
    this.getSmssCfgInfo()
    this.getStreamStatusInfo()
  },
  destroyed() {
    clearTimeout(this.streamTime)
  },
  methods:{
    getStreamStatusInfo() {
      getSvrState({}).then(res => {
        this.VispRegState = res.SvrStateResp.SmssState
        this.streamTime = setTimeout(() => {
            this.getStreamStatusInfo()
        },3000)
      })
    },
    changeServeStatus(){
      this.dataContiner.Enabled = this.serveSwitch
    },
    channelChange(){
    },
    getSmssCfgInfo(){
      getSmssCfg({}).then(res => {
        this.dataContiner = res.GetSmssCfgResp
        this.dataContiner.FtpUploadSpeed = Number(this.dataContiner.FtpUploadSpeed)
        this.dataContiner.SmmsPort = Number(this.dataContiner.SmmsPort)
      })
    },
    setSmssCfgInfo(){
      this.$refs.streamForm.validate(valid => {
        if(valid) {
          let params = {
            SetSmssCfgReq: this.dataContiner
          }
          setSmssCfg(params).then(res => {
            this.$message({
              message: '保存成功',
              type: 'success'
            })
          })
        }
      })
    }
  }
}
</script>

<style lang="scss">
  .streamMedia {
    .el-form {
      .el-form-item {
        >div {
           line-height: 32px !important;
        }
      }
    }
  }
  .content {
    padding-top: 8px;
  }
  .smssStatus {
    font-size: 14px;
  }
  .config-stream-media {
     display: flex;
     justify-content: flex-start;
     align-items: center;
     padding: 8px 0px;
  }
  .config-title {
     width: 150px;
     font-size: 14px;
     color: rgba(255,255,255,0.85);
     font-weight: normal;
  }
</style>
