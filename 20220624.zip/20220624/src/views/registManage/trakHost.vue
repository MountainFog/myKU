<template>
  <div class="trak-host-page">
    <div class="kd-main-title">注册管理 / 跟踪主机</div>
    <el-form
      ref="hostForm"
      :model="config"
      :rules="rules"
      label-width="150px"
      label-position="left"
    >
      <el-form-item label="连接状态："><span>{{ status }}</span></el-form-item>
      <el-form-item label="接入状态：">
        <el-radio-group v-model="config.Enabled">
          <el-radio :label="true">开</el-radio>
          <el-radio :label="false">关</el-radio>
        </el-radio-group></el-form-item>
      <el-form-item label="跟踪主机地址：" prop="TrackhostIp">
        <el-input v-model="config.TrackhostIp" />
      </el-form-item>
      <el-form-item label="跟踪主机接入端口：" prop="TrackhostPort">
        <el-input v-model="config.TrackhostPort" />
      </el-form-item>
      <el-form-item label=" ">
        <el-button
          type="primary"
          :loading="loading"
          @click="SetTrackHostCfg"
        >保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import { GetTrackHostStatus, GetTrackHostCfg, SetTrackHostCfg } from '@/api/registManage'
import { validateIP, isPort } from '@/utils/validateModule'
export default {
  name: 'TrakHost',
  data() {
    return {
      // 提交loading
      loading: false,
      // 主机状态
      status: '',
      // 主机配置
      config: {
        Enabled: false,
        TrackhostIp: '',
        TrackhostPort: ''
      },
      rules: {
        TrackhostIp: [{ validator: validateIP, required: true, trigger: 'blur' }],
        TrackhostPort: [{ validator: isPort, required: true, trigger: 'blur' }]
      }
    }
  },
  mounted() {
    this.getTrakHostStatus()
    this.getTrackHostCfg()
  },
  methods: {
    // 获取跟踪主机连接状态
    getTrakHostStatus() {
      GetTrackHostStatus().then(res => {
        this.status = res.GetTrackHostStatusResp.Online === 'true' ? '已连接' : '未连接'
      })
    },
    // 获取跟踪主机配置
    getTrackHostCfg() {
      GetTrackHostCfg().then(res => {
        this.config.Enabled = res.GetTrackHostCfgResp.Enabled === 'true'
        this.config.TrackhostIp = res.GetTrackHostCfgResp.TrackhostIp
        this.config.TrackhostPort = res.GetTrackHostCfgResp.TrackhostPort
      })
    },
    // 设置跟踪主机配置
    SetTrackHostCfg() {
      this.$refs.hostForm.validate((valid) => {
        if (valid) {
          this.loading = true
          SetTrackHostCfg({
            SetTrackHostCfgReq: this.config
          }).then(_ => {
            this.loading = false
            this.$message({
              type: 'success',
              message: '保存成功'
            })
            // 刷新数据
            this.getTrackHostCfg()
          }).catch(_ => {
            this.loading = false
          })
        }
      })
    }
  }
}
</script>
<style lang="scss">
.trak-host-page {
  .el-form .el-input {
    width: 220px;
  }
}
</style>
