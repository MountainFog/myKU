<template>
  <div class="sipManage">
    <div class="kd-main-title">注册管理 / SIP</div>
    <div class="sip-manage-content-container">
      <el-form :rules="rules" :model="sipConfig" ref="sipForm">
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="config-title">注册状态:</label>
            <span class="font-title-color">{{VispRegState == 'false' ? '未连接' : '已连接'}}</span>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="config-title">注册平台:</label>
            <div>
              <el-select v-model="sipPlatform" @change="changePlat" class="input-width-default" placeholder="请选择">
                <el-option
                  v-for="item in platformList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </div>
          </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">注册SIP平台:</label>
          <div>
            <el-radio v-model="sipEnable" label="1">开启</el-radio>
            <el-radio v-model="sipEnable" label="0">关闭</el-radio>
          </div>
        </div>
      </el-form-item>
      <el-form-item prop="LocalPort">
        <div class="config-stream-media">
          <label for="" class="config-title">本地端口:</label>
          <div>
            <el-input type="text" v-model.number="sipConfig.LocalPort" class="border-input-default default-border-radius input-width-default" />
            <span class="paddingLeft16">1024-65535</span>
          </div>
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">入网ID:</label>
          <div>
            <el-input type="text" v-model="sipConfig.DevID" class="border-input-default default-border-radius input-width-default" />
            <!-- <span style="padding-left:16px;">1024-65535</span> -->
          </div>
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">设备名称:</label>
          <el-input type="text" v-model="sipConfig.DevName" class="border-input-default default-border-radius input-width-default" />
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">平台ID:</label>
          <el-input type="text" v-model="sipConfig.PlatID" class="border-input-default default-border-radius input-width-default" />
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">平台地址:</label>
          <el-input type="text" v-model="sipConfig.PlatIP" class="border-input-default default-border-radius input-width-default" />
        </div>
      </el-form-item>
      <el-form-item prop="PlatPort">
        <div class="config-stream-media">
          <label for="" class="config-title">平台端口:</label>
          <div>
            <el-input type="text" v-model.number="sipConfig.PlatPort" class="border-input-default default-border-radius input-width-default" />
            <span class="paddingLeft16">1024-65535</span>
          </div>
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">用户名:</label>
          <el-input type="text" v-model="sipConfig.UserName" class="border-input-default default-border-radius input-width-default" />
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">密码:</label>
          <el-input type="password" v-model="sipConfig.Password" class="border-input-default default-border-radius input-width-default" />
        </div>
      </el-form-item>
      <el-form-item prop="ReletSpan">
        <div class="config-stream-media">
          <label for="" class="config-title">续租时间:</label>
          <el-input type="text" v-model.number="sipConfig.ReletSpan" class="border-input-default default-border-radius input-width-default" />
          <span class="paddingLeft16">30~999999(秒)</span>
        </div>
      </el-form-item>
      <el-form-item prop="KplvSpan">
        <div class="config-stream-media">
          <label for="" class="config-title">心跳间隔:</label>
          <el-input type="text" v-model.number="sipConfig.KplvSpan" class="border-input-default default-border-radius input-width-default" />
          <span class="paddingLeft16">10~1000(秒)</span>
        </div>
      </el-form-item>
      <el-form-item prop="KplvTimeOutMaxTimes">
        <div class="config-stream-media">
          <label for="" class="config-title">超时次数:</label>
          <el-input type="text" v-model.number="sipConfig.KplvTimeOutMaxTimes" class="border-input-default default-border-radius input-width-default" />
          <span class="paddingLeft16">1~10</span>
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">行政区域:</label>
          <el-input type="text" v-model="sipConfig.CivilCode" class="border-input-default default-border-radius input-width-default" />
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">设备归属:</label>
          <el-input type="text" v-model="sipConfig.Owner" class="border-input-default default-border-radius input-width-default" />
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">警区:</label>
          <el-input type="text" v-model="sipConfig.PoliceRgn" class="border-input-default default-border-radius input-width-default" />
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">安装地址:</label>
          <el-input type="text" v-model="sipConfig.SetupAddress" class="border-input-default default-border-radius input-width-default" />
        </div>
      </el-form-item>
      <el-form-item>
        <el-form :rules="rules" :model="chnLength" ref="chnForm">
          <el-form-item prop="chnLengths">
            <div class="config-stream-media">
              <label for="" class="config-title">视频通道数:</label>
              <el-input type="text" v-model.number="chnLength.chnLengths"  class="border-input-default default-border-radius input-width-default"  />
              <input type="button" @click="editChannel" class="default default-border-radius font-title-color marginLeft16" value="编辑"/>
              <span class="paddingLeft16 font-title-color">(1-29)</span>
            </div>
          </el-form-item>
        </el-form>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">国标加密:</label>
          <div>
            <el-select v-model="sipConfig.SecurityLev" class="input-width-default" placeholder="请选择">
              <el-option
                v-for="item in securityList"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </div>
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title">国标高级配置:</label>
          <input type="button" @click="setConfig" class="primary default-border-radius" value="设置"/>
        </div>
      </el-form-item>
      <el-form-item>
        <div class="config-stream-media">
          <label for="" class="config-title"></label>
          <div>
            <input type="button" @click="save" class="primary default-border-radius" value="保存"/>
          </div>
        </div>
      </el-form-item>
      </el-form>
    </div>
    <el-dialog :close-on-click-modal="false" title="添加视频通道ID" class="font-title-color dialogChn" :visible.sync="sipConfigShow">
      <el-form :model="form">
        <el-form-item :label="getLabel(index + 1)" :key="index" v-for="(item,index) in showChnList" :label-width="formLabelWidth">
          <el-input type="text" v-model="item.ID" @change="changeId(index)" class="border-input-default default-border-radius input-width-default" ></el-input>
          <el-select v-model="item.v_chn_id" class="border-select-default input-width-default" placeholder="请选择通道号">
            <el-option
              v-for="list in chnList"
              :key="list.value"
              :label="('D' + list.NvrChnId + ' ' + list.SvrChnAlias)"
              :value="('D' + list.NvrChnId + ' ' + list.SvrChnAlias)">
            </el-option>
          </el-select>
          <el-select v-model="item.EncID" class="border-select-default dialog-select-width input-width-default" placeholder="请选择通道号">
            <el-option label="主流" value="1"></el-option>
            <el-option label="辅流" value="2"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <input type="button" @click="autoAddChannelId" class="default font-title-color default-border-radius" value="ID自动叠加" />
        <div>
          <input type="button" @click="saveEdit" class="primary default-border-radius" value="保存"/>
          <input type="button" @click="cancelEdit" class="default default-border-radius font-title-color marginLeft16" value="取消"/>
        </div>
      </div>
    </el-dialog>
    <el-dialog :close-on-click-modal="false" title="高级设置" class="font-title-color set-config" :visible.sync="setConfigShow">
      <el-form :model="form">
        <el-form-item :label-width="formLabelWidth">
          <el-tabs v-model="activeName" @tab-click="handleClick">
              <el-tab-pane label="兼容次序" name="first">
                <el-transfer v-model="value" :titles="titles" :data="transfer"></el-transfer>
              </el-tab-pane>
              <el-tab-pane label="扩展配置" name="second">
                <div>
                  <div class="config-stream-media">
                    <label for="" class="config-title">可扩展配置:</label>
                    <el-select v-model="optionConfigSele" class="border-select-default input-width-default" placeholder="请选择">
                      <el-option
                        v-for="(item,index) in optionConfigList"
                        :key="index"
                        :label="item"
                        :value="item">
                      </el-option>
                    </el-select>
                    <input type="button" @click="addOptionConfig" class="default default-border-radius marginLeft16" value="添加"/>
                  </div>
                  <div class="config-stream-media">
                    <label for="" class="config-title">可选配置:</label>
                    <div class="option-config">
                      <div v-if="showOPtionCon.length > 0">
                        <div class="option-item" :key='option' v-for="option in showOPtionCon">
                          <label for="">{{option + '='}}</label>
                          <input type="text" class='option-input' :ref="option" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <div>
          <input type="button" @click="saveOptionConfig" class="primary default-border-radius" value="确认"/>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { getSvrState } from "@/api/user";
import { getGb28181AppCfg,setGb28181AppCfg } from '@/api/registManage.js'
import { getSvrChnList } from '@/api/channelManage.js'
export default {
  data(){
    return {
      rules: {
        PlatPort: [{ max: 65535, min: 1024, type: 'number', message: '不在范围之内', trigger: 'blur' }],
        LocalPort: [{ max: 65535, min: 1024, type: 'number', message: '不在范围之内', trigger: 'blur' }],
        ReletSpan: [{ max: 999999, min: 30, type: 'number', message: '不在范围之内', trigger: 'blur' }],
        KplvTimeOutMaxTimes: [{ max: 10, min: 1, type: 'number', message: '不在范围之内', trigger: 'blur' }],
        KplvSpan: [{ max: 1000, min: 10, type: 'number', message: '不在范围之内', trigger: 'blur' }],
        chnLengths: [{ max: 29, min: 1, type: 'number', message: '不在范围之内', trigger: 'blur' }]
      },
      transfer: [
        { key: 'GbStdModule', label: '国标标准' },
        { key: 'GbExt1403Module', label: '国标扩展(2014)' },
        { key: 'GbExt1608Module', label: '国标扩展(2016)' },
        { key: 'GbExtNetPosaModule', label: '东方网力扩展' },
        { key: 'GbExtElectricityModule_Independent', label: 'GbExtElectricityModule_Independent' }
      ],
      value: ['GbStdModule','GbExt1403Module','GbExt1608Module'],
      titles: ['候选协议','优选次序'],
      optionConfigList: ['plat_domain','requriusedomain','fromtousedomain','longitude','latitude','reg_retry_span','kplv_timeout_max_time','sdpfuseipc','sdptimeisutc','rtcprtpdiff','alarmspan','ptztype','PosiType','RoomType','UseType','SupplyLightType','DirectionType','report_res','ServiceGroupID','SeriWithAlm','CompMode','sipusetcp','ReportAudOut','useragenttype','tcppacktype','recqryusetcp','judgeSubject','audiocalltranstype'],
      securityList: [
        {
          value: 'no',
          label: '不加密'
        },
        {
          value: 'class_a',
          label: 'A类加密'
        },
        {
          value: 'class_b',
          label: 'B类加密'
        },
        {
          value: 'class_c',
          label: 'C类加密'
        }
      ],
      sipConfig: {},
      chnLength: {chnLengths:0},
      sipConfigShow: false,
      setConfigShow: false,
      formLabelWidth: '100px',
      VispRegState: 'false',
      encChns: [],
      sipEnable: '0',
      sipPlatform: '1',
      optionConfigSele: '',
      showOPtionCon: [],
      platformList: [{ value:'1',label:'注册平台1' },{ value:'2',label:'注册平台2' }],
      form: {
      },
      capLength: 0,
      chnList: [],
      showChnList: [],
      activeName: 'first',
      autoAddIndex: -1,
      statusTime: null,
      originShowChnList: []
    }
  },
  created() {
    this.getInit()
  },
  components: {
    /* breadCrumb */
  },
  computed: {
    chnAliasCom(id) {
      return 'D' + id + chnList[id].SvrChnAlias;
    }
  },
  destroyed() {
    clearTimeout(this.statusTime)
  },
  methods: {
    deepClone(obj) {
      let objClone =  Array.isArray(obj) ? [] : {};
      if (obj && typeof obj === 'object') {
        for(let key in obj){
          if (obj[key] && typeof obj[key] === 'object'){
            objClone[key] = this.deepClone(obj[key]);
          }else{
            objClone[key] = obj[key]
          }
        }
      }
      return objClone;
    },
    changeId(index) {
      this.autoAddIndex = (index + 1)
    },
    autoAddChannelId() { //自动添加id
      if(this.autoAddIndex == 1) {
        let id = this.showChnList[0].ID
        let len = this.showChnList.length
        let idNum = Number(id)
        if(id.length <= 3) {
          for(let i = 1; i < len; i++) {
            this.showChnList[i].ID = ++idNum
          }
        }else {
          let idPix = id.substr(0,id.length - 3)
          let idFix = parseInt(id.substr(id.length - 3))
          for(let i = 1; i < len; i++) {
            let idC = (idFix + i) + ''
            let idLength = idC.length
            idC = idLength == 3 ? idC : idLength == 2 ? '0' + idC : '00' + idC
            this.showChnList[i].ID = idPix + idC
          }
        }
      }
    },
    handleClick() {
    },
    changePlat() {
      this.getInit()
    },
    getInit() {
      var param = {
        GetGb28181AppCfgReq: {
          PlatIndex: Number(this.sipPlatform)
        }
      }
      getGb28181AppCfg(param).then(res => {
        this.sipConfig = res.GetGb28181AppCfgResp;
        if(res.GetGb28181AppCfgResp.EncChns != '') {
          if(Array.isArray(res.GetGb28181AppCfgResp.EncChns.Chn)) {
            this.chnLength.chnLengths = res.GetGb28181AppCfgResp.EncChns.Chn.length
            this.encChns = res.GetGb28181AppCfgResp.EncChns.Chn
          }else {
            this.chnLength.chnLengths = 1
            this.encChns.push(res.GetGb28181AppCfgResp.EncChns.Chn)
          }
        }else {
          this.chnLength.chnLengths = 0
          this.encChns = []
        }
        this.sipEnable = res.GetGb28181AppCfgResp.Enable == 'true' ? '1' : '0'
        this.value = res.GetGb28181AppCfgResp.GbOrder.split(",")
        this.sipConfig.PlatPort = Number(this.sipConfig.PlatPort)
        this.sipConfig.ReletSpan = Number(this.sipConfig.ReletSpan)
        this.sipConfig.KplvTimeOutMaxTimes = Number(this.sipConfig.KplvTimeOutMaxTimes)
        this.sipConfig.KplvSpan = Number(this.sipConfig.KplvSpan)
        this.sipConfig.LocalPort = Number(this.sipConfig.LocalPort) === 5060 ? 5062 : Number(this.sipConfig.LocalPort)
      })
      this.getVispStatus()
    },
    getVispStatus() {
      getSvrState({}).then(res => {
        //this.VispRegState = 'false'
        if(this.sipPlatform == '1') {
          this.VispRegState = res.SvrStateResp.Gb28181State
        }else {
          this.VispRegState = res.SvrStateResp.Gb28181State2
        }
        this.statusTime = setTimeout(() => {
          this.getVispStatus()
        },3000)
      })
    },
    saveOptionConfig() {
      this.$nextTick(() => {//扩展配置
        var inputDomList = document.getElementsByClassName('option-input')
        var list = []
        let inputList = Array.prototype.slice.call(inputDomList)
        inputList.forEach((val,index) => {
          list.push({
            opt: this.showOPtionCon[index],
            value: val.value
          })
        })
        this.setConfigShow = false
      })
    },
    addOptionConfig() {
      this.showOPtionCon.push(this.optionConfigSele)
    },
    getLabel(index) {
      return '视频通道' + index
    },
    setConfig() {
      this.setConfigShow = true
    },
    save() {
      this.$refs.chnForm.validate((valids) => {
        if(valids) {
          this.$refs.sipForm.validate( (valid) => {
            if(valid) {
              if(this.sipEnable == '1') {
                this.sipConfig.Enable = 'true'
              }else if(this.sipEnable == '0') {
                this.sipConfig.Enable = 'false'
              }
              let chns = []
              for(let i = 0, len = this.encChns.length; i < len; i++) {
                let objChn = {
                  ChnID: this.encChns[i].ChnID,
                  EncID: this.encChns[i].EncID,
                  ID: this.encChns[i].ID,
                  Name: this.encChns[i].ChnID.Name ? this.encChns[i].ChnID.Name : ''
                }
                chns.push(objChn)
              }
              let param = {
                SetGb28181AppCfgReq: {
                  PlatIndex: Number(this.sipPlatform),
                  Cfg: {
                    Enable: this.sipConfig.Enable,
                    LocalPort: this.sipConfig.LocalPort === 5060 ? 5062 : this.sipConfig.LocalPort,
                    DevID: this.sipConfig.DevID,
                    DevName: this.sipConfig.DevName,
                    PlatID: this.sipConfig.PlatID,
                    PlatIP: this.sipConfig.PlatIP,
                    PlatPort: this.sipConfig.PlatPort,
                    UserName: this.sipConfig.UserName,
                    Password: this.sipConfig.Password,
                    AlmChns: this.sipConfig.AlmChns,
                    ReletSpan: this.sipConfig.ReletSpan,
                    KplvSpan: this.sipConfig.KplvSpan,
                    KplvTimeOutMaxTimes: this.sipConfig.KplvTimeOutMaxTimes,
                    Owner: this.sipConfig.Owner,
                    CivilCode: this.sipConfig.CivilCode,
                    PoliceRgn: this.sipConfig.PoliceRgn,
                    SetupAddress: this.sipConfig.SetupAddress,
                    ExtendCfg: this.sipConfig.ExtendCfg,
                    SecurityLev: this.sipConfig.SecurityLev,
                    GbOrder: this.value.join(','),
                    EncChns: {
                      K_E_Y: 'Chn',
                      P_R_O_P:{
                        num: this.encChns ? this.encChns.length : 0
                      },
                      V_A_L_U_E: chns
                    }
                  }
                }
              }
              setGb28181AppCfg(param).then(res => {
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
              })
            }
          } )
        }
      })
    },
    async editChannel() {
      this.showChnList = []
      this.sipConfigShow = true
      await this.getCap()
      await this.getSvrChn()
      let len = this.chnLength.chnLengths
      let length = this.showChnList.length
      if(len < length) {
         this.showChnList.splice(len,length- len)
      }else if(length < len) {
        for(let i = 0;i < len - length; i++) {
          this.showChnList.push({
            ID: '',
            v_chn_id: ('D' + this.chnList[0].NvrChnId + ' ' + this.chnList[0].SvrChnAlias),
            EncID: '1',
            ChnID: this.chnList[0].NvrChnId,
            Name: this.chnList[0].SvrChnAlias
          })
        }
      }
      this.originShowChnList = this.deepClone(this.showChnList)
    },
    saveEdit() {
      this.sipConfigShow = false
      this.originShowChnList = []
      var cnList = []
      this.showChnList.forEach(val => {
        let ChId = Number(val.v_chn_id.split(' ')[0].substr(1))
        var obj = {
          ChnID: ChId,
          EncID: val.EncID,
          ID: val.ID,
          Name: val.Name,
          v_chn_id: val.v_chn_id
        }
        cnList.push(obj)
      })
      this.encChns = cnList
    },
    cancelEdit() {
      this.sipConfigShow = false
      this.showChnList = this.deepClone(this.originShowChnList)
    },
    async getCap() {
     await this.$store.dispatch('channelManage/getSrvCap',{}).then(res => {
        this.capLength = Number(res.capinfo.GroupNum)
      })
    },
    async getSvrChn() {
      await getSvrChnList({}).then(res => {
        let length = res.GetSvrChnListResp.SvrChnItemList.SvrChnItem.length
        this.chnList = res.GetSvrChnListResp.SvrChnItemList.SvrChnItem
        for(let i = length + 1; i <= this.capLength; i++) {
          let obj = {
            NvrChnId: i,
            SvrChnAlias: ''
          }
          this.chnList.push(obj)
        }
        this.encChns.forEach((val,index) => {
          this.chnList.forEach(item => {
            if(item.NvrChnId == val.ChnID) {
              let objs = {
                ChnID: val.ChnID,
                EncID: val.EncID,
                ID: val.ID,
                Name: val.Name,
                v_chn_id: val.v_chn_id ? val.v_chn_id : ("D" + item.NvrChnId + " " + item.SvrChnAlias)
                /* v_chn_id: ("D" + val.ChnID + " " + item.SvrChnAlias) */
              }
              this.showChnList.push(objs)
              return false
            }
          })
        })
      })
    },
  }
}
</script>
<style lang="scss">
.sipManage {
  .sip-manage-content-container {
    .el-form-item {
      > div {
        line-height: 32px;
      }
    }
  }
  .el-tabs {
    .is-top {
      color: rgba(255, 255, 255, 0.85);
      &.is-active {
        color: #409EFF;
      }
    }
  }
  .set-config {
    .el-dialog {
      width: 680px;
      .el-dialog__body {
        padding: 12px 20px;
        .el-form-item__content {
          margin-left: 0px !important;
        }
      }
      .el-tabs {
          .el-tabs__nav-wrap {
            .el-tabs__item {
              color: rgba(255,255,255,0.65);
              &.is-active {
                color: #3884FF;
              }
            }
            &::after {
              background-color: rgba(216,222,234,0.20);
            }
          }
        .el-transfer-panel {
          background: rgba(13,16,22,0.48);
          border: 1px solid rgba(216,222,234,0.20);
          .el-transfer-panel__header {
            border-bottom: 1px solid rgba(216,222,234,0.20);
            background: rgba(13,16,22,0.48);
            .el-checkbox {
              display: flex;
              justify-content: space-between;
              align-items: center;
              padding-top: 10px;
              padding-right: 12px;
              .el-checkbox__label {
                color: rgba(255,255,255,0.65);
                >span {
                  display: none;
                }
              }
            }
          }
          .el-transfer-panel__body {
            .el-transfer-panel__item {
              .el-checkbox__label {
                >span {
                  font-size: 14px;
                  color: rgba(255,255,255,0.85);
                }
              }
            }
          }
        }
      }
    }
  }
}
</style>
<style lang="scss" scoped>
.sipManage {
  .dialogChn {
    .el-dialog {
      .el-dialog__body {
        max-height: 400px;
        overflow-y: scroll;
      }
      .dialog-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .dialog-select-width {
        width: 160px;
      }
    }
  }
  .sip-manage-content-container {
    padding-top: 8px;
  }
  .set-config {
    .el-dialog {
      width: 600px;
      .option-config {
        height: 200px;
        border: 1px solid rgba(216, 222, 234, 0.2);
        width: 390px;
        background: rgba(13, 16, 22, 0.48);
      }
      .el-form-item__content {
        margin-left: 0px !important;
        .el-transfer {
          display: flex;
          .el-transfer-panel {
            flex: 1;
          }
          .el-transfer__buttons {
            display: flex;
            flex-direction: column;
            width: 100px;
            .el-button+.el-button {
              margin-left: 0px;
            }
          }
          .el-form-item__content {
            margin-left: 0px !important;
            .el-tabs__item {
              color: rgba(255,255,255,0.85);
            }
          }
          .el-tabs__nav-wrap::after {
            background-color: rgba(255,255,255,0.20);
            height: 1px;
          }
        }
      }
    }
  }
}
.smssStatus {
  font-size: 14px;
}
.config-stream-media {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  padding: 8px 0px;
}
.config-title {
  width: 150px;
  font-size: 14px;
  color: rgba(255,255,255,0.85);
  font-weight: normal;
}
</style>
