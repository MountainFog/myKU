<template>
  <div class="application-plat-config">
    <div class="kd-main-title">注册管理 / 应用平台</div>
    <div class="application-config-form">
      <el-form ref="applicationForm" label-width="150px" label-position="left" :model="GetVideoSysConfigResp" :rules="rules">
        <el-form-item label="注册状态:">
          <div class="config-stream-media">
            <span class="smssStatus font-title-color">{{ applicationStatus == 'false' ? '未连接!' : '已连接' }}</span>
          </div>
        </el-form-item>
        <el-form-item label="注册应用平台:">
          <div class="config-stream-media">
            <el-radio v-model="GetVideoSysConfigResp.IsConnect" label="true">开启</el-radio>
            <el-radio v-model="GetVideoSysConfigResp.IsConnect" label="false">关闭</el-radio>
          </div>
        </el-form-item>
        <el-form-item label="设备UUID:">
          <div class="config-stream-media">
            <el-input v-model="GetVideoSysConfigResp.Guid" type="text" class="config-stream-input border-input-default default-border-radius input-width-default" />
            <span class="paddingLeft16 font-title-table">应用平台生成的录播主机唯一标识</span>
          </div>
        </el-form-item>
        <el-form-item label="应用平台地址:" prop="IpAddress">
          <div class="config-stream-media">
            <el-input v-model="GetVideoSysConfigResp.IpAddress" type="text" class="config-stream-input border-input-default default-border-radius input-width-default" />
          </div>
        </el-form-item>
        <el-form-item label="SSL启用:">
          <div class="config-stream-media">
            <el-select v-model="GetVideoSysConfigResp.SSLEnabled" class="border-select-default input-width-default">
              <el-option
                v-for="item in enableList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
        </el-form-item>
        <el-form-item label="应用平台端口:">
          <div class="config-stream-media">
            <el-input v-show="!GetVideoSysConfigResp.SSLEnabled" key="port" v-model.number="GetVideoSysConfigResp.Port" type="text" class="config-stream-input border-input-default default-border-radius input-width-default" />
            <el-input v-show="GetVideoSysConfigResp.SSLEnabled" key="sslport" v-model.number="GetVideoSysConfigResp.SSLPort" type="text" class="config-stream-input border-input-default default-border-radius input-width-default" />
          </div>
        </el-form-item>
        <el-form-item label="录像上传速率:" prop="UploadSpeed">
          <div class="config-stream-media">
            <el-input v-model.number="GetVideoSysConfigResp.UploadSpeed" type="text" class="config-stream-input border-input-default default-border-radius input-width-default" />
            <span class="paddingLeft16 font-title-table">128-163840(Kb/s)</span>
          </div>
        </el-form-item>
        <el-form-item label="断链重连时间:" prop="ReconnectInteval" :rules="{min:15, max:30, type: 'number', message: '参数不正确且不能为空', trigger:'blur'}">
          <el-input v-model.number="GetVideoSysConfigResp.ReconnectInteval" class="input-width-default" />
          <span class="paddingLeft16 font-title-table">15-30s</span>
        </el-form-item>
        <el-form-item label="">
          <input type="button" class="primary default-border-radius" value="保存" @click="saveApplicaConfig">
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import { getVideoSysConfig, setVideoSysConfig } from '@/api/registManage.js'
import { validateIP } from '@/utils/validateModule.js'
import { getSvrState } from '@/api/user'
export default {
  data() {
    return {
      rules: {
        UploadSpeed: [{ max: 163840, min: 128, type: 'number', message: '不在可选范围之内', trigger: 'blur' }],
        IpAddress: [{ required: false, trigger: 'blur', validator: validateIP }]
      },
      applicationConfigTime: null, // 定时器
      applicationStatus: 'false', // 应用平台状态
      GetVideoSysConfigResp: {},
      enableList: [
        {
          value: true,
          label: '是'
        },
        {
          value: false,
          label: '否'
        }
      ]
    }
  },
  mounted() {
    this.getApplicationConfig().then(res => {
      this.GetVideoSysConfigResp = res.GetVideoSysConfigResp
      this.GetVideoSysConfigResp.UploadSpeed = Number(this.GetVideoSysConfigResp.UploadSpeed)
      this.GetVideoSysConfigResp.Port = Number(this.GetVideoSysConfigResp.Port)
      this.GetVideoSysConfigResp.SSLPort = Number(this.GetVideoSysConfigResp.SSLPort)
      this.GetVideoSysConfigResp.ReconnectInteval = Number(this.GetVideoSysConfigResp.ReconnectInteval)
      this.GetVideoSysConfigResp.SSLEnabled = this.GetVideoSysConfigResp.SSLEnabled === 'true'
    })
    this.getApplicationStatusInfo()
  },
  destroyed() {
    clearTimeout(this.applicationConfigTime)
  },
  methods: {
    getApplicationConfig() {
      return new Promise((resolve, reject) => {
        getVideoSysConfig({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    setApplicationConfig() {
      return new Promise((resolve, reject) => {
        const param = {
          SetVideoSysConfigReq: this.GetVideoSysConfigResp
        }
        setVideoSysConfig(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    saveApplicaConfig() { // 保存配置
      this.$refs.applicationForm.validate(valid => {
        if (valid) {
          this.setApplicationConfig().then(res => {
            this.$message({
              type: 'success',
              message: '保存成功'
            })
          })
        }
      })
    },
    getApplicationStatusInfo() { // 查询应用平台的状态
      getSvrState({}).then(res => {
        this.applicationStatus = res.SvrStateResp.VideoSysConnState
        this.applicationConfigTime = setTimeout(() => {
          this.getApplicationStatusInfo()
        }, 3000)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .application-plat-config {
  }
</style>
