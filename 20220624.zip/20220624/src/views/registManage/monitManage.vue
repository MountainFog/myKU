<template>
  <div>
    <template>
      <div>
        <div class="kd-main-title">注册管理 / 监控管理</div>
        <div class="content">
          <div class="config-stream-media">
            <label for="" class="config-title">注册平台状态:</label>
            <span class="font-title-color">{{VispRegState == 'false' ? '未连接' : '已连接'}}</span>
          </div>
          <el-form :rules="rules" ref="monitForm" :model="GetVsipAppCfgResp">
            <el-form-item>
              <div class="config-stream-media">
                <label for="" class="config-title">注册平台开关:</label>
                <div>
                  <el-radio v-model="GetVsipAppCfgResp.Enable" label="true">开启</el-radio>
                  <el-radio v-model="GetVsipAppCfgResp.Enable" label="false">关闭</el-radio>
                </div>
              </div>
            </el-form-item>
            <el-form-item>
              <div class="config-stream-media">
                <label for="" class="config-title">注册平台方式:</label>
                <div>
                  <el-select v-model="GetVsipAppCfgResp.AddressType" @change="platformChange" class="border-select-default" placeholder="请选择">
                    <el-option
                      v-for="item in way"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </div>
              </div>
            </el-form-item>
            <el-form-item prop="PlatAddr">
              <div class="config-stream-media" v-show='showIp'>
                <label for="" class="config-title">注册平台IPv4地址:</label>
                <el-input type="text" v-model="GetVsipAppCfgResp.PlatAddr" class="config-stream-input border-input-default default-border-radius" />
              </div>
            </el-form-item>
            <el-form-item>
              <div class="config-stream-media" v-show='!showIp'>
                <label for="" class="config-title">注册平台域名:</label>
                <el-input type="text" v-model="GetVsipAppCfgResp.PlatDomain" class="config-stream-input border-input-default default-border-radius" />
              </div>
            </el-form-item>
            <el-form-item prop="PlatPort">
              <div class="config-stream-media">
                <label for="" class="config-title">注册平台端口:</label>
                <div>
                  <el-input type="text" v-model.number="GetVsipAppCfgResp.PlatPort" class="config-stream-input border-input-default default-border-radius" />
                  <span class="font-title-color default-port">默认端口号为5510</span>
                </div>
              </div>
            </el-form-item>
            <el-form-item prop="UUID">
              <div class="config-stream-media">
                <label for="" class="config-title">入网设备UUID:</label>
                <el-input type="text" v-model="GetVsipAppCfgResp.UUID" class="config-stream-input border-input-default default-border-radius" />
              </div>
            </el-form-item>
            <el-form-item prop="Password">
              <div class="config-stream-media">
                <label for="" class="config-title">入网设备密码:</label>
                <el-input type="password" v-model="GetVsipAppCfgResp.Password" class="config-stream-input border-input-default default-border-radius" />
              </div>
            </el-form-item>
            <el-form-item>
              <div class="config-stream-media">
                <label for="" class="config-title">发送NAT探测包:</label>
                <div>
                  <el-select v-model="GetVsipAppCfgResp.SendNatPack" class="border-select-default" placeholder="请选择">
                    <el-option
                      v-for="item in natList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </div>
              </div>
            </el-form-item>
          </el-form>
          <div class="config-stream-media">
            <label for="" class="config-title"></label>
            <div>
              <input type="button" @click="setVsip" class="primary default-border-radius" value="保存"/>
            </div>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>
<script>
import { isPort,isBlank,validateIP } from '@/utils/validateModule'
import { getSvrState } from "@/api/user"
import { setVsipAppCfg,getVsipAppCfg } from "@/api/registManage.js"
export default {
  data() {
    return {
      rules: {
        PlatPort: [{ required: true, trigger: 'blur', validator: isPort }],
        PlatAddr: [{ required: true, trigger: 'blur', validator: validateIP }],
        UUID: [{ required: true, trigger: 'blur', validator: isBlank }],
        Password: [{ required: true, trigger: 'blur', validator: isBlank }]
      },
      page: '监控管理',
      platformSwitch: '0',
      platformWay: 'IP',
      VispRegState: 'false',
      way: [
        {
          value: 'ip',
          label: 'IP地址'
        }, {
          value: 'url',
          label: '域名'
        }
      ],
      platformNat: 'true',
      moniTime: null,
      natList: [
        {
          value: 'true',
          label: '是'
        }, {
          value: 'false',
          label: '否'
        }
      ],
      GetVsipAppCfgResp: {
        /* AddressType: 'ip',
        Enable: 'true',
        Password: '',
        PlatAddr: '',
        PlatPort: '',
        PlatDomain: '',
        ReportSlaveChn: true,
        ReportZeroChn: false,
        SendNatPack: true,
        UUID: '' */
      }
    }
  },
  computed:{
    showIp(){
      return this.platformWay == 'ip'
    }
  },
  components:{
    /* breadCrumb */
  },
  destroyed() {
    clearTimeout(this.moniTime)
  },
  mounted() {
    this.init()
    this.getmoniInfo()
  },
  methods:{
    getmoniInfo() {
      getSvrState({}).then(res => {
        this.VispRegState = res.SvrStateResp.VispRegState
        this.moniTime = setTimeout(() => {
          this.getmoniInfo()
        },3000)
      })
    },
    platformChange(){
      console.log(this.platformWay)
    },
    init(){
      getVsipAppCfg({}).then(res => {
        this.GetVsipAppCfgResp = res.GetVsipAppCfgResp
        this.platformWay = res.GetVsipAppCfgResp.AddressType
        /* this.platformSwitch = res.GetVsipAppCfgResp.Enable == "true" ? '1' : '0' */
        //SendNatPack
        this.platformNat = res.GetVsipAppCfgResp.SendNatPack
        this.GetVsipAppCfgResp.PlatPort = Number(this.GetVsipAppCfgResp.PlatPort)
      })
    },
    setVsip(){
      let _that = this
      let param = {
        //SetVsipAppCfgReq: _that.GetVsipAppCfgResp
        SetVsipAppCfgReq: {
          Enable: _that.GetVsipAppCfgResp.Enable === "true" ? true : false,
          AddressType: _that.GetVsipAppCfgResp.AddressType,
          PlatAddr: _that.GetVsipAppCfgResp.PlatAddr,
          PlatDomain: _that.GetVsipAppCfgResp.PlatDomain ? _that.GetVsipAppCfgResp.PlatDomain : '',
          PlatPort: _that.GetVsipAppCfgResp.PlatPort,
          SendNatPack: _that.GetVsipAppCfgResp.SendNatPack === "true" ? true : false,
          UUID: _that.GetVsipAppCfgResp.UUID,
          Password: _that.GetVsipAppCfgResp.Password,
          ReportSlaveChn: _that.GetVsipAppCfgResp.ReportSlaveChn === "true" ? true : false,
          ReportZeroChn: true
          /*ReportZeroChn: _that.GetVsipAppCfgResp.ReportZeroChn === "true" ? true : false */
        }
      }
      setVsipAppCfg(param).then(res => {
        this.$message({
          message: '接入平台配置成功',
          type: 'success'
        })
      })
      /* this.$refs.monitForm.validate((valid) => {
        if(valid) {
        }
      }) */
    }
  }
}
</script>
<style>
.content {
  padding-top: 8px;
}
.default-port {
  padding-left: 10px;
  font-size: 14px;
}
.smssStatus {
  font-size: 14px;
}
.config-stream-media {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  /* padding: 8px 0px; */
}
.config-title {
  width: 150px;
  font-size: 14px;
  color: rgba(255,255,255,0.85);
  font-weight: normal;
}
.config-stream-input,.border-select-default {
  width: 312px;
}
.marginLeft16 {
  margin-left: 16px;
}
.paddingLeft16 {
  padding-left: 16px;
}
</style>
