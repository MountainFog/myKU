<template>
  <div class="svr-rtmp-config">
    <div class="svr-rtmp-config-container">
      <div class="kd-main-title">通道管理 / RTMP</div>
      <div class="rtmp-btn-group">
        <el-button
          :loading="refreshDisabled"
          @click="refresh"
        >
          刷新
        </el-button>
        <el-button
          type="primary"
          @click="addRtmp"
        >
          添加
        </el-button>
        <el-button @click="editConfigShow">
          编辑
        </el-button>
        <el-button @click="pushConfig">
          推送
        </el-button>
        <el-button @click="stopConfig">
          停止
        </el-button>
        <el-button @click="open">
          删除
        </el-button>
      </div>
      <div class="rtmp-table-config">
        <el-table
          :data="rtmpData"
          style="width: 100%"
          @select="selectItem"
          @selection-change="changeS"
        >
          <el-table-column
            type="selection"
            width="80"
          />
          <el-table-column
            prop="chn_id"
            label="通道号"
          >
            <template scope="scope">
              <div>D{{ scope.row.chn_id }} </div>
            </template>
          </el-table-column>
          <el-table-column
            prop="channelAlias"
            label="通道别名"
          />
          <el-table-column
            prop="deviceSt"
            label="设备状态"
          />
          <el-table-column
            prop="vid_id"
            label="推送视频"
          >
            <template scope="scope">
              <div>{{ scope.row.vid_id == "0" ? "主流" : "辅流" }} </div>
            </template>
          </el-table-column>
          <el-table-column
            prop="aud"
            label="是否推送音频"
          >
            <template scope="scope">
              <div>{{ scope.row.aud == "true" ? "是" : "否" }} </div>
            </template>
          </el-table-column>
          <el-table-column
            prop="url"
            width="400"
            label="推送URL"
            show-overflow-tooltip
          />
          <el-table-column
            prop="state"
            label="推送状态"
          >
            <template scope="scope">
              <div>{{ scope.row.err_desc == "null" ? (scope.row.state == 'true' ? '推送中' : '未推送') : (scope.row.err_desc == '' ? '未推送' : scope.row.err_desc) }} </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <el-dialog
        title="RTMP配置"
        :close-on-click-modal="false"
        class="font-title-color"
        :visible.sync="rtmpConfigShow"
      >
        <el-form :model="form">
          <el-form-item
            label="通道号"
            :label-width="formLabelWidth"
          >
            <el-select
              v-model="form.chn_id"
              class="border-select-default"
              placeholder="请选择通道号"
            >
              <el-option
                v-for="item in chnList"
                :key="item.value"
                :label="('D' + item.NvrChnId + ' ' + item.SvrChnAlias)"
                :value="('D' + item.NvrChnId + ' ' + item.SvrChnAlias)"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            label="推送视频"
            :label-width="formLabelWidth"
          >
            <el-select
              v-model="form.vid_id"
              class="border-select-default"
              placeholder="请选择通道号"
            >
              <el-option
                label="主流"
                value="0"
              />
              <el-option
                label="辅流"
                value="1"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            label="推送url"
            :label-width="formLabelWidth"
          >
            <el-input
              v-model="form.url"
              type="text"
              class="config-stream-input border-input-default default-border-radius"
            />
          </el-form-item>
          <el-form-item
            label="是否推送音频"
            :label-width="formLabelWidth"
          >
            <el-select
              v-model="form.aud"
              class="border-select-default"
              placeholder="请选择推送音频"
            >
              <el-option
                label="是"
                value="true"
              />
              <el-option
                label="否"
                value="false"
              />
            </el-select>
          </el-form-item>
        </el-form>
        <div
          slot="footer"
          class="dialog-footer"
        >
          <input
            type="button"
            class="primary default-border-radius"
            value="保存"
            @click="save"
          >
          <input
            type="button"
            class="default default-border-radius font-title-color marginLeft16"
            value="取消"
            @click="cancelDialog"
          >
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import {
  getRtmpParam,
  setRtmpParam,
  getNvrChnList,
  getSrvCap,
  getCompositeChnCap,
  getSvrChnList
} from '@/api/channelManage'
export default {
  components: {
    /* breadCrumb */
  },
  data() {
    return {
      refreshDisabled: false,
      rtmpData: [],
      rtmpSendData: [],
      svrChnAlias: [],
      nvrList: [],
      chnList: [],
      capLength: 0,
      isSelect: false,
      deleteItems: [],
      remainItems: [],
      rtmpConfigShow: false,
      form: {
        mode: 0,
        chn_id: null,
        vid_id: '0',
        url: '',
        aud: 'true'
      },
      formLabelWidth: '100px',
      isEditOrAdd: false
    }
  },
  created() {
    this.init()
  },
  methods: {
    // 刷新
    refresh() {
      this.refreshDisabled = true
      this.getCap()
    },
    addRtmp() {
      this.form.chn_id =
        'D' + this.chnList[0].NvrChnId + ' ' + this.chnList[0].SvrChnAlias
      this.isEditOrAdd = false
      this.rtmpConfigShow = true
    },
    deepClone(obj) {
      const objClone = Array.isArray(obj) ? [] : {}
      if (obj && typeof obj === 'object') {
        for (const key in obj) {
          if (obj[key] && typeof obj[key] === 'object') {
            objClone[key] = this.deepClone(obj[key])
          } else {
            objClone[key] = obj[key]
          }
        }
      }
      return objClone
    },
    changeS(val) {
      this.deleteItems = val
    },
    async init() {
      // await this.getCompositeCap()
      await this.getSvrChn()
      await this.getRtmp()
      await this.getCap()
    },
    save() {
      const idnx = this.rtmpData.findIndex((item) => item.url == this.form.url)
      if (idnx > -1 && !this.isEditOrAdd) {
        // 添加时不允许重复添加相同的url
        this.$message({
          type: 'error',
          message: '当前url已存在!'
        })
        return
      } else if (idnx > -1 && this.isEditOrAdd) {
        // 编辑不允许与其他数据的url相同
        const editData = this.deepClone(this.deleteItems[0])
        const editIdx = this.rtmpData.findIndex(
          (item) => item.url == editData.url
        )
        if (idnx != editIdx) {
          this.$message({
            type: 'error',
            message: '当前url已存在!'
          })
          return
        }
      }
      const obj = this.deepClone(this.form)
      const chn_id = obj.chn_id.match(/\d+(\.\d+)?\s/)[0]
      obj.chn_id = chn_id
      this.remainItems = []
      const list = this.deepClone(this.rtmpData)
      this.deleteItems.forEach((val) => {
        const idx = list.findIndex(
          (item) =>
            item.chn_id == val.chn_id &&
            item.vid_id == val.vid_id &&
            item.aud == val.aud &&
            item.url == val.url
        )
        if (idx > -1) {
          list.splice(idx, 1)
        }
      })
      this.remainItems = list
      this.remainItems.push(obj)
      this.setRTMP().then((res) => {
        this.init()
      })
    },
    editConfigShow() {
      if (this.deleteItems.length == 0 || this.deleteItems.length > 1) return
      this.isEditOrAdd = true
      const formList = this.deepClone(this.deleteItems[0])
      if (formList.state == 'true') {
        this.$message({
          type: 'warning',
          message: '正在推流中,请先关闭推流再进行编辑'
        })
        return
      }
      this.form = {
        mode: formList.mode,
        chn_id: 'D' + formList.chn_id + ' ' + formList.channelAlias,
        vid_id: formList.vid_id,
        url: formList.url,
        aud: formList.aud
      }
      this.rtmpConfigShow = true
    },
    selectItem(selection, row) {
      const selected = selection.length && selection.indexOf(row) !== -1
      if (selected) {
        this.isSelect = true
      } else {
        this.isSelect = false
      }
    },
    open() {
      if (this.isSelect) {
        this.$confirm('确定要删除吗', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            this.remainItems = []
            var list = this.deepClone(this.rtmpData)
            let pushConFlag = false
            this.deleteItems.forEach((val) => {
              if (val.state == 'true') pushConFlag = true
              const idx = list.findIndex(
                (item) =>
                  item.chn_id == val.chn_id &&
                  item.vid_id == val.vid_id &&
                  item.aud == val.aud &&
                  item.url == val.url
              )
              if (idx > -1) {
                list.splice(idx, 1)
              }
            })
            if (pushConFlag) {
              this.$message({
                type: 'warning',
                message: '有正在推流中设备，请先结束推流设备再删除...'
              })
              return
            }
            this.remainItems = list
            this.setRTMP().then((res) => {
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
              this.init()
            })
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '取消删除'
            })
          })
      }
    },
    getCap() {
      getSrvCap({})
        .then(async(res) => {
          this.capLength = Number(res.capinfo.GroupNum)
          await this.getNvrListC(Number(res.capinfo.GroupNum))
        })
        .catch((_) => {
          this.refreshDisabled = false
        })
    },
    async getCompositeCap() {
      await getCompositeChnCap({}).then((res) => {
        console.log(res)
      })
    },
    async getSvrChn() {
      await getSvrChnList({}).then((res) => {
        var length = res.GetSvrChnListResp.SvrChnItemList.SvrChnItem.length
        this.chnList = res.GetSvrChnListResp.SvrChnItemList.SvrChnItem
        for (let i = length + 1; i <= this.capLength; i++) {
          var obj = {
            NvrChnId: i,
            SvrChnAlias: ''
          }
          this.chnList.push(obj)
        }
        this.svrChnAlias = res.GetSvrChnListResp.SvrChnItemList.SvrChnItem
      })
    },
    async getRtmp() {
      getRtmpParam({}).then(async(res) => {
        const resData = res.GetRtmpParamResp.RtmpParamList.ParamItem
        if (!resData) {
          this.rtmpSendData = []
          return
        }
        let xmlJson = []
        if (Array.isArray(resData)) {
          xmlJson = resData
        } else {
          xmlJson.push(resData)
        }
        var _that = this
        this.rtmpSendData = await this.dealWithData(xmlJson)
      })
    },
    async dealWithData(data) {
      const rtmp = []
      const _that = this
      await data.forEach(async(val) => {
        var obj = val
        await _that.svrChnAlias.forEach((svr) => {
          if (val.chn_id == svr.NvrChnId) {
            obj.channelAlias = svr.SvrChnAlias
            // // 特殊字符解码
            // obj.url = obj.url
            rtmp.push(obj)
            return false
          }
        })
      })
      return rtmp
    },
    async getNvrListC(subNum) {
      var param = {
        GetNvrChnListReq: {
          ChnIDStart: 1,
          ChnIDEnd: subNum,
          NeedMask: {
            ChnAlias: true,
            DevSrcID: true,
            ChnState: true,
            DevInfo: true,
            ChnDevCfg: false
          }
        }
      }
      await getNvrChnList(param)
        .then((res) => {
          this.refreshDisabled = false
          var nvrList = res.GetNvrChnListResp.ChnList.ChnInfo
          const tableData = this.deepClone(this.rtmpSendData)
          this.rtmpSendData = []
          tableData.forEach((val) => {
            // ChnID
            var obj = val
            nvrList.forEach((list) => {
              if (list.ChnID == val.chn_id) {
                if (list.ChnState) {
                  obj.deviceSt =
                    list.ChnState.Connect == 'online' ? '在线' : '下线'
                } else {
                  obj.deviceSt = '空闲'
                }
                this.rtmpSendData.push(obj)
                return false
              }
            })
          })
          this.rtmpData = this.rtmpSendData
        })
        .catch((_) => {
          this.refreshDisabled = false
        })
    },
    // 特殊字符转引用实体
    encodeEntity(text) {
      var str = text
        .replace(/\&/g, '&amp;')
        .replace(/\</g, '&lt;')
        .replace(/\>/g, '&gt;')
        .replace(/\'/g, '&apos;')
        .replace(/\"/g, '&quot;')
      return str
    },
    setRTMP() {
      var arr = []
      for (var i = 0, len = this.remainItems.length; i < len; i++) {
        var obj = {}
        var itemD = this.remainItems[i]
        obj = {
          mode: itemD.mode,
          chn_id: itemD.chn_id,
          vid_id: itemD.vid_id,
          aud: itemD.aud,
          url: this.encodeEntity(itemD.url)
        }
        arr.push(obj)
      }
      var param = {
        SetRtmpParamReq: {
          RtmpParamList: {
            K_E_Y: 'ParamItem',
            P_R_O_P: {
              num: this.remainItems.length
            },
            V_A_L_U_E: arr
          }
        }
      }
      return new Promise((resolve, reject) => {
        setRtmpParam(param)
          .then((res) => {
            this.rtmpData = this.remainItems
            this.deleteItems = []
            this.rtmpConfigShow = false
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    pushConfig() {
      if (this.deleteItems.length == 0) return
      this.stopOrPushConfig('1')
    },
    stopConfig() {
      if (this.deleteItems.length == 0) return
      this.stopOrPushConfig('0')
    },
    async stopOrPushConfig(pushValue) {
      this.remainItems = []
      var list = this.deleteItems
      var listA = this.deepClone(this.rtmpData)
      var listRtmp = []
      list.forEach((val) => {
        const idx = listA.findIndex(
          (item) =>
            item.chn_id == val.chn_id &&
            item.vid_id == val.vid_id &&
            item.aud == val.aud &&
            item.url == val.url
        )
        if (idx > -1) {
          listA.splice(idx, 1)
        }
      })
      let pushConFlag = false
      list.forEach((val) => {
        var obj = {
          mode: pushValue,
          chn_id: val.chn_id,
          vid_id: val.vid_id,
          url: val.url,
          aud: val.aud
        }
        if (val.state == 'true') {
          pushConFlag = true
        }
        listRtmp.push(obj)
      })
      if (pushConFlag && pushValue == '1') {
        this.$message({
          type: 'warning',
          message: '有正在推流中设备，请先结束再开始推流...'
        })
        return
      }
      this.remainItems = listA.concat(listRtmp)
      this.setRTMP().then(async(res) => {
        this.rtmpData = []
        this.remainItems = []
        this.deleteItems = []
        if (pushValue == '1') {
          let time = null
          let timeNum = 0
          time = setInterval(() => {
            timeNum++
            if (timeNum < 4) {
              this.init()
              let restart = false
              this.rtmpData.forEach((item) => {
                if (item.err_desc == '连接中') {
                  restart = true
                  return false
                }
              })
              if (restart) {
                timeNum--
              }
            } else {
              timeNum = 0
              clearInterval(time)
            }
          }, 1000)
        } else {
          setTimeout(() => {
            this.init()
          }, 1000)
        }
      })
    },
    cancelDialog() {
      this.rtmpConfigShow = false
      this.isEditOrAdd = false
      this.form = {
        mode: 0,
        chn_id: null,
        vid_id: '0',
        url: '',
        aud: 'true'
      }
    }
  }
}
</script>

<style lang="scss">
.svr-rtmp-config {
  color: $-fff-85;
  .svr-rtmp-config-container {
    .device-list {
    }
    .el-table {
      background: transparent;
    }
    .el-table th,
    .el-table tr {
      color: rgba(255, 255, 255, 0.65);
      background: #1d222c;
    }
    .el-table th {
      background: rgba(255, 255, 255, 0.08);
    }
    .el-table th.is-leaf {
      border-bottom: none;
    }
    .el-table td {
      border-bottom: 1px solid rgba(216, 222, 234, 0.12);
    }
    .el-table--border::after,
    .el-table--group::after,
    .el-table::before {
      background: rgba(216, 222, 234, 0.02);
    }
    .el-table--enable-row-hover .el-table__body tr:hover > td {
      background: #1d222c;
    }
    .el-table td,
    .el-table th {
      padding: 15px 0;
    }
    .table-edit {
      color: #177ddc;
      cursor: pointer;
    }
    .rtmp-btn-group {
      padding: 16px 20px 16px 0;
      .marginLeft16 {
        margin-left: 16px;
      }
    }
    .rtmp-table-config {
      padding-right: 20px;
    }
    .el-dialog {
      width: 500px;
      .border-select-default {
        width: 312px;
      }
      .config-stream-input {
        width: 312px;
      }
      .marginLeft16 {
        margin-left: 16px;
      }
    }
  }
}
</style>
