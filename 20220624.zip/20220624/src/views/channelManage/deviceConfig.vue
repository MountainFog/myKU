<template>
  <div class="svr-device-config">
    <div>
      <div class="kd-main-title">通道管理 / 前端配置</div>
      <div class="front-device-list">
        <div class="front-device-oper">
          <span class="label-title font-title-color fontSize20">设备列表</span>
          <div>
            <el-button :loading="refreshDisabled" @click="refresh">
              刷新
            </el-button>
            <el-button
              type="primary"
              @click="addFrontConfig($event)"
            >添加</el-button>
            <el-button
              type="default"
              @click="removeDevConfig"
            >删除</el-button>
          </div>
        </div>
        <div class="device-list">
          <el-table
            :data="tableData"
            style="width: 100%"
            @selection-change="selectDevice"
          >
            <el-table-column
              type="selection"
              width="80"
            />
            <el-table-column
              prop="svrList.ChnID"
              label="通道号"
            >
              <template slot-scope="scope">
                <div>D{{ scope.row.ChnID }} </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="svrChnAlias"
              label="通道别名"
            />
            <el-table-column
              prop=""
              label="跟踪摄像机"
            >
              <template slot-scope="scope">
                <el-checkbox
                  v-model="scope.row.IsEptzIpc"
                  @change="changeBindCamera(scope.row)"
                />
              </template>
            </el-table-column>
            <el-table-column
              prop=""
              label="IP地址"
            >
              <template slot-scope="scope">
                <el-link :href="getEthInfoUrl(scope.row)" target="_blank" type="primary">{{ scope.row.svrList.Ip }}</el-link>
              </template>
            </el-table-column>
            <!-- <template slot-scope="scope">
              <div class="table-edit">scope.row.</div>
            </template> -->
            <el-table-column
              prop="svrList.Proto"
              label="协议"
            />
            <el-table-column
              prop="svrList.Port"
              label="端口"
            />
            <el-table-column
              prop="svrList.DevModel"
              label="设备型号"
            />
            <el-table-column
              prop="ChnState"
              label="状态"
              width="100"
            />
            <el-table-column
              prop="operation"
              label="操作"
              width="100"
            >
              <template slot-scope="scope">
                <div
                  v-show="scope.row.ChnState !== '空闲'"
                  class="table-edit"
                  @click="getId(scope.row)"
                >编辑</div>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="front-device-oper">
          <span class="label-title font-title-color fontSize20">设备搜索列表</span>
          <div>
            <input
              v-show="isNowSearching"
              type="button"
              class="primary default-border-radius"
              value="搜索"
              @click="search"
            >
            <input
              v-show="!isNowSearching"
              type="button"
              class="primary default-border-radius"
              value="停止"
              @click="stopSearchList"
            >
            <input
              type="button"
              class="default default-border-radius font-title-color marginLeft16"
              value="添加"
              @click="addFrontConfig($event,'search')"
            >
          </div>
        </div>
        <div class="device-list">
          <el-table
            :data="tableDatas"
            style="width: 100%"
            @selection-change="searchAdd"
          >
            <el-table-column
              class="check-list"
              type="selection"
              width="80"
            />
            <el-table-column
              type="index"
              label="序号"
            />
            <el-table-column
              prop="Ip"
              label="IP地址"
            />
            <el-table-column
              prop="Proto"
              label="协议"
            />
            <el-table-column
              prop="Port"
              label="端口"
            />
            <el-table-column
              prop="PuType"
              label="设备类型"
            />
            <el-table-column
              prop="PuModel"
              label="设备型号"
            />

          </el-table>
        </div>
      </div>
      <el-dialog
        :title="dialogTitle"
        class="font-title-color add-chn-device-dialog"
        :visible.sync="frontConfig"
        :close-on-click-modal="false"
        @closed="closeDialog"
      >
        <el-form
          ref="deviceForm"
          :model="form"
          :rules="rules"
        >
          <el-form-item
            label="通道号"
            :label-width="formLabelWidth"
          >
            <el-select
              v-model="NvrChnId"
              class="border-select-default"
              placeholder="请选择通道号"
              @change="changeNvrId"
            >
              <el-option
                v-for="item in nvrChannelItem"
                :key="item.ChnID"
                :label="item.chnChannel"
                :value="item.ChnID"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            v-if="!isSearchAdd"
            label="通道别名"
            :label-width="formLabelWidth"
          >
            <el-input
              v-model="SvrChnAlias"
              type="text"
              :disabled="NvrChnId === 'auto'"
              class="config-stream-input border-input-default default-border-radius"
            />
          </el-form-item>
          <el-form-item
            label="协议类型"
            :label-width="formLabelWidth"
          >
            <el-select
              v-model="form.Proto"
              :disabled="isEditAdd"
              class="border-select-default"
              placeholder="请选择协议类型"
            >
              <el-option
                label="ONVIF"
                value="ONVIF"
              />
              <el-option
                label="RTSP"
                value="RTSP"
              />
              <el-option
                label="RTMP"
                value="RTMP"
              />
              <!-- <el-option label="LCAM" value="LCAM"></el-option> -->
            </el-select>
          </el-form-item>
          <!-- <div v-if="form.Proto === 'ONVIF' || form.Proto === 'RTSP'" key="trans"> -->
          <div key="trans">
            <el-form-item
              label="传输协议"
              :label-width="formLabelWidth"
            >
              <el-select
                v-model="form.TransProto"
                class="border-select-default"
                placeholder="请选择传输协议"
              >
                <el-option
                  label="自适应"
                  value="auto"
                />
                <el-option
                  label="TCP"
                  value="rtp_over_rtsp_over_tcp"
                />
                <el-option
                  label="UDP"
                  value="rtp_over_udp"
                />
              </el-select>
            </el-form-item>
          </div>
          <div
            v-if="form.Proto === 'ONVIF'"
            key="ONVIF"
          >
            <el-form-item
              prop="DevIp"
              label="IP地址"
              :label-width="formLabelWidth"
            >
              <el-input
                v-model="form.DevIp"
                type="text"
                :disabled="isSear"
                class="config-stream-input border-input-default default-border-radius"
              />
            </el-form-item>
            <el-form-item
              label="管理端口"
              :label-width="formLabelWidth"
            >
              <el-input
                v-model="form.DevPort"
                type="text"
                :disabled="isSear"
                class="config-stream-input border-input-default default-border-radius"
              />
            </el-form-item>
            <el-form-item
              prop="DevIp"
              label="添加模式"
              :label-width="formLabelWidth"
            >
              <el-select
                v-model="form.AddMode"
                :disabled="isEdit"
                class="border-select-default"
                @change="changeSourceModel"
              >
                <el-option
                  v-for="source in sourceModel"
                  :key="source.value"
                  :label="source.label"
                  :value="source.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item
              v-if="isSingleSource"
              label="远程通道"
              :label-width="formLabelWidth"
            >
              <el-input
                v-model.number="form.SrcNum"
                type="text"
                class="config-stream-input border-input-default default-border-radius"
                oninput="value=value.replace(/\D/g,'')"
              />
            </el-form-item>
            <el-form-item
              v-if="!isSingleSource"
              label="远程通道"
              :label-width="formLabelWidth"
            >
              <el-select
                v-model.number="form.SrcNum"
                class="border-select-default"
              >
                <el-option
                  v-for="n in 3"
                  :key="n"
                  :label="n"
                  :value="n"
                />
              </el-select>
            </el-form-item>
          </div>
          <div
            v-if="form.Proto === 'RTSP' || form.Proto === 'RTMP'"
            key="RTSP"
          >
            <el-form-item
              label="主码流地址"
              :label-width="formLabelWidth"
            >
              <el-input
                v-model="form.mainStream"
                type="text"
                class="config-stream-input border-input-default default-border-radius"
              />
            </el-form-item>
            <el-form-item
              label="辅码流地址"
              :label-width="formLabelWidth"
            >
              <el-input
                v-model="form.auxStream"
                type="text"
                class="config-stream-input border-input-default default-border-radius"
              />
            </el-form-item>
          </div>
          <!-- <div v-if="form.Proto === 'ONVIF' || form.Proto === 'RTSP'" key="use"> -->
          <div
            v-if="form.Proto === 'ONVIF' || form.Proto === 'RTSP'"
            key="use"
          >
            <el-form-item
              label="认证用户名"
              :label-width="formLabelWidth"
            >
              <el-input
                v-model="form.Username"
                type="text"
                class="config-stream-input border-input-default default-border-radius"
              />
            </el-form-item>
            <el-form-item
              label="认证密码"
              :label-width="formLabelWidth"
            >
              <el-input
                v-model="form.Password"
                type="password"
                class="config-stream-input border-input-default default-border-radius"
              />
            </el-form-item>
          </div>
        </el-form>
        <div
          slot="footer"
          class="dialog-footer"
        >
          <input
            type="button"
            class="primary default-border-radius"
            value="保存"
            @click="addDev"
          >
          <input
            type="button"
            class="default default-border-radius font-title-color marginLeft16"
            value="取消"
            @click="cancelAdd"
          >
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import {
  addDevParam,
  removeDevParam,
  modifyDev,
  createSearchPuTask,
  getSearchedPuList,
  getNvrChnList,
  getSrvCap,
  getSvrChnList,
  setSvrChnList,
  getCompositeChnCap,
  destroySearchPuTask
} from '@/api/channelManage'
import store from '@/store'
import { xmlToJson } from '@/utils/dataParse.js'
import { validateIP } from '@/utils/validateModule'
import { getEthInfo } from '@/api/networkConfig'
export default {
  components: {
    /* breadCrumb */
  },
  data() {
    return {
      // 禁止刷新
      refreshDisabled: false,
      rules: {
        DevIp: [{ required: false, trigger: 'blur', validator: validateIP }]
      },
      searchFilter: [
        'KSCA',
        'G400',
        'kkkk',
        '2801',
        '2802',
        '2901',
        '28-',
        'MSS',
        'SSR',
        'IVS',
        'CVS',
        'DS',
        'ATBOX',
        'KDM',
        'SCT',
        'SVR',
        'NVR',
        'KD-M',
        'KEDU',
        'SXMS'
      ],
      SvrChnAlias: '',
      isSearchAdd: false,
      isNowSearching: true,
      searchId: '',
      searchTime: null,
      searchProto: 'onvif',
      dialogTitle: '添加通道',
      isEdit: false,
      isEditAdd: false,
      isSear: false,
      tableDatas: [],
      tableData: [],
      deleteData: [],
      frontConfig: false,
      chnId: 0,
      capSum: 0,
      compositeSum: 0,
      SvrChnItem: [],
      nvrList: [],
      nvrChannelItem: [],
      NvrChnId: 'auto',
      form: {
        Proto: 'ONVIF',
        TransProto: 'auto',
        DevPort: 80,
        SrcId: '1',
        Username: 'admin',
        Password: 'admin123',
        ChnID: '自适应',
        DevIp: '',
        auxStream: '', // 辅流地址
        mainStream: '', // 主流地址
        AddMode: 'single_source', // 添加模式 单源或多源模式
        SrcNum: 1 // 远程通道
      },
      formLabelWidth: '100px',
      DevInfo: {
        svrList: {},
        svrChnAlias: '',
        ChnState: '',
        ChnID: '',
        DevCfg: '',
        IsEptzIpc: false
      },
      svrTimeCount: 1,
      svrChnTime: null,
      searchData: [],
      isSingleSource: true, // 是否为单源添加
      sourceModel: [
        {
          value: 'single_source',
          label: '单源添加'
        },
        {
          value: 'double_source',
          label: '多源添加'
        }
      ],
      isWeb: true, // 是不是web浏览器
      EthIp: '',
      EthMask: ''
    }
  },
  computed: {},
  destroyed() {
    clearTimeout(this.svrChnTime)
    clearTimeout(this.searchTime)
  },
  created() {
    this.isWeb = store.getters.isWeb
    this.getEthInfo()
    this.getCap()
  },
  methods: {
    // 刷新
    refresh() {
      this.refreshDisabled = true
      this.getCap()
    },
    // 获取网卡信息
    getEthInfo() {
      getEthInfo({}).then((res) => {
        this.EthIp = res.GetEthInfoResp.EthList.EthItem[1].IpList.IpItem.Ip
        this.EthMask = res.GetEthInfoResp.EthList.EthItem[1].IpList.IpItem.Mask
      })
    },
    // 根据网卡信息获取跳转的url
    getEthInfoUrl(row) {
      const isEqual = this.isEqualIpAddress(this.EthIp, row.svrList.Ip, this.EthMask)
      let url = ''
      if (isEqual) {
        // 同一网段
        url =
          location.protocol +
          '//' +
          location.hostname +
          ':' +
          (47000 + (Number(row.ChnID) - 1))
      } else {
        url = 'http://' + row.svrList.Ip + ':' + row.svrList.Port
      }
      return url
    },
    isEqualIpAddress(ip1, ip2, mask) {
      if (!ip1 || !ip2 || !mask) {
        return false
      }
      const res1 = []
      const res2 = []
      const ipA1 = ip1.split('.')
      const ipA2 = ip2.split('.')
      const maskA = mask.split('.')
      for (let i = 0, len = ipA1.length; i < len; i++) {
        res1.push(parseInt(ipA1[i]) & parseInt(maskA[i]))
        res2.push(parseInt(ipA2[i]) & parseInt(maskA[i]))
      }
      if (res1.join('.') === res2.join('.')) {
        return true
      } else {
        return false
      }
    },
    deepClone(obj) {
      const objClone = Array.isArray(obj) ? [] : {}
      if (obj && typeof obj === 'object') {
        for (const key in obj) {
          if (obj[key] && typeof obj[key] === 'object') {
            objClone[key] = this.deepClone(obj[key])
          } else {
            objClone[key] = obj[key]
          }
        }
      }
      return objClone
    },
    changeBindCamera(row) {
      const itemAc = row.IsEptzIpc
      if (!itemAc) {
        const idx = this.SvrChnItem.findIndex(
          (item) => item.NvrChnId === row.ChnID
        )
        this.SvrChnItem[idx].IsEptzIpc = '' + row.IsEptzIpc
      } else {
        let activeN = 0
        const activeA = []
        const index = this.tableData.findIndex((item) => item.ChnID === row.ChnID)
        this.tableData.forEach((item, ind) => {
          if (ind !== index) {
            if (item.IsEptzIpc === 'true' || item.IsEptzIpc) {
              activeN++
              activeA.push(ind)
            }
          }
        })
        if (row.IsEptzIpc) {
          activeN++
          activeA.push(index)
        }
        if (activeN <= 2) {
          const idx = this.SvrChnItem.findIndex(
            (item) => item.NvrChnId === row.ChnID
          )
          this.SvrChnItem[idx].IsEptzIpc = '' + row.IsEptzIpc
        } else {
          this.tableData[activeA[0]].IsEptzIpc = false
          this.SvrChnItem[activeA[0]].IsEptzIpc = 'false'
          this.SvrChnItem[index].IsEptzIpc = 'true'
        }
      }
      this.SvrChnAlias = row.svrChnAlias
      this.setChnAlias(row.ChnID).then((res) => {
        console.log(res)
      })
    },
    selectDevice(val) {
      // 选中需要删除的通道
      this.deleteData = val
      if (val.length > 0) {
        const ind = val.findIndex((item) => item.ChnState === '空闲')
        if (ind > -1) {
          this.SvrChnAlias = val[ind].svrChnAlias
        } else {
          this.SvrChnAlias = ''
        }
      } else {
        this.SvrChnAlias = ''
      }
    },
    getId(row) {
      // 编辑通道
      const useInfo = this.editInfoDealWith(row.DevCfg)
      this.isEdit = true
      this.isEditAdd = true
      this.NvrChnId = 'D' + row.ChnID
      this.dialogTitle = '修改通道'
      this.SvrChnAlias = row.svrChnAlias
      this.isSearchAdd = false
      this.form = {
        Proto: row.svrList.Proto ? row.svrList.Proto.toUpperCase() : '',
        TransProto: useInfo.TransProto ? useInfo.TransProto : 'auto',
        DevPort: row.svrList.Port ? row.svrList.Port : '',
        SrcId: useInfo.SrcId ? useInfo.SrcId : '1',
        Username: useInfo.Username,
        Password: useInfo.Password,
        ChnID: row.ChnID,
        DevIp: row.svrList.Ip ? row.svrList.Ip : '',
        auxStream: useInfo.StreamUrl2,
        mainStream: useInfo.StreamUrl1,
        AddMode: 'single_source', // 添加模式 单源或多源模式
        SrcNum: useInfo.SrcId ? Number(useInfo.SrcId) : 1 // 远程通道
      }
      this.frontConfig = true
    },
    async removeDevConfig() {
      // 删除config
      if (this.deleteData.length === 0) return
      var deleteA = []
      for (const ele of this.deleteData.values()) {
        deleteA.push(ele.ChnID)
      }
      var param = {
        RemoveDevReq: {
          NvrChnIDList: {
            // num属性
            K_E_Y: 'NvrChnID',
            P_R_O_P: {
              num: this.deleteData.length
            },
            V_A_L_U_E: deleteA
          }
        }
      }
      await removeDevParam(param).then((res) => {
        this.deleteData = []
        this.getCap()
      })
    },
    setChnAlias(chnId) {
      return new Promise((resolve, reject) => {
        if (this.SvrChnAlias) {
          const chnIndex = this.SvrChnItem.findIndex(
            (val) => val.NvrChnId === chnId
          )
          this.SvrChnItem[chnIndex].SvrChnAlias = this.SvrChnAlias
          let szXml = '<contentroot>'
          szXml += '<authenticationinfo type="7.0">'
          szXml += '<username>' + store.getters.username + '</username>'
          szXml += '<password>' + store.getters.password + '</password>'
          szXml +=
            '<authenticationid>' + store.getters.authId + '</authenticationid>'
          szXml += '</authenticationinfo>'
          szXml += '<SetSvrChnListReq>'
          szXml += '<SvrChnItemList>'
          for (let i = 0, len = this.SvrChnItem.length; i < len; i++) {
            szXml += '<SvrChnItem>'
            szXml += '<NvrChnId>' + this.SvrChnItem[i].NvrChnId + '</NvrChnId>'
            szXml +=
              '<SvrChnAlias>' +
              this.SvrChnItem[i].SvrChnAlias +
              '</SvrChnAlias>'
            szXml +=
              '<IsEptzIpc>' +
              (this.SvrChnItem[i].IsEptzIpc === 'true') +
              '</IsEptzIpc>'
            szXml += '<EncId>' + this.SvrChnItem[i].EncId + '</EncId>'
            szXml +=
              '<VidSrcNum>' + this.SvrChnItem[i].VidSrcNum + '</VidSrcNum>'
            szXml += '</SvrChnItem>'
          }
          szXml += '</SvrChnItemList>'
          szXml += '</SetSvrChnListReq>'
          szXml += '</contentroot>'
          setSvrChnList(szXml)
            .then((res) => {
              resolve(res)
            })
            .catch((err) => {
              reject(err)
            })
        } else {
          resolve()
        }
      })
    },
    addDev() {
      // 添加通道
      this.$refs.deviceForm.validate((valid) => {
        if (valid) {
          this.frontConfig = false
          let dataInfo
          let num = 1
          if (!this.isEdit) {
            if (this.form.AddMode === 'double_source') {
              if (this.nvrChannelItem.length - 1 < this.form.SrcNum) {
                this.$message({
                  type: 'warning',
                  message: '选中的通道个数多于空闲通道数，请重新选择'
                })
                return
              }
            }
          }
          if (this.isSearchAdd) {
            dataInfo = this.searchData
            num = dataInfo.length > 0 ? dataInfo.length : 1
            if (this.nvrChannelItem.length - 1 < num) {
              this.$message({
                type: 'warning',
                message: '选中的通道个数多于空闲通道数，请重新选择'
              })
              return
            }
          } else {
            // dataInfo = this.deleteData
            // num = dataInfo.length > 0 ? dataInfo.length : 1
          }
          let szXml = '<contentroot>'
          szXml += '<authenticationinfo type="7.0">'
          szXml += '<username>' + store.getters.username + '</username>'
          szXml += '<password>' + store.getters.password + '</password>'
          szXml +=
            '<authenticationid>' + store.getters.authId + '</authenticationid>'
          szXml += '</authenticationinfo>'
          if (this.isEdit && !this.isSearchAdd) {
            szXml += '<ModifyDevReq>'
            szXml += '<DevCfgXml>'
            szXml += '<![CDATA[<DevCfg>'
            if (this.form.Proto === 'ONVIF') {
              szXml += '<OnvifCfg>'
              szXml += '<DevIp>' + this.form.DevIp + '</DevIp>'
              szXml += '<DevPort>' + this.form.DevPort + '</DevPort>'
              szXml += '<AddMode>single_source</AddMode>'
              szXml += '<SrcId>' + this.form.SrcNum + '</SrcId>'
              szXml += '<SrcNum>1</SrcNum>'
              szXml += '<TransProto>' + this.form.TransProto + '</TransProto>'
              szXml += '<Username>' + this.form.Username + '</Username>'
              szXml +=
                '<Password>' + window.btoa(this.form.Password) + '</Password>'
              szXml += '</OnvifCfg>'
            } else if (this.form.Proto === 'RTSP' || this.form.Proto === 'RTMP') {
              if (this.form.Proto === 'RTSP') {
                szXml += '<RtspCfg>'
                szXml += '<TransProto>' + this.form.TransProto + '</TransProto>'
                szXml += '<Username>' + this.form.Username + '</Username>'
                szXml +=
                  '<Password>' + window.btoa(this.form.Password) + '</Password>'
              } else {
                szXml += '<RtmpCfg>'
              }
              let StreamUrlLen = 0
              if (this.form.mainStream) {
                StreamUrlLen++
              }
              if (this.form.auxStream) {
                StreamUrlLen++
              }
              szXml += '<StreamUrls num="' + StreamUrlLen + '">'
              if (this.form.mainStream) {
                szXml += '<StreamUrl>' + this.form.mainStream + '</StreamUrl>'
              }
              if (this.form.auxStream) {
                szXml += '<StreamUrl>' + this.form.auxStream + '</StreamUrl>'
              }
              szXml += '</StreamUrls>'

              if (this.form.Proto === 'RTSP') {
                szXml += '</RtspCfg>'
              } else {
                szXml += '</RtmpCfg>'
              }
            } else {
              szXml += '<LcamCfg/>'
            }
            szXml += '</DevCfg>'
            szXml += ']]>'
            szXml += '</DevCfgXml>'
            if (this.NvrChnId !== 'auto') {
              this.NvrChnId = this.NvrChnId.replace(/D/, '')
              if (this.isEdit) {
                szXml += '<NvrChnID>' + this.NvrChnId + '</NvrChnID>'
              } else {
                szXml += '<NvrChnId>' + this.NvrChnId + '</NvrChnId>'
              }
            }
            szXml += '</ModifyDevReq>'
          } else {
            szXml += '<AddDevReq>'
            if (this.isSearchAdd) {
              // 搜索添加
              if (dataInfo.length > 0) {
                // 有选中搜索的数据
                szXml += '<PuList num="' + num + '">'
                for (let i = 0, len = dataInfo.length; i < len; i++) {
                  szXml += '<PuInfo>'
                  szXml += '<AddInfo>'
                  szXml += '<![CDATA[<DevCfg>'
                  if (this.form.Proto === 'ONVIF') {
                    szXml += '<OnvifCfg>'
                    szXml += '<DevIp>' + dataInfo[i].Ip + '</DevIp>'
                    szXml += '<DevPort>' + dataInfo[i].Port + '</DevPort>'
                    szXml += '<AddMode>single_source</AddMode>'
                    szXml += '<SrcId>1</SrcId>'
                    szXml += '<SrcNum>1</SrcNum>'
                    szXml += '<TransProto>auto</TransProto>'
                    szXml += '<Username>' + this.form.Username + '</Username>'
                    szXml +=
                      '<Password>' +
                      window.btoa(this.form.Password) +
                      '</Password>'
                    szXml += '</OnvifCfg>'
                  }
                  szXml += '</DevCfg>'
                  szXml += ']]>'
                  szXml += '</AddInfo>'
                  szXml += '</PuInfo>'
                }
              } else {
                // 无选中搜索的数据添加
                if (this.form.Proto === 'ONVIF') {
                  let srcNumLength = 0
                  if (this.form.AddMode === 'single_source') {
                    srcNumLength = 1
                  } else {
                    srcNumLength = this.form.SrcNum
                  }
                  szXml += '<PuList num="' + srcNumLength + '">'
                  for (let i = 0; i < srcNumLength; i++) {
                    szXml += '<PuInfo>'
                    szXml += '<AddInfo>'
                    szXml += '<![CDATA[<DevCfg>'
                    szXml += '<OnvifCfg>'
                    szXml += '<DevIp>' + this.form.DevIp + '</DevIp>'
                    szXml += '<DevPort>' + this.form.DevPort + '</DevPort>'
                    szXml += '<AddMode >single_source</AddMode>'
                    if (this.form.AddMode === 'single_source') {
                      // 单源添加
                      szXml += '<SrcNum>' + (i + 1) + '</SrcNum>'
                      szXml += '<SrcId>' + this.form.SrcNum + '</SrcId>'
                    } else {
                      // 多源添加
                      szXml += '<SrcNum>' + this.form.SrcNum + '</SrcNum>'
                      szXml += '<SrcId>' + (i + 1) + '</SrcId>'
                    }
                    szXml +=
                      '<TransProto>' + this.form.TransProto + '</TransProto>'
                    szXml += '<Username>' + this.form.Username + '</Username>'
                    szXml +=
                      '<Password>' +
                      window.btoa(this.form.Password) +
                      '</Password>'
                    szXml += '</OnvifCfg>'
                    szXml += '</DevCfg>'
                    szXml += ']]>'
                    szXml += '</AddInfo>'
                    if (this.NvrChnId !== 'auto') {
                      this.NvrChnId = this.NvrChnId.replace(/D/, '')
                      if (this.isEdit) {
                        szXml += '<NvrChnID>' + this.NvrChnId + '</NvrChnID>'
                      } else {
                        szXml += '<NvrChnId>' + this.NvrChnId + '</NvrChnId>'
                      }
                    }
                    szXml += '</PuInfo>'
                  }
                } else if (
                  this.form.Proto === 'RTSP' ||
                  this.form.Proto === 'RTMP'
                ) {
                  szXml += '<PuList num="' + num + '">'
                  szXml += '<PuInfo>'
                  szXml += '<AddInfo>'
                  szXml += '<![CDATA[<DevCfg>'
                  if (this.form.Proto === 'RTSP') {
                    szXml += '<RtspCfg>'
                    szXml +=
                      '<TransProto>' + this.form.TransProto + '</TransProto>'
                    szXml += '<Username>' + this.form.Username + '</Username>'
                    szXml +=
                      '<Password>' +
                      window.btoa(this.form.Password) +
                      '</Password>'
                  } else {
                    szXml += '<RtmpCfg>'
                  }
                  let StreamUrlLen = 0
                  if (this.form.mainStream) {
                    StreamUrlLen++
                  }
                  if (this.form.auxStream) {
                    StreamUrlLen++
                  }
                  szXml += '<StreamUrls num="' + StreamUrlLen + '">'
                  if (this.form.mainStream) {
                    szXml +=
                      '<StreamUrl>' + this.form.mainStream + '</StreamUrl>'
                  }
                  if (this.form.auxStream) {
                    szXml +=
                      '<StreamUrl>' + this.form.auxStream + '</StreamUrl>'
                  }
                  szXml += '</StreamUrls>'

                  if (this.form.Proto === 'RTSP') {
                    szXml += '</RtspCfg>'
                  } else {
                    szXml += '</RtmpCfg>'
                  }
                  szXml += '</DevCfg>'
                  szXml += ']]>'
                  szXml += '</AddInfo>'
                  if (this.NvrChnId !== 'auto') {
                    this.NvrChnId = this.NvrChnId.replace(/D/, '')
                    if (this.isEdit) {
                      szXml += '<NvrChnID>' + this.NvrChnId + '</NvrChnID>'
                    } else {
                      szXml += '<NvrChnId>' + this.NvrChnId + '</NvrChnId>'
                    }
                  }
                  szXml += '</PuInfo>'
                } else {
                  szXml += '<PuList num="' + num + '">'
                  szXml += '<PuInfo>'
                  szXml += '<AddInfo>'
                  szXml += '<![CDATA[<DevCfg>'
                  szXml += '<LcamCfg/>'
                  szXml += '</DevCfg>'
                  szXml += ']]>'
                  szXml += '</AddInfo>'
                  if (this.NvrChnId !== 'auto') {
                    this.NvrChnId = this.NvrChnId.replace(/D/, '')
                    if (this.isEdit) {
                      szXml += '<NvrChnID>' + this.NvrChnId + '</NvrChnID>'
                    } else {
                      szXml += '<NvrChnId>' + this.NvrChnId + '</NvrChnId>'
                    }
                  }
                  szXml += '</PuInfo>'
                }
              }
            } else {
              // 非搜索添加
              if (this.form.Proto === 'ONVIF') {
                let srcNumLength = 0
                if (this.form.AddMode === 'single_source') {
                  srcNumLength = 1
                } else {
                  srcNumLength = this.form.SrcNum
                }
                szXml += '<PuList num="' + srcNumLength + '">'
                for (let i = 0; i < srcNumLength; i++) {
                  szXml += '<PuInfo>'
                  szXml += '<AddInfo>'
                  szXml += '<![CDATA[<DevCfg>'
                  szXml += '<OnvifCfg>'
                  szXml += '<DevIp>' + this.form.DevIp + '</DevIp>'
                  szXml += '<DevPort>' + this.form.DevPort + '</DevPort>'
                  szXml += '<AddMode >single_source</AddMode>'
                  if (this.form.AddMode === 'single_source') {
                    // 单源添加
                    szXml += '<SrcNum>' + (i + 1) + '</SrcNum>'
                    szXml += '<SrcId>' + this.form.SrcNum + '</SrcId>'
                  } else {
                    // 多源添加
                    szXml += '<SrcNum>' + this.form.SrcNum + '</SrcNum>'
                    szXml += '<SrcId>' + (i + 1) + '</SrcId>'
                  }
                  szXml +=
                    '<TransProto>' + this.form.TransProto + '</TransProto>'
                  szXml += '<Username>' + this.form.Username + '</Username>'
                  szXml +=
                    '<Password>' +
                    window.btoa(this.form.Password) +
                    '</Password>'
                  szXml += '</OnvifCfg>'
                  szXml += '</DevCfg>'
                  szXml += ']]>'
                  szXml += '</AddInfo>'
                  if (this.NvrChnId !== 'auto') {
                    this.NvrChnId = this.NvrChnId.replace(/D/, '')
                    if (this.isEdit) {
                      szXml += '<NvrChnID>' + this.NvrChnId + '</NvrChnID>'
                    } else {
                      szXml += '<NvrChnId>' + this.NvrChnId + '</NvrChnId>'
                    }
                  }
                  szXml += '</PuInfo>'
                }
              } else if (
                this.form.Proto === 'RTSP' ||
                this.form.Proto === 'RTMP'
              ) {
                szXml += '<PuList num="' + num + '">'
                szXml += '<PuInfo>'
                szXml += '<AddInfo>'
                szXml += '<![CDATA[<DevCfg>'
                if (this.form.Proto === 'RTSP') {
                  szXml += '<RtspCfg>'
                  szXml +=
                    '<TransProto>' + this.form.TransProto + '</TransProto>'
                  szXml += '<Username>' + this.form.Username + '</Username>'
                  szXml +=
                    '<Password>' +
                    window.btoa(this.form.Password) +
                    '</Password>'
                } else {
                  szXml += '<RtmpCfg>'
                }
                let StreamUrlLen = 0
                if (this.form.mainStream) {
                  StreamUrlLen++
                }
                if (this.form.auxStream) {
                  StreamUrlLen++
                }
                szXml += '<StreamUrls num="' + StreamUrlLen + '">'
                if (this.form.mainStream) {
                  szXml += '<StreamUrl>' + this.form.mainStream + '</StreamUrl>'
                }
                if (this.form.auxStream) {
                  szXml += '<StreamUrl>' + this.form.auxStream + '</StreamUrl>'
                }
                szXml += '</StreamUrls>'

                if (this.form.Proto === 'RTSP') {
                  szXml += '</RtspCfg>'
                } else {
                  szXml += '</RtmpCfg>'
                }
                szXml += '</DevCfg>'
                szXml += ']]>'
                szXml += '</AddInfo>'
                if (this.NvrChnId !== 'auto') {
                  this.NvrChnId = this.NvrChnId.replace(/D/, '')
                  if (this.isEdit) {
                    szXml += '<NvrChnID>' + this.NvrChnId + '</NvrChnID>'
                  } else {
                    szXml += '<NvrChnId>' + this.NvrChnId + '</NvrChnId>'
                  }
                }
                szXml += '</PuInfo>'
              } else {
                szXml += '<PuList num="' + num + '">'
                szXml += '<PuInfo>'
                szXml += '<AddInfo>'
                szXml += '<![CDATA[<DevCfg>'
                szXml += '<LcamCfg/>'
                szXml += '</DevCfg>'
                szXml += ']]>'
                szXml += '</AddInfo>'
                if (this.NvrChnId !== 'auto') {
                  this.NvrChnId = this.NvrChnId.replace(/D/, '')
                  if (this.isEdit) {
                    szXml += '<NvrChnID>' + this.NvrChnId + '</NvrChnID>'
                  } else {
                    szXml += '<NvrChnId>' + this.NvrChnId + '</NvrChnId>'
                  }
                }
                szXml += '</PuInfo>'
              }
            }
            szXml += '</PuList>'
            szXml += '</AddDevReq>'
          }
          szXml += '</contentroot>'
          let chnAlias
          let addItemPro
          if (this.NvrChnId === 'auto') {
            if (!this.isSearchAdd) {
              chnAlias = this.setChnAlias(this.nvrChannelItem[1].ChnID)
            }
          } else {
            if (!this.isSearchAdd) {
              chnAlias = this.setChnAlias(this.NvrChnId)
            }
          }
          if (this.isEdit && !this.isSearchAdd) {
            addItemPro = modifyDev(szXml)
          } else {
            addItemPro = addDevParam(szXml)
          }
          Promise.all([chnAlias, addItemPro]).then((res) => {
            this.$message({
              type: 'success',
              message: '保存成功'
            })
            this.SvrChnAlias = ''
            this.NvrChnId = 'auto'
            if (this.isSearchAdd) {
              this.searchData.forEach((item) => {
                const idx = this.tableDatas.findIndex(
                  (temp) => temp.Ip === item.Ip
                )
                if (idx > -1) {
                  this.tableDatas.splice(idx, 1)
                }
              })
              this.isSearchAdd = false
            }
            this.getCap()
          })
        }
      })
    },
    cancelAdd() {
      this.frontConfig = false
      this.SvrChnAlias = ''
      this.NvrChnId = 'auto'
    },
    search() {
      this.tableDatas = []
      // this.tableDatas = this.tableData
      this.createSearch().then((res) => {
        this.getCreateSearchList(res)
      })
    },
    searchAdd(val) {
      this.searchData = val
    },
    createSearch() {
      return new Promise((resolve, reject) => {
        let szXml = '<contentroot>'
        szXml += '<authenticationinfo type="7.0">'
        szXml += '<username>' + store.getters.username + '</username>'
        szXml += '<password>' + store.getters.password + '</password>'
        szXml +=
          '<authenticationid>' + store.getters.authId + '</authenticationid>'
        szXml += '</authenticationinfo>'
        szXml += '<CreateSearchPuTaskReq>'
        szXml += '<SearchProtoList num="1">'
        szXml += '<CltProto>' + this.searchProto + '</CltProto>'
        szXml += '</SearchProtoList>'
        szXml += '<FilterIp>'
        szXml += '<Enable>false</Enable>'
        szXml += '<BeginIp>0.0.0.0</BeginIp>'
        szXml += '<EndIp>0.0.0.0</EndIp>'
        szXml += '</FilterIp>'
        szXml += '</CreateSearchPuTaskReq>'
        szXml += '</contentroot>'
        createSearchPuTask(szXml)
          .then((res) => {
            this.isNowSearching = false
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    getCreateSearchList(resp) {
      const id = resp.CreateSearchPuTaskResp.TaskId
      this.searchId = id
      const param = {
        GetSearchedPuListReq: {
          MaxItemNum: 32
        }
      }
      getSearchedPuList(param, id).then((res) => {
        if (res.GetSearchedPuListResp.Finished === 'false') {
          if (res.GetSearchedPuListResp.PuList) {
            this.tableDatas = []
            const resData = res.GetSearchedPuListResp.PuList.PuInfo
            this.searchFilter.forEach((val) => {
              this.filterArray(resData, val)
            })
            if (Array.isArray(resData)) {
              this.tableDatas = resData
            } else {
              this.tableDatas.push(resData)
            }
            clearTimeout(this.searchTime)
          } else {
            this.searchTime = setTimeout(() => {
              this.getCreateSearchList(resp)
            }, 1000)
          }
        } else {
          clearTimeout(this.searchTime)
        }
      })
    },
    filterArray(backA, filterV) {
      const idx = backA.findIndex((item) => item.PuModel.indexOf(filterV) === 0)
      if (idx !== -1) {
        backA.splice(idx, 1)
        this.filterArray(backA, filterV)
      } else {
        return backA
      }
    },
    stopSearchList() {
      this.isNowSearching = true
      destroySearchPuTask({}, this.searchId).then((res) => {
        clearTimeout(this.searchTime)
      })
    },
    addFrontConfig(event, sear) {
      if (this.nvrChannelItem.length === 0 || this.nvrChannelItem.length === 1) {
        this.$message.error('没有空闲通道')
        return
      }
      this.isEdit = false
      this.isSear = false
      this.isEditAdd = false
      this.isSearchAdd = false
      if (sear) {
        this.isSearchAdd = true
        this.isEditAdd = true
        const searchL = this.searchData.length
        if (searchL !== 0) {
          this.isEdit = true
          this.isSear = true
        }
        let blankChnL = 0
        this.tableData.forEach((item) => {
          if (item.ChnState === '空闲') {
            blankChnL++
          }
        })
        if (blankChnL < searchL) {
          this.$message({
            type: 'warning',
            message: '空闲通道不足'
          })
          return
        }
        let port = 80
        let DevIp = '0.0.0.0'
        for (let i = 0; i < searchL; i++) {
          if (i === 0) {
            port = this.searchData[i].Port
            DevIp = this.searchData[i].Ip
          }
        }
        this.form = {
          Proto: 'ONVIF',
          TransProto: 'auto',
          DevPort: port,
          SrcId: '1',
          Username: 'admin',
          Password: 'admin123',
          ChnID: '自适应',
          DevIp: DevIp,
          auxStream: '',
          mainStream: '',
          AddMode: 'single_source', // 添加模式 单源或多源模式
          SrcNum: 1 // 远程通道
        }
      } else {
        this.form = {
          Proto: 'ONVIF',
          TransProto: 'auto',
          DevPort: 80,
          SrcId: '1',
          Username: 'admin',
          Password: 'admin123',
          ChnID: '自适应',
          DevIp: '',
          auxStream: '',
          mainStream: '',
          AddMode: 'single_source', // 添加模式 单源或多源模式
          SrcNum: 1 // 远程通道
        }
      }
      if (!sear && this.NvrChnId !== 'auto' && this.deleteData.length === 0) {
        const ind = Number(this.nvrChannelItem[1].ChnID)
        const rowData = this.tableData[ind - 1]
        this.SvrChnAlias = rowData.svrChnAlias
      }
      this.dialogTitle = '添加通道'
      this.frontConfig = true
    },
    closeDialog() {
      this.$refs.deviceForm.resetFields()
      this.SvrChnAlias = ''
      this.NvrChnId = 'auto'
    },
    async getCompositeCap() {
      await getCompositeChnCap({}).then((res) => {
        this.compositeSum = res.GetCompositeChnCapResp.ChnList.Chn.length
      })
    },
    getCap() {
      getSrvCap().then(async(res) => {
        await this.getCompositeCap()
        this.capSum = 6
        await this.getNvrListC(Number(res.capinfo.GroupNum))
        await this.getSvrChn()
        this.refreshDisabled = false
      }).catch(_ => {
        this.refreshDisabled = false
      })
    },
    async getSvrChn() {
      await getSvrChnList({}).then((res) => {
        this.SvrChnItem = res.GetSvrChnListResp.SvrChnItemList.SvrChnItem
        this.nvrChannelItem = []
        this.tableData = []
        this.nvrChannelItem.push({ chnChannel: '自适应', ChnID: 'auto' })
        this.SvrChnItem.forEach((val, index) => {
          if (Number(val.NvrChnId) <= this.capSum) {
            this.DevInfo = {
              svrList: {},
              svrChnAlias: '',
              ChnState: '',
              ChnID: '',
              DevCfg: '',
              IsEptzIpc: false
            }
            this.DevInfo.svrChnAlias = val.SvrChnAlias
            this.DevInfo.IsEptzIpc = val.IsEptzIpc !== 'false'
            var svrList = this.nvrList[index]
            this.DevInfo.ChnID = svrList.ChnID
            this.DevInfo.DevCfg = svrList.DevCfg
            if (svrList.DevInfo) {
              this.DevInfo.svrList = svrList.DevInfo
              this.DevInfo.ChnState =
                svrList.ChnState.Connect === 'online'
                  ? '在线'
                  : svrList.ChnState.Connect === 'off_autherr'
                    ? '认证失败'
                    : '下线'
            } else {
              this.nvrChannelItem.push({
                ChnID: svrList.ChnID,
                chnChannel: 'D' + svrList.ChnID
              })
              this.DevInfo.svrList = {}
              this.DevInfo.ChnState = '空闲'
            }
            this.tableData.push(this.DevInfo)
          }
        })
      })
    },
    async getNvrListC(subNum) {
      var param = {
        GetNvrChnListReq: {
          ChnIDStart: 1,
          ChnIDEnd: subNum,
          NeedMask: {
            ChnAlias: true,
            DevSrcID: true,
            ChnState: true,
            DevInfo: true,
            DevCfg: true
          }
        }
      }
      await getNvrChnList(param).then((res) => {
        this.nvrList = res.GetNvrChnListResp.ChnList.ChnInfo
      })
    },
    changeNvrId() {
      if (this.NvrChnId !== 'auto') {
        const index = this.tableData.findIndex(
          (item) => item.ChnID === this.NvrChnId
        )
        const rowData = this.deepClone(this.tableData[index])
        this.SvrChnAlias = rowData.svrChnAlias
      } else {
        this.SvrChnAlias = ''
      }
    },
    editInfoDealWith(info) {
      const xmlObj = new DOMParser().parseFromString(info, 'text/xml')
      let jsonObj = {}
      if (xmlObj.childNodes.length > 0) {
        jsonObj = xmlToJson(xmlObj)
      }
      let username
      let password
      let SrcId = 1
      const usePatt = /<Username>(.*)<\/Username>/
      const passPatt = /<Password>(.*)<\/Password>/
      const SrcIdPatt = /<SrcId>(.*)<\/SrcId>/
      if (SrcIdPatt.test(info)) {
        SrcId = RegExp.$1
      }
      if (usePatt.test(info)) {
        username = RegExp.$1
      }
      if (passPatt.test(info)) {
        password = window.atob(RegExp.$1)
      }
      let StreamUrl1 = ''
      let StreamUrl2 = ''
      if (jsonObj.DevCfg.RtmpCfg) {
        if (Array.isArray(jsonObj.DevCfg.RtmpCfg.StreamUrls.StreamUrl)) {
          StreamUrl1 = jsonObj.DevCfg.RtmpCfg.StreamUrls.StreamUrl[0]
          StreamUrl2 = jsonObj.DevCfg.RtmpCfg.StreamUrls.StreamUrl[1]
        } else {
          StreamUrl1 = jsonObj.DevCfg.RtmpCfg.StreamUrls.StreamUrl
          StreamUrl2 = ''
        }
      }
      if (jsonObj.DevCfg.RtspCfg) {
        if (Array.isArray(jsonObj.DevCfg.RtspCfg.StreamUrls.StreamUrl)) {
          StreamUrl1 = jsonObj.DevCfg.RtspCfg.StreamUrls.StreamUrl[0]
          StreamUrl2 = jsonObj.DevCfg.RtspCfg.StreamUrls.StreamUrl[1]
        } else {
          StreamUrl1 = jsonObj.DevCfg.RtspCfg.StreamUrls.StreamUrl
          StreamUrl2 = ''
        }
      }
      const TransProto = jsonObj.DevCfg.OnvifCfg
        ? jsonObj.DevCfg.OnvifCfg.TransProto
        : jsonObj.DevCfg.RtspCfg
          ? jsonObj.DevCfg.RtspCfg.TransProto
          : jsonObj.DevCfg.RtmpCfg
            ? jsonObj.DevCfg.RtmpCfg.TransProto
            : 'auto'
      return {
        Username: username,
        Password: password,
        StreamUrl1: StreamUrl1,
        StreamUrl2: StreamUrl2,
        TransProto: TransProto,
        SrcId: SrcId
      }
    },
    changeSourceModel() {
      if (this.form.AddMode === 'single_source') {
        // 切换为单源
        this.form.SrcNum = 1
        this.isSingleSource = true
      } else {
        // 切换为多源
        this.form.SrcNum = 2
        this.isSingleSource = false
      }
    }
  }
}
</script>

<style lang="scss">
.svr-device-config {
  color: $-fff-85;
  .front-device-list {
    padding-right: 20px;
  }
  .marginLeft16 {
    margin-left: 16px;
  }
  .el-form-item {
    margin-bottom: 16px;
  }
  .add-chn-device-dialog {
    .el-dialog {
      .el-dialog__body {
        padding: 16px 20px;
        .el-form {
          .el-form-item {
            margin-bottom: 0px;
          }
        }
      }
    }
  }
  .el-dialog {
    width: 500px;
    .border-select-default {
      width: 312px;
    }
    .config-stream-input {
      width: 312px;
    }
  }
}
.front-device-oper {
  display: flex;
  /* width: 980px; */
  justify-content: space-between;
  align-items: center;
  padding: 16px 0px;
  .fontSize20 {
    font-size: 20px;
  }
}
.el-table {
  background: transparent;
}
.el-table th,
.el-table tr {
  color: rgba(255, 255, 255, 0.65);
  background: #1d222c;
}
.el-table th {
  background: rgba(255, 255, 255, 0.08);
}
.el-table th.is-leaf {
  border-bottom: none;
}
.el-table td {
  border-bottom: 1px solid rgba(216, 222, 234, 0.12);
}
.el-table--border::after,
.el-table--group::after,
.el-table::before {
  background: rgba(216, 222, 234, 0.02);
}
.el-table--enable-row-hover .el-table__body tr:hover > td {
  background: #1d222c;
}
.el-table td,
.el-table th {
  padding: 15px 0;
}
.table-edit {
  color: #177ddc;
  cursor: pointer;
}
.ip-link {
  cursor: pointer;
}
</style>
