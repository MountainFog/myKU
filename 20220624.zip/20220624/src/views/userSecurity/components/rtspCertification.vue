<template>
  <div class="rtsp-certification-config">
    <div class="config-stream-media flex-center">
      <label for="" class="config-title">rtsp认证:</label>
      <div>
        <el-select v-model="rtsp" @change="rtspChange" class="border-select-default input-width-default" placeholder="请选择">
          <el-option
            v-for="item in rtspList"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </div>
    </div>
    <div class="config-stream-media flex-center paddingTop16">
      <label for="" class="config-title"></label>
      <div>
        <input type="button" @click="save" class="primary default-border-radius" value="保存"/>
      </div>
    </div>
  </div>
</template>

<script>
import {getRtspAuthMethod,setRtspAuthMethod} from '@/api/systemConfig'
export default {
  data(){
    return {
      rtspList:[
        {
          label:'none',
          value:'none'
        },
        {
          label:'basic/digest',
          value:'basic/digest'
        },
        {
          label:'digest',
          value:'digest'
        }
      ],
      rtsp:'basic/digest'
    }
  },
  created(){
    console.log(2)
    this.getRtspMethod()
  },
  methods:{
    getRtspMethod(){
      getRtspAuthMethod({}).then(res => {
        console.log(res)
        this.rtsp = res.GetRtspAuthMethodResp.AuthMethod
      })
    },
    rtspChange(val){
      this.rtsp = val
    },
    save(){
      var param = {
        SetRtspAuthMethodReq:{
          AuthMethod: this.rtsp
        }
      }
      setRtspAuthMethod(param).then(res => {
        console.log(res)
      })
    }
  }
}
</script>

<style lang="scss">
.rtsp-certification-config {
  padding-top: 16px;
  .config-title {
    width: 100px;
    font-size: 14px;
    color: rgba(255,255,255,0.85);
    font-weight: normal;
  }
  .paddingTop16 {
    padding-top: 16px;
  }
}
</style>
