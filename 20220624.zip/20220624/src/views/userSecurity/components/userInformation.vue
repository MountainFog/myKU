<template>
  <div class="user-information-config">
    <div class="btn-groups-container">
      <!-- <input type="button" class="primary default-border-radius" value="添加"/>
      <input type="button" class="default default-border-radius font-title-color marginLeft16" value="删除"/>
      <input type="button" class="default default-border-radius font-title-color marginLeft16" value="启用"/>
      <input type="button" class="default default-border-radius font-title-color marginLeft16" value="停用"/> -->
    </div>
    <div class="table-list">
      <el-table
        @selection-change="selectUserInfo"
        :data="userInfoList"
        style="width: 100%">
        <el-table-column
          type="selection"
          width="80">
        </el-table-column>
        <el-table-column
          prop="Name"
          label="用户名"
          width="250">
        </el-table-column>
        <el-table-column
          prop="LoginTimes"
          label="用户在线数"
          width="250">
        </el-table-column>
        <!-- <el-table-column
          prop="svrList.Ip"
          label="用户状态" width="250">
        </el-table-column> -->
        <el-table-column
          prop="operation"
          label="操作">
          <template scope="scope">
            <div class="table-edit" @click="editUse(scope.row)">编辑</div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog title="修改密码" :close-on-click-modal="false" class="font-title-color edit-use-info" :visible.sync="editUseFlag">
      <el-form :model="edituseForm" :rules='rules' ref="editFormRef">
        <el-form-item label="用户名:" :label-width="formLabelWidth">
          <el-input v-model="edituseForm.Name" type="text" class="input-width-default border-input-default default-border-radius" :disabled="true" />
        </el-form-item>
        <el-form-item label="原密码:" :label-width="formLabelWidth">
          <el-input v-model="edituseForm.OldPassword" type="password" class="input-width-default border-input-default default-border-radius" />
        </el-form-item>
        <el-form-item label="新密码:" prop="NewPassword" :label-width="formLabelWidth">
          <el-input v-model="edituseForm.NewPassword" type="password" class="input-width-default border-input-default default-border-radius" />
        </el-form-item>
        <el-form-item label="" :label-width="formLabelWidth" class="pass-form-item">
          <div class="pass-strong-cont">
            <span :class="{ low: passStrong=== 'low' }">低</span>
            <span :class="{ middle: passStrong=== 'middle' }">中</span>
            <span :class="{ high: passStrong=== 'high' }">高</span>
          </div>
        </el-form-item>
        <el-form-item label="" :label-width="formLabelWidth">
          <div class="pass-title">8-16位，数字，大、小写字母或特殊符号的两种或以上组合</div>
        </el-form-item>
        <el-form-item label="确认密码:" :label-width="formLabelWidth">
          <el-input v-model="edituseForm.ensurePassword" type="password" class="input-width-default border-input-default default-border-radius" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <input type="button" class="primary default-border-radius" value="确认" @click="saveEditPass">
        <input type="button" class="default default-border-radius font-title-color marginLeft16" value="取消" @click="editUseFlag = false">
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getTotalUserInfo,getUserInfo,setUserPwd } from '@/api/systemConfig.js'
import store from '@/store'
import { isBlank } from '@/utils/validateModule.js'
export default {
  data(){
    const validatePass = (rule,value,callback) => {
      if(value === '') {
        this.passStrong = 'normal'
        //callback(new Error('请输入密码'))
      }else {
        let strLen = 0
        if(this.edituseForm.NewPassword !== '') {
          if(this.edituseForm.NewPassword.match(/([a-z])+/)) {
            strLen++
          }
          if(this.edituseForm.NewPassword.match(/([0-9])+/)) {
            strLen++
          }
          if(this.edituseForm.NewPassword.match(/([A-Z])+/)) {
            strLen++
          }
          if(this.edituseForm.NewPassword.match(/([\W])+/) && !this.edituseForm.NewPassword.match(/(![\u4E00-\u9FA5])+/) ) {
            strLen++
          }
          if(this.edituseForm.NewPassword.length === 0 ||  16 < this.edituseForm.NewPassword.length) {
            callback(new Error("要求8-16位字符"))
            strLen = 0
          }
          if(this.edituseForm.NewPassword.match(/(![\u4E00-\u9FA5])+/)) {
            callback(new Error('不能包含中文字符'))
            strLen = 0
          }
          switch(strLen) {
            case 0:
              this.passStrong = 'normal'
              break
            case 1:
              this.passStrong = 'low'
              break
            case 2:
              this.passStrong = 'low'
              break
            case 3:
              this.passStrong = 'middle'
              break
            case 4:
              this.passStrong = 'high'
              break
            default:
              this.passStrong = 'normal'
              break
          }
        }
        callback()
      }
    };
    return {
      userInfoList:[],
      deleteUserInfoList:[],
      editUseFlag: false,//编辑密码控制
      edituseForm: {},
      passStrong: 'normal',
      formLabelWidth: '100px',
      rules:{
        NewPassword: [
          {
            required: false,validator: validatePass,trigger:['change','blur']
          }
          /* {
            pattern: /^(?![a-zA-Z]+$)(?![A-z0-9]+$)(?![A-Z\W_]+$)(?![a-z0-9]+$)(?![a-z\W_]+$)(?![0-9\W_]+$)[a-zA-Z0-9\W_]{8,16}$/,message:'8-16位，数字，大、小写字母或特殊符号的两种或以上组合'
          } */
        ],
        OldPassword: [{ required: false, trigger: 'blur', validator: isBlank}],
        ensurePassword: [{ required: false, trigger: 'blur', validator: isBlank}]
      }
    }
  },
  created(){
    this.getUseInfoList().then(res => {
      let useInfo = res.GetTotalUserInfoResp.UserInfoList.UserInfo
      console.log("useInfo:::",useInfo)
      if(useInfo) {
        this.userInfoList = []
        if(Array.isArray(useInfo)) {
          this.userInfoList = useInfo
        }else {
          this.userInfoList.push(useInfo)
        }
      }
    })
  },
  methods:{
    selectUserInfo(val){
      this.deleteUserInfoList = val
    },
    getUseInfoList() {//获取用户信息列表
      return new Promise((resolve,reject) => {
        getTotalUserInfo({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    getSingleUseInfo(useName) {
      return new Promise( (resolve,reject) => {
        let param = {
          GetUserInfoReq: {
            UserName: useName,
            Mask: {
              BaseInfo: true,
              RemoteCtrl: false,
              SysPerm: false,
              ChnPermList: false,
            }
          }
        }
        getUserInfo(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      } )
    },
    editUse(row) {
      this.edituseForm = {}
      this.edituseForm.Name = row.Name
      this.getSingleUseInfo(this.edituseForm.Name).then(res => {
        this.passStrong = 'normal'
        this.editUseFlag = true
      })
    },
    saveEditPass(){
      this.$refs.editFormRef.validate(valid => {
        if(valid) {
          let oldPass = this.$store.getters.pwd
          if(oldPass !== this.edituseForm.OldPassword) {
            this.$message({
              type:'error',
              message: '原密码输入错误'
            })
            return
          }
          if(this.edituseForm.NewPassword !== this.edituseForm.ensurePassword) {
            this.$message({
              type:'error',
              message: '新密码和确认密码输入不一致,请重新输入'
            })
            return
          }
          this.setUsePassInfo().then(res => {//修改成功
            const loginForm = {
              username: this.edituseForm.Name,
              password: this.edituseForm.NewPassword
            }
            //修改密码之后要重新登录，否则会保活失败，进入到登录路由中
            this.$store.dispatch('user/login', loginForm).then(res => {
              this.editUseFlag = false
              this.$message({
                type: 'success',
                message: '修改密码成功'
              })
            })
          })
        }
      })
    },
    setUsePassInfo() {
      return new Promise((resolve,reject) => {
        let param = {
          SetUserPwdReq: {
            UserName: this.edituseForm.Name,
            OldPassword: window.btoa(this.$store.getters.pwd),
            NewPassword: window.btoa(this.edituseForm.NewPassword)
          }
        }
        setUserPwd(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    setInitialize() {//初始化数据
      this.edituseForm = {
        Name: '',//用户名
        OldPassword: '',//旧密码
        NewPassword: '',//新密码
        ensurePassword: ''//确认密码
      }
    }
  }
}
</script>

<style lang="scss">
.user-information-config {
  .btn-groups-container {
    padding: 16px 0px;
  }
  .table-list {
    .table-edit {
      cursor: pointer;
    }
  }
  .edit-use-info {
    .el-dialog {
      width: 454px;
      .pass-title {
        line-height: 16px;
      }
      .pass-form-item {
        .pass-strong-cont {
          display: flex;
          padding: 8px 0px;
          > span {
            flex: 1;
            text-align: center;
            background: rgba(13, 16, 22, 0.48);
            height: 20px;
            line-height: 20px;
            font-size: 14px;
            color: #fff;
            &.low {
              background: green;
              color: #fff;
            }
            &.middle {
              background: blue;
              color: #fff;
            }
            &.high {
              background: red;
              color: #fff;
            }
          }
        }
      }

    }
  }
}
</style>
