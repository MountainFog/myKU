<template>
  <div class="system-security-service-config">
    <div class="security-content local-content">
      <el-form :rules="rules" :model="GetSecurityCfgReq" ref="securitForm">
        <div class="font-title-color local-title">登录安全</div>
        <div class="play-config">
          <el-form-item>
            <div class="config-stream-media">
              <label for="" class="local-config-title">非法登录锁定:</label>
              <div>
                <el-radio v-model="GetSecurityCfgReq.IllegalLogInLock" label="true">开启</el-radio>
                <el-radio v-model="GetSecurityCfgReq.IllegalLogInLock" label="false">关闭</el-radio>
              </div>
            </div>
          </el-form-item>
          <el-form-item prop="LoginTimeMax">
            <div class="config-stream-media">
              <label for="" class="local-config-title">登录次数:</label>
              <div>
                <el-input type="text" v-model.number="GetSecurityCfgReq.LoginTimeMax" class="config-stream-input border-input-default default-border-radius" />
                <span class="paddingLeft16 font-title-table">3-10</span>
              </div>
            </div>
          </el-form-item>
          <el-form-item prop="LockTime">
            <div class="config-stream-media">
              <label for="" class="local-config-title">锁定时长:</label>
              <div>
                <el-input type="text" v-model.number="GetSecurityCfgReq.LockTime" class="config-stream-input border-input-default default-border-radius" />
                <span class="paddingLeft16 font-title-table">10-60(分钟)</span>
              </div>
            </div>
          </el-form-item>
         </div>
         <div class="font-title-color local-title">通用安全</div>
         <div class="save-config play-config">
           <el-form-item>
             <div class="config-stream-media">
               <label for="" class="local-config-title">SSH远程连接:</label>
               <div>
                 <el-radio v-model="GetSecurityCfgReq.SshEnable" label="true">开启</el-radio>
                 <el-radio v-model="GetSecurityCfgReq.SshEnable" label="false">关闭</el-radio>
               </div>
             </div>
           </el-form-item>
           <el-form-item>
             <div class="config-stream-media">
               <label for="" class="local-config-title">管理邮箱:</label>
               <div>
                 <el-input type="text" v-model="GetSecurityCfgReq.AdminEmail" class="config-stream-input border-input-default default-border-radius" />
               </div>
             </div>
           </el-form-item>
           <div class="config-stream-media">
               <label for="" class="local-config-title"></label>
               <div>
                 <input type="button" @click="save" class="primary default-border-radius" value="保存"/>
               </div>
             </div>
           </div>
      </el-form>
    </div>
  </div>
</template>

<script>
import {getSecurityCfg,setSecurityCfg} from '@/api/systemConfig'
export default {
  data(){
    return {
      rules: {
        LockTime: [{ max: 60, min: 10, type: 'number', message: '不在范围之内', trigger: 'blur' }],
        LoginTimeMax: [{ max: 10, min: 3, type: 'number', message: '不在范围之内', trigger: 'blur' }]
      },
      GetSecurityCfgReq: {}
    }
  },
  methods:{
    getSecurity(){
      getSecurityCfg({}).then(res => {
        this.GetSecurityCfgReq = res.GetSecurityCfgReq
        this.GetSecurityCfgReq.LoginTimeMax = Number(this.GetSecurityCfgReq.LoginTimeMax)
        this.GetSecurityCfgReq.LockTime = Number(this.GetSecurityCfgReq.LockTime)
      })
    },
    save(){
      this.$refs.securitForm.validate( (valid) => {
        if(valid) {
          let param = {
            SetSecurityCfgReq: {
              SshEnable: this.GetSecurityCfgReq.SshEnable,
              AdminEmail: this.GetSecurityCfgReq.AdminEmail,
              IllegalLogInLock: this.GetSecurityCfgReq.IllegalLogInLock,
              LoginTimeMax: this.GetSecurityCfgReq.LoginTimeMax,
              LockTime: this.GetSecurityCfgReq.LockTime
            }
          }
          setSecurityCfg(param).then(res => {
            this.$message({
              message: '保存成功',
              type: 'success'
            })
          })
        }
      } )

    }
  },
  created(){
    this.getSecurity()
  }
}
</script>
<style lang="scss">
.system-security-service-config {
  .security-content {
    .el-form-item {
      >div {
        line-height: 32px;
      }
    }
  }
}
</style>
<style lang="scss" scoped>
.system-security-service-config {
  .local-content {
    .local-title {
      padding: 16px 0px;
      font-size: 14px;
      line-height: 28px;
    }
    .play-config {
      .config-stream-media {
        display: flex;
        padding: 8px 0px;
        align-items: center;
        .local-config-title {
          width: 150px;
          font-size: 14px;
          padding-left: 24px;
          font-weight: normal;
        }
        .config-stream-input {
          width: 312px;
        }
        .paddingLeft16 {
          padding-left: 16px;
          font-size: 14px;
        }
      }
    }
  }
}
</style>
