<template>
  <div class="address-filter-config">
    <div class="address-filter-container local-content">
      <div class="play-config">
        <div class="config-stream-media">
          <label for="" class="local-config-title">地址过滤:</label>
          <div>
            <el-radio v-model="addressFilter" label="true">开启</el-radio>
            <el-radio v-model="addressFilter" label="false">关闭</el-radio>
          </div>
        </div>
        <div class="config-stream-media">
          <label for="" class="local-config-title">过滤方式:</label>
          <div>
            <el-select v-model="filterType" @change="filterTypeChange" class="border-select-default input-width-default" placeholder="请选择">
              <el-option
                v-for="item in filterTypeList"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </div>
        </div>
      </div>
      <div class="btn-groups-filter">
        <input type="button" class="default default-border-radius font-title-color" value="刷新"/>
        <input type="button" @click="addFilter" class="primary default-border-radius marginLeft16" value="添加"/>
        <input type="button" @click="deleteFilter" class="default default-border-radius font-title-color marginLeft16" value="删除"/>
      </div>
      <div class="table-list">
        <el-table
          @selection-change="addresFilterInfo"
          :data="addressFilterData"
          :row-key="getKey"
          style="width: 100%">
          <el-table-column
            type="selection"
            width="80">
          </el-table-column>
          <el-table-column
            label="起始IP地址"
            width="250">
            <template scope="scope">
              <div>{{ scope.row.StartAddr != '' && scope.row.StartAddr ? scope.row.StartAddr : scope.row.IpAddr }}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="结束IP地址"
            width="250">
            <template scope="scope">
              <div>{{ scope.row.EndAddr != '' && scope.row.EndAddr ? scope.row.EndAddr : scope.row.IpAddr }}</div>
            </template>
          </el-table-column>
          <el-table-column
            label="MAC地址" width="250">
            <template scope="scope">
              <div>{{ scope.row.Mac != '' ? scope.row.Mac : '---' }}</div>
            </template>
          </el-table-column>
          <el-table-column
            prop="operation"
            label="操作">
            <template scope="scope">
              <div class="table-edit" @click="edit(scope.row)">编辑</div>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="address-save-container">
        <input type="button" @click="save" class="primary default-border-radius marginLeft16" value="保存"/>
      </div>
    </div>
    <el-dialog :close-on-click-modal="false" title="地址过滤" class="font-title-color" :visible.sync="addressFilterFlag">
      <el-form :model="form">
        <el-form-item label="IP过滤:" :label-width="formLabelWidth">
          <el-checkbox v-model="form.IpEnable"></el-checkbox>
        </el-form-item>
        <el-form-item label="IP过滤模式:" :label-width="formLabelWidth">
          <el-select v-model="form.FilterMode" class="border-select-default input-width-default" placeholder="请选择过滤方式">
            <el-option label="单地址" value="ip_single"></el-option>
            <el-option label="地址范围" value="ip_list"></el-option>
          </el-select>
        </el-form-item>
        <div v-show="form.FilterMode == 'ip_single'">
          <el-form-item label="IP地址:" :label-width="formLabelWidth">
            <el-input type="text" v-model="form.IpAddr" class="config-stream-input border-input-default default-border-radius input-width-default" />
          </el-form-item>
        </div>
        <div v-show="form.FilterMode == 'ip_list'">
          <el-form-item label="起始IP地址:" :label-width="formLabelWidth">
            <el-input type="text" v-model="form.StartAddr" class="config-stream-input border-input-default default-border-radius input-width-default" />
          </el-form-item>
          <el-form-item label="结束IP地址:" :label-width="formLabelWidth">
            <el-input type="text" v-model="form.EndAddr" class="config-stream-input border-input-default default-border-radius input-width-default" />
          </el-form-item>
          <el-form-item label="子网掩码:" :label-width="formLabelWidth">
            <el-input type="text" v-model="form.Mask" class="config-stream-input border-input-default default-border-radius input-width-default" />
          </el-form-item>
        </div>
        <el-form-item label="MAC过滤:" :label-width="formLabelWidth">
          <el-checkbox v-model="form.MacEnable"></el-checkbox>
        </el-form-item>
        <el-form-item label="MAC地址:" :label-width="formLabelWidth">
          <el-input type="text" v-model="form.Mac" class="config-stream-input border-input-default default-border-radius input-width-default" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <input type="button" @click="addAddressFilter" class="primary default-border-radius" value="保存"/>
        <input type="button" @click="addressFilterFlag = false" class="default default-border-radius font-title-color marginLeft16" value="取消"/>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getIpFilterCfg,setIpFilterCfg } from '@/api/systemConfig'
// import '@/styles/table.scss'
export default {
  data(){
    return {
      addressFilter: 'true',
      filterTypeList: [
        {
          label: '黑名单',
          value: 'black'
        },
        {
          label: '白名单',
          value: 'white'
        }
      ],
      filterType: 'white',
      addressFilterData: [],
      BlackList: [],
      WhiteList: [],
      deleteList: [],
      MacSupCap: 'true',
      addressFilterFlag: false,
      editIndex: -1,
      formLabelWidth: '100px',
      form: {
        IpEnable: false,
        FilterMode: 'ip_single',
        IpAddr: '',
        StartAddr: '',
        EndAddr: '',
        Mask: '',
        MacEnable: false,
        Mac: ''
      }
    }
  },
  methods:{
    getKey(row){
      return JSON.stringify(row)
    },
    isObjectValueEqual(a, b) {
      if (a === b) return true
      let aProps = Object.getOwnPropertyNames(a)
      let bProps = Object.getOwnPropertyNames(b)
      if (aProps.length !== bProps.length) return false
      for (let prop in a) {
       if (b.hasOwnProperty(prop)) {
        if (typeof a[prop] === 'object') {
         if (!((this.isObjectValueEqual)(a[prop], b[prop]))) return false
        } else if (a[prop] !== b[prop]) {
         return false
        }
       } else {
        return false
       }
      }
      return true
    },
    deepClone(obj) {
      let objClone =  Array.isArray(obj) ? [] : {};
      if (obj && typeof obj === 'object') {
        for(let key in obj){
          if (obj[key] && typeof obj[key] === 'object'){
            objClone[key] = this.deepClone(obj[key]);
          }else{
            objClone[key] = obj[key]
          }
        }
      }
      return objClone;
    },
    filterTypeChange(){
      if(this.filterType == 'white') {
        this.addressFilterData = this.WhiteList
      }else {
        this.addressFilterData = this.BlackList
      }
    },
    addresFilterInfo(val){
      this.deleteList = val
      console.log(this.deleteList)
    },
    addAddressFilter(){
      if(this.filterType == 'white') {
        var obj = this.deepClone(this.form)
        if(this.editIndex != -1){
          this.WhiteList.splice(this.editIndex,1,obj)
        }else {
          this.WhiteList.push(obj)
        }
        this.addressFilterData = this.WhiteList
      }else {
        var obj = this.deepClone(this.form)
        if(this.editIndex != -1) {
          this.BlackList.splice(this.editIndex,1,obj)
        }else {
          this.BlackList.push(obj)
        }
        this.addressFilterData = this.BlackList
      }
      this.addressFilterFlag = false
    },
    addFilter(){
      this.form = {
        IpEnable: false,
        FilterMode: 'ip_single',
        IpAddr: '',
        StartAddr: '',
        EndAddr: '',
        Mask: '',
        MacEnable: false,
        Mac: ''
      }
      this.addressFilterFlag = true
    },
    deleteFilter(){
      if(this.deleteList.length == 0) return
      this.deleteList.forEach(val => {
       this.addressFilterData.forEach((item,i) => {
          if(this.isObjectValueEqual(val,item)) {
            this.addressFilterData = this.addressFilterData.splice(i,1)
            return false
          }
        })
        if(this.filterType == 'white') {
          this.WhiteList.forEach((item,idx) => {
            if(this.isObjectValueEqual(val,item)) {
              this.WhiteList = this.WhiteList.splice(idx,1)
              return false
            }
          })
        }else {
          this.BlackList.forEach((item,index) => {
            if(this.isObjectValueEqual(val,item)) {
              this.BlackList = this.BlackList.splice(index,1)
              return false
            }
          })
        }
      })
      this.deleteList = []
      if(this.filterType == 'white'){
        this.addressFilterData = this.WhiteList
      }else {
        this.addressFilterData = this.BlackList
      }
    },
    getIpFilter(){
      getIpFilterCfg({}).then(res => {
        this.addressFilter = res.GetIpFilterCfgReq.Enable
        this.filterType = res.GetIpFilterCfgReq.IpFilterType
        if(res.GetIpFilterCfgReq.BlackList != '') {
          var black = res.GetIpFilterCfgReq.BlackList.Black
          if(Array.isArray(black)) {
            this.BlackList = black
          }else {
            this.BlackList.push(black)
          }
        }
        if(res.GetIpFilterCfgReq.WhiteList != '') {
          var white =res.GetIpFilterCfgReq.WhiteList.White
           if(Array.isArray(white)) {
             this.WhiteList = white
           }else {
             this.WhiteList.push(white)
           }
        }
        if(res.GetIpFilterCfgReq.IpFilterType == 'white') {
          this.addressFilterData = this.WhiteList
        }else {
          this.addressFilterData = this.BlackList
        }
      })
    },
    setIpFilter(){
      var blackArray = []
      var whiteArray = []
      var param = {
        SetIpFilterCfgReq: {
          Enable: this.addressFilter,
          IpFilterType: this.filterType,
          BlackList: {
            P_R_O_P: {
              num: this.BlackList.length
            },
            K_E_Y: 'Black',
            V_A_L_U_E: this.BlackList
          },
          WhiteList:{
            P_R_O_P: {
              num: this.WhiteList.length
            },
            K_E_Y: 'White',
            V_A_L_U_E: this.WhiteList
          }
        }
      }
      setIpFilterCfg(param).then(res => {
        this.$message({
          type: 'success',
          message: '保存成功'
        })
      }).catch(err => {
        alert("保存失败")
      })
    },
    edit(val){
      var obj = {
        IpEnable: val.IpEnable == 'false' ? false : true,
        FilterMode: val.FilterMode,
        IpAddr: val.IpAddr ? val.IpAddr : '',
        StartAddr: val.StartAddr ? val.StartAddr : '',
        EndAddr: val.EndAddr ? val.EndAddr : '',
        Mask: val.Mask ? val.Mask : '',
        MacEnable: val.MacEnable == 'false' ? false : true,
        Mac: val.Mac ? val.Mac : ''
      }
      if(this.filterType == 'white'){
        this.WhiteList.forEach((item,index) => {
          if(this.isObjectValueEqual(val,item)) {
            this.editIndex = index
            return false
          }
        })
      }else {
        this.BlackList.forEach((item,index) => {
          if(this.isObjectValueEqual(val,item)) {
            this.editIndex = index
            return false
          }
        })
      }
      this.form = obj
      this.addressFilterFlag = true
    },
    save(){
      this.setIpFilter()
    }
  },
  created(){
    this.getIpFilter()
  }
}
</script>

<style lang="scss">
.address-filter-config {
  .address-filter-container {
    padding-top: 16px;
  }
  .local-content {
    .local-title {
      padding: 16px 0px;
      font-size: 20px;
      line-height: 28px;
    }
    .play-config {
      .config-stream-media {
        display: flex;
        padding: 8px 0px;
        align-items: center;
        .local-config-title {
          width: 150px;
          font-size: 14px;
          padding-left: 24px;
          font-weight: normal;
        }
        .paddingLeft16 {
          padding-left: 16px;
          font-size: 14px;
        }
      }
    }
  }
  .btn-groups-filter {
    padding-top: 16px;
    padding-bottom: 16px;
  }
  .el-dialog {
    width: 500px;
  }
  .address-save-container {
    width: 980px;
    padding-top: 16px;
  }
}
</style>
