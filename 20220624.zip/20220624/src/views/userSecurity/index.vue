<template>
  <div class="user-security-config second-tabs-item">
    <tabItem :tabList="tabList" @active="tabComponent"></tabItem>
    <div class="dynamic-component">
        <component v-bind:is="currentTabComponent"></component>
    </div>
  </div>
</template>

<script>
import userInformation from './components/userInformation'
import rtspCertification from './components/rtspCertification'
import securityServices from './components/securityServices'
import addressFilter from './components/addressFilter'
import tabItem from '../tabs/tabItem'
export default {
  data(){
    return {
      tabList:[
        {name:'用户信息',component:'userInformation'},
        {name:'RTSP认证',component:'rtspCertification'},
        {name:'安全服务',component:'securityServices'},
        {name:'地址过滤',component:'addressFilter'},
      ],
      currentTabComponent:'userInformation'
    }
  },
  methods:{
    tabComponent(item){
      this.currentTabComponent = item.component
    }
  },
  components:{
    userInformation,
    rtspCertification,
    securityServices,
    addressFilter,
    tabItem
  }
}
</script>

<style lang="scss" scoped="scoped">
.dynamic-component {
}
</style>
