<template>
  <div class="channle-port-map">
    <div class="kd-main-title">网络配置 / 通道端口映射</div>
    <div style="padding: 16px 0;">
      <el-button type="primary" @click="add">添加</el-button>
      <el-button @click="del">删除</el-button>
    </div>
    <el-table
      :data="tableData"
      @selection-change="handleSelectionChange"
    >
      <el-table-column
        type="selection"
        width="55"
      />
      <el-table-column
        prop="ChnID"
        label="通道名称"
        align="center"
      >
        <template slot-scope="scope">
          <span>{{ findName(scope.row.ChnID) }}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="DestPort"
        label="映射端口号"
        align="center"
      />
      <el-table-column
        label="操作"
        width="80"
      >
        <template slot-scope="scope">
          <el-button type="text" @click="edit(scope.row)">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog
      :visible.sync="visible"
      title="添加映射配置"
      width="300px"
      @close="cancle"
    >
      <el-form
        ref="form"
        :model="formData"
        label-width="80px"
        label-position="left"
      >
        <el-form-item label="通道">
          <el-select v-model="formData.ChnID" :disabled="isEdit">
            <el-option
              v-for="(item, index) in svrList"
              v-show="index < 6"
              :key="item.NvrChnId"
              :value="item.NvrChnId"
              :label="`D${item.NvrChnId} ${item.SvrChnAlias}`"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          label="映射端口"
          prop="DestPort"
          :rules="[{validator:isPort, max: 65535, min: 1, type: 'number', message: '端口号不正确', trigger: 'blur' }]"
        >
          <el-input v-model="formData.DestPort" />
        </el-form-item>
        <el-form-item label=" ">
          <el-button
            type="primary"
            @click="submit"
          >保存</el-button>
          <el-button @click="cancle">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import { getPortsMap, setPortsMap } from '@/api/networkConfig'
import { getChannel } from '../applicationScenarios/getChannel'
import { isPort } from '@/utils/validateModule'
export default {
  name: 'ChannelPortMap',
  mixins: [getChannel],
  data() {
    return {
      isPort,
      tableData: [],
      visible: false,
      isEdit: false,
      formData: {
        ChnID: '',
        DestPort: ''
      },
      channel: '1',
      selected: []
    }
  },
  mounted() {
    this.getPortsMap()
  },
  methods: {
    add() {
      this.visible = true
      this.isEdit = false
    },
    edit(data) {
      this.visible = true
      this.isEdit = true
      this.formData.ChnID = data.ChnID
      this.formData.DestPort = data.DestPort
    },
    del() {
      this.$confirm('此操作将永久删除该数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.selected.forEach(row => {
          const index = this.tableData.findIndex(item => item.ChnID === row.ChnID)
          if (index > -1) {
            this.tableData.splice(index, 1)
          }
        })
        setPortsMap({
          SetPortsMapReq: {
            PortsMapList: {
              K_E_Y: 'PortsMapItem',
              V_A_L_U_E: this.tableData
            }
          }
        }).then(() => {
          this.getPortsMap()
          this.$message({
            message: '删除成功',
            type: 'success'
          })
        })
      })
    },
    handleSelectionChange(selected) {
      this.selected = selected
    },
    getPortsMap() {
      this.tableData = []
      getPortsMap().then(res => {
        const data = res.GetPortsMapResp.PortsMapList.PortsMapItem
        if (data) {
          if (!Array.isArray(data)) {
            this.tableData.push(data)
            return
          }
          this.tableData = data
        }
      })
    },
    findName(id) {
      const channel = this.svrList.find(item => item.NvrChnId === id)
      if (!channel) return ''
      return `D${id} ${channel.SvrChnAlias}`
    },
    cancle() {
      this.visible = false
      this.formData.ChnID = ''
      this.formData.DestPort = ''
      this.$refs.form.clearValidate()
    },
    submit() {
      const formData = {
        ChnID: this.formData.ChnID,
        DestPort: this.formData.DestPort,
        SrcPort: this.formData.DestPort
      }
      const index = this.tableData.findIndex(item => item.ChnID === this.formData.ChnID)
      if (this.isEdit) {
        this.tableData.splice(index, 1, formData)
      } else {
        if (index > -1) {
          this.$message({
            type: 'error',
            message: '当前通道已存在，请勿重复添加'
          })
          return
        }
        this.tableData.push(formData)
      }
      this.visible = false
      setPortsMap({
        SetPortsMapReq: {
          PortsMapList: {
            K_E_Y: 'PortsMapItem',
            V_A_L_U_E: this.tableData
          }
        }
      }).then(() => {
        this.getPortsMap()
        this.$message({
          message: '提交成功',
          type: 'success'
        })
      })
    }
  }
}
</script>
