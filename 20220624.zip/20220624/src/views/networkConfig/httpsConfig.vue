<template>
  <div class="https-config">
    <div class="kd-main-title">网络配置 / HTTPS</div>
    <div>
      <el-form>
        <el-form-item>
          <div class="config-stream-media">
            <label for="" class="config-title">启用HTTPS:</label>
            <div>
              <el-radio v-model="httpsInfoConfig.Enable" :disabled="isDetail" label="true">开启</el-radio>
              <el-radio v-model="httpsInfoConfig.Enable" :disabled="isDetail" label="false">关闭</el-radio>
            </div>
          </div>
        </el-form-item>
        <div v-show="installSuccess" key="installCon">
          <el-form-item>
            <div class="config-stream-media">
              <label for="" class="config-title">证书安装方式:</label>
              <el-select v-model="certificate" class="border-select-default input-width-default" placeholder="请选择">
                <el-option
                  v-for="item in certificateList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </div>
          </el-form-item>
          <el-form-item>
            <div class="config-stream-media">
              <label for="" class="config-title">证书文件:</label>
              <div class="flex-center">
                <el-input v-model="certificateInfo" type="text" class="input-width-default border-input-default default-border-radius" />
                <label for="up_certificate" class="default default-border-radius default-width up-grade-button marginLeft16">浏览</label>
                <input id="up_certificate" type="file" style="display: none;" @change="changeCertificate">
              </div>
            </div>
          </el-form-item>
          <el-form-item>
            <div class="config-stream-media">
              <label for="" class="config-title">私钥文件:</label>
              <div class="flex-center">
                <el-input v-model="privateInfo" type="text" class="input-width-default border-input-default default-border-radius" />
                <label for="up_private" class="default default-border-radius default-width up-grade-button marginLeft16">浏览</label>
                <input id="up_private" type="file" style="display: none;" @change="privateKey">
              </div>
            </div>
          </el-form-item>
        </div>
        <div v-show="!installSuccess" key="keyDetail">
          <el-form-item>
            <div v-if="Object.keys(httpsCrtDetails).length != 0" class="certical-detail">
              <label for="" class="config-title">证书详情:</label>
              <div class="issued detail">
                <span>颁发者:</span><span class="paddingLeft8">C=</span><span>{{ httpsCrtDetails.IssuerInfo.CountryName }},</span>
                <span>ST=</span><span>{{ httpsCrtDetails.IssuerInfo.ProvinceName }},</span><span>L=</span><span>{{ httpsCrtDetails.IssuerInfo.LocalityName }},</span>
                <span>O=</span><span>{{ httpsCrtDetails.IssuerInfo.OrgName }},</span><span>OU=</span><span>{{ httpsCrtDetails.IssuerInfo.UnitName }},</span>
                <span>H/IP=</span><span>{{ httpsCrtDetails.IssuerInfo.CommonName }},</span><span>EM=</span><span>{{ httpsCrtDetails.IssuerInfo.EmailAddress }}</span>
              </div>
              <div class="awarded detail">
                <span>颁发给:</span><span class="paddingLeft8">C=</span><span>{{ httpsCrtDetails.IssueToInfo.CountryName }},</span>
                <span>ST=</span><span>{{ httpsCrtDetails.IssueToInfo.ProvinceName }},</span><span>L=</span><span>{{ httpsCrtDetails.IssueToInfo.LocalityName }},</span>
                <span>O=</span><span>{{ httpsCrtDetails.IssueToInfo.OrgName }},</span><span>OU=</span><span>{{ httpsCrtDetails.IssueToInfo.UnitName }},</span>
                <span>H/IP=</span><span>{{ httpsCrtDetails.IssueToInfo.CommonName }},</span><span>EM=</span><span>{{ httpsCrtDetails.IssueToInfo.EmailAddress }}</span>
              </div>
              <div class="period detail">
                <span>有效期:</span><span class="paddingLeft8">{{ httpsCrtDetails.ValidityFrom }}</span><span>到</span><span>{{ httpsCrtDetails.ValidityTo }}</span>
              </div>
            </div>
          </el-form-item>
        </div>
      </el-form>
      <div class="https-oper-btn-group">
        <input v-show="installSuccess" key="install" type="button" value="安装" class="primary default-border-radius" @click="installHttps">
        <input v-show="!installSuccess" key="save" type="button" value="保存" class="primary default-border-radius" @click="saveHttps">
        <input v-show="!installSuccess" key="delet" type="button" value="删除文件" class="default default-border-radius marginLeft16" @click="deleteHttps">
      </div>
    </div>
    <el-dialog title="提示" class="device-status-dialog" :visible.sync="deviceStatus">
      <el-form>
        <div>{{ deviceStausTitle }}</div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" :disabled="disableButton" @click="rebootSuccess">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>

import { getHttpsCfg, setHttpsCfg, getHttpsCrtDetails, httpsDelCrt, httpsImportCrt } from '@/api/networkConfig.js'
export default {
  components: {
    /*breadCrumb*/
  },
  data() {
    return {
      deviceStausTitle: '设备正在重启',
      disableButton: true,
      deviceStatus: false,
      isDetail: true,
      installSuccess: false,
      certificate: 'aready',
      certificateInfo: '', // 证书
      privateInfo: '', // 私钥
      certificateList: [
        {
          value: 'aready',
          label: '已签名证书'
        }
      ],
      httpsInfoConfig: {
        Enable: 'false',
        CrtExist: 'false',
        CapList: {
          InstallMode: '',
          CountryName: '',
          ProvinceName: '',
          LocalityName: '',
          OrgName: '',
          UnitName: '',
          CommonName: '',
          EmailAddress: '',
          ValidDays: '',
          Password: ''
        }
      },
      httpsCrtDetails: {}
    }
  },
  computed: {
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.getHttps().then(res => {
        this.httpsInfoConfig = res.GetHttpsCfgResp
        if (res.GetHttpsCfgResp.CrtExist === 'true') {
          this.getHttpsDetail().then(res => {
            this.httpsCrtDetails = res.GetHttpsCrtDetailsResp
            this.isDetail = false
            this.installSuccess = false
          })
        } else {
          this.installSuccess = true
        }
      })
    },
    getHttps() { // 获取https配置
      return new Promise((resolve, reject) => {
        getHttpsCfg({}).then(res => {
          resolve(res)
        }).catch(_ => {
          reject(reject)
        })
      })
    },
    setHttps() { // 设置https配置
      const param = {
        SetHttpsCfgReq: {
          Enable: this.httpsInfoConfig.Enable === 'true'
        }
      }
      return new Promise((resolve, reject) => {
        setHttpsCfg(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    changeCertificate() {
      this.certificateInfo = document.getElementById('up_certificate').value
    },
    privateKey() {
      this.privateInfo = document.getElementById('up_private').value
    },
    saveHttps() { // 保存
      this.$confirm('该操作完成后设备会自动重启，是否继续', '提示', {
        confirmButtonText: '是',
        cancelButtonText: '否',
        type: 'warning'
      }).then(() => {
        this.setHttps().then(res => {
          if (this.httpsInfoConfig.Enable === 'true') {
            this.deviceStatus = true
            this.rebootSuccess()
          } else {
            this.$message({
              message: '保存成功',
              type: 'success'
            })
          }
        })// 设置https 后续操作重启
      }).catch(() => {
      })
    },
    rebootSuccess() { // 重启成功
      if (this.$store.getters.isWeb) { // 是不是web端
        this.$router.push({ path: '/login' })
      }
    },
    deleteHttps() { // 删除文件
      httpsDelCrt({}).then(res => {
        this.installSuccess = true
        this.isDetail = true
        this.getHttps().then(res => {
          this.httpsInfoConfig = res.GetHttpsCfgResp
        })
      })
    },
    installHttps() { // 安装https
      const fileCer = (document.getElementById('up_certificate').files)[0]
      const filePri = (document.getElementById('up_private').files)[0]
      if (!fileCer || !filePri) {
        this.$message({
          showClose: true,
          message: '证书或私钥不能为空'
        })
        return
      }
      const params = {
        HttpsImportCrtReq: {
          CrtData: '', // 证书文件内容base64编码
          CrtDataLen: fileCer.size, // 证书内容长度
          KeyData: '', // 私钥文件内容base64编码
          KeyDataLen: filePri.size // 私钥文件内容长度
        }
      }
      this.loadInfo(fileCer).then(res => {
        params.HttpsImportCrtReq.CrtData = res
      })
      this.loadInfo(filePri).then(res => {
        params.HttpsImportCrtReq.KeyData = res
      })
      setTimeout(() => {
        httpsImportCrt(params).then(res => {
          this.httpsCrtDetails = {}
          this.isDetail = false
          this.init()
        })
      }, 500)
    },
    installRequest(param) {
      return new Promise((resolve, reject) => {
        httpsImportCrt(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    },
    loadInfo(files) {
      return new Promise((resolve, reject) => {
        if (files) {
          const reader = new FileReader()
          reader.onload = function(event) {
            const fileContentHeader = event.target.result.replace(/data:(.*);base64,/, '')
            resolve(fileContentHeader)
          }
          reader.readAsText(files, 'GB2312')
        }
      })
    },
    getHttpsDetail() {
      return new Promise((resolve, reject) => {
        getHttpsCrtDetails({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      })
    }
  }
}
</script>
<style lang="scss">
.device-status-dialog {
  .el-dialog {
    width: 500px;
    .el-dialog__headerbtn {
      display: none;
    }
  }
}
</style>
<style lang="scss" scoped>
.https-config {
  .config-stream-media {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    padding: 8px 0px;
    .config-title {
      width: 120px;
      font-size: 14px;
      color: rgba(255,255,255,0.85);
      font-weight: normal;
    }
    .up-grade-button {
      display: inline-block;
      height: 32px;
      line-height: 32px;
    }
    label {
      font-weight: normal;
    }
  }
  .https-oper-btn-group {
    padding-top: 8px;
    padding-left: 120px;
  }
  .certical-detail {
    .detail {
      font-size: 14px;
      padding-left: 16px;
      .paddingLeft8 {
        padding-left: 8px;
      }
    }
    label {
      font-weight: normal;
    }
  }
}
</style>
