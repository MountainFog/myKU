<template>
  <div class="static-router-config">
    <div class="kd-main-title">网络配置 / 静态路由</div>
    <div class="static-btn-group">
      <input type="button" class="primary default-border-radius" value="添加" @click="addRouter">
      <input
        type="button"
        class="default default-border-radius font-title-color marginLeft16"
        value="删除"
        @click="removeStaticRouter"
      >
    </div>
    <div class="router-rules-table">
      <el-table
        :data="staticRouterData"
        style="width: 100%;"
        @selection-change="selectStaticRouter"
      >
        <el-table-column type="selection" width="80" />
        <el-table-column prop="Ip" label="目的地址" />
        <el-table-column prop="Mask" label="子网掩码" />
        <el-table-column prop="GateWay" label="网关" />
        <el-table-column prop="operation" label="操作" width="100">
          <template scope="scope">
            <div class="table-edit" @click="editRouterStatic(scope.row)">编辑</div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="router-rules-container">
      <div class="paddingTop8 fontSize16">静态路由规则</div>
      <div class="paddingTop8">
        1.子网掩码为255.255.255.255或0.0.0.0时，目的地址为主机地址；否则目的地址需为网段地址
      </div>
      <div class="paddingTop8">2.网关必须和网卡1所配置的地址在同一网段</div>
    </div>
    <el-dialog
      :close-on-click-modal="false"
      :title="routerDialogTitle"
      class="font-title-color static-router-dialog"
      :visible.sync="routerConfig"
    >
      <el-form :model="routerForm">
        <el-form-item label="目的地址" :label-width="formLabelWidth">
          <el-input
            v-model="routerForm.Ip"
            type="text"
            class="config-stream-input border-input-default default-border-radius"
          />
        </el-form-item>
        <el-form-item label="子网掩码" :label-width="formLabelWidth">
          <el-input
            v-model="routerForm.Mask"
            type="text"
            class="config-stream-input border-input-default default-border-radius"
          />
        </el-form-item>
        <div key="trans">
          <el-form-item label="网关" :label-width="formLabelWidth">
            <el-input
              v-model="routerForm.GateWay"
              type="text"
              class="config-stream-input border-input-default default-border-radius"
            />
          </el-form-item>
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <input
          type="button"
          class="primary default-border-radius"
          value="保存"
          @click="addRouterStatic"
        >
        <input
          type="button"
          class="default default-border-radius font-title-color marginLeft16"
          value="取消"
          @click="routerConfig = false"
        >
      </div>
    </el-dialog>
  </div>
</template>
<script>
import store from '@/store'
import { getStaticRouteList, setStaticRouteList } from '@/api/networkConfig.js'
import { getEthInfo } from '@/api/networkConfig'
export default {
  components: {
    /* breadCrumb*/
  },
  data() {
    return {
      staticRouterData: [],
      staticSaveRouterData: [],
      deleteStaticRouter: [],
      routerConfig: false, // 编辑弹框
      routerDialogTitle: '添加静态路由',
      formLabelWidth: '100px',
      StaticRouteCapNum: -1, // 静态路由最大个数
      routerForm: {
        Ip: '',
        Mask: '',
        GateWay: ''
      },
      editIndex: -1,
      editForm: {},
      Ip: '',
      Mask: ''
    }
  },
  computed: {},
  created() {
    this.initRouter()
  },
  methods: {
    deepClone(obj) {
      const objClone = Array.isArray(obj) ? [] : {}
      if (obj && typeof obj === 'object') {
        for (const key in obj) {
          if (obj[key] && typeof obj[key] === 'object') {
            objClone[key] = this.deepClone(obj[key])
          } else {
            objClone[key] = obj[key]
          }
        }
      }
      return objClone
    },
    initRouter() {
      this.staticRouterData = []
      this.getRouterStatic().then((res) => {
        const staticData = res.GetStaitcRouterListResp.RouterList.RouterItem
        if (staticData && Array.isArray(staticData)) {
          this.staticRouterData = staticData
        } else if (staticData && !Array.isArray(staticData)) {
          this.staticRouterData.push(staticData)
        }
      })
    },
    addRouter() {
      // 添加静态路由
      this.routerForm = {
        Ip: '',
        Mask: '',
        GateWay: ''
      }
      this.routerDialogTitle = '添加静态路由'
      this.routerConfig = true
    },
    editRouterStatic(row) {
      // 编辑静态路由
      this.routerDialogTitle = '编辑静态路由'
      this.routerConfig = true
      this.editIndex = this.staticRouterData.findIndex(
        (val) => val.Ip == row.Ip && val.Mask == row.Mask && val.GateWay == row.GateWay
      )
      this.routerForm = row
      this.editForm = row
    },
    getRouterStatic() {
      // 获取静态路由数据
      return new Promise((resolve, reject) => {
        getStaticRouteList({})
          .then((res) => {
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    setRouterStatic(routerData) {
      // 设置静态路由数据
      return new Promise((resolve, reject) => {
        setStaticRouteList(routerData)
          .then((res) => {
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    addRouterStatic() {
      // 保存
      getEthInfo({}).then((res) => {
        this.Ip = res.GetEthInfoResp.EthList.EthItem[0].IpList.IpItem.Ip
        this.Mask = res.GetEthInfoResp.EthList.EthItem[0].IpList.IpItem.Mask
        const isEqual = this.isEqualIpAddress(this.Ip, this.routerForm.Ip, this.Mask)
        if (isEqual) {
          if (this.editIndex == -1) {
            // 添加
            this.setRouterStatic(this.setRouterHtml(this.routerForm))
              .then((res) => {
                this.routerConfig = false
                this.initRouter()
              })
              .catch((err) => {
                console.log(err)
              })
          } else {
            // 编辑
            this.staticRouterData.splice(this.editIndex, 1, this.routerForm)
            this.setRouterStatic(this.setRouterHtml())
              .then((res) => {
                this.routerConfig = false
                this.editIndex = -1
                this.editForm = {}
                this.initRouter()
              })
              .catch((err) => {
                console.log(err)
              })
          }
        } else {
          this.$message({
            type: 'warning',
            message: '网络不可达'
          })
        }
      })
    },
    setRouterHtml(staticRouter) {
      this.staticSaveRouterData = []
      this.staticSaveRouterData = this.deepClone(this.staticRouterData)
      if (staticRouter) {
        this.staticSaveRouterData.push(staticRouter)
      }
      const len = this.staticSaveRouterData.length
      let szXml = '<contentroot>'
      szXml += '<authenticationinfo type="7.0">'
      szXml += '<username>' + store.getters.username + '</username>'
      szXml += '<password>' + store.getters.password + '</password>'
      szXml += '<authenticationid>' + store.getters.authId + '</authenticationid>'
      szXml += '</authenticationinfo>'
      szXml += '<SetStaitcRouterListReq>'
      szXml += '<RouterList>'
      for (let i = 0; i < len; i++) {
        szXml += '<RouterItem>'
        szXml += '<Ip>' + this.staticSaveRouterData[i].Ip + '</Ip>'
        szXml += '<Mask>' + this.staticSaveRouterData[i].Mask + '</Mask>'
        szXml += '<GateWay>' + this.staticSaveRouterData[i].GateWay + '</GateWay>'
        szXml += '</RouterItem>'
      }
      szXml += '</RouterList>'
      szXml += '</SetStaitcRouterListReq>'
      szXml += '</contentroot>'
      return szXml
    },
    selectStaticRouter(val) {
      this.deleteStaticRouter = val
    },
    removeStaticRouter() {
      const len = this.deleteStaticRouter.length
      if (len == 0) return
      this.deleteStaticRouter.forEach((item) => {
        const index = this.staticRouterData.findIndex(
          (val) => val.Ip == item.Ip && val.Mask == item.Mask && val.GateWay == item.GateWay
        )
        if (index != -1) {
          this.staticRouterData.splice(index, 1)
        }
      })
      this.setRouterStatic(this.setRouterHtml())
        .then(() => {
          this.deleteStaticRouter = []
          this.initRouter()
        })
    },
    isEqualIpAddress(ip1, ip2, mask) {
      if (!ip1 || !ip2 || !mask) {
        return false
      }
      const res1 = []
      const res2 = []
      const ipA1 = ip1.split('.')
      const ipA2 = ip2.split('.')
      const maskA = mask.split('.')
      for (let i = 0, len = ipA1.length; i < len; i++) {
        res1.push(parseInt(ipA1[i]) & parseInt(maskA[i]))
        res2.push(parseInt(ipA2[i]) & parseInt(maskA[i]))
      }
      if (res1.join('.') === res2.join('.')) {
        return true
      } else {
        return false
      }
    }
  }
}
</script>

<style lang="scss">
.static-router-dialog {
  .el-dialog {
    width: 454px;
  }
}
</style>
<style lang="scss" scoped>
.static-router-config {
  .static-btn-group {
    padding: 16px 20px 16px 0;
  }
  .router-rules-table {
    .table-edit {
      cursor: pointer;
    }
  }
  .router-rules-container {
    padding: 16px 0px;
    .paddingTop8 {
      padding-top: 8px;
      font-size: 14px;
      &.fontSize16 {
        font-size: 16px;
      }
    }
  }
}
</style>
