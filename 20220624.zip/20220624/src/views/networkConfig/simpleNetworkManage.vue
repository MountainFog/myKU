<template>
  <div class="simple-network-manage">
    <div class="kd-main-title">网络配置 / SNMP</div>
    <el-form
      ref="ruleForm"
      label-width="150px"
      label-position="left"
      :model="formData"
      :rules="rules"
    >
      <el-form-item label="启用SNMP：">
        <el-radio-group v-model="formData.SnmpEnable">
          <el-radio :label="true">开启</el-radio>
          <el-radio :label="false">关闭</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="SNMP版本：">
        <el-input v-model="formData.SnmpVer" />
      </el-form-item>
      <el-form-item label="SNMP端口：" prop="SnmpPort">
        <el-input v-model="formData.SnmpPort" />
      </el-form-item>
      <el-form-item label="读写共同体：">
        <el-input v-model="formData.ReadUnionName" maxlength="32" minlength="0" />
      </el-form-item>
      <el-form-item label="写共同体：">
        <el-input v-model="formData.WriteUnionName" maxlength="32" minlength="0" />
      </el-form-item>
      <el-form-item label="Trap地址：" prop="TrapAddr">
        <el-input v-model="formData.TrapAddr" />
      </el-form-item>
      <el-form-item label="Trap端口：" prop="TrapPort">
        <el-input v-model="formData.TrapPort" />
      </el-form-item>
      <el-form-item label="Trap团体名：">
        <el-input v-model="formData.TrapName" maxlength="32" minlength="0" />
      </el-form-item>
      <el-form-item label="入网设备ID：">
        <el-input v-model="formData.PuId" maxlength="32" minlength="0" />
      </el-form-item>
      <el-form-item label="">
        <el-button
          type="primary"
          :loading="loading"
          @click="saveParams"
        >保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import { getSnmpParam, setSnmpParam } from '@/api/networkConfig'
import { validateIP, isPort } from '@/utils/validateModule'
export default {
  data() {
    return {
      // 保存按钮
      loading: false,
      // 表单数据
      formData: {},
      // 验证规则
      rules: {
        SnmpPort: [{ validator: isPort, message: '端口号不正确', trigger: 'blur' }],
        TrapPort: [{ validator: isPort, message: '端口号不正确', trigger: 'blur' }],
        TrapAddr: [{ validator: validateIP, message: 'Trap地址格式错误', trigger: 'blur' }]
      }
    }
  },
  mounted() {
    // 获取初始参数
    getSnmpParam().then(res => {
      this.formData = res.GetSnmpParamResp
      this.formData.SnmpEnable = this.formData.SnmpEnable === 'true'
    })
  },
  methods: {
    // 保存SNMP参数
    saveParams() {
      // 验证参数格式
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          this.loading = true
          setSnmpParam({
            SetSnmpParamReq: this.formData
          }).then(_ => {
            this.$message({
              type: 'success',
              message: '保存成功！'
            })
            this.loading = false
          }).catch(_ => {
            this.loading = false
          })
        }
      })
    }
  }
}
</script>
<style lang="scss">
.simple-network-manage {
  .el-form {
    margin-top: 16px;

    .el-input {
      width: 312px;
    }
  }
}
</style>
