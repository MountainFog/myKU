<template>
  <div class="port-service">
    <div class="kd-main-title">网络配置 / 端口服务</div>
    <el-form
      ref="ruleForm"
      label-width="150px"
      label-position="left"
      :model="formData"
      :rules="rules"
    >
      <el-form-item label="HTTP端口：" prop="HttpPort">
        <el-input v-model.number="formData.HttpPort" />
      </el-form-item>
      <el-form-item label="RTSP端口：" prop="RtspPort">
        <el-input v-model.number="formData.RtspPort" />
      </el-form-item>
      <el-form-item label="HTTPS端口：" prop="HttpsPort">
        <el-input v-model.number="formData.HttpsPort" />
      </el-form-item>
      <el-form-item label="">
        <el-button
          type="primary"
          :loading="loading"
          @click="saveParams"
        >保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import { getProtoPort, setProtoPort } from '@/api/networkConfig'
export default {
  data() {
    return {
      // 保存按钮
      loading: false,
      // 表单数据
      formData: {},
      // 验证规则
      rules: {
        HttpPort: [{ max: 65535, min: 1, type: 'number', message: '端口号不正确', trigger: 'blur' }],
        RtspPort: [{ max: 65535, min: 1, type: 'number', message: '端口号不正确', trigger: 'blur' }],
        HttpsPort: [{ max: 65535, min: 1, type: 'number', message: '端口号不正确', trigger: 'blur' }]
      }
    }
  },
  mounted() {
    // 获取初始数据
    getProtoPort().then(res => {
      for (const key in res.GetProtoPortResp) {
        res.GetProtoPortResp[key] = Number(res.GetProtoPortResp[key])
      }
      this.formData = res.GetProtoPortResp
    })
  },
  methods: {
    // 保存参数
    saveParams() {
      // 验证参数格式
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          this.loading = true
          const params = {
            SetProtoPortReq: this.formData
          }
          setProtoPort(params).then(_ => {
            this.$message({
              type: 'success',
              message: '保存成功！'
            })
            this.loading = false
          }).catch(_ => {
            this.loading = false
          })
        }
      })
    }
  }
}
</script>
<style lang="scss">
.port-service {
  .el-form {
    margin-top: 16px;

    .el-input {
      width: 312px;
    }
  }
}
</style>
