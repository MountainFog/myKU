<template>
  <div class="network-params">
    <div class="kd-main-title">网络配置 / 网卡参数</div>
    <el-form
      ref="ruleForm"
      label-width="150px"
      label-position="left"
      :model="formData"
      :rules="rules"
    >
      <el-form-item label="网口：">
        <el-select
          v-model="ethernet"
          @change="ethernetChange"
        >
          <el-option :value="0" label="以太网口1" />
          <el-option :value="1" label="以太网口2" />
        </el-select>
      </el-form-item>
      <el-form-item label="配置模式：">
        <el-select v-model="formData.DhcpEnabled">
          <el-option :value="false" label="手动设定" />
          <el-option :value="true" label="自动获取" />
        </el-select>
      </el-form-item>
      <div v-for="(item, index) in formData.IpList" :key="index">
        <el-form-item
          :label="`IP地址${index + 1}：`"
          :prop="`IpList.${index}.Ip`"
        >
          <!-- :rules="[{ validator: validate, message: 'IP地址格式不正确', trigger: 'blur' }]" -->
          <el-input v-model="item.Ip" />
          <span v-if="index === 0" class="input-advice__after">互动需绑定此地址</span>
        </el-form-item>
        <el-form-item
          :label="`子网掩码${index + 1}：`"
          :prop="`IpList.${index}.Mask`"
          :rules="[{ validator: validate, message: '子网掩码格式不正确', trigger: 'blur' }]"
        >
          <el-input v-model="item.Mask" />
          <span
            v-if="(index + 1) === formData.IpList.length"
            style="margin-left: 8px;"
          >
            <el-button
              v-if="index !== 2"
              size="small"
              @click="addIpConfig"
            >添加</el-button>
            <el-button
              v-if="index !== 0"
              size="small"
              @click="delIpConfig"
            >删除</el-button>
          </span>
        </el-form-item>
      </div>
      <el-form-item
        label="默认网关："
        prop="GateWay"
        :rules="[{ validator: validate, message: '默认网关格式不正确', trigger: 'blur' }]"
      >
        <el-input v-model="formData.GateWay" />
      </el-form-item>
      <el-form-item
        label="MTU："
        prop="MTU"
      >
        <el-input v-model="formData.MTU" />
        <span class="input-advice__after">（500 ~ 1500）</span>
      </el-form-item>
      <el-form-item
        label="首选DNS服务器："
        prop="FirstDns"
        :rules="[{ validator: validate, message: 'DNS服务器格式不正确', trigger: 'blur' }]"
      >
        <el-input v-model="formData.FirstDns" />
      </el-form-item>
      <el-form-item
        label="备用DNS服务器："
        prop="SecondDns"
        :rules="[{ validator: validate, message: 'DNS服务器格式不正确', trigger: 'blur' }]"
      >
        <el-input v-model="formData.SecondDns" />
      </el-form-item>
      <el-form-item label="">
        <el-button
          type="primary"
          :loading="loading"
          @click="saveParams"
        >保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import { getEthInfo, setEthInfo } from '@/api/networkConfig'
import { validateIP } from '@/utils/validateModule'
export default {
  data() {
    const limitMTU = (rule, value, callback) => {
      const reg = new RegExp(/^[0-9]*$/)
      if (!reg.test(value)) {
        return callback(new Error('请设置500~1500之间的整数'))
      }
      if (value > 499 && value < 1501) {
        return callback()
      }
      return callback(new Error('超出可设置范围'))
    }
    return {
      loading: false,
      paramsList: [],
      ethernet: 0,
      configMode: 1,
      SecondDns: '',
      FirstDns: '',
      validate: validateIP,
      rules: {
        MTU: [{ validator: limitMTU, trigger: 'blur' }]
      }
    }
  },
  computed: {
    formData() {
      let data = {}
      if (this.paramsList[this.ethernet]) {
        data = this.paramsList[this.ethernet]
      }
      return data
    }
  },
  mounted() {
    getEthInfo().then(res => {
      this.formatParams(res.GetEthInfoResp.EthList.EthItem)
    })
  },
  methods: {
    // 格式化回显参数
    formatParams(params) {
      for (let i = 0; i < params.length; i++) {
        delete params[i].EthType
        delete params[i].LinkState
        delete params[i].ActualSpeedType
        params[i].AutoDns = params[i].AutoDns === 'true'
        params[i].DhcpEnabled = params[i].DhcpEnabled === 'true'
        this.FirstDns = params[i].FirstDns
        this.SecondDns = params[i].SecondDns
        if (typeof params[i].IpList.IpItem === 'object' && params[i].IpList.IpItem.length !== undefined) {
          // 多条
          params[i].IpList = params[i].IpList.IpItem
        } else {
          // 一条
          const item = params[i].IpList.IpItem
          params[i].IpList = []
          params[i].IpList.push(item)
        }
      }
      this.paramsList = params
    },
    // 添加IP配置
    addIpConfig() {
      this.formData.IpList.push({
        Ip: '',
        Mask: ''
      })
    },
    // 删除IP配置
    delIpConfig() {
      const idx = this.formData.IpList.length
      this.formData.IpList.splice(idx - 1, 1)
    },
    // 反解参数
    deformatParams() {
      const list = []
      for (let i = 0; i < this.paramsList.length; i++) {
        const item = this.paramsList[i]
        const data = {}
        for (const key in item) {
          const value = item[key]
          if (key === 'IpList') {
            data[key] = {
              K_E_Y: 'IpItem',
              V_A_L_U_E: value
            }
          } else {
            data[key] = value
          }
        }
        list.push(data)
      }
      return list
    },
    // 保存参数
    saveParams() {
      // 验证参数格式
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          // 给出操作提示
          this.$confirm('网卡参数修改会导致设备重启，是否继续保存?', '提示', {
            confirmButtonText: '是',
            cancelButtonText: '否',
            type: 'warning'
          }).then(() => {
            // 解析参数
            const params = {
              SetEthInfoReq: {
                EthList: {
                  K_E_Y: 'EthItem',
                  V_A_L_U_E: this.deformatParams()
                }
              }
            }
            // 设置参数
            this.loading = true
            setEthInfo(params).then(_ => {
              this.loading = false
              this.$message({
                type: 'success',
                message: '保存成功！'
              })
            }).catch(_ => {
              this.loading = false
            })
          }).catch(() => {})
        }
      })
    },
    // 网口切换
    ethernetChange(value) {
      // 验证IP、子网掩码
      this.$refs.ruleForm.validate((valid) => {
        // 不通过 不允许切换
        if (!valid) {
          this.ethernet = value ? 0 : 1
        }
      })
    }
  }
}
</script>
<style lang="scss">
.network-params {
  .el-form {
    margin-top: 16px;

    .el-input {
      width: 312px;
    }
  }

  // 输入框后缀提示
  .input-advice__after {
    margin-left: 8px;
  }
}
</style>
