<template>
  <div class="video-config">
    <div class="el-tab-wrap">
      <div class="plan-condi">
        <span>录播模式：</span>
        <el-radio
          v-model="planMode"
          :disabled="isRecording"
          label="1"
          @change="arrangCourse"
        >自动录播</el-radio>
        <el-radio
          v-model="planMode"
          :disabled="isRecording"
          label="2"
        >手动录播</el-radio>
      </div>
      <div v-show="planMode === '1'" class="plan-condi-schedule">
        <div class="plan-condi">
          <span>排课类型：</span>
          <el-checkbox
            v-model="WeeklyEnabled"
            :disabled="isRecording"
            @change="setMp4RecSchEx(false)"
          >周期课表</el-checkbox>
          <el-checkbox
            v-model="OnceEnabled"
            :disabled="isRecording"
            @change="setMp4RecSchEx(false)"
          >一次性课表（优先级高于周期课表）</el-checkbox>
        </div>
        <div class="plan-condi">
          <el-button
            :disabled="isRecording"
            @click="addWeekData"
          >添加</el-button>
          <el-button
            :disabled="isRecording"
            @click="copyVisible = true"
          >复制</el-button>
        </div>
        <div class="week-options">
          <div
            v-for="(item, index) in weekList"
            :key="index"
            :class="['week-options-item', {'week-option__active': timeNode === index}]"
            @click="handleWeekClick(index)"
          >{{ item }}</div>
        </div>
        <el-table
          :data="tableData"
          border
          class="video-config-table"
        >
          <el-table-column
            label="启用"
            width="80"
            align="center"
          >
            <template slot-scope="scope">
              <el-checkbox
                v-model="scope.row.Enabled"
                :disabled="disabled"
                @change="handleCheckedChange"
              />
            </template>
          </el-table-column>
          <el-table-column
            label="开始时间"
            property="StartTime"
          >
            <template slot-scope="scope">
              {{ scope.row.StartTime }}
            </template>
          </el-table-column>
          <el-table-column
            label="结束时间"
            property="EndTime"
          >
            <template slot-scope="scope">
              {{ scope.row.EndTime }}
            </template>
          </el-table-column>
          <el-table-column
            label="课程名称"
            property="CourseName"
          />
          <el-table-column
            label="主讲教师"
            property="TeacherName"
          />
          <el-table-column
            label="课程单位"
            property="UnitName"
          />
          <el-table-column
            label="导播模式"
            property="Director"
          />
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button type="text" @click="handleTableEdit(scope.row)">编辑</el-button>
              <el-button type="text" @click="handleTableDel(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div v-show="planMode === '2'" class="plan-condi-manual">
        <el-form
          ref="ruleManual"
          :model="manualData"
          :rules="rules"
          label-width="210px"
          label-position="left"
        >
          <el-form-item label="课程名称" prop="CourseName">
            <el-input v-model="manualData.CourseName" maxlength="12" @keyup.native="inputCourseName" />
          </el-form-item>
          <el-form-item label="主讲教师" prop="TeacherName">
            <el-input v-model="manualData.TeacherName" maxlength="12" />
          </el-form-item>
          <el-form-item label="课程单位">
            <el-input v-model="manualData.UnitName" maxlength="12" />
          </el-form-item>
          <el-form-item label="导播模式">
            <el-input v-model="manualData.Director" maxlength="12" />
          </el-form-item>
          <el-form-item label=" ">
            <el-button
              type="primary"
              :loading="manualLoading"
              @click="saveManual"
            >保存</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-dialog
      :visible.sync="visible"
      :title="`${isEdit ? '编辑' : '新增'}课表`"
      width="560px"
      :close-on-click-modal="false"
      :modal-append-to-body="false"
      @close="resetDialogData"
    >
      <el-form
        ref="ruleDialog"
        :model="dialogData"
        :config="rules"
        label-width="80px"
      >
        <el-form-item label="启用">
          <el-checkbox v-model="dialogData.Enabled" />
        </el-form-item>
        <el-form-item label="星期">
          <el-input
            :value="weekList[timeNode]"
            disabled
          />
        </el-form-item>
        <el-form-item
          v-if="timeNode === 7"
          label="指定时间"
        >
          <el-date-picker
            v-model="dialogData.StartTime"
            type="datetime"
            placeholder="开始时间"
            value-format="yyyy/MM/dd HH:mm:ss"
            default-time="12:00:00"
          />
          <span class="picker-spacing_8">~</span>
          <el-date-picker
            v-model="dialogData.EndTime"
            type="datetime"
            placeholder="结束时间"
            value-format="yyyy/MM/dd HH:mm:ss"
            default-time="12:00:00"
          />
        </el-form-item>
        <el-form-item
          v-else
          label="时间"
        >
          <el-time-picker
            v-model="dialogData.StartTime"
            value-format="HH:mm:ss"
            placeholder="开始时间"
          />
          <span class="picker-spacing_8">~</span>
          <el-time-picker
            v-model="dialogData.EndTime"
            value-format="HH:mm:ss"
            placeholder="结束时间"
          />
        </el-form-item>
        <el-form-item label="课程名称" prop="CourseName">
          <el-input v-model="dialogData.CourseName" maxlength="12" @keyup.native="inputCourseName" />
        </el-form-item>
        <el-form-item label="主讲教师" prop="TeacherName">
          <el-input v-model="dialogData.TeacherName" maxlength="12" />
        </el-form-item>
        <el-form-item label="课程单位">
          <el-input v-model="dialogData.UnitName" maxlength="12" />
        </el-form-item>
        <el-form-item label="导播模式">
          <el-input v-model="dialogData.Director" maxlength="12" />
        </el-form-item>
      </el-form>
      <div class="btn-align__right">
        <el-button
          type="primary"
          @click="saveDialogData"
        >保存
        </el-button>
        <el-button @click="resetDialogData">取消</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="复制到"
      :visible.sync="copyVisible"
      width="700px"
    >
      <el-checkbox
        v-model="checkAll"
        :indeterminate="isIndeterminate"
        @change="handleCheckAllChange"
      >全选</el-checkbox>
      <div style="margin: 15px 0;">
        <el-checkbox-group
          v-model="copyList"
          @change="handleCheckedCitiesChange"
        >
          <el-checkbox
            v-for="index in 7"
            :key="index"
            :label="index - 1"
          >{{ weekList[index - 1] }}</el-checkbox>
        </el-checkbox-group>
      </div>
      <div class="btn-align__right">
        <el-button
          type="primary"
          @click="copyToTarget"
        >确认
        </el-button>
        <el-button @click="copyVisible = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { getVideoCfg, setVideoCfg, getMp4RecSchEx, setMp4RecSchEx, getMp4ManulRecCfg, setMp4ManulRecCfg } from '@/api/resourceManage'
import { getSvrState } from '@/api/deviceInfo'
import moment from 'moment'
import { jsonToXml } from '@/utils/dataParse'
import { specialEncode } from '@/utils/specialCharacters'
export default {
  data() {
    return {
      isRecording: false,
      // 排课计划 / 录象配置 tab标签
      activeName: 'plan',
      // 添加 or 编辑
      isEdit: true,
      // 排课计划弹出框
      visible: false,
      // 复制功能弹出框
      copyVisible: false,
      // 表格复选框 禁选
      disabled: false,
      // 排课计划模式
      planMode: '1',
      // 复制弹出框 全选
      checkAll: false,
      // 复制弹出框 半选
      isIndeterminate: false,
      copyList: [],
      WeeklyEnabled: false,
      OnceEnabled: false,
      // 时间节点列表
      weekList: ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日', '指定时间'],
      // 排课计划表格数据
      tableData: [],
      // 录象配置参数
      videoConfig: {
        CoverPolicy: 'false',
        SpaceFullThreshold: 50,
        SpaceLackThreshold: 10,
        CutPolicy: 0,
        RecSaveFormat: 'mp4'
      },
      // 排课计划 - 时间节点
      timeNode: 0,
      // 录象配置 - 保存状态
      configLoading: false,
      // 弹出框数据
      dialogData: {
        Enabled: true,
        StartTime: '00:00:00',
        EndTime: '',
        CourseName: '',
        TeacherName: '',
        UnitName: '',
        Director: ''
      },
      // 参数为空时发送到后台的xml模板
      nullParam: {
        TimeSectionItem: {
          Enabled: true,
          CourseInfo: {
            StartTime: '0:0:0',
            EndTime: '0:0:0',
            CourseName: '',
            TeacherName: '',
            UnitName: '',
            Director: ''
          }
        }
      },
      // 手动选定 保存按钮状态
      manualLoading: false,
      // 手动选定数据
      manualData: {
        CourseName: '',
        TeacherName: '',
        UnitName: '',
        Director: ''
      },
      rules: {
        CourseName: [{ required: true, message: '不能为空', trigger: 'blur' }],
        TeacherName: [{ required: true, message: '不能为空', trigger: 'blur' }]
      },
      configrules: {
        SpaceLackThreshold: [{ min: 5, max: 20, type: 'number', message: '超出可设置范围' }],
        CutPolicy: [{ min: 500, max: 3800, type: 'number', message: '超出可设置范围' }]
      }
    }
  },
  computed: {
    currentWeek() {
      return this.weekList[this.timeNode]
    }
  },
  mounted() {
    this.getWeekDay()
    this.getVideoCfg()
    this.getMp4RecSchEx()
    // 获取手动选定参数
    getMp4ManulRecCfg().then(res => {
      this.manualData = res.GetMp4ManulRecCfgResp.CourseInfo
      this.planMode = res.GetMp4ManulRecCfgResp.Enabled == 'false' ? '1' : '2'
    })
    // 获取录制状态
    getSvrState().then(res => {
      this.isRecording = res.SvrStateResp.Mp4RecState === 'recording'
      if (this.isRecording) {
        this.$message({
          type: 'warning',
          message: '录制中，暂时无法修改排课计划'
        })
        return
      }
    })
  },
  methods: {
    // 获取当前日期是星期几
    getWeekDay() {
      let weekday = moment().weekday()
      // 周日返回的是0 修改为7
      if (weekday === 0) weekday = 7
      this.timeNode = weekday - 1
    },
    // 保存 手动选定
    saveManual() {
      if (this.isRecording) {
        this.$message({
          type: 'warning',
          message: '录制中，暂时无法修改排课计划'
        })
        return
      }
      this.$refs.ruleManual.validate((valid) => {
        if (!valid) {
          this.$message({
            type: 'warning',
            message: '参数不正确'
          })
          return
        }
        this.manualLoading = true
        setMp4ManulRecCfg({
          SetMp4ManulRecCfgReq: {
            Enabled: true,
            CourseInfo: {
              CourseName: specialEncode(this.manualData.CourseName),
              TeacherName: specialEncode(this.manualData.TeacherName),
              UnitName: specialEncode(this.manualData.UnitName),
              Director: specialEncode(this.manualData.Director)
            }
          }
        }).then(res => {
          this.manualLoading = false
          this.$message({
            type: 'success',
            message: '保存成功！'
          })
        })
      })
    },
    // 复制功能选项的全选事件
    handleCheckAllChange(val) {
      this.copyList = val ? [0, 1, 2, 3, 4, 5, 6] : []
      this.isIndeterminate = false
    },
    // 复制功能选项的半选与全选状态
    handleCheckedCitiesChange(value) {
      this.checkAll = value.length === 7
      this.isIndeterminate = value.length > 0 && value.length < 7
      this.copyList = value
    },
    // 复制到
    copyToTarget() {
      this.copyVisible = false
      for (let i = 0; i < this.copyList.length; i++) {
        this.setMp4RecSchEx(this.copyList[i])
      }
    },
    // 获取录象配置
    getVideoCfg() {
      getVideoCfg().then(res => {
        const data = res.GetMp4RecPolicyCfgResp
        this.videoConfig.CoverPolicy = data.CoverPolicy
        this.videoConfig.SpaceFullThreshold = Number(data.SpaceFullThreshold)
        this.videoConfig.CutPolicy = Number(data.CutPolicy)
        this.videoConfig.SpaceLackThreshold = Number(data.SpaceLackThreshold)
        this.videoConfig.RecSaveFormat = data.RecSaveFormat
      })
    },
    // 保存录象配置
    saveVideoCfg() {
      this.$refs.configForm.validate((valid) => {
        if (valid) {
          this.configLoading = true
          // 深拷贝
          const params = {}
          for (const key in this.videoConfig) {
            params[key] = this.videoConfig[key]
          }
          setVideoCfg({
            SetMp4RecPolicyCfgReq: params
          }).then(_ => {
            this.$message({
              type: 'success',
              message: '保存成功！'
            })
            this.configLoading = false
            this.getVideoCfg()
          })
        }
      })
    },
    // 处理星期点击事件
    handleWeekClick(index) {
      this.timeNode = index
      this.getMp4RecSchEx()
    },
    // 获取课表
    getMp4RecSchEx() {
      const index = this.timeNode
      getMp4RecSchEx({
        GetMp4RecSchExReq: {
          DayIndex: this.timeNode
        }
      }).then(res => {
        let list = []
        this.WeeklyEnabled = res.GetMp4RecSchExResp.WeeklyEnabled === 'true'
        this.OnceEnabled = res.GetMp4RecSchExResp.OnceEnabled === 'true'
        if (index === 7) {
          // 指定时间
          list = res.GetMp4RecSchExResp.OnceTableList.OnceTableItem
        } else {
          // 周一到周日
          list = res.GetMp4RecSchExResp.WeeklyTableList.WeeklyTableItem[index].TimeSectionList.TimeSectionItem
        }
        this.formatRespData(list)
      })
    },
    // 格式化服务端数据
    formatRespData(list) {
      const tableList = []
      for (let i = 0; i < list.length; i++) {
        const info = list[i].CourseInfo
        if (info.EndTime !== info.StartTime) {
          tableList.push({
            index: i,
            CourseName: info.CourseName,
            Director: info.Director,
            EndTime: this.timeFormat(info.EndTime),
            StartTime: this.timeFormat(info.StartTime),
            TeacherName: info.TeacherName,
            UnitName: info.UnitName,
            Enabled: list[i].Enabled === 'true'
          })
        }
      }
      this.$set(this, 'tableData', tableList)
    },
    // 时间格式
    timeFormat(value) {
      if (value.length > 8) {
        const time = new Date(value)
        return moment(time).format('YYYY/MM/DD HH:mm:ss')
      } else {
        // Date对象的解析参数必须包含年月日
        return moment(new Date('1991-08-15 ' + value)).format('HH:mm:ss')
      }
    },
    // 表格 - 添加
    addWeekData() {
      this.isEdit = false
      this.visible = true
      let date = ''
      // 指定时间需要完整年-月-日 时:分:秒
      if (this.timeNode === 7) {
        date = moment().format('YYYY/MM/DD') + ' '
      }
      this.dialogData.StartTime = date + moment().format('00:00:00')
      this.dialogData.EndTime = date + moment().format('00:00:00')
    },
    // 表格 - 编辑
    handleTableEdit(data) {
      this.isEdit = true
      // 回显数据
      for (const key in data) {
        const value = data[key]
        this.dialogData[key] = value
      }
      this.visible = true
    },
    // 表格 - 删除
    handleTableDel(data) {
      this.$confirm('此操作将永久删除此项排课, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const index = this.tableData.findIndex(item => item.index === data.index)
        this.tableData.splice(index, 1)
        this.setMp4RecSchEx().then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
      }).catch(() => {})
    },
    // 生成星期对应表格数据的xml
    creatWeekTableXml(day) {
      const list = this.formatRequestParams()
      let xml = ''
      for (let i = 0; i < 7; i++) {
        if (i === day) {
          xml += `<WeeklyTableItem>${jsonToXml({
            TimeSectionList: {
              K_E_Y: 'TimeSectionItem',
              V_A_L_U_E: list
            }
          })}</WeeklyTableItem>`
        } else {
          xml += `<WeeklyTableItem><TimeSectionList>${jsonToXml(this.nullParam)}</TimeSectionList></WeeklyTableItem>`
        }
      }
      return xml
    },
    // 格式化发送请求参数结构
    formatRequestParams() {
      const list = []
      this.tableData.forEach(item => {
        list.push({
          Enabled: item.Enabled,
          CourseInfo: {
            StartTime: item.StartTime,
            EndTime: item.EndTime,
            CourseName: item.CourseName,
            TeacherName: item.TeacherName,
            UnitName: item.UnitName,
            Director: item.Director
          }
        })
      })
      return list
    },
    // 表格内 是否启用复选框
    handleCheckedChange() {
      this.disabled = true
      this.setMp4RecSchEx().then(() => {
        this.disabled = false
      })
    },
    // 保存编辑或者添加的数据
    saveDialogData() {
      // 是否录制状态
      if (this.isRecording) {
        this.$message({
          type: 'warning',
          message: '录制中，暂时无法修改排课计划'
        })
        return
      }
      // 开始时间与结束时间
      if (this.checkTime(this.dialogData)) return
      // 参数格式校验
      this.$refs.ruleDialog.validate((valid) => {
        if (!valid) {
          this.$message({
            type: 'warning',
            message: '参数不正确'
          })
          return
        }

        // 判断编辑与新增
        if (this.isEdit) {
          const index = this.tableData.findIndex(item => item.index === this.dialogData.index)
          this.tableData.splice(index, 1, this.dialogData)
        } else {
          this.tableData.push(this.dialogData)
        }

        this.setMp4RecSchEx().then(() => {
          this.$message({
            type: 'success',
            message: '保存成功！'
          })
          this.resetDialogData()
          this.getMp4RecSchEx()
        })
      })
    },
    // 检查开始时间与结束时间
    checkTime(data) {
      const start = this.formatDateTime(data.StartTime)
      const end = this.formatDateTime(data.EndTime)
      if (start >= end) {
        this.$message({
          type: 'warning',
          message: '结束时间必须大于开始时间'
        })
        return true
      }
      for (let i = 0; i < this.tableData.length; i++) {
        const item = this.tableData[i]
        const targetStart = this.formatDateTime(item.StartTime)
        const targetEnd = this.formatDateTime(item.EndTime)
        // 编辑时无需与被编辑项的时间比较
        if (data.index !== item.index) {
          // 开始时间与已有课程时间重叠
          if (start >= targetStart && start <= targetEnd) {
            this.$message({
              type: 'warning',
              message: '开始时间与已有课程时间重叠'
            })
            return true
          }
          // 结束时间与已有课程时间重叠
          if (end >= targetStart && end <= targetEnd) {
            this.$message({
              type: 'warning',
              message: '结束时间与已有课程时间重叠'
            })
            return true
          }
          // 当前所选时间段包含了已存在课程的时间
          if (start <= targetStart && end >= targetEnd) {
            this.$message({
              type: 'warning',
              message: '当前时间段已存在其它课程'
            })
            return true
          }
        }
      }
      return false
    },
    // 格式化日期时间
    formatDateTime(time) {
      return time.replace(/:/g, '').replace(/\//g, '')
    },
    // 设置排课计划
    setMp4RecSchEx(day) {
      return new Promise((resolve, reject) => {
        const dayIndex = (day || day === 0) ? day : this.timeNode
        setMp4RecSchEx({
          SetMp4RecSchExReq: {
            DayIndex: dayIndex,
            OnceEnabled: this.OnceEnabled,
            WeeklyEnabled: this.WeeklyEnabled,
            OnceTableList: {
              K_E_Y: 'OnceTableItem',
              V_A_L_U_E: this.formatRequestParams()
            },
            WeeklyTableList: this.creatWeekTableXml(dayIndex)
          }
        }).then(_ => {
          resolve()
        }).catch(_ => {
          reject()
        })
      })
    },
    // 重置弹出框数据
    resetDialogData() {
      this.visible = false
      this.dialogData = {
        Enabled: true,
        UnitName: '',
        EndTime: '',
        StartTime: '',
        TeacherName: '',
        Director: '',
        CourseName: ''
      }
      this.$refs.ruleDialog.resetFields()
    },
    arrangCourse() {
      this.manualLoading = true
      setMp4ManulRecCfg({
        SetMp4ManulRecCfgReq: {
          Enabled: false,
          CourseInfo: {
            CourseName: specialEncode(this.manualData.CourseName),
            TeacherName: specialEncode(this.manualData.TeacherName),
            UnitName: specialEncode(this.manualData.UnitName),
            Director: specialEncode(this.manualData.Director)
          }
        }
      }).then(res => {
        this.manualLoading = false
      })
    },
    // 课程名称特殊字符不能输入限制
    inputCourseName(event) {
      event.target.value = event.target.value.replace(/#|\u0020/g, '')
    }
  }
}
</script>
<style lang="scss">
.video-config {
  padding: 8px 40px;
  .el-tabs__item {
    height: 50px;
    line-height: 50px;
    color: $-fff-85;
    font-size: 18px;
  }

  .el-tabs__item.is-active {
    color: #3884FF;
  }

  .el-tabs__nav-wrap::after {
    height: 1px;
    background-color: rgba(216,222,234,0.20);
  }

  .el-tabs__active-bar {
    background-color: #1F75FF;
  }

  .el-tab-wrap {
    .el-input {
      width: 312px;
    }
  }

  // 输入框后缀提示
  .input-advice__after {
    margin-left: 8px;
  }

  .plan-condi {
    padding: 16px 0;
    .el-radio, .el-checkbox {
      margin-left: 40px;
    }
  }

  // 星期节点样式
  .week-options {
    display: flex;
    border: 1px solid rgba(216, 222, 234, 0.12);
    border-right: none;

    &-item {
      width: 12.5%;
      text-align: center;
      line-height: 40px;
      border-right: 1px solid rgba(216, 222, 234, 0.12);
      cursor: pointer;
      transition: 0.3s all ease;
    }

    &-item:hover {
      color: $-fff-85;
      background-color: #3884FF;
    }

    .week-option__active {
      color: $-fff-85;
      background-color: #3884FF;
    }
  }

  &-table {
    margin-top: 16px;
  }
  .el-dialog {

    .btn-align__right {
      margin-top: 16px;
      text-align: right;
    }

    .picker-spacing_8 {
      display: inline-block;
      width: 37px;
      text-align: center;
    }
    .el-date-editor.el-input, .el-date-editor.el-input__inner {
      width: 200px;
    }
  }
}
</style>
