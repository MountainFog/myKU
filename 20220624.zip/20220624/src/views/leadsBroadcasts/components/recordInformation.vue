<template>
  <div class="direct-record-information">
    <!-- <div>录制信息</div> -->
    <div class="direct-record-container">
      <div class="record-info-item">
        <label for="" class="record-info-title">课程名称:</label>
        <span class="font-title-color record-info-content">{{ courseInfo.CourseName }}</span>
      </div>
      <div class="record-info-item">
        <label for="" class="record-info-title">主讲教师:</label>
        <span class="font-title-color record-info-content">{{ courseInfo.TeacherName }}</span>
      </div>
      <div class="record-info-item">
        <label for="" class="record-info-title">课程单位:</label>
        <span class="font-title-color record-info-content">{{ courseInfo.UnitName }}</span>
      </div>
      <div class="record-info-item">
        <label for="" class="record-info-title">开始时间:</label>
        <span class="font-title-color record-info-content">{{ couserBeginTime }}</span>

      </div>
      <div class="record-info-item">
        <label for="" class="record-info-title">课程时长:</label>
        <span class="font-title-color record-info-content" v-cloak>{{ timeRecode }}</span>
      </div>
      <!-- <div class="record-info-item">
        <label for="" class="record-info-title">结束时间:</label>
        <span class="font-title-color record-info-content">{{ courseInfo.EndTime }}</span>
      </div> -->
    </div>
    <div class="direct-record-container">
      <div class="record-info-item">
        <label for="" class="record-info-title">导播模式:</label>
        <span class="font-title-color record-info-content">{{ courseInfo.Director }}</span>
      </div>
      <div class="record-info-item">
        <label for="" class="record-info-title">视频信息:</label>
        <span class="font-title-color record-info-content">{{ vidEncParam.Resolution }};{{ vidEncParam.BitRate }}kbps</span>
      </div>
      <div class="record-info-item">
        <label for="" class="record-info-title">音频格式:</label>
        <span class="font-title-color record-info-content">{{ audioFormats }}</span>
      </div>
    </div>
    <div class="direct-record-container">
      <input type="button" @click="recordInfo" value="课程录制信息" class="default" />
    </div>
    <div class="direct-record-status">
      <div class="status-title">
        <i class="u-icon"></i>
        <span class="font-title-color u-status-title">U盘状态</span>
      </div>
      <div class="status-use-precent"><span class="font-title-table">{{ (UsbFreeCap / 1024).toFixed(1) }}G/{{UsbCap / 1024}}G</span></div>
    </div>
    <div class="u-consumption"><el-progress :percentage="UsbFreePres" :text-inside="true"></el-progress></div>
    <div class="direct-record-status">
      <div class="status-title use-support">
        USB2.0仅支持4M码率以下的录制
      </div>
    </div>
    <el-dialog title="课程录制信息" v-if="recodeingInfo" :visible.sync="recodeingInfo" :append-to-body="true">
      <videoConfig></videoConfig>
    </el-dialog>
  </div>
</template>

<script>
import {
  getCurCourseInfo,
  getCmpChnVidEncParam,
  getSvrStateEx
} from '@/api/leadsBroadcasts.js'
import { dateFormat } from '@/utils/dateFormat'
import eventBus from '@/utils/eventBus.js'
import videoConfig from './videoConfig'
export default {
  data() {
    return {
      recodeingInfo: false,
      recordTime: null,
      UsbFreeCap: 30,
      UsbCap: 100,
      audioFormats: '',
      UsbFreePres: 0,
      recordTimeCount: 1,
      timeRecode: '00:00:00',
      getCourRecodeTime: '00:00:00',
      courseInfo: { //课程信息
        CourseName: '',//课程名称
        Director: '',//导播名称
        TeacherName: '',//教师名称
        UnitName: '',//单位名称
        StartTime: '',//开始时间
        EndTime: ''//结束时间
      },
      vidEncParam: {
        EncType: '',//编码类型
        ProfileLevel: '',//编码复杂度
        Resolution: '',//视频分辨率
        FrameRate: '',//视频帧率
        BitRate: '',//视频码率
        KeyframeInterval: ''//关键帧间隔
      }
    }
  },
  mounted() {
    this.initRecordInfo()
  },
  watch:{
    isRecoding() {
      this.recodeTime()
    },
    recodeTimeValue() {
      let time = Number(this.recodeTimeValue)
      let h = parseInt( time / 60 / 60 ) < 10 ? ('0' + parseInt( time / 60 / 60 )) : parseInt( time / 60 / 60 )
      let m = parseInt( time % 3600 / 60 ) < 10 ? ('0' + parseInt( time % 3600 / 60 )) : parseInt( time % 3600 / 60 )
      let s = parseInt( time % 60 ) < 10 ? ('0' + parseInt( time % 60 )) : parseInt( time % 60 )
      this.timeRecode = (h + ':' + m + ":" + s)
    }
  },
  computed:{
    couserBeginTime() {
      let _that = this
      if(dateFormat('MM-dd hh:mm:ss',new Date(_that.courseInfo.StartTime)) == 'aN-aN aN:aN:aN') {
        return '00-00 00:00:00'
      }
      return dateFormat('MM-dd hh:mm:ss',new Date(_that.courseInfo.StartTime))
    }
  },
  created() {
    eventBus.$on('infoChange',(message) => {
      this.getAudTypeCh(message.audType)
    })
  },
  destroyed() {
    clearTimeout(this.courseTime)
  },
  methods: {
    initRecordInfo() {
      this.showCourseInfo()
      this.getVideoInfo().then(res => {
        this.vidEncParam = res.GetCmpChnVidEncParamResp.VidEncParam
      })
      this.getAudioInfo().then(res => {
        this.getAudTypeCh(res.SvrStateResp.AmtAudType)
        this.UsbCap = Number(res.SvrStateResp.UsbCap)
        this.UsbFreeCap = Number(res.SvrStateResp.UsbCap) - Number(res.SvrStateResp.UsbFreeCap)
        if(res.SvrStateResp.UsbFreePres == '0') {
          this.UsbFreePres = 0
        }else {
          this.UsbFreePres = (100 - Number(res.SvrStateResp.UsbFreePres))
        }
      })
    },
    recordInfo() {
      this.recodeingInfo = true
    },
    getAudTypeCh(type) {
      let _that = this
      switch(type) {
        case 'g711a':
          _that.audioFormats = 'PCMA'
          break
        case 'g711u':
          _that.audioFormats = 'PCMU'
          break
        case 'g722':
          _that.audioFormats = 'G722'
          break
        case 'aaclc16_mono':
          _that.audioFormats = 'AACLC_16(单声道)'
          break
        case 'aaclc16_stereo':
          _that.audioFormats = 'AACLC_16(双声道)'
          break
        case 'aaclc32_mono':
          _that.audioFormats = 'AACLC_32(单声道)'
          break
        case 'aaclc32_stereo':
          _that.audioFormats = 'AACLC_32(双声道)'
          break
        case 'aaclc48_mono':
          _that.audioFormats = 'AACLC_48(单声道)'
          break
        case 'aaclc48_stereo':
          _that.audioFormats = 'AACLC_48(双声道)'
          break
      }
    },
    getCourseInfo() {
      return new Promise( (resolve,reject) => {
        getCurCourseInfo({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      } )
    },
    getVideoInfo() {
      return new Promise( (resolve,reject) => {
        getCmpChnVidEncParam({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      } )
    },
    getAudioInfo() {
      return new Promise( (resolve,reject) => {
        getSvrStateEx({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      } )
    },
    showCourseInfo() {
      clearTimeout(this.courseTime)
      this.getCourseInfo().then(res => {
        let _that = this
        this.courseInfo = res.GetCurCourseInfoResp.CourseInfo
        this.courseTime = setTimeout(() => {
          _that.showCourseInfo()
        },1000)
      })
    },
    async recodeTime() {
      if(this.isRecoding == 'recording') {//录制中
        let _that = this
        let patt = /-/g
        let date = await new Date( _that.courseInfo.StartTime.replace(patt,'/') )
        let sec = await (new Date(this.recordTimeCount * 1000).getTime() - 8* 60* 60* 1000)
        let dateRe = await new Date(sec)
        let showRe = await dateFormat("hh:mm:ss",dateRe)
        if(showRe == 'aN:aN:aN') {
          _that.getCourRecodeTime = '00:00:00'
        }else {
          _that.getCourRecodeTime = showRe
        }
        this.recordTime = setTimeout(() => {
          this.recordTimeCount++
          _that.recodeTime()
        },1000)
      }else if(this.isRecoding == 'normal') {//录制结束
        clearTimeout(this.recordTime)
        this.getCourRecodeTime = '00:00:00'
        this.recordTimeCount = 1
      }else if(this.isRecoding == 'pause') {//暂停录制
      }
    }
  },
  components: {
    videoConfig
  },
  props: {
    isRecoding: {
      type: String,
      default: 'normal'
    },
    recodeTimeValue: {
      type: String,
      default: '00:00:00'
    }
  }
}
</script>

<style lang="scss">
.u-consumption {
    padding: 12px;
    .el-progress {
      .el-progress-bar {
        .el-progress-bar__outer {
          height: 8px !important;
          background-color: #1D222C;
          border-radius: 4px;
          .el-progress-bar__inner {
            height: 8px;
            background-color: #1F75FF;
            border-radius: 4px;
            .el-progress-bar__innerText {
              display: none;
            }
          }
        }
      }
    }
  }
</style>
<style scoped lang="scss">
.direct-record-information {
  .direct-record-container {
    padding: 12px;
    .record-info-item {
      display: flex;
      padding-top: 6px;
      padding-bottom: 6px;
      .record-info-title {
        font-weight: normal;
        width: 72px;
        font-size: 14px;
        color: rgba(255,255,255,0.45);
      }
      .record-info-content {
        flex: 1;
        font-size: 14px;
      }
    }
    &::after {
      height: 1px;
      background: #0E1116;
      width: 100%;
      content: '';
      display: inline-block;
    }
  }
  .direct-record-status {
    padding-left: 12px;
    padding-right: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .status-title {
      display: flex;
      align-items: center;
      &.use-support {
        color: orange;
        font-size: 14px;
      }
      .u-icon {
        width: 12px;
        height: 20px;
        background: url(../../../assets/img/disk_status.png) no-repeat center center;
      }
      .u-status-title {
        padding-left: 8px;
        font-size: 14px;
      }
    }
    .status-use-precent {
      .font-title-table {
        font-size: 14px;
      }
    }
  }

}
</style>
