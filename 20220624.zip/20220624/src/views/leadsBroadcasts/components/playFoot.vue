<template>
  <div
    class="play-foot-item"
    @mousedown.stop="moveItem($event)"
    @mouseup="moveUpItem($event)"
  >
    <div class="play-item-control">
      <div class="flex-play-item">
        <input
          v-for="item in switchBut"
          :key="item.value"
          type="button"
          :class="{'primary': isMain === item.value}"
          class="default default-border-radius"
          :value="item.label"
          @click="swtichMainStream(item.value)"
        >
        <div class="paddingLeft8">
          <el-select
            v-model="chnId"
            class="border-select-default"
            placeholder="请选择"
            @change="changeSvrChnId"
          >
            <el-option
              v-for="item in svrAlias"
              :key="item.NvrChnId"
              :label="item.SvrChnAlias"
              :value="item.NvrChnId"
            />
          </el-select>
        </div>

      </div>
      <input
        type="button"
        class="default default-border-radius browse"
        value="浏览"
        :class="{'isActive': isactive}"
        @click="isBrowse"
      >
    </div>
    <div
      v-if="playStream"
      :id="'play_stream_'+ idIndex"
      :class="['play-stream-item', {'active': activeId === idIndex }]"
      @click.stop="chooseItem"
    />
  </div>
</template>

<script>
import { KMediaUni } from 'kmedia-uni'
import store from '@/store'
import Cookies from 'js-cookie'
import { getRtspUrlRealStream } from '@/api/interactive.js'
import { getWebsocketAccess } from '@/api/resourceManage'
window.KMediaUni = KMediaUni
export default {
  props: {
    idIndex: {
      default: 1,
      type: Number
    },
    svrAlias: {
      type: Array,
      default() {
        return []
      }
    },
    activeId: {
      type: Number,
      default: -1
    },
    volumeSet: {
      type: Number,
      default: 0
    },
    capList: {
      type: Array,
      default() {
        return []
      }
    },
    isMuted: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      playStream: true,
      isActive: false,
      chnId: '1',
      nvrEncId: 1,
      isMain: 'main',
      player: null,
      isactive: false,
      websocketIp: '',
      port: 80,
      switchBut: [
        {
          label: '主流',
          value: 'main'
        },
        {
          label: '辅流',
          value: 'stream'
        }
      ]
    }
  },
  watch: {
    volumeSet() {
      // this.setPlayVolume()
    },
    isMuted(newValue) {
      if (newValue) {
        this.player.volume(50)
      } else {
        this.player.volume(0)
      }
    }
  },
  beforeDestroy() {
    if (this.player) {
      this.player.volume(0)
      this.player.destroy()
      this.playStream = false
      this.initPlay()
    }
  },
  mounted() {
    this.initPlayFootInfo()
  },
  methods: {
    initPlayFootInfo() {
      this.chnId = Cookies.get('nvr' + this.idIndex + '')
        ? Cookies.get('nvr' + this.idIndex + '')
        : '1'
      this.nvrEncId =
        Cookies.get('isMain' + this.idIndex + '') === 'stream' ? 2 : 1
      this.isMain =
        Cookies.get('isMain' + this.idIndex + '') === 'stream'
          ? 'stream'
          : 'main'
      this.initPlayFoot()
    },
    setPlayVolume() {
      if (this.activeId === this.idIndex) {
        this.player.volume(50)
        // this.player.volume(this.volumeSet)
      } else {
        this.player.volume(0)
      }
    },
    initPlayFoot() {
      this.player = this.initPlay()
      this.isactive = Cookies.get('isactive' + this.idIndex + '') === 'true'
      if (this.isactive) {
        this.playFootVideo()
      }
    },
    initPlay() {
      this.playStream = true
      const options = {
        selector: document.getElementById('play_stream_' + this.idIndex),
        loading: true,
        control: {
          hideControlsBar: true
        },
        request: {
          restore: 10,
          timeout: 50000
        },
        autoplay: false,
        muted: true,
        FILL_TYPE: 'RATIO_16_9'
      }
      const playItem = new KMediaUni(options)
      playItem.addEventListener('loadedmetadata', () => {
        if (this.activeId === this.idIndex) {
          playItem.volume(50)
        } else {
          playItem.muted(true)
        }
        playItem.play()
      })
      return playItem
    },
    loadVideoUrl(url) {
      getWebsocketAccess({}).then((res) => {
        const websocket = res.GetWebsocketAccessResp.RtspOverUrl
        let websocketUrl = ''
        if (websocket.match(/(ws+:\/\/(.+):\d{0,4})/)) websocketUrl = RegExp.$1
        this.player.loadVideo({
          src: {
            websocketUrl: websocketUrl,
            rtspUrl: url,
            username: this.$store.getters.username,
            password: this.$store.getters.pwd
          },
          transport: KMediaUni.MODE.MSE
        })
      })
    },
    swtichMainStream(main) {
      // 主辅流切换
      this.isMain = main
      if (this.isMain === 'main') {
        // 主流
        this.nvrEncId = 1
        if (this.isactive) {
          this.playFootVideo()
        }
      } else if (this.isMain === 'stream') {
        // 辅流
        this.nvrEncId = 2
        if (this.isactive) {
          this.playFootVideo()
        }
      }
      Cookies.set('isMain' + this.idIndex + '', this.isMain)
    },
    isBrowse() {
      // 浏览操作
      this.isactive = !this.isactive
      Cookies.set('isactive' + this.idIndex + '', this.isactive)
      if (this.isactive) {
        // 浏览
        this.playFootVideo()
      } else {
        // 取消浏览
        this.player.destroy()
        this.playStream = false
        // document.getElementsByClassName('play-stream-item')[0].innerHTML = ''
        this.player = this.initPlay()
      }
    },
    changeSvrChnId() {
      // 切换通道id
      const itemNvr = this.svrAlias.find((item) => item.NvrChnId === this.chnId)
      /* this.nvrEncId = itemNvr.EncId */
      Cookies.set('nvr' + this.idIndex + '', itemNvr.NvrChnId)
      if (this.isactive) {
        this.playFootVideo()
      }
    },
    playFootVideo() {
      this.getUrlRealStream().then((res) => {
        const rtspUrl = res.GetRtspUrlRealStreamResp.RtspUrl
        this.port = Number(res.GetRtspUrlRealStreamResp.Port)
        this.loadVideoUrl(rtspUrl)
      })
    },
    getUrlRealStream() {
      // 获取播放url
      return new Promise((resolve, reject) => {
        let szXml = '<contentroot>'
        szXml += '<authenticationinfo type="7.0">'
        szXml += '<username>' + store.getters.username + '</username>'
        szXml += '<password>' + store.getters.password + '</password>'
        szXml +=
          '<authenticationid>' + store.getters.authId + '</authenticationid>'
        szXml += '</authenticationinfo>'
        szXml += '<GetRtspUrlRealStreamReq>'
        szXml += '<NvrChnID>' + this.chnId + '</NvrChnID>'
        szXml +=
          '<TransType>' +
          (Cookies.get('TransType') ? Cookies.get('TransType') : 'tcp') +
          '</TransType>'
        szXml += '<VideoList num="1">'
        szXml += '<EncID>' + this.nvrEncId + '</EncID>'
        szXml += '</VideoList>'
        szXml += '<AudioList num="1">'
        szXml += '<SrcID>1</SrcID>'
        szXml += '</AudioList>'
        szXml += '</GetRtspUrlRealStreamReq>'
        szXml += '</contentroot>'
        getRtspUrlRealStream(szXml)
          .then((res) => {
            resolve(res)
          })
          .catch(_ => {
            reject()
          })
      })
    },
    chooseItem() {
      /* this.isActive = true */
      // this.player.volume(this.volumeSet)
      this.player.volume(50)
      this.$emit('changActive', this.idIndex, this.chnId)
    },
    moveItem(event) {
      // 拖动触发更改
      const PictureItem = {
        EncId:
          this.chnId === '9' ? 0 : this.chnId === '8' ? 0 : this.nvrEncId - 1,
        NvrChnId: this.chnId,
        SrcType:
          this.chnId <= 6
            ? 'chn'
            : this.capList[this.chnId - 7].ChnType === 'composite_extenc'
              ? 'cap'
              : 'chn'
      }
      let isSynthetic = false
      if (this.chnId === '7') isSynthetic = true
      this.$emit('smallPic', PictureItem, isSynthetic)
    },
    moveUpItem(event) {
      this.$emit('smallPic', {}, true)
    }
  }
}
</script>

<style lang="scss">
.play-foot-item {
  height: 100%;
  padding: 4px;
  background-color: #2a313e;
  .play-item-control {
    padding: 2px;
    display: flex;
    justify-content: space-between;
    .default {
      border: none;
      &.browse {
        background: #8490a9;
        &:hover {
          background: #1f75ff;
        }
      }
      &.isActive {
        background: #1f75ff;
        &:hover {
          background: #1f75ff;
        }
      }
    }
    .primary {
      border: none;
    }
    .flex-play-item {
      display: flex;
      align-items: center;
      .paddingLeft8 {
        padding-left: 8px;
      }
    }
  }
  .play-stream-item {
    width: 352px;
    height: 198px;

    &.active {
      border: 2px solid skyblue;
    }
  }
}
</style>
