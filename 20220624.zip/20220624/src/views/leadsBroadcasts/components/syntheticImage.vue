<template>
  <div class="direct-synthetic-image">
    <div class="direct-synthentic-contain">
      <el-form :rules="rules" ref="synthForm" :model="synthCourseInfo">
        <el-form-item>
          <div class="record-info-item">
            <label for="" class="record-info-title">视频分辨率:</label>
            <div class="direct-input-container">
              <el-select v-model="synthCourseInfo.Resolution" :disabled="isRecoding" class="border-select-default" placeholder="请选择">
                <el-option
                  v-for="item in resolutionInfo"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
              <span class="paddingLeft16 font-title-table width124"></span>
            </div>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="record-info-item">
            <label for="" class="record-info-title">编码格式:</label>
            <div class="direct-input-container">
              <el-select v-model="synthCourseInfo.EncType" :disabled="isRecoding" class="border-select-default" placeholder="请选择">
                <el-option
                  v-for="item in encTypeInfo"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
              <span class="paddingLeft16 font-title-table width124"></span>
            </div>
          </div>
        </el-form-item>
        <el-form-item prop="FrameRate">
          <div class="record-info-item">
            <label for="" class="record-info-title">视频帧率:</label>
            <div class="direct-input-container">
              <el-input type="text" :disabled="isRecoding" oninput="value=value.replace(/\D/g,'')" v-model.number="synthCourseInfo.FrameRate" class="border-input-default default-border-radius" />
              <span class="paddingLeft16 font-title-table width124">1-30 (fps)</span>
            </div>
          </div>
        </el-form-item>
        <el-form-item prop="BitRate">
          <div class="record-info-item">
            <label for="" class="record-info-title">平均码率:</label>
            <div class="direct-input-container">
              <el-input type="text" :disabled="isRecoding" oninput="value=value.replace(/\D/g,'')" v-model.number="synthCourseInfo.BitRate" class="border-input-default default-border-radius" />
              <span class="paddingLeft16 font-title-table width124">64-8192 (kbps)</span>
            </div>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="record-info-item">
            <label for="" class="record-info-title">编码复杂度:</label>
            <div class="direct-input-container">
              <el-select :disabled="isRecoding" v-model="synthCourseInfo.ProfileLevel" class="border-select-default" placeholder="请选择">
                <el-option
                  v-for="item in complexity"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
              <span class="paddingLeft16 font-title-table width124"></span>
            </div>
          </div>
        </el-form-item>
        <el-form-item prop="KeyframeInterval">
          <div class="record-info-item">
            <label for="" class="record-info-title">关键帧间隔:</label>
            <div class="direct-input-container">
              <el-input type="text" :disabled="isRecoding" oninput="value=value.replace(/\D/g,'')" v-model.number="synthCourseInfo.KeyframeInterval" class="border-input-default default-border-radius" />
              <span class="paddingLeft16 font-title-table width124">1-75 (帧)</span>
            </div>
          </div>
        </el-form-item>

      </el-form>
      <div class="record-info-item">
        <label for="" class="record-info-title">音频格式:</label>
        <div class="direct-input-container">
          <el-select v-model="audioType" :disabled="isRecoding" class="border-select-default" placeholder="请选择">
            <el-option
              v-for="item in audioTypeList"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <span class="paddingLeft16 font-title-table width124"></span>
        </div>
      </div>
      <el-form :rules="rules" :model="mergeInfo" ref="mergeForm">
        <el-form-item>
          <div class="record-info-item">
            <label for="" class="record-info-title">叠加时间:</label>
            <div class="direct-input-container">
              <el-checkbox :disabled="isRecoding" v-model="mergeInfo.IsTimeEnable" @change="addTime"></el-checkbox>
            </div>
          </div>
        </el-form-item>
        <el-form-item prop="TimeX">
          <div class="record-info-item">
            <label for="" class="record-info-title">X轴坐标:</label>
            <div class="direct-input-container">
              <el-input type="text" :disabled="isRecoding" oninput="value=value.replace(/\D/g,'')" v-model.number="mergeInfo.TimeX" class="border-input-default default-border-radius" @change="changeOxias('X')" />
              <span class="paddingLeft16 font-title-table width124">0-1920</span>
            </div>
          </div>
        </el-form-item>
        <el-form-item prop="TimeY">
          <div class="record-info-item">
            <label for="" class="record-info-title">Y轴坐标:</label>
            <div class="direct-input-container">
              <el-input type="text" :disabled="isRecoding" oninput="value=value.replace(/\D/g,'')" v-model.number="mergeInfo.TimeY" class="border-input-default default-border-radius" @change="changeOxias('Y')" />
              <span class="paddingLeft16 font-title-table width124">0-1080</span>
            </div>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="record-info-item">
            <label for="" class="record-info-title">画面边框:</label>
            <div class="direct-input-container">
              <el-select :disabled="isRecoding" v-model="mergeInfo.BorderWidth" @change="borderChange" class="border-select-default" placeholder="请选择">
                <el-option
                  v-for="item in borderWInfo"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
              <span class="paddingLeft16 font-title-table width124"></span>
            </div>
          </div>
        </el-form-item>
      </el-form>
      <div class="record-info-item">
        <label for="" class="record-info-title">边框颜色:</label>
        <div class="direct-input-container border-color">
          <!-- <el-select v-model="courseware" class="border-select-default input-width-default" placeholder="请选择">
            <el-option
              v-for="item in coursewareList"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select> -->
          <el-color-picker
            v-model="color"
            @change="selfBorderColor"
            color-format="rgb"
            :disabled="isRecoding"
            :predefine="predefineColors">
          </el-color-picker>
          <span class="paddingLeft16 font-title-table width124"></span>
        </div>
      </div>
      <div class="record-info-item paddingLeft12">
        <input type="button" @click="saveSynthInfo" value="保存" class="primary" />
      </div>
    </div>
  </div>
</template>

<script>
import { getCmpMergeStyleParam,getPptChnVidEncParam,setPptChnVidEncParam,setAmtAudType,setCmpChnVidEncParam,getCmpChnVidEncParam,getSvrStateEx } from '@/api/leadsBroadcasts.js'
import eventBus from '@/utils/eventBus.js'
export default {
  data() {
    return {
      //自定义颜色
      rules: {
        FrameRate: [{ max: 30, min: 1, type: 'number', message: '不在可取范围之内', trigger: 'blur' }],
        BitRate: [{ max: 8192, min: 64, type: 'number', message: '不在可取范围之内', trigger: 'blur' }],
        KeyframeInterval: [{ max: 75, min: 1, type: 'number', message: '不在可取范围之内', trigger: 'blur' }],
        TimeX: [{ max: 1920, min: 0, type: 'number', message: '不在可取范围之内', trigger: 'blur' }],
        TimeY: [{ max: 1080, min: 0, type: 'number', message: '不在可取范围之内', trigger: 'blur' }]
      },
      color: 'rgb(255, 255,255)',
      predefineColors: [
        '#ff4500',
        '#ff8c00',
        '#ffd700',
        '#90ee90',
        '#00ced1',
        '#1e90ff',
        '#c71585',
        '#000000',
        'rgba(255, 69, 0, 0.68)',
        'rgb(255, 120, 0)',
        'hsv(51, 100, 98)',
        'hsva(120, 40, 94, 0.5)',
        'hsl(181, 100%, 37%)',
        'hsla(209, 100%, 56%, 0.73)',
        '#c7158577'
      ],
      audioType: 'aaclc16_mono',
      audioTypeList: [
        {
          label: 'PCMA',
          value: 'g711a'
        },
        {
          label: 'PCMU',
          value: 'g711u'
        },
        /* {
          label: 'G722',
          value: 'g722'
        }, */
        /* {
          label: 'ADPCM',
          value: 'adpcm'
        }, */
        {
          label: 'AACLC_16(单声道)',
          value: 'aaclc16_mono'
        },
        {
          label: 'AACLC_16(双声道)',
          value: 'aaclc16_stereo'
        },
        {
          label: 'AACLC_32(单声道)',
          value: 'aaclc32_mono'
        },
        {
          label: 'AACLC_32(双声道)',
          value: 'aaclc32_stereo'
        },
        {
          label: 'AACLC_48(单声道)',
          value: 'aaclc48_mono'
        },
        {
          label: 'AACLC_48(双声道)',
          value: 'aaclc48_stereo'
        }
      ],
      mergeInfo: {
        BorderWidth: 2,
        ChgNum: 1,
        IsTimeEnable: false,
        MergeStyle: 'only_one',
        TimeX: 0,
        TimeY: 0,
        BorderColor: {
          R: 255,
          G: 255,
          B: 255
        },
        PictureList: {
          PictureItem: []
        }
      },
      borderWInfo: [
        {
          value: '0',
          label: '0像素'
        },
        {
          value: '2',
          label: '2像素'
        },
        {
          value: '4',
          label: '4像素'
        }
      ],
      complexity: [
        {
          label: 'BASELINE',
          value: 'baseline'
        },
        {
          label: 'MAIN',
          value: 'main_profile'
        },
        {
          label: 'HIGH',
          value: 'high_profile'
        }
      ],
      encTypeInfo: [
        {
          label: 'H264',
          value: 'H264'
        },
        {
          label: 'H265',
          value: 'H265'
        }
      ],
      resolutionInfo: [
        {
          label: '1280*720',
          value: '1280*720'
        },
        {
          label: '1920*1080',
          value: '1920*1080'
        }
      ],
      synthCourseInfo: {
        BitRate: '',
        EncType: '',
        FrameRate: '',
        KeyframeInterval: '',
        ProfileLevel: '',
        Resolution: ''
      }
    }
  },
  props: {
    synthCourInfo: {
      type: Object,
      default: {}
    },
    isRecoding: {
      type: Boolean,
      default: false
    }
  },
  mounted() {
    this.initSynthImg()
  },
  methods: {
    initSynthImg() {
      this.getAudType().then(res => {
        this.audioType = res.SvrStateResp.AmtAudType
      })
      this.getSyntheticInfo().then(res => {
        this.mergeInfo = res.GetCmpMergeStyleParamResp.MergeCfg
        this.mergeInfo.IsTimeEnable = this.mergeInfo.IsTimeEnable == 'false' ? false : true
        this.color = 'rgb('+ Number(this.mergeInfo.BorderColor.R) +','+ Number(this.mergeInfo.BorderColor.G) +','+ Number(this.mergeInfo.BorderColor.B) +')'
        this.mergeInfo.TimeX = Number(this.mergeInfo.TimeX)
        this.mergeInfo.TimeY = Number(this.mergeInfo.TimeY)
      })
      this.getSynthCoursewareInfo().then(res => {
        this.synthCourseInfo = res.GetCmpChnVidEncParamResp.VidEncParam
        this.synthCourseInfo.FrameRate = Number(this.synthCourseInfo.FrameRate)
        this.synthCourseInfo.BitRate = Number(this.synthCourseInfo.BitRate)
        this.synthCourseInfo.KeyframeInterval = Number(this.synthCourseInfo.KeyframeInterval)
      })
    },
    getAudType() {
      return new Promise( (resolve,reject) => {
        getSvrStateEx({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      } )
    },
    getSyntheticInfo() {
      return new Promise( (resolve,reject) => {
        getCmpMergeStyleParam({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      } )
    },
    getSynthCoursewareInfo() {
      return new Promise( (resolve,reject) => {
        getCmpChnVidEncParam({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      } )
    },
    setAudType() {
      return new Promise( (resolve,reject) => {
        let param = {
          SetAmtAudTypeReq: {
            AudType: this.audioType
          }
        }
        setAmtAudType(param).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      } )
    },
    setPptChnVidEnc() {
      return new Promise((resolve,reject) => {
        this.$refs.synthForm.validate((valid) => {
          if(valid) {
            let param = {
              SetCmpChnVidEncParamReq: {
                VidEncParam: this.synthCourseInfo
              }
            }
            setCmpChnVidEncParam(param).then(res => {
              resolve(res)
            }).catch(err => {
              reject(err)
            })
          }
        })
      })
    },
    saveSynthInfo() {
      this.$refs.mergeForm.validate(valid => {
        if(valid) {
          if(!this.isRecoding) {
            let setAud = this.setAudType()
            let setPpt = this.setPptChnVidEnc()
            Promise.all([setAud,setPpt]).then(res => {
              this.$emit('changeAudType')
              eventBus.$emit('infoChange',{
                audType: this.audioType,//音频格式
                videoRes: this.synthCourseInfo.Resolution//视频分辨率
              })
              this.$message({
                message: '保存成功',
                type: 'success'
              })
            })
          }
        }
      })
    },
    addTime() {
      this.$emit('overlayTime',this.mergeInfo.IsTimeEnable)
    },
    changeOxias(posi) {
      this.$refs.mergeForm.validate(valid => {
        if(valid) {
          let pos
          if(posi == "X") {
            pos = this.mergeInfo.TimeX
          }else {
            pos = this.mergeInfo.TimeY
          }
          this.$emit('coordinates',pos,posi)
        }
      })
    },
    borderChange() {
      this.$emit('borderSwtich',this.mergeInfo.BorderWidth)
    },
    selfBorderColor(col) {
      this.color = col
      this.$emit('borderColor',col)
    }
  }
}
</script>
<style lang="scss">
.direct-synthetic-image {
  .direct-synthentic-contain {
    .el-form {
      .el-form-item {
        >div {
           line-height: 32px !important;
        }
      }
    }
  }
  .direct-input-container {
    &.border-color {
      .is-disabled {
        > div:nth-child(1) {
          display: none;
        }
      }
    }
  }
}
</style>
<style scoped lang="scss">
.direct-synthetic-image {
  .direct-synthentic-contain {
    padding-bottom: 12px;
    padding-right: 12px;
    .record-info-item {
      display: flex;
      align-items: center;
      padding-top: 6px;
      padding-bottom: 6px;
      &.paddingLeft12 {
        padding-left: 12px;
        padding-bottom: 12px;
        .primary {
          width: 100%;
        }
      }
      .record-info-title {
        font-weight: normal;
        width: 96px;
        padding-left: 12px;
        font-size: 14px;
        color: rgba(255,255,255,0.45);
      }
      .direct-input-container {
        display: flex;
        flex: 1;
        align-items: center;
        > div {
          flex: 1;
        }
        .width124 {
          width: 124px;
        }
      }
    }
  }
}
</style>
