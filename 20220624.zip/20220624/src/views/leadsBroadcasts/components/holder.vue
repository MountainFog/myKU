<template>
  <div class="direct-holder">
    <div class="direct-holder-circle">
      <div class="direct-circle-traject">
        <div class="direct-circle-traject-cont">
          <svg-icon
            icon-class="top"
            class="icon-top icon-bin-direct"
            @mousedown.stop="holderControl('move_up',{'TilSpeed': holderInfo.TilSpeed})"
            @mouseup.stop="stopMouse('move_up')"
            @mouseout.stop="stopMouse('move_up')"
          />
          <svg-icon
            icon-class="bottom"
            class="icon-bottom icon-bin-direct"
            @mousedown.stop="holderControl('move_down',{'TilSpeed': holderInfo.TilSpeed})"
            @mouseup.stop="stopMouse('move_down')"
            @mouseout.stop="stopMouse('move_down')"
          />
          <svg-icon
            icon-class="left"
            class="icon-left icon-bin-direct"
            @mousedown.stop="holderControl('move_left',{ 'PanSpeed': holderInfo.PanSpeed })"
            @mouseup.stop="stopMouse('move_left')"
            @mouseout.stop="stopMouse('move_left')"
          />
          <svg-icon
            icon-class="right"
            class="icon-right icon-bin-direct"
            @mousedown.stop="holderControl('move_right',{ 'PanSpeed': holderInfo.PanSpeed })"
            @mouseup.stop="stopMouse('move_right')"
            @mouseout.stop="stopMouse('move_right')"
          />
          <svg-icon
            icon-class="left_top"
            class="icon-left-top icon-bin-direct"
            @mousedown.stop="holderControl('move_leftup',{ 'PanSpeed': holderInfo.PanSpeed,'TilSpeed': holderInfo.TilSpeed })"
            @mouseup.stop="stopMouse('move_leftup')"
            @mouseout.stop="stopMouse('move_leftup')"
          />
          <svg-icon
            icon-class="right_top"
            class="icon-right-top icon-bin-direct"
            @mousedown.stop="holderControl('move_rightup',{ 'PanSpeed': holderInfo.PanSpeed,'TilSpeed': holderInfo.TilSpeed })"
            @mouseup.stop="stopMouse('move_rightup')"
            @mouseout.stop="stopMouse('move_rightup')"
          />
          <svg-icon
            icon-class="left_bottom"
            class="icon-left-bottom icon-bin-direct"
            @mousedown.stop="holderControl('move_leftdown',{ 'PanSpeed': holderInfo.PanSpeed,'TilSpeed': holderInfo.TilSpeed })"
            @mouseup.stop="stopMouse('move_leftdown')"
            @mouseout.stop="stopMouse('move_leftdown')"
          />
          <svg-icon
            icon-class="right_bottom"
            class="icon-right-bottom icon-bin-direct"
            @mousedown.stop="holderControl('move_rightdown',{ 'PanSpeed': holderInfo.PanSpeed,'TilSpeed': holderInfo.TilSpeed })"
            @mouseup.stop="stopMouse('move_rightdown')"
            @mouseout.stop="stopMouse('move_rightdown')"
          />
          <svg-icon
            icon-class="center"
            class="icon-center icon-bin-direct"
            @click="holderControl('reset')"
          />
        </div>
      </div>
      <div class="slider-block">
        <i
          title="步长降低"
          class="el-icon-remove-outline icon-minues"
        />
        <div class="slider-contain">
          <el-slider
            v-model="slider"
            @change="changeSliderValue"
          />
        </div>
        <i
          title="步长增高"
          class="el-icon-circle-plus-outline icon-plus"
        />
      </div>
      <div class="oper-button-contain">
        <div class="button-grounp">
          <div class="button-item">
            <el-tooltip
              content="拉近"
              :visible-arrow="false"
              placement="right-end"
            >
              <svg-icon
                icon-class="single"
                class="icon-single icon-oper"
                @mousedown.stop="holderControl('zoom_tele',{'IspSpeed': holderInfo.IspSpeed})"
                @mouseup.stop="stopMouse('zoom_tele')"
                @mouseout.stop="stopMouse('zoom_tele')"
              />
            </el-tooltip>
          </div>
          <div class="button-item">
            <el-tooltip
              content="拉远"
              :visible-arrow="false"
              placement="right-end"
            >
              <svg-icon
                icon-class="double"
                class="icon-double icon-oper"
                @mousedown.stop="holderControl('zoom_wide',{'IspSpeed': holderInfo.IspSpeed})"
                @mouseup.stop="stopMouse('zoom_wide')"
                @mouseout.stop="stopMouse('zoom_wide')"
              />
            </el-tooltip>
          </div>
          <div class="button-item button-item-dis" />
        </div>
        <div class="button-grounp">
          <div class="button-item">
            <el-tooltip
              content="聚近"
              :visible-arrow="false"
              placement="right-end"
            >
              <svg-icon
                icon-class="search_add"
                class="icon-search-add icon-oper"
                @mousedown.stop="holderControl('focus_near',{'IspSpeed': holderInfo.IspSpeed})"
                @mouseup.stop="stopMouse('focus_near')"
                @mouseout.stop="stopMouse('focus_near')"
              />
            </el-tooltip>
          </div>
          <div class="button-item">
            <el-tooltip
              content="聚远"
              :visible-arrow="false"
              placement="right-end"
            >
              <svg-icon
                icon-class="search_min"
                class="icon-search-minues icon-oper"
                @mousedown.stop="holderControl('focus_far',{'IspSpeed': holderInfo.IspSpeed })"
                @mouseup.stop="stopMouse('focus_far')"
                @mouseout.stop="stopMouse('focus_far')"
              />
            </el-tooltip>
          </div>
          <div class="button-item">
            <el-tooltip
              content="自动聚焦"
              :visible-arrow="false"
              placement="right-end"
            >
              <svg-icon
                icon-class="a"
                class="icon-a icon-oper"
                @mousedown.stop="holderControl('focus_auto')"
                @mouseup.stop="stopMouse('focus_auto')"
                @mouseout.stop="stopMouse('focus_auto')"
              />
            </el-tooltip>
          </div>
        </div>
        <div class="button-grounp">
          <div class="button-item">
            <el-tooltip
              content="增大光圈"
              :visible-arrow="false"
              placement="right-end"
            >
              <svg-icon
                icon-class="circle_holder"
                class="icon-circle icon-oper"
                @mousedown.stop="holderControl('iris_plus')"
                @mouseup.stop="stopMouse('iris_plus')"
                @mouseout.stop="stopMouse('iris_plus')"
              />
            </el-tooltip>
          </div>
          <div class="button-item">
            <el-tooltip
              content="缩小光圈"
              :visible-arrow="false"
              placement="right-end"
            >
              <svg-icon
                icon-class="circle_holder_dou"
                class="icon-ring icon-oper"
                @mousedown.stop="holderControl('iris_minus')"
                @mouseup.stop="stopMouse('iris_minus')"
                @mouseout.stop="stopMouse('iris_minus')"
              />
            </el-tooltip>
          </div>
          <div class="button-item">
            <el-tooltip
              content="自动光圈"
              :visible-arrow="false"
              placement="right-end"
            >
              <svg-icon
                icon-class="a"
                class="icon-a-active icon-oper"
                @mousedown.stop="holderControl('iris_auto')"
                @mouseup.stop="stopMouse('iris_auto')"
                @mouseout.stop="stopMouse('iris_auto')"
              />
            </el-tooltip>
          </div>
        </div>
      </div>
      <div class="preset-holder-contain">
        <div class="preset-title">预置位:</div>
        <div class="preset-opera">
          <div class="preset-input">
            <el-input
              v-model.number="preset"
              type="text"
              oninput="value=value.replace(/\D/g,'')"
              class="config-stream-input border-input-default default-border-radius"
            />
          </div>
          <div class="preset-btn-group flex-center">
            <div class="preset-add-min-contain">
              <div class="preset-add-min-top">
                <i
                  class="preset-add icon-add el-icon-arrow-up"
                  @click.stop="addPreset(1)"
                />
              </div>
              <div class="preset-add-min-bottom">
                <i
                  class="preset-min icon-add el-icon-arrow-down"
                  @click.stop="addPreset(-1)"
                />
              </div>
            </div>
            <div
              title="加载预位置"
              class="down-preset marginLeft16"
              @click="holderControl('preset_load',{'Number': preset})"
            >
              <i class="icon-down-preset icon-preset-btn" />
            </div>
            <div
              title="保存预位置"
              class="save-preset marginLeft16"
              @click="holderControl('preset_save',{'Number': preset})"
            >
              <i class="icon-save-preset icon-preset-btn" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { changePtz } from '@/api/leadsBroadcasts'
export default {
  props: {
    channelId: {
      // eslint-disable-next-line
      type: Number | String,
      default: ''
    }
  },
  data() {
    return {
      hasMouseout: false,
      slider: 30,
      preset: 5,
      activeClass: '',
      holderInfo: {
        AddrNum: 1,
        IspSpeed: 30,
        PanSpeed: 30,
        TilSpeed: 30,
        Number: 5,
        Wide: 0,
        Height: 0,
        XPos: 0,
        YPos: 0,
        Mode: 'open',
        WinWide: 0,
        WinHeight: 0
      }
    }
  },
  methods: {
    // 云台控件操作
    holderControl(type, addition) {
      this.activeClass = type
      // 未选中通道
      if (this.channelId === -1) {
        this.$message({
          type: 'warning',
          message: '请先选择需要操作的通道对应的设备'
        })
        return
      }

      // 禁止操作的通道号
      const forbid = [7, 8, 9]
      if (forbid.indexOf(Number(this.channelId)) > -1) return

      // 没有停止指令的操作
      const notStop = ['reset']
      // 当前操作具有停止指令 允许触发mouse事件
      this.hasMouseout = !(notStop.indexOf(type) > -1)

      var params = {
        PtzReq: {
          NvrChnID: this.channelId,
          CmdType: type
        }
      }
      // 操作指令添加到请求参数
      if (addition) {
        for (const key in addition) {
          if (Object.hasOwnProperty.call(addition, key)) {
            params.PtzReq[key] = addition[key]
          }
        }
      }
      // 发送操作到服务器
      changePtz(params)
    },
    addPreset(num) {
      this.preset += num
      if (this.preset <= 1) {
        this.preset = 1
      }
    },
    stopMouse(type) {
      // 动作_方向 仅获取动作作为停止指令
      const stopType = type.split('_')[0]
      if (this.hasMouseout) {
        this.hasMouseout = false
        // 发送操作到服务器
        changePtz({
          PtzReq: {
            NvrChnID: this.channelId,
            CmdType: stopType + '_stop'
          }
        })
      }
    },
    changeSliderValue(val) {
      this.holderInfo.IspSpeed = val
      this.holderInfo.PanSpeed = val
      this.holderInfo.TilSpeed = val
    }
  }
}
</script>

<style scoped lang="scss">
.direct-holder {
  .direct-holder-circle {
    padding: 20px;
    .direct-circle-traject {
      display: flex;
      justify-content: center;
      .direct-circle-traject-cont {
        position: relative;
        width: 174px;
        height: 174px;
        background: url(../../../assets/img/all_holder.png) no-repeat center
          center;
        .icon-bin-direct {
          position: absolute;
          cursor: pointer;
          display: inline-block;
          color: #a9b4c9;
          font-size: 18px;
          cursor: pointer;
          &:active {
            color: #f7ab30;
          }
          &:hover {
            color: #f7ab30;
          }
        }
        .icon-top {
          top: 28px;
          left: 50%;
          margin-left: -9px;
        }
        .icon-bottom {
          left: 50%;
          margin-left: -9px;
          bottom: 28px;
        }
        .icon-left {
          top: 50%;
          left: 28px;
          margin-top: -9px;
        }
        .icon-right {
          top: 50%;
          right: 28px;
          margin-top: -9px;
        }
        .icon-center {
          top: 50%;
          left: 50%;
          width: 24px;
          height: 24px;
          transform: translateX(-50%) translateY(-50%);
        }
        .icon-left-top {
          left: 44px;
          top: 44px;
        }
        .icon-right-top {
          right: 44px;
          top: 44px;
        }
        .icon-left-bottom {
          left: 44px;
          bottom: 44px;
        }
        .icon-right-bottom {
          right: 44px;
          bottom: 44px;
        }
      }
    }
    .slider-block {
      display: flex;
      align-items: center;
      .icon-minues,
      .icon-plus {
        width: 16px;
        height: 16px;
        cursor: pointer;
      }
      .slider-contain {
        flex: 1;
        padding-left: 8px;
        padding-right: 8px;
      }
    }
    .oper-button-contain {
      .button-grounp {
        padding: 12px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        .button-item {
          width: 50px;
          height: 50px;
          background-image: linear-gradient(138deg, #242a36 0%, #2a313d 100%);
          border: 1px solid #151a23;
          box-shadow: -7px -7px 10px -1px rgba(187, 211, 255, 0.02),
            7px 7px 10px -1px rgba(0, 0, 0, 0.1);
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          &.button-item-dis {
            background: #2a313e;
            border: 1px solid #2a313e;
            box-shadow: none;
          }
          .icon-oper {
            width: 32px;
            height: 32px;
            cursor: pointer;
            &:hover {
              color: #f7ab30;
            }
            &.active {
              color: #f7ab30;
            }
          }
        }
      }
    }
    .preset-holder-contain {
      padding-top: 16px;
      .preset-title {
        font-size: 16px;
        line-height: 24px;
      }
      .preset-opera {
        padding-top: 8px;
        display: flex;
        align-items: center;
        .preset-btn-group {
          .preset-add-min-contain {
            .preset-add-min-top,
            .preset-add-min-bottom {
              width: 20px;
              height: 15px;
              border: 1px solid rgba(216, 222, 234, 0.2);
              border-left: none;
              display: flex;
              align-items: center;
              justify-content: center;
              background-color: rgba(13, 16, 22, 0.48);
              .icon-add {
                cursor: pointer;
                font-size: 12px;
              }
            }
            .preset-add-min-bottom {
              margin-top: 2px;
            }
          }
          .down-preset,
          .save-preset {
            width: 32px;
            height: 32px;
            background-image: linear-gradient(138deg, #242a36 0%, #2a313d 100%);
            border: 1px solid #151a23;
            box-shadow: -7px -7px 10px -1px rgba(187, 211, 255, 0.02),
              7px 7px 10px -1px rgba(0, 0, 0, 0.1);
            border-radius: 4px;
            cursor: pointer;
            .icon-preset-btn {
              width: 16px;
              height: 16px;
              display: inline-block;
              margin-top: 8px;
              margin-left: 8px;
              &.icon-down-preset {
                background: url(../../../assets/img/down_preset_holder.png)
                  no-repeat center center;
              }
              &.icon-save-preset {
                background: url(../../../assets/img/save_preset_holder.png)
                  no-repeat center center;
              }
            }
          }
        }
      }
    }
  }
}
</style>
