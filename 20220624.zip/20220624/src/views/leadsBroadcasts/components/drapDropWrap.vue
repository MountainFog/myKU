<template>
  <div
    :class="['drag-drop-wrap', 'style-type-' + styleType]"
    @mouseleave="leaveDragWrap"
    @click="handleClickModal"
    @dblclick="screen"
  >
    <div
      v-for="item in count"
      :key="item"
      :class="['drag-item', 'drag-item-' + item]"
      @mousedown="downEvent(item)"
      @mouseup="upEvent(item)"
    />
  </div>
</template>
<script>
export default {
  props: {
    styleType: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {
      count: 4,
      orignalNode: null
    }
  },
  methods: {
    screen() {
      this.$emit('dbclick-event')
    },
    // 离开拖拽框 清除节点
    leaveDragWrap() {
      this.orignalNode = null
    },
    // 鼠标按下 记录节点
    downEvent(item) {
      this.orignalNode = item
      this.$emit('down-node', item)
    },
    // 鼠标抬起 清除节点
    upEvent(item) {
      if (!this.orignalNode) {
        // 由外部拖入
        this.$emit('external-node', item)
        return
      }
      // 未发生节点拖拽
      if (this.orignalNode === item) {
        this.orignalNode = null
        return
      }
      // 内部交换位置
      this.orignalNode = null
      this.$emit('up-node', item)
    },
    // 检查当前元素的父类元素
    findClassNode(dom, name) {
      if (dom.className.indexOf(name) > -1) {
        return dom
      }
      return this.findParentClass(dom.parentNode, name)
    },
    handleClickModal() {
      this.$emit('handleClickModal')
    }
  }
}
</script>
<style lang="scss">
  .drag-drop-wrap {
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 40px;
    z-index: 1;
    user-select: none;

    .drag-item {
      position: absolute;
      z-index: 2;
    }
  }

// 样式1
.style-type-1,.style-type-3,.style-type-4,.style-type-5,.style-type-6 {
  .drag-item-1 {
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
  }
}

// 样式2
.style-type-2 {
  .drag-item-1 {
    left: 0;
    top: 25%;
    width: 50%;
    height: 50%;
  }

  .drag-item-2 {
    left: 50%;
    top: 25%;
    width: 50%;
    height: 50%;
  }
}

// 样式3
.style-type-3 {
  .drag-item-2 {
    left: 0;
    top: 0;
    width: 33.3%;
    height: 33.3%;
  }
}

// 样式4
.style-type-4 {
  .drag-item-2 {
    right: 0;
    top: 0;
    width: 33.3%;
    height: 33.3%;
  }
}

// 样式5
.style-type-5 {
  .drag-item-2 {
    left: 0;
    bottom: 0;
    width: 33.3%;
    height: 33.3%;
  }
}

// 样式6
.style-type-6 {
  .drag-item-2 {
    right: 0;
    bottom: 0;
    width: 33.3%;
    height: 33.3%;
  }
}

// 样式7
.style-type-7 {
  .drag-item-1 {
    left: 25%;
    top: 0;
    width: 50%;
    height: 50%;
  }

  .drag-item-2 {
    left: 0;
    bottom: 0;
    width: 50%;
    height: 50%;
  }

  .drag-item-3 {
    right: 0;
    bottom: 0;
    width: 50%;
    height: 50%;
  }
}

// 样式8
.style-type-8 {
  .drag-item-1 {
    left: 0;
    top: 16.7%;
    width: 66.7%;
    height: 66.7%;
  }
  .drag-item-2 {
    right: 0;
    top: 16.7%;
    width: 33.3%;
    height: 33.3%;
  }
  .drag-item-3 {
    right: 0;
    bottom: 16.7%;
    width: 33.3%;
    height: 33.3%;
  }
}

// 样式9
.style-type-9 {
  .drag-item {
    width: 50%;
    height: 50%;
  }

  .drag-item-1 {
    top: 0;
    left: 0;
  }
  .drag-item-2 {
    right: 0;
    top: 0;
  }
  .drag-item-3 {
    left: 0;
    bottom: 0;
  }
  .drag-item-4 {
    right: 0;
    bottom: 0;
  }
}

// 样式10
.style-type-10 {
  .drag-item {
    width: 33.3%;
    height: 33.3%;
  }

  .drag-item-1 {
    top: 0;
    left: 16.65%;
    width: 66.7%;
    height: 66.7%;
  }
  .drag-item-2 {
    left: 0;
    bottom: 0;
  }
  .drag-item-3 {
    left: 33.3%;
    bottom: 0;
  }
  .drag-item-4 {
    left: 66.6%;
    bottom: 0;
  }
}

// 样式11
.style-type-11 {
  .drag-item {
    width: 33.3%;
    height: 33.3%;
  }

  .drag-item-1 {
    left: 0;
    top: 16.65%;
    width: 66.7%;
    height: 66.7%;
  }
  .drag-item-2 {
    top: 0;
    right: 0;
  }
  .drag-item-3 {
    top: 33.3%;
    right: 0;
  }
  .drag-item-4 {
    top: 66.6%;
    right: 0;
  }
}
</style>
