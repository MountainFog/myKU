<template>
  <div class="direct-open-credits">
    <div class="direct-open-credits-contain">
      <el-form>
        <div class="direct-open-credits-mark-con">
          <div class="direct-open-credits-mark">
            <el-checkbox v-model="openInfo.CustomCaption.Enabled">台标</el-checkbox>
            <el-checkbox
              v-model="openInfo.Watermark.Enabled"
            >水印</el-checkbox>
            <el-button style="margin: 4px 0 0 16px" @click="stickerSetShow">
              详细配置
            </el-button>
            <!-- <input
              type="button"
              class="default default-border-radius"
              value="详细配置"
              @click.stop="stickerSetShow"
            > -->
          </div>
        </div>
        <div class="direct-open-credits-open">
          <div class="open-check">
            <el-checkbox v-model="openInfo.Title.Enabled">片头</el-checkbox>
          </div>
          <div class="open-content">
            <div class="config-stream-media flex-center">
              <label
                for=""
                class="config-title"
              >持续时间:</label>
              <el-select
                v-model="openInfo.Title.Duration"
                class="border-select-default input-width-default open-select-continuous config-stream-input"
                placeholder="请选择"
              >
                <el-option
                  v-for="item in durationInfo"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </div>
            <div class="open-check-item">
              <el-checkbox
                v-model="openInfo.Title.CourseName.Enabled"
                class="check-item"
              >课程名称</el-checkbox>
              <el-checkbox
                v-model="openInfo.Title.TeacherName.Enabled"
                class="check-item"
              >主讲教师</el-checkbox>
            </div>
            <div class="open-check-item">
              <el-checkbox
                v-model="openInfo.Title.UnitName.Enabled"
                class="check-item"
              >课程单位</el-checkbox>
              <el-checkbox
                v-model="openInfo.Title.DirectorName.Enabled"
                class="check-item"
              >导播模式</el-checkbox>
            </div>
            <div class="open-check-item">
              <el-checkbox
                v-model="openInfo.Title.Date.Enabled"
                class="check-item"
              >日期</el-checkbox>
              <el-checkbox
                v-model="openInfo.Title.Time.Enabled"
                class="check-item"
              >时间</el-checkbox>
            </div>
            <div class="open-check-button">
              <input
                type="button"
                value="详细配置"
                class="default default-border-radius"
                @click.stop="openingCreditSet('Title')"
              >
            </div>
          </div>
        </div>
        <div class="direct-open-credits-open">
          <div class="open-check">
            <el-checkbox v-model="openInfo.Ending.Enabled">片尾</el-checkbox>
          </div>
          <div class="open-content">
            <div class="config-stream-media flex-center">
              <label
                for=""
                class="config-title"
              >持续时间:</label>
              <el-select
                v-model="openInfo.Ending.Duration"
                class="border-select-default input-width-default open-select-continuous config-stream-input"
                placeholder="请选择"
              >
                <el-option
                  v-for="item in durationInfo"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </div>
            <div class="open-check-item">
              <el-checkbox
                v-model="openInfo.Ending.CourseName.Enabled"
                class="check-item"
              >课程名称</el-checkbox>
              <el-checkbox
                v-model="openInfo.Ending.TeacherName.Enabled"
                class="check-item"
              >主讲教师</el-checkbox>
            </div>
            <div class="open-check-item">
              <el-checkbox
                v-model="openInfo.Ending.UnitName.Enabled"
                class="check-item"
              >课程单位</el-checkbox>
              <el-checkbox
                v-model="openInfo.Ending.DirectorName.Enabled"
                class="check-item"
              >导播模式</el-checkbox>
            </div>
            <div class="open-check-item">
              <el-checkbox
                v-model="openInfo.Ending.Date.Enabled"
                class="check-item"
              >日期</el-checkbox>
              <el-checkbox
                v-model="openInfo.Ending.Time.Enabled"
                class="check-item"
              >时间</el-checkbox>
            </div>
            <div class="open-check-button">
              <input
                type="button"
                value="详细配置"
                class="default default-border-radius"
                @click.stop="openingCreditSet('Ending')"
              >
            </div>
          </div>
        </div>
        <div class="direct-open-save">
          <input
            type="button"
            value="保存"
            class="primary default-border-radius"
            @click.stop="setOpeningCredInfo"
          >
        </div>
      </el-form>
    </div>
    <el-dialog
      :close-on-click-modal="false"
      title="台标设置"
      class="font-title-color sticker-set-dialog"
      :visible.sync="stickerSet"
    >
      <el-form
        :model="form"
        label-position="left"
      >

        <el-form-item>
          <el-checkbox v-model="openInfo.CustomCaption.Enabled">台标</el-checkbox>
          <el-input
            v-model="openInfo.CustomCaption.Caption.Content"
            placeholder="请输入台标"
            style="width: 200px;margin-left:16px;"
          />
        </el-form-item>

        <div class="stick-item">
          <el-form-item
            label="对齐方式:"
            :label-width="formLabelWidth"
          >
            <el-select
              v-model="alignment"
              class="border-select-default"
              placeholder="请选择传输协议"
            >
              <el-option
                v-for="item in hAlignment"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            label="字体大小:"
            :label-width="formLabelWidth"
          >
            <el-select
              v-model="FontSize"
              class="border-select-default"
              placeholder="请选择传输协议"
            >
              <el-option
                v-for="item in fontSizeList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            label="字体颜色:"
            :label-width="formLabelWidth"
            style="height:40px;"
          >
            <el-color-picker
              v-model="color"
              color-format="rgb"
              :predefine="predefineColors"
              @change="changeActive"
            />
          </el-form-item>
        </div>
        <el-checkbox
          v-model="openInfo.Watermark.Enabled"
          class="font-title-table"
        >水印</el-checkbox>
        <p class="stick-wraning">注：水印图片请采用尺寸宽高比为16：9的图片，显示效果最佳</p>
        <div ref="logoConfig" class="stick-item-point">
          <div
            v-show="openInfo.Watermark.Enabled"
            ref="OsdMark"
            class="open-cred-point"
            :style="setDefaultStyle"
            @mousedown="addDragEvent($event, {'key':'Watermark','keyd':openInfo.Watermark,'attrs':'OsdMark'}, 'logoConfig')"
          >
            <el-upload
              ref="watermarkUpload"
              class="image-uploader"
              :action="baseUrl + '/nvrcgi2/upload/disk/01_02/watermark.bmp'"
              :show-file-list="false"
              :auto-upload="false"
              :on-change="handleStateChange"
              :on-success="handleUploadSuccess"
              :on-error="handleUploadErr"
            >
              <template slot="trigger">
                <div class="avatar-uploader-icon"><i class="el-icon-plus" /></div>
              </template>
              <img v-if="imageUrl" :src="imageUrl" draggable="false" class="image-preview">
            </el-upload>
          </div>
          <div ref="logoWrap" class="stick-point">
            <div
              id="drag_stick"
              ref="remark"
              class="drag-stick-item"
              :style="setLogoStyle"
              @mousedown="addDragEvent($event, null, 'logoWrap')"
            >台标</div>
            <!-- v-drag="{'size':FontSize,'wid': 300}" -->
          </div>
        </div>
      </el-form>
      <div
        slot="footer"
        class="dialog-footer"
      >
        <input
          type="button"
          class="default default-border-radius font-title-color"
          value="恢复默认值"
          @click="setDefault"
        >
        <div>
          <input
            type="button"
            class="primary default-border-radius"
            value="确认"
            @click="setStickInfo"
          >
          <input
            type="button"
            class="default default-border-radius font-title-color marginLeft16"
            value="取消"
            @click="stickerSet = false"
          >
        </div>

      </div>
    </el-dialog>

    <el-dialog
      ref="configDialog"
      :close-on-click-modal="false"
      :title="titleEndingTitle"
      class="font-title-color sticker-set-dialog"
      :visible.sync="stickerSetOpeningCred"
    >
      <el-form :model="titleEndingInfo">
        <div class="stick-item">
          <div class="stick-item-check">
            <el-checkbox
              v-model="titleEndingInfo.CourseName.Enabled"
              class="font-title-table"
              @change="changeBorderStyle('CourseName',titleEndingInfo.CourseName.Caption)"
            >课程名称</el-checkbox>
          </div>
          <div class="stick-item-check">
            <el-checkbox
              v-model="titleEndingInfo.TeacherName.Enabled"
              class="font-title-table"
              @change="changeBorderStyle('TeacherName',titleEndingInfo.TeacherName.Caption)"
            >主讲教师</el-checkbox>
          </div>
          <div class="stick-item-check">
            <el-checkbox
              v-model="titleEndingInfo.UnitName.Enabled"
              class="font-title-table"
              @change="changeBorderStyle('UnitName',titleEndingInfo.UnitName.Caption)"
            >课程单位</el-checkbox>
          </div>
          <div class="stick-item-check">
            <el-checkbox
              v-model="titleEndingInfo.DirectorName.Enabled"
              class="font-title-table"
              @change="changeBorderStyle('DirectorName',titleEndingInfo.DirectorName.Caption)"
            >导播模式</el-checkbox>
          </div>
          <div class="stick-item-check">
            <el-checkbox
              v-model="titleEndingInfo.Date.Enabled"
              class="font-title-table"
              @change="changeBorderStyle('Date',titleEndingInfo.Date.Caption)"
            >日期</el-checkbox>
          </div>
          <div class="stick-item-check">
            <el-checkbox
              v-model="titleEndingInfo.Time.Enabled"
              class="font-title-table"
              @change="changeBorderStyle('Time',titleEndingInfo.Time.Caption)"
            >时间</el-checkbox>
          </div>
        </div>
        <div class="stick-item">
          <el-form-item
            label="对齐方式:"
            :label-width="formLabelWidth"
          >
            <el-select
              v-model="alignment"
              class="border-select-default"
              placeholder="请选择传输协议"
              @change="changeAlignment"
            >
              <el-option
                v-for="item in hAlignment"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            label="字体大小:"
            :label-width="formLabelWidth"
          >
            <el-select
              v-model="FontSize"
              class="border-select-default"
              placeholder="请选择传输协议"
              @change="changeFontSize"
            >
              <el-option
                v-for="item in fontSizeList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            label="字体颜色:"
            class="open-color-picker"
            :label-width="formLabelWidth"
          >
            <el-color-picker
              v-model="openColor"
              color-format="rgb"
              :predefine="predefineColors"
              @change="openCredChangeColor"
            />
          </el-form-item>
        </div>
        <div class="stick-item-point">
          <div
            ref="canvasWrap"
            class="stick-point"
          >

            <div
              v-for="(value,key) in titleEndingInfo"
              v-show="openCredShow(value,key)"
              :key="key"
              :ref="key"
              class="open-cred-item"
              :style="openCredStyle(value,key)"
              @mousedown="addDragEvent($event, {'key':key,'keyd':value,'attrs': 'Caption'})"
            >{{ openCredTitle(key) }}</div>
            <!-- v-dragopen="{'key':key,'keyd':value,'attrs': 'Caption'}" -->
          </div>
        </div>
      </el-form>
      <div
        slot="footer"
        class="dialog-footer"
      >
        <input
          type="button"
          class="default default-border-radius font-title-color"
          value="恢复默认值"
          @click="setTitleEndingDefault"
        >
        <div>
          <input
            type="button"
            class="primary default-border-radius"
            value="确认"
            @click="ensureOpenCredSet"
          >
          <input
            type="button"
            class="default default-border-radius font-title-color marginLeft16"
            value="取消"
            @click="cancleFormData"
          >
        </div>

      </div>
    </el-dialog>
  </div>
</template>

<script>
import store from '@/store'
import { getOsdCfg, setOsdCfg } from '@/api/leadsBroadcasts.js'
export default {
  data() {
    return {
      // 禁止拖拽
      disabledDrag: true,
      diaSumWidth: 640,
      diaSumHeight: 360,
      widthPrecent: 640 / 1920,
      heightPrecent: 360 / 1080,
      uploadIsBlank: false,
      borderStyle: 'Watermark',
      borderValue: {},
      borderAttrs: 'OsdMark',
      markInfo: { size: 30, wid: 300 },
      PosX: 0,
      PosY: 0,
      selfSticker: false,
      titleEndingTitle: '片头设置',
      title: 'Title',
      color: 'rgb(255, 255,255)',
      openColor: 'rgb(255, 255,255)',
      predefineColors: [
        '#ff4500',
        '#ff8c00',
        '#ffd700',
        '#90ee90',
        '#00ced1',
        '#1e90ff',
        '#000000',
        '#c71585',
        'rgba(255, 69, 0, 0.68)',
        'rgb(255, 120, 0)',
        'hsv(51, 100, 98)',
        'hsva(120, 40, 94, 0.5)',
        'hsl(181, 100%, 37%)',
        'hsla(209, 100%, 56%, 0.73)',
        '#c7158577'
      ],
      defaultFontColor: 'rgb(255, 255,255)',
      defaultFontSize: 23,
      FontSize: 23,
      stickerSet: false,
      formLabelWidth: '80px',
      defaultAlignment: 'aligncenter',
      alignment: 'aligncenter',
      form: {},
      stickerSetOpeningCred: false,
      fontSizeList: [
        {
          value: 15,
          label: 30
        },
        {
          value: 23,
          label: 46
        },
        {
          value: 26,
          label: 52
        },
        {
          value: 28,
          label: 56
        },
        {
          value: 31,
          label: 62
        },
        {
          value: 33,
          label: 66
        },
        {
          value: 36,
          label: 72
        }
      ],
      hAlignment: [
        {
          value: 'alignleft',
          label: '居左对齐'
        },
        {
          value: 'alignright',
          label: '居右对齐'
        },
        {
          value: 'aligncenter',
          label: '居中对齐'
        }
      ],
      durationInfo: [
        {
          value: 5,
          label: 5
        },
        {
          value: 6,
          label: 6
        },
        {
          value: 7,
          label: 7
        },
        {
          value: 8,
          label: 8
        },
        {
          value: 9,
          label: 9
        },
        {
          value: 10,
          label: 10
        },
        {
          value: 11,
          label: 11
        },
        {
          value: 12,
          label: 12
        },
        {
          value: 13,
          label: 13
        },
        {
          value: 14,
          label: 14
        },
        {
          value: 15,
          label: 15
        }
      ],
      openInfo: {
        SysDate: {
          Enabled: false,
          Caption: {
            PosX: 0,
            PosY: 0,
            Width: 0,
            FontSize: 10,
            FontColor: {
              R: 255,
              G: 255,
              B: 255
            },
            HAlignment: '',
            VAlignment: ''
          }
        },
        CustomCaption: {
          Enabled: false,
          Caption: {
            PosX: 0,
            PosY: 0,
            Width: 0,
            FontSize: 10,
            FontColor: {
              R: 255,
              G: 255,
              B: 255
            },
            HAlignment: '',
            VAlignment: '',
            Content: ''
          }
        },
        Title: {
          Enabled: false,
          Duration: 10,
          BackGround: {
            Enabled: false,
            FilePath: '',
            FileName: ''
          },
          CourseName: {
            Enabled: false,
            Caption: {}
          },
          TeacherName: {
            Enabled: false,
            Caption: {}
          },
          UnitName: {
            Enabled: false,
            Caption: {}
          },
          DirectorName: {
            Enabled: false,
            Caption: {}
          },
          Date: {
            Enabled: false,
            Caption: {}
          },
          Time: {
            Enabled: false,
            Caption: {}
          }
        },
        Ending: {
          Enabled: false,
          Duration: 10,
          BackGround: {
            Enabled: false,
            FilePath: '',
            FileName: ''
          },
          CourseName: {
            Enabled: false,
            Caption: {}
          },
          TeacherName: {
            Enabled: false,
            Caption: {}
          },
          UnitName: {
            Enabled: false,
            Caption: {}
          },
          DirectorName: {
            Enabled: false,
            Caption: {}
          },
          Date: {
            Enabled: false,
            Caption: {}
          },
          Time: {
            Enabled: false,
            Caption: {}
          }
        },
        Watermark: {
          Enabled: true,
          OsdMark: {}
        }
      },
      titleEndingInfo: {
        Enabled: false,
        Duration: 10,
        BackGround: {
          Enabled: false,
          FilePath: '',
          FileName: ''
        },
        CourseName: {
          Enabled: false,
          Caption: {}
        },
        TeacherName: {
          Enabled: false,
          Caption: {}
        },
        UnitName: {
          Enabled: false,
          Caption: {}
        },
        DirectorName: {
          Enabled: false,
          Caption: {}
        },
        Date: {
          Enabled: false,
          Caption: {}
        },
        Time: {
          Enabled: false,
          Caption: {}
        }
      },
      imageUrl: ''
    }
  },
  computed: {
    alignStyle() {
      return this.alignment === 'aligncenter'
        ? 'center'
        : this.alignment === 'alignleft'
          ? 'left'
          : 'right'
    },
    setLogoStyle() {
      return {
        fontSize: this.FontSize + 'px',
        textAlign: this.alignStyle,
        color: this.color,
        top: this.openInfo.CustomCaption.Caption.PosY * this.heightPrecent + 'px',
        left: this.openInfo.CustomCaption.Caption.PosX * this.widthPrecent + 'px'
      }
    },
    // 设置水印默认样式
    setDefaultStyle() {
      if (this.openInfo && this.openInfo.Watermark) {
        const OsdMark = this.openInfo.Watermark.OsdMark
        return {
          left: OsdMark.PosX * this.widthPrecent + 'px',
          top: OsdMark.PosY * this.heightPrecent + 'px'
        }
      }
      return ''
    },
    baseUrl() {
      // return 'http://172.18.1.199:80'
      const origin = window.location.origin
      return origin
    }
  },
  mounted() {
    this.initOpeningCredInfo()
  },
  methods: {
    // 添加拖拽事件
    addDragEvent(evt, value, ref) {
      if (value) {
        this.borderStyle = value.key
        this.borderValue = value.keyd
        this.borderAttrs = value.attrs
      }
      const wrap = ref ? this.$refs[ref] : this.$refs.canvasWrap
      const drag = evt.currentTarget || document.querySelector('.open-cred-point')
      // 被拖拽节点在页面位置
      const diffX = evt.clientX - drag.offsetLeft
      const diffY = evt.clientY - drag.offsetTop
      let moveX = 0
      let moveY = 0
      this.disabledDrag = false
      // 是否拖拽
      let isMove = false
      document.onmousemove = (evt) => {
        if (this.disabledDrag) return
        isMove = true
        // 鼠标移动距离
        moveX = evt.clientX - diffX
        moveY = evt.clientY - diffY
        // x轴移动边界
        if (moveX < 0) {
          moveX = 0
        } else if (moveX > wrap.offsetWidth - drag.offsetWidth) {
          moveX = wrap.offsetWidth - drag.offsetWidth
        }
        // Y轴移动边界
        if (moveY < 0) {
          moveY = 0
        } else if (moveY > wrap.offsetHeight - drag.offsetHeight) {
          moveY = wrap.offsetHeight - drag.offsetHeight
        }
        // 拖拽目标移动
        drag.style.left = moveX + 'px'
        drag.style.top = moveY + 'px'
      }
      document.onmouseup = () => {
        this.disabledDrag = true
        if (!isMove) return
        // 被拖拽 并且是台标
        if (ref === 'logoWrap') {
          // 计算并更新台标偏移位置
          this.openInfo.CustomCaption.Caption.PosX = moveX / this.widthPrecent
          this.openInfo.CustomCaption.Caption.PosY = moveY / this.heightPrecent
          return
        }
        const borderStyle =
          this.borderStyle === 'Watermark' ? 'OsdMark' : this.borderStyle
        const refs = this.$refs[borderStyle][0]
        // 被拖拽 计算并更新水印偏移位置
        if (borderStyle === 'OsdMark') {
          this.borderValue.OsdMark.PosX = moveX / this.widthPrecent
          this.borderValue.OsdMark.PosY = moveY / this.heightPrecent
          return
        }
        // 其它元素偏移位置
        const PosX = parseInt(refs.offsetLeft / this.widthPrecent)
        const PosY = parseInt(refs.offsetTop / this.heightPrecent)
        this.titleEndingInfo[this.borderStyle][this.borderAttrs].PosX = PosX
        this.titleEndingInfo[this.borderStyle][this.borderAttrs].PosY = PosY
      }
    },
    initOpeningCredInfo() {
      this.getOpeningCredInfo().then((res) => {
        this.openInfo = res.GetOsdCfgResp
        this.openInfo.CustomCaption.Enabled =
          this.openInfo.CustomCaption.Enabled === 'true'
        this.openInfo.Title.Enabled = this.openInfo.Title.Enabled === 'true'
        this.openInfo.Title.BackGround.Enabled =
          this.openInfo.Title.BackGround.Enabled === 'true'
        this.openInfo.Title.CourseName.Enabled =
          this.openInfo.Title.CourseName.Enabled === 'true'
        this.openInfo.Title.TeacherName.Enabled =
          this.openInfo.Title.TeacherName.Enabled === 'true'
        this.openInfo.Title.UnitName.Enabled =
          this.openInfo.Title.UnitName.Enabled === 'true'
        this.openInfo.Title.DirectorName.Enabled =
          this.openInfo.Title.DirectorName.Enabled === 'true'
        this.openInfo.Title.Date.Enabled =
          this.openInfo.Title.Date.Enabled === 'true'
        this.openInfo.Title.Time.Enabled =
          this.openInfo.Title.Time.Enabled === 'true'

        this.openInfo.Ending.Enabled = this.openInfo.Ending.Enabled === 'true'
        this.openInfo.Ending.BackGround.Enabled =
          this.openInfo.Ending.BackGround.Enabled === 'true'
        this.openInfo.Ending.CourseName.Enabled =
          this.openInfo.Ending.CourseName.Enabled === 'true'
        this.openInfo.Ending.TeacherName.Enabled =
          this.openInfo.Ending.TeacherName.Enabled === 'true'
        this.openInfo.Ending.UnitName.Enabled =
          this.openInfo.Ending.UnitName.Enabled === 'true'
        this.openInfo.Ending.DirectorName.Enabled =
          this.openInfo.Ending.DirectorName.Enabled === 'true'
        this.openInfo.Ending.Date.Enabled =
          this.openInfo.Ending.Date.Enabled === 'true'
        this.openInfo.Ending.Time.Enabled =
          this.openInfo.Ending.Time.Enabled === 'true'
        this.openInfo.Watermark.Enabled =
          this.openInfo.Watermark.Enabled === 'true'
        this.form = res.GetOsdCfgResp.CustomCaption.Caption
      })
    },
    deepClone(obj) {
      const objClone = Array.isArray(obj) ? [] : {}
      if (obj && typeof obj === 'object') {
        for (const key in obj) {
          if (obj[key] && typeof obj[key] === 'object') {
            objClone[key] = this.deepClone(obj[key])
          } else {
            objClone[key] = obj[key]
          }
        }
      }
      return objClone
    },
    changeActive(col) {
      this.color = col
    },
    getOpeningCredInfo() {
      return new Promise((resolve, reject) => {
        const param = {
          GetOsdCfgReq: {
            Reset: false
          }
        }
        getOsdCfg(param)
          .then((res) => {
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    setOpeningCredInfo() {
      // diaSumWidth: 640,
      // diaSumHeight: 360,
      // widthPrecent: 640 / 1920,
      // heightPrecent: 360 / 1080,

      let szXml = '<contentroot>'
      szXml += '<authenticationinfo type="7.0">'
      szXml += '<username>' + store.getters.username + '</username>'
      szXml += '<password>' + store.getters.password + '</password>'
      szXml +=
        '<authenticationid>' + store.getters.authId + '</authenticationid>'
      szXml += '</authenticationinfo>'
      szXml += '<SetOsdCfgReq>'
      szXml += '<CustomCaption>'
      szXml += '<Enabled>' + this.openInfo.CustomCaption.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml += '<PosX>' + this.openInfo.CustomCaption.Caption.PosX + '</PosX>'
      szXml += '<PosY>' + this.openInfo.CustomCaption.Caption.PosY + '</PosY>'
      szXml +=
        '<Width>' + this.openInfo.CustomCaption.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.CustomCaption.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml += '<R>' + this.openInfo.CustomCaption.Caption.FontColor.R + '</R>'
      szXml += '<G>' + this.openInfo.CustomCaption.Caption.FontColor.G + '</G>'
      szXml += '<B>' + this.openInfo.CustomCaption.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.CustomCaption.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '<Content>'
      szXml += '<![CDATA[' + this.openInfo.CustomCaption.Caption.Content + ']]>'
      szXml += '</Content>'
      szXml += '</Caption>'
      szXml += '</CustomCaption>'
      szXml += '<Title>'
      szXml += '<Enabled>' + this.openInfo.Title.Enabled + '</Enabled>'
      szXml += '<Duration>' + this.openInfo.Title.Duration + '</Duration>'
      szXml += '<BackGround>'
      szXml +=
        '<Enabled>' + this.openInfo.Title.BackGround.Enabled + '</Enabled>'
      szXml += '</BackGround>'
      szXml += '<CourseName>'
      szXml +=
        '<Enabled>' + this.openInfo.Title.CourseName.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml +=
        '<PosX>' + this.openInfo.Title.CourseName.Caption.PosX + '</PosX>'
      szXml +=
        '<PosY>' + this.openInfo.Title.CourseName.Caption.PosY + '</PosY>'
      szXml +=
        '<Width>' + this.openInfo.Title.CourseName.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.Title.CourseName.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml +=
        '<R>' + this.openInfo.Title.CourseName.Caption.FontColor.R + '</R>'
      szXml +=
        '<G>' + this.openInfo.Title.CourseName.Caption.FontColor.G + '</G>'
      szXml +=
        '<B>' + this.openInfo.Title.CourseName.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Title.CourseName.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</CourseName>'
      szXml += '<TeacherName>'
      szXml +=
        '<Enabled>' + this.openInfo.Title.TeacherName.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml +=
        '<PosX>' + this.openInfo.Title.TeacherName.Caption.PosX + '</PosX>'
      szXml +=
        '<PosY>' + this.openInfo.Title.TeacherName.Caption.PosY + '</PosY>'
      szXml +=
        '<Width>' + this.openInfo.Title.TeacherName.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.Title.TeacherName.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml +=
        '<R>' + this.openInfo.Title.TeacherName.Caption.FontColor.R + '</R>'
      szXml +=
        '<G>' + this.openInfo.Title.TeacherName.Caption.FontColor.G + '</G>'
      szXml +=
        '<B>' + this.openInfo.Title.TeacherName.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Title.TeacherName.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</TeacherName>'
      szXml += '<UnitName>'
      szXml += '<Enabled>' + this.openInfo.Title.UnitName.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml += '<PosX>' + this.openInfo.Title.UnitName.Caption.PosX + '</PosX>'
      szXml += '<PosY>' + this.openInfo.Title.UnitName.Caption.PosY + '</PosY>'
      szXml +=
        '<Width>' + this.openInfo.Title.UnitName.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.Title.UnitName.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml += '<R>' + this.openInfo.Title.UnitName.Caption.FontColor.R + '</R>'
      szXml += '<G>' + this.openInfo.Title.UnitName.Caption.FontColor.G + '</G>'
      szXml += '<B>' + this.openInfo.Title.UnitName.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Title.UnitName.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</UnitName>'
      szXml += '<DirectorName>'
      szXml +=
        '<Enabled>' + this.openInfo.Title.DirectorName.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml +=
        '<PosX>' + this.openInfo.Title.DirectorName.Caption.PosX + '</PosX>'
      szXml +=
        '<PosY>' + this.openInfo.Title.DirectorName.Caption.PosY + '</PosY>'
      szXml +=
        '<Width>' + this.openInfo.Title.DirectorName.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.Title.DirectorName.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml +=
        '<R>' + this.openInfo.Title.DirectorName.Caption.FontColor.R + '</R>'
      szXml +=
        '<G>' + this.openInfo.Title.DirectorName.Caption.FontColor.G + '</G>'
      szXml +=
        '<B>' + this.openInfo.Title.DirectorName.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Title.DirectorName.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>' +
        this.openInfo.Title.DirectorName.Caption.VAlignment +
        '</VAlignment>'
      szXml += '</Caption>'
      szXml += '</DirectorName>'
      szXml += '<Date>'
      szXml += '<Enabled>' + this.openInfo.Title.Date.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml += '<PosX>' + this.openInfo.Title.Date.Caption.PosX + '</PosX>'
      szXml += '<PosY>' + this.openInfo.Title.Date.Caption.PosY + '</PosY>'
      szXml += '<Width>' + this.openInfo.Title.Date.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' + this.openInfo.Title.Date.Caption.FontSize + '</FontSize>'
      szXml += '<FontColor>'
      szXml += '<R>' + this.openInfo.Title.Date.Caption.FontColor.R + '</R>'
      szXml += '<G>' + this.openInfo.Title.Date.Caption.FontColor.G + '</G>'
      szXml += '<B>' + this.openInfo.Title.Date.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Title.Date.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</Date>'
      szXml += '<Time>'
      szXml += '<Enabled>' + this.openInfo.Title.Time.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml += '<PosX>' + this.openInfo.Title.Time.Caption.PosX + '</PosX>'
      szXml += '<PosY>' + this.openInfo.Title.Time.Caption.PosY + '</PosY>'
      szXml += '<Width>' + this.openInfo.Title.Time.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' + this.openInfo.Title.Time.Caption.FontSize + '</FontSize>'
      szXml += '<FontColor>'
      szXml += '<R>' + this.openInfo.Title.Time.Caption.FontColor.R + '</R>'
      szXml += '<G>' + this.openInfo.Title.Time.Caption.FontColor.G + '</G>'
      szXml += '<B>' + this.openInfo.Title.Time.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Title.Time.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</Time>'
      szXml += '</Title>'
      szXml += '<Ending>'
      szXml += '<Enabled>' + this.openInfo.Ending.Enabled + '</Enabled>'
      szXml += '<Duration>' + this.openInfo.Ending.Duration + '</Duration>'
      szXml += '<BackGround>'
      szXml +=
        '<Enabled>' + this.openInfo.Ending.BackGround.Enabled + '</Enabled>'
      szXml += '</BackGround>'
      szXml += '<CourseName>'
      szXml +=
        '<Enabled>' + this.openInfo.Ending.CourseName.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml +=
        '<PosX>' + this.openInfo.Ending.CourseName.Caption.PosX + '</PosX>'
      szXml +=
        '<PosY>' + this.openInfo.Ending.CourseName.Caption.PosY + '</PosY>'
      szXml +=
        '<Width>' + this.openInfo.Ending.CourseName.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.Ending.CourseName.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml +=
        '<R>' + this.openInfo.Ending.CourseName.Caption.FontColor.R + '</R>'
      szXml +=
        '<G>' + this.openInfo.Ending.CourseName.Caption.FontColor.G + '</G>'
      szXml +=
        '<B>' + this.openInfo.Ending.CourseName.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Ending.CourseName.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</CourseName>'
      szXml += '<TeacherName>'
      szXml +=
        '<Enabled>' + this.openInfo.Ending.TeacherName.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml +=
        '<PosX>' + this.openInfo.Ending.TeacherName.Caption.PosX + '</PosX>'
      szXml +=
        '<PosY>' + this.openInfo.Ending.TeacherName.Caption.PosY + '</PosY>'
      szXml +=
        '<Width>' + this.openInfo.Ending.TeacherName.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.Ending.TeacherName.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml +=
        '<R>' + this.openInfo.Ending.TeacherName.Caption.FontColor.R + '</R>'
      szXml +=
        '<G>' + this.openInfo.Ending.TeacherName.Caption.FontColor.G + '</G>'
      szXml +=
        '<B>' + this.openInfo.Ending.TeacherName.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Ending.TeacherName.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</TeacherName>'
      szXml += '<UnitName>'
      szXml +=
        '<Enabled>' + this.openInfo.Ending.UnitName.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml += '<PosX>' + this.openInfo.Ending.UnitName.Caption.PosX + '</PosX>'
      szXml += '<PosY>' + this.openInfo.Ending.UnitName.Caption.PosY + '</PosY>'
      szXml +=
        '<Width>' + this.openInfo.Ending.UnitName.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.Ending.UnitName.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml +=
        '<R>' + this.openInfo.Ending.UnitName.Caption.FontColor.R + '</R>'
      szXml +=
        '<G>' + this.openInfo.Ending.UnitName.Caption.FontColor.G + '</G>'
      szXml +=
        '<B>' + this.openInfo.Ending.UnitName.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Ending.UnitName.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</UnitName>'
      szXml += '<DirectorName>'
      szXml +=
        '<Enabled>' + this.openInfo.Ending.DirectorName.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml +=
        '<PosX>' + this.openInfo.Ending.DirectorName.Caption.PosX + '</PosX>'
      szXml +=
        '<PosY>' + this.openInfo.Ending.DirectorName.Caption.PosY + '</PosY>'
      szXml +=
        '<Width>' + this.openInfo.Ending.DirectorName.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.Ending.DirectorName.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml +=
        '<R>' + this.openInfo.Ending.DirectorName.Caption.FontColor.R + '</R>'
      szXml +=
        '<G>' + this.openInfo.Ending.DirectorName.Caption.FontColor.G + '</G>'
      szXml +=
        '<B>' + this.openInfo.Ending.DirectorName.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Ending.DirectorName.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</DirectorName>'
      szXml += '<Date>'
      szXml += '<Enabled>' + this.openInfo.Ending.Date.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml += '<PosX>' + this.openInfo.Ending.Date.Caption.PosX + '</PosX>'
      szXml += '<PosY>' + this.openInfo.Ending.Date.Caption.PosY + '</PosY>'
      szXml += '<Width>' + this.openInfo.Ending.Date.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.Ending.Date.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml += '<R>' + this.openInfo.Ending.Date.Caption.FontColor.R + '</R>'
      szXml += '<G>' + this.openInfo.Ending.Date.Caption.FontColor.G + '</G>'
      szXml += '<B>' + this.openInfo.Ending.Date.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Ending.Date.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</Date>'
      szXml += '<Time>'
      szXml += '<Enabled>' + this.openInfo.Ending.Time.Enabled + '</Enabled>'
      szXml += '<Caption>'
      szXml += '<PosX>' + this.openInfo.Ending.Time.Caption.PosX + '</PosX>'
      szXml += '<PosY>' + this.openInfo.Ending.Time.Caption.PosY + '</PosY>'
      szXml += '<Width>' + this.openInfo.Ending.Time.Caption.Width + '</Width>'
      szXml +=
        '<FontSize>' +
        this.openInfo.Ending.Time.Caption.FontSize +
        '</FontSize>'
      szXml += '<FontColor>'
      szXml += '<R>' + this.openInfo.Ending.Time.Caption.FontColor.R + '</R>'
      szXml += '<G>' + this.openInfo.Ending.Time.Caption.FontColor.G + '</G>'
      szXml += '<B>' + this.openInfo.Ending.Time.Caption.FontColor.B + '</B>'
      szXml += '</FontColor>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Ending.Time.Caption.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</Caption>'
      szXml += '</Time>'
      szXml += '</Ending>'
      szXml += '<Watermark>'
      szXml += '<Enabled>' + this.openInfo.Watermark.Enabled + '</Enabled>'
      szXml += '<OsdMark>'
      szXml +=
        '<PosX>' +
        this.openInfo.Watermark.OsdMark.PosX +
        '</PosX>'
      szXml +=
        '<PosY>' +
        this.openInfo.Watermark.OsdMark.PosY +
        '</PosY>'
      szXml += '<Width>' + 160 / this.widthPrecent + '</Width>'
      szXml += '<Height>' + 90 / this.heightPrecent + '</Height>'
      szXml +=
        '<HAlignment>' +
        this.openInfo.Watermark.OsdMark.HAlignment +
        '</HAlignment>'
      szXml +=
        '<VAlignment>aligntop</VAlignment>'
      szXml += '</OsdMark>'
      szXml += '</Watermark>'
      szXml += '</SetOsdCfgReq>'
      szXml += '</contentroot>'
      setOsdCfg(szXml)
        .then((res) => {
          this.stickerSet = false
          this.$message({
            message: '保存成功',
            type: 'success'
          })
        })
        .catch((_) => {
          this.$message({
            message: '保存失败',
            type: 'error'
          })
        })
    },
    stickerSetShow() {
      this.stickerSet = true
      // 水印图片
      this.imageUrl = this.baseUrl + '/disk/01_02/watermark.bmp'
      this.$nextTick(() => {
        const dragBox = document.getElementById('drag_stick')
        const database = this.openInfo.CustomCaption.Caption
        this.alignment = database.HAlignment
        dragBox.style.fontSize = database.FontSize + 'px'
        dragBox.style.textAlign = this.alignment.substr(5)
        const fColor =
          'rgb(' +
          Number(database.FontColor.R) +
          ',' +
          Number(database.FontColor.G) +
          ',' +
          Number(database.FontColor.B) +
          ')'
        this.color = fColor
        this.FontSize = Number(database.FontSize) / 2
        dragBox.style.color = this.color
        dragBox.style.left = Number(database.PosX) * this.widthPrecent + 'px'
        dragBox.style.top = Number(database.PosY) * this.heightPrecent + 'px'
        dragBox.style.width = Number(database.Width) * this.widthPrecent + 'px'
        dragBox.style.fontSize = this.FontSize + 'px'
      })
    },
    setDefault() {
      this.FontSize = this.defaultFontSize
      this.alignment = this.defaultAlignment
      this.color = this.defaultFontColor
    },
    setTitleEndingDefault() {
      // 恢复默认片头片尾
      this.setDefault()
      if (this.title === 'Title') {
        this.titleEndingInfo = this.deepClone(this.openInfo.Title)
      } else if (this.title === 'Ending') {
        this.titleEndingInfo = this.deepClone(this.openInfo.Ending)
      }
    },
    ensureOpenCredSet() {
      // 上传水印图片
      this.$refs.watermarkUpload.submit()
      this.stickerSetOpeningCred = false
      // 确认片头片尾
      if (this.title === 'Title') {
        this.openInfo.Title = this.deepClone(this.titleEndingInfo)
      } else if (this.title === 'Ending') {
        this.openInfo.Ending = this.deepClone(this.titleEndingInfo)
      }
    },
    openingCreditSet(titleOrEnding) {
      if (titleOrEnding === 'Title') {
        this.title = 'Title'
        this.titleEndingInfo = this.deepClone(this.openInfo.Title)
        this.titleEndingTitle = '片头设置'
      } else if (titleOrEnding === 'Ending') {
        this.title = 'Ending'
        this.titleEndingInfo = this.deepClone(this.openInfo.Ending)
        this.titleEndingTitle = '片尾设置'
      }
      this.$nextTick(() => {
        Object.keys(this.titleEndingInfo).forEach((key) => {
          if (typeof this.titleEndingInfo[key] === 'object') {
            const item = this.titleEndingInfo[key]
            if (item.Enabled) {
              this.changeBorderStyle(key + '', item.Caption)
              this.openColor = this.colorEdit(item.Caption.FontColor)
              return false
            }
          }
        })
      })
      this.stickerSetOpeningCred = true
    },
    setStickInfo() {
      let colStr = ''
      if (this.color.match(/rgb\((.+)\)/)) colStr = RegExp.$1
      const arr = colStr.split(',')
      const R = Number(arr[0].trim())
      const G = Number(arr[1].trim())
      const B = Number(arr[2].trim())
      this.form.FontSize = this.FontSize * 2
      this.form.HAlignment = this.alignment
      this.form.FontColor.R = R
      this.form.FontColor.G = G
      this.form.FontColor.B = B
      this.form.PosX = this.openInfo.CustomCaption.Caption.PosX
      this.form.PosY = this.openInfo.CustomCaption.Caption.PosY
      this.openInfo.CustomCaption.Caption = this.form
      this.setOpeningCredInfo()
    },
    addOpenOrCredFile() {
      // 双击添加图片
      window.getSelection
        ? window.getSelection().removeAllRanges()
        : document.selection.empty()
      this.$refs.fileEle.dispatchEvent(new MouseEvent('click'))
    },
    openCredTitle(title) {
      let chTitle = ''
      switch (title) {
        case 'CourseName':
          chTitle = '课程名称'
          break
        case 'TeacherName':
          chTitle = '讲师'
          break
        case 'UnitName':
          chTitle = '单位'
          break
        case 'DirectorName':
          chTitle = '导播'
          break
        case 'Date':
          chTitle = '日期'
          break
        case 'Time':
          chTitle = '时间'
          break
        default:
          break
      }
      return chTitle
    },
    openCredStyle(value, key) {
      if (typeof value !== 'object') return { display: 'none' }
      if (value.Caption) {
        const _that = this
        return {
          'text-align': value.Caption.HAlignment,
          color: _that.colorEdit(value.Caption.FontColor),
          fontSize: Number(value.Caption.FontSize) / 2 + 'px',
          width: Number(value.Caption.Width) * _that.widthPrecent + 'px',
          left: Number(value.Caption.PosX) * _that.widthPrecent + 'px',
          top: Number(value.Caption.PosY) * _that.heightPrecent + 'px',
          'border-style': key === _that.borderStyle ? 'dashed' : 'solid'
        }
      } else {
        return {}
      }
    },
    colorEdit(colors) {
      if (!colors) return 'rgb(255,255,255)'
      return (
        'rgb(' +
        Number(colors.R) +
        ',' +
        Number(colors.G) +
        ',' +
        Number(colors.B) +
        ')'
      )
    },
    openCredShow(value, key) {
      if (key === 'Enabled' || key === 'Duration') return false
      if (typeof value !== 'object') return false
      return value.Enabled === true
    },
    changeBorderStyle(borderDash, database) {
      if (this.titleEndingInfo[borderDash].Enabled) {
        this.borderStyle = borderDash
        if (database) {
          this.alignment = database.HAlignment
          this.FontSize = Number(database.FontSize) / 2
          this.$refs[borderDash][0].style.textAlign =
            database.HAlignment.substr(5)
          this.$refs[borderDash][0].style.fontSize =
            Number(database.FontSize) / 2 + 'px'
          const fColor =
            'rgb(' +
            Number(database.FontColor.R) +
            ',' +
            Number(database.FontColor.G) +
            ',' +
            Number(database.FontColor.B) +
            ')'
          this.$refs[borderDash][0].style.color = fColor
          this.openColor = fColor
        }
      }
    },
    // 添加水印图片
    handleStateChange(res, file) {
      if (res.raw.type !== 'image/bmp') {
        this.$message({
          type: 'warning',
          message: '仅支持bmp格式的水印图片'
        })
        return
      }
      if (res.raw.size > 4194304) {
        this.$message({
          type: 'warning',
          message: '仅支持4M以内的水印文件'
        })
        return
      }
      this.imageUrl = URL.createObjectURL(res.raw)
    },
    // 水印图片上传成功事件
    handleUploadSuccess() {
      this.$message({
        type: 'success',
        message: '水印图片已上传至服务器'
      })
    },
    // 水印图片上传失败事件
    handleUploadErr() {
      this.$message({
        type: 'error',
        message: '水印图片上传发生错误'
      })
    },
    // 片头片尾弹窗取消操作
    cancleFormData() {
      this.$refs.watermarkUpload.clearFiles()
      this.stickerSetOpeningCred = false
    },
    changeAlignment() {
      // 修改片头片尾字体对齐方式
      if (this.borderStyle === 'Watermark') return
      this.titleEndingInfo[this.borderStyle].Caption.HAlignment = this.alignment
      this.$refs[this.borderStyle][0].style.textAlign = this.alignment.substr(5)
    },
    changeFontSize() {
      // 修改片头片尾字体大小
      if (this.borderStyle === 'Watermark') return
      this.titleEndingInfo[this.borderStyle].Caption.FontSize =
        this.FontSize * 2
      this.$refs[this.borderStyle][0].style.fontSize = this.FontSize + 'px'
    },
    openCredChangeColor(color) {
      // 片头片尾颜色改变
      if (this.borderStyle === 'Watermark') return
      const colObj = this.rgbToEle(this.openColor)
      this.$refs[this.borderStyle][0].style.color = this.colorEdit(colObj)
      this.titleEndingInfo[this.borderStyle].Caption.FontColor = colObj
    },
    rgbToEle(col) {
      let colStr = ''
      if (col.match(/rgb\((.+)\)/)) colStr = RegExp.$1
      const arr = colStr.split(',')
      const R = Number(arr[0].trim())
      const G = Number(arr[1].trim())
      const B = Number(arr[2].trim())
      return { R, G, B }
    }
  }
}
</script>

<style lang="scss">
.sticker-set-dialog {
  .el-dialog {
    width: 680px;
    .open-color-picker {
      display: flex;
      align-items: center;
      > div {
        margin-left: 0px !important;
        display: flex;
        .el-color-picker {
          margin-top: 0px;
        }
      }
    }
  }
}
.el-color-picker {
  height: 32px;
  margin-top: 4px;
  .el-icon-close:before,
  .el-icon-arrow-down:before,
  .el-color-dropdown__value,
  .el-button {
    display: none;
  }
  .el-color-picker__trigger,
  .el-color-picker__color {
    border: none;
    padding: 0px;
    width: 32px;
    height: 32px;
  }
}
.el-color-dropdown {
  .el-color-dropdown__value,
  .el-button--text {
    display: none;
  }
  .is-plain {
    background: #1f75ff;
    outline: none;
    border: 1px solid #1f75ff;
    color: #fff;
    &:hover {
      background: #1f75ff;
      color: #fff;
    }
  }
}
</style>

<style scoped lang="scss">
.direct-open-credits {
  .direct-open-credits-contain {
    .direct-open-credits-mark-con {
      padding: 0px 12px;
      .direct-open-credits-mark {
        display: flex;
        align-items: center;
        .direct-mark-input {
          flex: 1;
          .config-title {
            width: 42px;
            padding-left: 8px;
            font-weight: normal;
            font-size: 14px;
          }
          .mark-input {
            flex: 1;
            padding-left: 8px;
            padding-right: 8px;
          }
        }
      }
      &::after {
        height: 1px;
        background: #0e1116;
        width: 100%;
        content: "";
        display: inline-block;
      }
    }
    .direct-open-credits-open {
      padding: 12px 12px 0px 12px;
      .open-check {
        padding-bottom: 12px;
      }
      .open-content {
        background: #222933;
        border-radius: 2px;
        padding-left: 12px;
        padding-right: 12px;
        padding-top: 8px;
        .config-stream-media {
          .config-title {
            width: 60px;
            font-weight: normal;
            font-size: 14px;
          }
          .open-select-continuous {
            flex: 1;
            padding-left: 8px;
          }
        }
        .open-check-item {
          display: flex;
          align-items: center;
          padding-top: 12px;
          .check-item {
            flex: 1;
          }
        }
        .open-check-button {
          padding-top: 12px;
          padding-bottom: 12px;
          .default {
            width: 100%;
          }
        }
      }
    }
    .direct-open-save {
      padding: 12px;
      .primary {
        width: 100%;
      }
    }
  }
  .sticker-set-dialog {
    user-select: none;

    .stick-item {
      display: flex;
      align-items: center;
      .stick-item-check {
        flex: 1;
        padding-left: 8px;
        padding-bottom: 16px;
      }
      .font-color-default {
        background: #fff;
        display: inline-block;
        height: 32px;
        width: 32px;
        vertical-align: middle;
      }
    }
    .stick-wraning {
      padding: 12px 8px 4px;
      color: #f5c535;
    }
    .stick-item-point {
      position: relative;
      .stick-point {
        position: relative;
        width: 640px;
        height: 360px;
        background: #1d222c;
        border: 1px solid #0e1116;
        border-radius: 2px;
        user-select: none;

        .drag-stick-item {
          position: absolute;
          width: 300px;
          border: 1px dashed blue;
          cursor: move;
        }
      }
      .open-cred-point {
        position: absolute;
        border: 1px dashed #fff;
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: move;
        z-index: 1;

        .image-preview {
          width: 160px;
          height: 90px;
        }

        .avatar-uploader-icon {
          position: absolute;
          left: 50%;
          top: 50%;
          padding: 8px;
          transform: translateX(-23px) translateY(-23px);
          border: 1px solid #1f75ff;
          border-radius: 3px;
          transition: all 0.3s ease;
          &:hover {
            background-color: #1f75ff;
            i {
              color: #fff;
            }
          }

          i {
            transition: all 0.3s ease;
            font-size: 30px;
            color: #1f75ff;
          }
        }
      }
      .open-cred-item {
        position: absolute;
        border: 1px solid #fff;
        cursor: move;
      }
    }
    .dialog-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
}
</style>
