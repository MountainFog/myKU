<template>
  <div class="direct-screen-layout">
    <div class="direct-screen-contain">
      <div class="col-left">
        <div class="play-type" @click="setMergeStyle('only_one')" :class="{'active': mergeStyle == 'only_one'}"></div>
      </div>
      <div class="col-right">
        <div class="play-type type-sec-center" :class="{'active': mergeStyle == 'average_2'}" @click="setMergeStyle('average_2')">
          <div class="type-sec-left"></div>
          <div class="type-sec-right"></div>
        </div>
      </div>
    </div>
    <div class="direct-screen-contain">
      <div class="col-left">
        <div class="play-type type-sec-top-left" :class="{'active': mergeStyle == 'big_small_lt'}" @click="setMergeStyle('big_small_lt')">
          <div class="type-top-left"></div>
        </div>
      </div>
      <div class="col-right">
        <div class="play-type type-sec-top-right" :class="{'active': mergeStyle == 'big_small_rt'}" @click="setMergeStyle('big_small_rt')">
          <div class="type-top-right"></div>
        </div>
      </div>
    </div>
    <div class="direct-screen-contain">
      <div class="col-left">
        <div class="play-type type-sec-left-bottom" :class="{'active': mergeStyle == 'big_small_lb'}" @click="setMergeStyle('big_small_lb')">
          <div class="type-left-bottom"></div>
        </div>
      </div>
      <div class="col-right">
        <div class="play-type type-sec-right-bottom" :class="{'active': mergeStyle == 'big_small_rb'}" @click="setMergeStyle('big_small_rb')">
          <div class="type-right-bottom"></div>
        </div>
      </div>
    </div>

    <div class="direct-screen-contain">
      <div class="col-left">
        <div class="play-type type-thi-bottom" :class="{'active': mergeStyle == 'top_1_bottom_2'}" @click="setMergeStyle('top_1_bottom_2')">
          <div class="type-thi-top"></div>
          <div class="type-thi-bottom">
            <div class="type-thi-bottom-left"></div>
            <div class="type-thi-bottom-right"></div>
          </div>
        </div>
      </div>
      <div class="col-right">
        <div class="play-type type-thi-center" :class="{'active': mergeStyle == 'left_1_right_2'}" @click="setMergeStyle('left_1_right_2')">
          <div class="type-thi-center-left"></div>
          <div class="type-thi-center-right">
            <div class="type-thi-center-right-top"></div>
            <div class="type-thi-center-right-bottom"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="direct-screen-contain">
      <div class="col-left">
        <div class="play-type type-for-left" :class="{'active': mergeStyle == 'average_4'}" @click="setMergeStyle('average_4')">
          <div class="type-for-left-top">
            <div class="type-for-left-left"></div>
            <div class="type-for-left-left type-for-left-black"></div>
          </div>
          <div class="type-for-left-bottom">
            <div class="type-for-left-left type-for-left-black"></div>
            <div class="type-for-left-left"></div>
          </div>
        </div>
      </div>
      <div class="col-right">
        <div class="play-type type-for-right" :class="{'active': mergeStyle == 'top_1_bottom_3'}" @click="setMergeStyle('top_1_bottom_3')">
          <div class="type-for-right-top"></div>
          <div class="type-for-right-bottom">
            <div class="type-for-right-bottom-item"></div>
            <div class="type-for-right-bottom-item"></div>
            <div class="type-for-right-bottom-item"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="direct-screen-contain">
      <div class="col-left">
        <div class="play-type type-fiv" :class="{'active': mergeStyle == 'left_1_right_3'}" @click="setMergeStyle('left_1_right_3')">
          <div class="type-fiv-left"></div>
          <div class="type-fiv-right">
            <div class="type-fiv-right-top"></div>
            <div class="type-fiv-right-top"></div>
            <div class="type-fiv-right-top"></div>
          </div>
        </div>
      </div>
      <div class="col-right">
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
    }
  },
  props: {
    mergeStyle: {
      type: String,
      default: 'only_one'
    }
  },
  mounted() {
  },
  methods: {
    setMergeStyle(style) {//设置画面风格
      this.$emit('modeSet',style)
    },
  }
}
</script>

<style scoped lang="scss">
.direct-screen-layout {
  .direct-screen-contain {
    display: flex;
    align-items: center;
    padding: 16px;
    .col-left,.col-right {
      flex: 1;
      padding-right: 8px;
      .play-type {
        height: 64px;
        background: #2B313E;
        border: 1px solid #404857;
        cursor: pointer;
        &:hover {
          border: 1px solid blue;
        }
        &.active {
          border: 1px solid blue;
        }
        &.type-sec-center {
          display: flex;
          align-items: center;
          .type-sec-left,.type-sec-right {
            flex: 1;
            background: #394253;
            border: 1px solid #0B0E13;
            height: 50%;
          }
          .type-sec-right {
            background: #303949;
          }
        }
        &.type-sec-top-left {
          .type-top-left {
            width: 50%;
            height: 50%;
            background: #394253;
            border: 1px solid #0B0E13;
          }
        }
        &.type-sec-top-right {
          .type-top-right {
            width: 50%;
            height: 50%;
            background: #394253;
            border: 1px solid #0B0E13;
            margin-left: 50%;
          }
        }
        &.type-sec-left-bottom {
          display: flex;
          justify-content: flex-start;
          align-items: flex-end;
          .type-left-bottom {
            width: 50%;
            height: 50%;
            background: #394253;
            border: 1px solid #0B0E13;
          }
        }
        &.type-sec-right-bottom {
          display: flex;
          justify-content: flex-start;
          align-items: flex-end;
          .type-right-bottom {
            width: 50%;
            height: 50%;
            background: #394253;
            border: 1px solid #0B0E13;
            margin-left: 50%;
          }
        }
        &.type-thi-bottom {
          .type-thi-top,.type-thi-bottom {
            height: 50%;
            width: 100%;
            display: flex;
            .type-thi-bottom-left,.type-thi-bottom-right {
              flex: 1;
              height: 100%;
              background: #394253;
              border: 1px solid #0B0E13;
            }
            .type-thi-bottom-right {
              background: #303949;
            }
          }
        }
        &.type-thi-center {
          display: flex;
          align-items: center;
          .type-thi-center-left,.type-thi-center-right {
            flex: 1;
            height: 50%;
            background: #303949;
            border: 1px solid #0B0E13;
            .type-thi-center-right-top,.type-thi-center-right-bottom {
              height: 50%;
            }
            .type-thi-center-right-top {
              border-bottom: 1px solid #0B0E13;
            }
          }
          .type-thi-center-left {
            flex: 2;
          }
          .type-thi-center-right {
            background: #394253;
          }
        }
        &.type-for-left {
          .type-for-left-top,.type-for-left-bottom {
            display: flex;
            align-items: center;
            height: 50%;
            width: 100%;
            .type-for-left-left {
              background: #394253;
              border: 1px solid #0B0E13;
              height: 100%;
              flex: 1;
              &.type-for-left-black {
                background: #303949;
              }
            }
          }
        }
        &.type-for-right {
          .type-for-right-top {
            height: 66.66667%;
            background: #2B313E;
          }
          .type-for-right-bottom {
            display: flex;
            height: 33.33333%;
            align-items: center;
            .type-for-right-bottom-item {
              flex: 1;
              background: #394253;
              border: 1px solid #0B0E13;
              height: 100%;
            }
          }
        }
        &.type-fiv {
          display: flex;
          align-items: center;
          .type-fiv-left {
            flex: 2;
            height: 66.66667%;
            background: #303949;
            border: 1px solid #0B0E13;
            border-right: none;
          }
          .type-fiv-right {
            flex: 1;
            height: 100%;
            .type-fiv-right-top {
              width: 100%;
              height: 33.33333%;
              background: #394253;
              border: 1px solid #0B0E13;
            }
          }
        }
      }
    }
    .col-right {
      flex: 1;
      padding-left: 8px;
    }
  }
}
</style>
