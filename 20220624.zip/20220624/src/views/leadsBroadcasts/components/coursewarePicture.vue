<template>
  <div class="direct-courseware-picture">
    <div class="direct-course-container">
      <div class="record-info-item">
        <label for="" class="record-info-title">课件选择:</label>
        <div class="direct-input-container">
          <el-select v-model="courseware" class="border-select-default" placeholder="请选择">
            <el-option
              v-for="item in coursewareList"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <span class="paddingLeft16 font-title-table width124"></span>
        </div>
      </div>
      <el-form :rules="rules" ref="coursewareForm" :model="coursewareInfo">
         <el-form-item>
           <div class="record-info-item">
             <label for="" class="record-info-title">视频分辨率:</label>
             <div class="direct-input-container">
               <el-select v-model="coursewareInfo.Resolution" class="border-select-default" placeholder="请选择">
                 <el-option
                   v-for="item in resolutionInfo"
                   :key="item.value"
                   :label="item.label"
                   :value="item.value">
                 </el-option>
               </el-select>
               <span class="paddingLeft16 font-title-table width124"></span>
             </div>
           </div>
         </el-form-item>
         <el-form-item>
           <div class="record-info-item">
             <label for="" class="record-info-title">编码格式:</label>
             <div class="direct-input-container">
               <el-select v-model="coursewareInfo.EncType" class="border-select-default" placeholder="请选择">
                 <el-option
                   v-for="item in encTypeInfo"
                   :key="item.value"
                   :label="item.label"
                   :value="item.value">
                 </el-option>
               </el-select>
               <span class="paddingLeft16 font-title-table width124"></span>
             </div>
           </div>
         </el-form-item>
         <el-form-item prop="FrameRate">
           <div class="record-info-item">
             <label for="" class="record-info-title">视频帧率:</label>
             <div class="direct-input-container">
               <el-input v-model.number="coursewareInfo.FrameRate" class="border-input-default default-border-radius" />
               <span class="paddingLeft16 font-title-table width124">1-30 (fps)</span>
             </div>
           </div>
         </el-form-item>
         <el-form-item prop="BitRate">
           <div class="record-info-item">
             <label for="" class="record-info-title">平均码率:</label>
             <div class="direct-input-container">
               <el-input v-model.number="coursewareInfo.BitRate" class="border-input-default default-border-radius" />
               <span class="paddingLeft16 font-title-table width124">64-8192 (kbps)</span>
             </div>
           </div>
         </el-form-item>
         <el-form-item>
           <div class="record-info-item">
             <label for="" class="record-info-title">编码复杂度:</label>
             <div class="direct-input-container">
               <el-select v-model="coursewareInfo.ProfileLevel" class="border-select-default" placeholder="请选择">
                 <el-option
                   v-for="item in complexity"
                   :key="item.value"
                   :label="item.label"
                   :value="item.value">
                 </el-option>
               </el-select>
               <span class="paddingLeft16 font-title-table width124"></span>
             </div>
           </div>
         </el-form-item>
         <el-form-item prop="KeyframeInterval">
           <div class="record-info-item">
             <label for="" class="record-info-title">关键帧间隔:</label>
             <div class="direct-input-container">
               <el-input v-model.number="coursewareInfo.KeyframeInterval" class="border-input-default default-border-radius" />
               <span class="paddingLeft16 font-title-table width124">1-75 (帧)</span>
             </div>
           </div>
         </el-form-item>
         <el-form-item>
           <div class="record-info-item paddingLeft12">
             <input type="button" @click="saveInfo" value="保存" class="primary" />
           </div>
         </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import Cookies from 'js-cookie'
import { getPptChnVidEncParam, setPptChnVidEncParam,getWBChnVidEncParam,setWBChnVidEncParam } from '@/api/leadsBroadcasts.js'
export default {
  data() {
    return {
      rules: {
        FrameRate: [{ max: 30, min: 1, type: 'number', message: '帧率不在可填范围之内', trigger: 'blur' }],
        BitRate: [{ max: 8192, min: 64, type: 'number', message: '码率不在可填范围之内', trigger: 'blur' }],
        KeyframeInterval: [{ max: 75, min: 1, type: 'number', message: '关键帧不在可填范围之内', trigger: 'blur' }]
      },
      coursewareList: [
        {
          label: '课件',
          value: 'courseware'
        },
        {
          label: '电子白板',
          value: 'whiteboard'
        }
      ],
      courseware: 'courseware',
      complexity: [
        {
          label: 'BASELINE',
          value: 'baseline'
        },
        {
          label: 'MAIN',
          value: 'main_profile'
        },
        {
          label: 'HIGH',
          value: 'high_profile'
        }
      ],
      resolutionInfo: [
        {
          label: '1280*720',
          value: '1280*720'
        },
        {
          label: '1920*1080',
          value: '1920*1080'
        }
      ],
      encTypeInfo: [
        {
          label: 'H264',
          value: 'H264'
        },
        {
          label: 'H265',
          value: 'H265'
        }
      ],
      coursewareInfo: {
      }
    }
  },
  mounted() {
    this.initCoursePicture()
  },
  methods: {
    initCoursePicture() {
      this.courseware = Cookies.get("courType") ? Cookies.get("courType") : 'courseware'
      if(this.courseware == 'courseware') {
        this.getCoursewareInfo().then(res => {
          this.coursewareInfo = res.GetPptChnVidEncParamResp.VidEncParam
          this.coursewareInfo.FrameRate = Number(this.coursewareInfo.FrameRate)
          this.coursewareInfo.BitRate = Number(this.coursewareInfo.BitRate)
          this.coursewareInfo.KeyframeInterval = Number(this.coursewareInfo.KeyframeInterval)
        })
      }else {
        this.getWhiteboardInfo().then(res => {
          this.coursewareInfo = res.GetWBChnVidEncParamResp.VidEncParam
          this.coursewareInfo.FrameRate = Number(this.coursewareInfo.FrameRate)
          this.coursewareInfo.BitRate = Number(this.coursewareInfo.BitRate)
          this.coursewareInfo.KeyframeInterval = Number(this.coursewareInfo.KeyframeInterval)
        })
      }
    },
    getCoursewareInfo() {
      return new Promise( (resolve,reject) => {
        getPptChnVidEncParam({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      } )
    },
    getWhiteboardInfo() {
      return new Promise( (resolve,reject) => {
        getWBChnVidEncParam({}).then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      } )
    },
    setWhiteboardInfo() {
      this.$refs.coursewareForm.validate((valid) => {
        if (valid) {
          this.loading = true
          let param = {
            SetWBChnVidEncParamReq: {
              VidEncParam: this.coursewareInfo
            }
          }
          setWBChnVidEncParam(param).then(res => {
            this.$message({
              message: '保存成功',
              type: 'success'
            })
            Cookies.set("courType",'whiteboard')
          }).catch(err => {
            this.$message({
              message: '保存失败',
              type: 'error'
            })
          })
        }
      })
    },
    setCoursewareInfo() {
      this.$refs.coursewareForm.validate((valid) => {
        if (valid) {
          this.loading = true
          let param = {
            SetPptChnVidEncParamReq: {
              VidEncParam: this.coursewareInfo
            }
          }
          setPptChnVidEncParam(param).then(res => {
            this.$message({
              message: '保存成功',
              type: 'success'
            })
            Cookies.set("courType",'courseware')
          }).catch(err => {
            this.$message({
              message: '保存失败',
              type: 'error'
            })
          })
        }
      })
    },
    saveInfo() {
      if(this.courseware == 'courseware') {
        this.setCoursewareInfo()
      }else {
        this.setWhiteboardInfo()
      }
    }
  }
}
</script>
<style lang="scss">
.direct-courseware-picture {
  .direct-course-container {
    .el-form {
      .el-form-item {
        >div {
           line-height: 32px !important;
        }
      }
    }
  }
}
</style>
<style scoped lang="scss">
.direct-courseware-picture {
  .direct-course-container {
    padding-top: 12px;
    padding-bottom: 12px;
    padding-right: 12px;
    .record-info-item {
      display: flex;
      align-items: center;
     padding-top: 6px;
      padding-bottom: 6px;
      &.paddingLeft12 {
        padding-left: 12px;
        .primary {
          width: 100%;
        }
      }
      .record-info-title {
        font-weight: normal;
        width: 96px;
        padding-left: 12px;
        font-size: 14px;
        color: rgba(255,255,255,0.45);
      }
      .direct-input-container {
        display: flex;
        flex: 1;
        align-items: center;
        > div {
          flex: 1;
        }
        .width124 {
          width: 124px;
        }
      }
    }
  }
}
</style>
