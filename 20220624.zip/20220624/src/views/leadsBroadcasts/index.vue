<template>
  <div class="direct-leads">
    <div
      id="direct"
      ref="direct"
      class="direct-container"
    >
      <!-- @mouseup.stop="removeMouseUp($event)" -->
      <div class="direct-left-content">
        <el-tabs
          v-model="activeName"
          @tab-click="leftTabsChange"
        >
          <el-tab-pane
            key="recordInformation"
            label="录制信息"
            name="recordInformation"
          >
            <recordInformation
              :is-recoding="recodeStatus"
              :recode-time-value="recodeTime"
            />
          </el-tab-pane>
          <el-tab-pane
            key="syntheticImage"
            label="合成画面"
            name="syntheticImage"
          >
            <syntheticImage
              :synth-cour-info="courseInfoware"
              :is-recoding="isRecoding"
              @overlayTime="overlayTime"
              @coordinates="coordinates"
              @borderSwtich="borderSwtich"
              @borderColor="borderColor"
              @changeAudType="changeAudType"
            />
          </el-tab-pane>
          <el-tab-pane
            key="coursewarePicture"
            label="课件画面"
            name="coursewarePicture"
          >
            <coursewarePicture
              :courseware-info="courseInfoware"
            />
          </el-tab-pane>
        </el-tabs>
      </div>
      <div class="direct-play-content">
        <div
          id="direct_play_contain"
          class="direct-play-contain"
        >
          <!-- @mouseup.stop="moveUpItem($event)"
          @mousedown.stop="mouseInnerItem($event)" -->

          <!-- 拖拽层 -->
          <drag-drop-wrap
            :style-type="styleType"
            :style="defautSize"
            @down-node="mouseInnerItem"
            @up-node="moveUpItem"
            @external-node="moveUpItem"
            @handleClickModal="chooseMainPlay"
            @dbclick-event="screenEvent"
          />
          <div
            id="play_main"
            :class="{'play_main': isChooseMain}"
            :style="defautSize"
            @dblclick="dbExit"
          />
          <div class="icon-stop-record-con">
            <span class="icon-record-span">
              <i
                class="el-icon-video-camera icon-recode-icon"
                :class="{'recodeing': Mp4RecState === 'recording' || Mp4RecState === 'pause' }"
                @click="recordControl"
              />
            </span>
            <span class="icon-stop-span">
              <i
                class="icon-recode-icon"
                :class="{'el-icon-video-pause': isPause,'el-icon-video-play': !isPause }"
                @click.stop="stopStartRecode"
              />
            </span>
          </div>
          <div
            v-show="isLoad"
            class="direct-play-bar-control"
          >
            <div class="bar-control-pregress">
              <div class="icon-recodeing">
                <i
                  class="el-icon-video-camera icon-recode-icon"
                  :class="{'recodeing': Mp4RecState === 'recording' || Mp4RecState === 'pause' }"
                  @click="recordControl"
                />
              </div>
              <div class="icon-recodeing paddingLeft16">
                <i
                  class="icon-recode-icon"
                  :class="{'el-icon-video-pause': isPause,'el-icon-video-play': !isPause }"
                  @click.stop="stopStartRecode"
                />
              </div>
              <div class="volume-control">
                <i
                  class="volume-control-icon"
                  :class="{ 'isMuted': muted }"
                  @click.stop="setMuted"
                />
                <el-slider
                  v-model="volume"
                  @change="changeVolume"
                />
              </div>
              <div class="screen-full">
                <i
                  class="full-screen-icon"
                  @click="fullScreen"
                />
              </div>
            </div>
            <div class="record-btn-group">
              <input
                v-show="isManual === 'manual'"
                type="button"
                class="default default-border-radius"
                value="手动导播"
                @click.stop="setDirectModeCtrl('auto')"
              >
              <input
                v-show="isManual === 'auto'"
                type="button"
                class="primary default-border-radius"
                value="自动导播"
                @click.stop="setDirectModeCtrl('manual')"
              >
              <input
                v-show="isRecode"
                type="button"
                class="default default-border-radius marginLeft16"
                value="录制合成"
                @click.self="recodeOper"
              >
              <input
                v-show="!isRecode"
                type="button"
                class="primary default-border-radius marginLeft16"
                value="互动输出"
                @click.self="interactiveOutput"
              >
            </div>
          </div>
        </div>
      </div>
      <div class="direct-right-content">
        <el-tabs>
          <el-tab-pane label="画面布局">
            <screenLayout
              :direct-mode="isManual"
              :merge-style="screenMode"
              @mode="isManual = 'manual'"
              @modeSet="modeSet"
            />
          </el-tab-pane>
          <el-tab-pane label="片头片尾">
            <openingCredits />
          </el-tab-pane>
          <el-tab-pane label="云台">
            <holder :channel-id="play_small_id" />
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
    <el-scrollbar class="direct-foot-scrollbar">
      <div class="direct-foot-wrap">
        <div class="direct-foot-players">
          <playFoot
            v-for="n in 6"
            :key="n"
            :id-index="n"
            :svr-alias="svrChnAlias"
            :active-id="chooseId"
            :volume-set="volumeSmall"
            :cap-list="capList"
            :is-muted="chooseId === n"
            @changActive="isActive"
            @smallPic="isSmallPictureChange"
          />
        </div>
      </div>
    </el-scrollbar>
  </div>
</template>
<script>
import { KMediaUni } from 'kmedia-uni'
import recordInformation from './components/recordInformation'
import coursewarePicture from './components/coursewarePicture'
import syntheticImage from './components/syntheticImage'
import openingCredits from './components/openingCredits'
import screenLayout from './components/screenLayout'
import holder from './components/holder'
import playFoot from './components/playFoot'
import dragDropWrap from './components/drapDropWrap.vue'
import {
  getPptChnVidEncParam,
  directGetMode,
  getCmpMergeStyleParam,
  setCmpMergeStyleParam,
  getIntMergeStyleParam,
  setIntMergeStyleParam,
  getCurMp4RecTaskState,
  mp4RecCtrl,
  directModeCtrl
} from '@/api/leadsBroadcasts.js'
import { getWebsocketAccess } from '@/api/resourceManage'
import { getSvrChnList, getCompositeChnCap } from '@/api/channelManage.js'
import store from '@/store'
import Cookies from 'js-cookie'
import { getRtspUrlRealStream, getInteractList } from '@/api/interactive.js'
export default {
  components: {
    recordInformation,
    coursewarePicture,
    syntheticImage,
    openingCredits,
    screenLayout,
    holder,
    playFoot,
    dragDropWrap
  },
  data() {
    return {
      // 播放器拖拽层布局
      styleType: 1,
      startPtzN: 0,
      stopPtzN: 0,
      clickPtzN: 0,
      bClickPTZ: false,
      bMovePTZ: false,
      showFoot: true,
      playMainFlag: true,
      isChooseMain: true,
      isRecoding: false,
      recodeStatus: 'normal',
      recodeStatusFlag: true, // 录制信息
      syntheticImageFlag: false, // 画面合成
      coursewarePictureFlag: false, // 课件信息
      activeName: 'recordInformation', // 初始化界面
      courseInfoware: {
        BitRate: '',
        EncType: '',
        FrameRate: '',
        KeyframeInterval: '',
        ProfileLevel: '',
        Resolution: ''
      },
      play_main: null,
      switchBut: [
        {
          label: '主流',
          value: 'main'
        },
        {
          label: '辅流',
          value: 'stream'
        }
      ],
      // 控制条
      volume: 20,
      volumeSmall: 0,
      muted: false,
      isFullScreen: false,
      isManual: 'manual', // 'auto'自动,'manual'手动
      isRecode: true,
      isLoad: true,
      // 通道别名
      svrChnAlias: [],
      directChnId: 7,
      deviceTime: null,
      Mp4RecState: 'normal',
      chooseId: -1,
      smallPictureDrag: false,
      smallInfo: {},
      screenMode: 'only_one',
      // 互动信息
      intInfo: {},
      intInfoFlag: false,
      // 画面合成
      mergeIn: {},
      innerNvrId: -1,
      isSynth: false,
      isPause: true,
      throttle: true,
      capList: [],
      recodeTime: '0', // 课程时长
      play_small_id: -1 // 被选中的底部视频通道id
    }
  },
  computed: {
    defautSize() {
      const innerHeight = window.innerHeight
      // topbar + palyfoot + toobar + padding = 364px
      let playerHeight = innerHeight - 364
      // 低于584px 会导致左侧‘合成画面’表单溢出
      playerHeight = playerHeight < 584 ? 584 : playerHeight
      const playerWidth = playerHeight / 9 * 16
      return {
        width: playerWidth + 'px',
        height: playerHeight + 'px'
      }
    }
  },
  watch: {
    screenMode(nv) {
      this.setStyleType(nv)
    },
    $route(to, from) {
      if (to.name === 'leadsBroadcasts') {
        this.showFoot = true
        this.initLead()
      }
    }
  },
  beforeDestroy() {
    this.play_main.destroy()
  },
  destroyed() {
    this.recodeStatusFlag = false
    this.syntheticImageFlag = false
    this.coursewarePictureFlag = false
    clearTimeout(this.deviceTime)
  },
  mounted() {
    this.muted = Cookies.get('mute') === 'true'
    this.volume = Cookies.get('volume') ? Number(Cookies.get('volume')) : 50
    this.initLead()
    getCompositeChnCap({}).then((res) => {
      this.capList = res.GetCompositeChnCapResp.ChnList.Chn
    })
  },
  methods: {
    // 合成画面全屏
    screenEvent() {
      if (this.play_main.isFullscreen()) {
        this.play_main.exitFullscreen()
      } else {
        this.play_main.requestFullscreen()
      }
    },
    initLead() {
      getCompositeChnCap({}).then((res) => {
        const chnCapList = res.GetCompositeChnCapResp.ChnList.Chn
        let hasFromRemote = false
        const index = chnCapList.findIndex(
          (item) => item.ChnType === 'from_remote'
        )
        if (index > -1) hasFromRemote = true
        getSvrChnList({}).then((res) => {
          this.svrChnAlias = res.GetSvrChnListResp.SvrChnItemList.SvrChnItem
          const obj = {
            EncId: '0',
            NvrChnId: '9',
            SvrChnAlias: '电子白板',
            VidSrcNum: '1',
            IsEptzIpc: 'true'
          }
          const inObj = {
            EncId: '0',
            NvrChnId: '10',
            SvrChnAlias: '互动输入',
            VidSrcNum: '1',
            IsEptzIpc: 'true'
          }
          const idx = this.svrChnAlias.findIndex(
            (item) => item.NvrChnId === obj.NvrChnId
          )
          if (idx === -1) this.svrChnAlias.push(obj)
          if (hasFromRemote) this.svrChnAlias.push(inObj)
        })
      })

      this.getCourseInfoware().then((res) => {
        this.courseInfoware = res.GetPptChnVidEncParamResp.VidEncParam
      })
      this.initDirect()
    },
    deepClone(obj) {
      const objClone = Array.isArray(obj) ? [] : {}
      if (obj && typeof obj === 'object') {
        for (const key in obj) {
          if (obj[key] && typeof obj[key] === 'object') {
            objClone[key] = this.deepClone(obj[key])
          } else {
            objClone[key] = obj[key]
          }
        }
      }
      return objClone
    },
    initDirect() {
      this.play_main = this.initPlay('play_main', true, [
        'volume',
        'requestFullscreen'
      ])
      this.getStyle()
      this.getDeviceState()
      this.getDirectMode()
      // this.playVideo()
    },
    initPlay(playerId, hideControl, toolList) {
      this.playMainFlag = true
      const options = {
        selector: document.getElementById(playerId),
        loading: true,
        control: {
          hideControlsBar: hideControl,
          tools: toolList
        },
        request: {
          restore: 3,
          timeout: 30000
        },
        autoplay: true,
        muted: true,
        FILL_TYPE: 'RATIO_16_9'
      }
      const playItem = new KMediaUni(options)
      playItem.addEventListener('loadedmetadata', () => {
        playItem.play()
        if (this.muted) {
          playItem.volume(0)
        } else {
          playItem.volume(this.volume)
        }
      })
      return playItem
    },
    loadVideoUrl(player, url, port) {
      getWebsocketAccess({}).then((res) => {
        const websocket = res.GetWebsocketAccessResp.RtspOverUrl
        let websocketUrl = ''
        if (websocket.match(/(ws+:\/\/(.+):\d{0,4})/)) websocketUrl = RegExp.$1
        player.loadVideo({
          src: {
            websocketUrl: websocketUrl,
            rtspUrl: url,
            username: this.$store.getters.username,
            password: this.$store.getters.pwd
          },
          transport: KMediaUni.MODE.MSE
        })
        if (this.muted) {
          player.volume(0)
        } else {
          player.volume(this.volume)
        }
      })
    },
    playVideo() {
      this.getUrlRealStream().then((res) => {
        const rtspUrl = res.GetRtspUrlRealStreamResp.RtspUrl
        let websocket = ''
        if (rtspUrl.match(/rtsp:\/\/(.+):/)) websocket = RegExp.$1
        this.websocketIp = websocket
        const port = Number(res.GetRtspUrlRealStreamResp.Port)
        this.loadVideoUrl(this.play_main, rtspUrl, port)
      })
    },
    getUrlRealStream() {
      // 获取播放url
      return new Promise((resolve, reject) => {
        let szXml = '<contentroot>'
        szXml += '<authenticationinfo type="7.0">'
        szXml += '<username>' + store.getters.username + '</username>'
        szXml += '<password>' + store.getters.password + '</password>'
        szXml +=
          '<authenticationid>' + store.getters.authId + '</authenticationid>'
        szXml += '</authenticationinfo>'
        szXml += '<GetRtspUrlRealStreamReq>'
        szXml += '<NvrChnID>' + this.directChnId + '</NvrChnID>'
        szXml +=
          '<TransType>' +
          (Cookies.get('TransType') ? Cookies.get('TransType') : 'tcp') +
          '</TransType>'
        szXml += '<VideoList num="1">'
        szXml += '<EncID>1</EncID>'
        szXml += '</VideoList>'
        szXml += '<AudioList num="1">'
        szXml += '<SrcID>1</SrcID>'
        szXml += '</AudioList>'
        szXml += '</GetRtspUrlRealStreamReq>'
        szXml += '</contentroot>'
        getRtspUrlRealStream(szXml)
          .then((res) => {
            resolve(res)
          })
          .catch(_ => {
            reject()
          })
      })
    },
    getCourseInfoware() {
      return new Promise((resolve, reject) => {
        getPptChnVidEncParam({})
          .then((res) => {
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    setCourseInfo() {},
    changeVolume() {
      if (this.isChooseMain) {
        if (this.volume !== 0) {
          this.muted = false
        } else {
          this.muted = true
        }
        if (this.isChooseMain) {
          this.play_main.volume(this.volume)
          Cookies.set('volume', this.volume)
          this.volumeSmall = 0
        } else {
          this.volumeSmall = this.volume
          this.play_main.volume(0)
        }
      }
    },
    setMuted() {
      if (this.isChooseMain) {
        if (this.muted) {
          // 有静音到非静音
          this.muted = false
          if (this.volume === 0) {
            this.volume = 20
          }
          if (this.isChooseMain) {
            this.play_main.volume(this.volume)
            this.volumeSmall = 0
          } else {
            this.play_main.volume(0)
            this.volumeSmall = this.volume
          }
          Cookies.set('mute', 'false')
          /* this.kmediaLocal.muted(true) */
        } else {
          // 非静音到静音
          this.muted = true
          /* this.kmediaLocal.muted(false) */
          if (this.isChooseMain) {
            this.play_main.volume(0)
            // this.play_main.volume(this.volume)
            this.volumeSmall = 0
          } else {
            this.play_main.volume(0)
            this.volumeSmall = 0
            // this.volumeSmall = this.volume
          }
          Cookies.set('mute', 'true')
        }
      }
    },
    fullScreen() {
      this.isFullScreen = !this.isFullScreen
      this.play_main.requestFullscreen()
    },
    dbExit() {
      this.isFullScreen = !this.isFullScreen
      this.play_main.exitFullscreen()
    },
    recodeOper() {
      // 录制合成操作
      Cookies.set('interval', 'interval')
      this.isRecode = !this.isRecode
      getInteractList({}).then((res) => {
        if (res.GetInteractListResp.InteractList === '') {
          // 无互动
          this.$message({
            type: 'warning',
            message: '当前设备无互动正在进行....'
          })
          this.isRecode = !this.isRecode
          Cookies.set('interval', 'recoder')
        } else {
          // 互动中
          getIntMergeStyleParam({}).then((res) => {
            // 获取互动信息
            if (!this.intInfoFlag) {
              this.intInfo = res.GetIntMergeStyleParamResp.MergeCfg
              this.intInfoFlag = true
            }
            this.screenMode = res.GetIntMergeStyleParamResp.MergeCfg.MergeStyle
            this.setStyle(this.screenMode, 'merge_style').then((res) => {
              this.throttle = true
              this.directChnId = 14
              this.playVideo()
            })
          })
        }
      })
    },
    interactiveOutput() {
      // 互动输出操作
      Cookies.set('interval', 'recoder')
      this.isRecode = !this.isRecode
      getCmpMergeStyleParam({}).then((res) => {
        this.screenMode =
          res.GetCmpMergeStyleParamResp.MergeCfg.MergeStyle === 'top_1_botton_3'
            ? 'top_1_bottom_3'
            : res.GetCmpMergeStyleParamResp.MergeCfg.MergeStyle
        this.setStyle(this.screenMode, 'merge_style').then((res) => {
          // pic_src
          this.throttle = true
          this.directChnId = 7
          this.playVideo()
        })
      })
    },
    setDirectModeCtrl(mode) {
      this.isManual = mode
      const param = {
        DirectModeCtrlReq: {
          Mode: mode
        }
      }
      directModeCtrl(param).then((res) => {
      })
    },
    getDirectMode() {
      directGetMode({}).then((res) => {
        this.isManual = res.DirectGetModeResp.Mode
      })
    },
    getDeviceState() {
      clearTimeout(this.deviceTime)
      // getSvrStateEx({}).then(res => {
      getCurMp4RecTaskState({}).then((res) => {
        // this.Mp4RecState = res.SvrStateResp.Mp4RecState
        this.Mp4RecState = res.GetCurMp4RecTaskStateResp.RecState
        if (this.Mp4RecState === 'recording') {
          // 录制中
          this.isPause = true
          this.isRecoding = true
          this.recodeStatus = 'recording'
          this.recodeTime = res.GetCurMp4RecTaskStateResp.Duration
        } else if (this.Mp4RecState === 'pause') {
          // 暂停
          this.isPause = false
          this.recodeStatus = 'pause'
          this.recodeTime = res.GetCurMp4RecTaskStateResp.Duration
        } else if (this.Mp4RecState === 'normal') {
          // 结束
          this.isRecoding = false
          this.recodeStatus = 'normal'
          this.isPause = true
          this.recodeTime = '0'
        } else if (this.Mp4RecState === 'abort') {
          // 异常关闭
          this.recodeStatus = 'abort'
          this.recodeTime = '0'
        }
        this.deviceTime = setTimeout(() => {
          this.getDeviceState()
        }, 1000)
      })
    },
    isActive(id, chnNvrId) {
      this.chooseId = id
      this.volumeSmall = this.volume + 1
      // chnNvrId 被选中的通道id
      this.play_small_id = chnNvrId
      this.isChooseMain = false
      this.play_main.muted(true)
    },
    moveUpItem(nvrId) {
      if (!this.throttle) {
        this.$message({
          type: 'error',
          message: '上次拖动还在请求中，请稍后再尝试拖动....'
        })
        return
      }
      // const nvrId = this.getIndex(event)
      if (nvrId === -1) return
      if (this.smallPictureDrag) {
        // 拖拽到播放器内容区中
        this.smallPictureDrag = false // 小拖动到大取消
        if (this.isSynth) return
        const dragInfo = this.deepClone(this.smallInfo)
        dragInfo.EncId = dragInfo.EncId + ''
        if (this.isRecode) {
          // 录制合成
          const idx = this.mergeIn.PictureList.PictureItem.findIndex(
            (item) =>
              item.NvrChnId === dragInfo.NvrChnId &&
              item.EncId === dragInfo.EncId &&
              item.SrcType === dragInfo.SrcType
          )
          if (idx > -1) {
            // 已存在 则交换位置
            if (idx !== nvrId - 1) {
              const nvrIdInfo = this.mergeIn.PictureList.PictureItem[nvrId - 1]
              const changeInfo = this.deepClone(nvrIdInfo)
              this.mergeIn.PictureList.PictureItem.splice(idx, 1, changeInfo)
              this.mergeIn.PictureList.PictureItem.splice(
                nvrId - 1,
                1,
                dragInfo
              )
            } else {
              return
            }
          } else {
            // 不存在 则替换到目标位置
            this.mergeIn.PictureList.PictureItem.splice(nvrId - 1, 1, dragInfo)
          }
        } else {
          // 互动输出
          const idIntx = this.intInfo.PictureList.PictureItem.findIndex(
            (item) =>
              item.NvrChnId === dragInfo.NvrChnId &&
              item.EncId === dragInfo.EncId &&
              item.SrcType === dragInfo.SrcType
          )
          if (idIntx > -1) {
            if (idIntx !== nvrId - 1) {
              const changeIntInfo = this.deepClone(
                this.intInfo.PictureList.PictureItem[nvrId - 1]
              )
              this.intInfo.PictureList.PictureItem.splice(
                idIntx,
                1,
                changeIntInfo
              )
              this.intInfo.PictureList.PictureItem.splice(
                nvrId - 1,
                1,
                dragInfo
              )
            } else {
              return
            }
          } else {
            this.intInfo.PictureList.PictureItem.splice(nvrId - 1, 1, dragInfo)
          }
        }
      } else {
        if (nvrId === this.innerNvrId) return
        if (this.isRecode) {
          // 录制合成
          const innerObj1 = this.deepClone(
            this.mergeIn.PictureList.PictureItem[nvrId - 1]
          ) // 拖动结束对象
          const innerObj2 = this.deepClone(
            this.mergeIn.PictureList.PictureItem[this.innerNvrId - 1]
          ) // 拖动起始对象
          this.mergeIn.PictureList.PictureItem.splice(nvrId - 1, 1, innerObj2)
          this.mergeIn.PictureList.PictureItem.splice(
            this.innerNvrId - 1,
            1,
            innerObj1
          )
        } else {
          // 互动输出
          const innerObj1 = this.deepClone(
            this.intInfo.PictureList.PictureItem[nvrId - 1]
          ) // 拖动结束对象
          const innerObj2 = this.deepClone(
            this.intInfo.PictureList.PictureItem[this.innerNvrId - 1]
          ) // 拖动起始对象
          this.intInfo.PictureList.PictureItem.splice(nvrId - 1, 1, innerObj2)
          this.intInfo.PictureList.PictureItem.splice(
            this.innerNvrId - 1,
            1,
            innerObj1
          )
        }
      }
      this.setStyle(this.screenMode, 'pic_src')
        .then((res) => {
          this.throttle = true
          this.getMergeOrIntInfo()
        })
        .catch(_ => {
          this.throttle = true
        })
    },
    getMergeOrIntInfo() {
      return new Promise((resolve, reject) => {
        if (this.isRecode) {
          // 录制合成
          getCmpMergeStyleParam({})
            .then((res) => {
              this.mergeIn = res.GetCmpMergeStyleParamResp.MergeCfg
              this.screenMode =
                res.GetCmpMergeStyleParamResp.MergeCfg.MergeStyle ===
                'top_1_botton_3'
                  ? 'top_1_bottom_3'
                  : res.GetCmpMergeStyleParamResp.MergeCfg.MergeStyle
              resolve(res)
            })
            .catch((err) => {
              reject(err)
            })
        } else {
          // 互动输出
          getIntMergeStyleParam({})
            .then((res) => {
              this.intInfo = res.GetIntMergeStyleParamResp.MergeCfg
              this.screenMode =
                res.GetIntMergeStyleParamResp.MergeCfg.MergeStyle ===
                'top_1_botton_3'
                  ? 'top_1_bottom_3'
                  : res.GetIntMergeStyleParamResp.MergeCfg.MergeStyle
              resolve(res)
            })
            .catch((err) => {
              reject(err)
            })
        }
      })
    },
    mouseInnerItem(index) {
      this.innerNvrId = index
    },
    modeSet(mode) {
      this.screenMode = mode
      this.getMergeOrIntInfo().then((res) => {
        this.setStyle(mode, 'merge_style')
          .then((res) => {
            this.throttle = true
          })
          .catch(_ => {
            this.throttle = true
          })
      })
    },
    // 设置拖拽层样式布局
    setStyleType(mode) {
      switch (mode) {
        case 'only_one':
          this.styleType = 1
          break
        case 'average_2':
          this.styleType = 2
          break
        case 'big_small_lt':
          this.styleType = 3
          break
        case 'big_small_rt':
          this.styleType = 4
          break
        case 'big_small_lb':
          this.styleType = 5
          break
        case 'big_small_rb':
          this.styleType = 6
          break
        case 'top_1_bottom_2':
          this.styleType = 7
          break
        case 'left_1_right_2':
          this.styleType = 8
          break
        case 'average_4':
          this.styleType = 9
          break
        case 'top_1_bottom_3':
          this.styleType = 10
          break
        case 'left_1_right_3':
          this.styleType = 11
          break
        default:
          this.styleType = 1
          break
      }
    },
    isSmallPictureChange(smallInfo, isSynth) {
      // 属于小窗拖拽
      this.smallPictureDrag = true
      // 是否合成画面
      this.isSynth = isSynth
      // 小窗对应通道信息
      this.smallInfo = smallInfo
    },
    // removeMouseUp(event) {
    //   this.isSynth = true
    // },
    getStyle() {
      getCmpMergeStyleParam({}).then((res) => {
        this.mergeIn = res.GetCmpMergeStyleParamResp.MergeCfg
        this.screenMode =
          res.GetCmpMergeStyleParamResp.MergeCfg.MergeStyle === 'top_1_botton_3'
            ? 'top_1_bottom_3'
            : res.GetCmpMergeStyleParamResp.MergeCfg.MergeStyle
      })
      this.isRecode = Cookies.get('interval') !== 'interval'
      if (this.isRecode) {
        this.directChnId = 7
        this.playVideo()
      } else {
        getInteractList({}).then((res) => {
          if (res.GetInteractListResp.InteractList === '') {
            // 无互动
            Cookies.set('interval', 'recoder')
            this.directChnId = 7
            this.playVideo()
            this.isRecode = true
          } else {
            // 互动中
            this.directChnId = 14
            getIntMergeStyleParam({}).then((res) => {
              // 获取互动信息
              this.intInfo = res.GetIntMergeStyleParamResp.MergeCfg
              this.screenMode =
                res.GetIntMergeStyleParamResp.MergeCfg.MergeStyle ===
                'top_1_botton_3'
                  ? 'top_1_bottom_3'
                  : res.GetIntMergeStyleParamResp.MergeCfg.MergeStyle
              this.intInfoFlag = true
              this.playVideo()
            })
          }
        })
      }
    },
    setStyle(style, CfgType) {
      this.throttle = false
      return new Promise((resolve, reject) => {
        if (this.isRecode) {
          // 录制合成
          const szXml = this.setMergeXml(style, CfgType)
          setCmpMergeStyleParam(szXml)
            .then((res) => {
              this.screenMode = style
              this.isSynth = false
              this.smallInfo = {}
              /* this.throttle = true */
              resolve(res)
            })
            .catch((err) => {
              /* this.throttle = true */
              reject(err)
            })
        } else {
          // 互动输出
          const szXml = this.setIntXml(style, CfgType)
          setIntMergeStyleParam(szXml)
            .then((res) => {
              this.screenMode = style
              this.isSynth = false
              this.smallInfo = {}
              /* this.throttle = true */
              resolve(res)
            })
            .catch((err) => {
              /* this.throttle = true */
              reject(err)
            })
        }
      })
    },
    setMergeXml(style, CfgType) {
      this.mergeIn.MergeStyle = style
      const len = this.mergeIn.PictureList.PictureItem.length
      let szXml = '<contentroot>'
      szXml += '<authenticationinfo type="7.0">'
      szXml += '<username>' + store.getters.username + '</username>'
      szXml += '<password>' + store.getters.password + '</password>'
      szXml +=
        '<authenticationid>' + store.getters.authId + '</authenticationid>'
      szXml += '</authenticationinfo>'
      szXml += '<SetCmpMergeStyleParamReq>'
      szXml += '<CfgType>' + CfgType + '</CfgType>'
      szXml += '<MergeCfg>'
      szXml +=
        '<MergeStyle>' +
        (style === 'top_1_botton_3' ? 'top_1_bottom_3' : style) +
        '</MergeStyle>'
      szXml += '<BorderWidth>' + this.mergeIn.BorderWidth + '</BorderWidth>'
      szXml += '<BorderColor>'
      szXml += '<R>' + this.mergeIn.BorderColor.R + '</R>'
      szXml += '<G>' + this.mergeIn.BorderColor.G + '</G>'
      szXml += '<B>' + this.mergeIn.BorderColor.B + '</B>'
      szXml += '</BorderColor>'
      szXml += '<PictureList>'
      for (let i = 0; i < len; i++) {
        szXml += '<PictureItem>'
        szXml +=
          '<SrcType>' +
          this.mergeIn.PictureList.PictureItem[i].SrcType +
          '</SrcType>'
        szXml +=
          '<NvrChnId>' +
          this.mergeIn.PictureList.PictureItem[i].NvrChnId +
          '</NvrChnId>'
        szXml +=
          '<EncId>' + this.mergeIn.PictureList.PictureItem[i].EncId + '</EncId>'
        szXml += '</PictureItem>'
      }
      szXml += '</PictureList>'
      szXml += '<IsTimeEnable>' + this.mergeIn.IsTimeEnable + '</IsTimeEnable>'
      szXml += '<TimeX>' + this.mergeIn.TimeX + '</TimeX>'
      szXml += '<TimeY>' + this.mergeIn.TimeY + '</TimeY>'
      szXml += '<ChgNum>' + this.mergeIn.ChgNum + '</ChgNum>'
      szXml += '</MergeCfg>'
      szXml += '</SetCmpMergeStyleParamReq>'
      szXml += '</contentroot>'
      if (this.isManual === 'auto') {
        this.setDirectModeCtrl('manual')
      }
      return szXml
    },
    setIntXml(style, CfgType) {
      this.intInfo.MergeStyle = style
      const len = this.intInfo.PictureList.PictureItem.length
      let szXml = '<contentroot>'
      szXml += '<authenticationinfo type="7.0">'
      szXml += '<username>' + store.getters.username + '</username>'
      szXml += '<password>' + store.getters.password + '</password>'
      szXml +=
        '<authenticationid>' + store.getters.authId + '</authenticationid>'
      szXml += '</authenticationinfo>'
      szXml += '<SetIntMergeStyleParamReq>'
      szXml += '<CfgType>' + CfgType + '</CfgType>'
      szXml += '<MergeCfg>'
      szXml +=
        '<MergeStyle>' +
        (style === 'top_1_botton_3' ? 'top_1_bottom_3' : style) +
        '</MergeStyle>'
      szXml += '<BorderWidth>' + this.intInfo.BorderWidth + '</BorderWidth>'
      szXml += '<BorderColor>'
      szXml += '<R>' + this.intInfo.BorderColor.R + '</R>'
      szXml += '<G>' + this.intInfo.BorderColor.G + '</G>'
      szXml += '<B>' + this.intInfo.BorderColor.B + '</B>'
      szXml += '</BorderColor>'
      szXml += '<PictureList>'
      for (let i = 0; i < len; i++) {
        szXml += '<PictureItem>'
        szXml +=
          '<SrcType>' +
          this.intInfo.PictureList.PictureItem[i].SrcType +
          '</SrcType>'
        szXml +=
          '<NvrChnId>' +
          this.intInfo.PictureList.PictureItem[i].NvrChnId +
          '</NvrChnId>'
        szXml +=
          '<EncId>' + this.intInfo.PictureList.PictureItem[i].EncId + '</EncId>'
        szXml += '</PictureItem>'
      }
      szXml += '</PictureList>'
      szXml += '<IsTimeEnable>' + this.intInfo.IsTimeEnable + '</IsTimeEnable>'
      szXml += '<TimeX>' + this.intInfo.TimeX + '</TimeX>'
      szXml += '<TimeY>' + this.intInfo.TimeY + '</TimeY>'
      szXml += '<ChgNum>' + this.intInfo.ChgNum + '</ChgNum>'
      szXml += '</MergeCfg>'
      szXml += '</SetIntMergeStyleParamReq>'
      szXml += '</contentroot>'
      if (this.isManual === 'auto') {
        this.setDirectModeCtrl('manual')
      }
      return szXml
    },
    overlayTime(status) {
      // 叠加时间触发事件
      this.mergeIn.IsTimeEnable = status
      this.setStyle(this.screenMode, 'sys_time')
    },
    coordinates(val, position) {
      // 左边修改
      if (position === 'X') {
        // x坐标改变
        this.mergeIn.TimeX = val
      } else if (position === 'Y') {
        // Y坐标改变
        this.mergeIn.TimeY = val
      }
      this.setStyle(this.screenMode, 'sys_time')
    },
    borderSwtich(val) {
      // 边框修改
      this.mergeIn.BorderWidth = val
      this.setStyle(this.screenMode, 'merge_style')
    },
    borderColor(col) {
      // 边框颜色改变
      let colStr = ''
      if (col.match(/rgb\((.+)\)/)) colStr = RegExp.$1
      const arr = colStr.split(',')
      const R = Number(arr[0].trim())
      const G = Number(arr[1].trim())
      const B = Number(arr[2].trim())
      this.mergeIn.BorderColor = { R, G, B }
      this.setStyle(this.screenMode, 'merge_style')
    },
    recordControl() {
      // 录制控制
      let ctrlType
      if (this.Mp4RecState === 'recording' || this.Mp4RecState === 'pause') {
        ctrlType = 'stop'
      } else if (this.Mp4RecState === 'normal') {
        ctrlType = 'start'
      }
      this.mp4Ctrl(ctrlType).then((res) => {
        clearTimeout(this.deviceTime)
        this.getDeviceState()
      })
    },
    stopStartRecode() {
      let ctrlType
      if (this.Mp4RecState === 'recording') {
        // 录制中 点击暂停
        ctrlType = 'pause'
        this.isPause = false
      } else if (this.Mp4RecState === 'pause') {
        // 暂停录制 点击开启录制
        ctrlType = 'resume'
        this.isPause = true
      } else {
        return
      }
      this.mp4Ctrl(ctrlType).then((res) => {
        clearTimeout(this.deviceTime)
        this.getDeviceState()
      })
    },
    mp4Ctrl(type) {
      return new Promise((resolve, reject) => {
        const param = {
          Mp4RecCtrlReq: {
            CtrlType: type
          }
        }
        mp4RecCtrl(param)
          .then((res) => {
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    chooseMainPlay() {
      this.isChooseMain = true
      this.chooseId = -1
      this.volumeSmall = 0
      if (this.muted) {
        this.play_main.volume(0)
      } else {
        this.play_main.volume(this.volume)
      }
    },
    changeAudType() {
      // 音频修改
      this.playVideo()
    },
    leftTabsChange(tab) {
      if (tab.name === 'recordInformation') {
        // 录制信息
        this.recodeStatusFlag = true
        this.syntheticImageFlag = false
        this.coursewarePictureFlag = false
      } else if (tab.name === 'syntheticImage') {
        // 画面合成
        this.syntheticImageFlag = true
        this.recodeStatusFlag = false
        this.coursewarePictureFlag = false
      } else if (tab.name === 'coursewarePicture') {
        // 课件
        this.recodeStatusFlag = false
        this.syntheticImageFlag = false
        this.coursewarePictureFlag = true
      }
    }
  }
}
</script>
<style lang="scss">
.direct-left-content,
.direct-right-content {
  .el-tabs {

    .el-tabs__header {
      margin: 0;
    }

    .is-top {
      background: #1d222c;
      &.el-tabs__nav-wrap {
        &::after {
          height: 0px;
        }

        .el-tabs__nav {
          display: flex;
          justify-content: space-around;
          align-items: center;
          width: 100%;
          .el-tabs__active-bar {
            display: none;
          }
          .el-tabs__item {
            flex: 1;
            display: flex;
            justify-content: center;
            color: rgba(255, 255, 255, 0.65);
            padding: 0;
            &.is-active {
              background: #2a313e;
            }
          }
        }
      }
    }
  }
}
</style>
<style lang="scss">
@media screen and (max-width: 1920px) {
  .direct-left-content {
    width: calc((100% - 1056px) / 2);
    height: 624px;
  }

  // .direct-play-content {
  //   width: 1056px;
  //   height: 634px;
  // }

  .direct-right-content {
    width: calc((100% - 1056px) / 2);
    height: 624px;
  }
}

.direct-leads {
  min-width: 1744px;
  background-color: #2a313e;

  .direct-container {
    display: flex;
    background-color: #2a313e;
    // 左侧信息
    .direct-left-content {
      flex: 1;
      min-width: 304px;
      background-color: #2a313e;
    }

    // 中间播放窗口
    .direct-play-content {
      padding: 0px 4px;
      background: #000000;

      .direct-play-contain {
        position: relative;
        height: 100%;
        #play_main {
          height: 594px;
          border: 2px solid transparent;
          &.play_main {
            border: 2px solid skyblue;
          }
        }
        .icon-stop-record-con {
          position: absolute;
          height: 80px;
          width: 30px;
          top: 50%;
          right: 10px;
          margin-top: -60px;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          z-index: 1;
          .icon-record-span,
          .icon-stop-span {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            .icon-recode-icon {
              cursor: pointer;
              font-size: 16px;
              &.recodeing {
                color: red;
              }
            }
          }
        }
        .direct-play-bar-control {
          display: flex;
          justify-content: space-between;
          align-items: center;
          width: 100%;
          height: 40px;
          padding-right: 32px;
          background: #2a313e;

          .bar-control-pregress {
            display: flex;
            align-items: center;
            padding-left: 16px;
            .icon-recodeing {
              .icon-recode-icon {
                cursor: pointer;
                font-size: 16px;
                &.recodeing {
                  color: red;
                }
              }
            }
            .volume-control {
              display: flex;
              align-items: center;
              justify-content: center;
              background: lighten;
              margin-left: 12px;
              .volume-control-icon {
                width: 16px;
                height: 16px;
                cursor: pointer;
                background: url(../../assets/img/volume.png) no-repeat center
                  center;
                &.isMuted {
                  background: url(../../assets/img/muted.png) no-repeat center
                    center;
                }
              }
              .el-slider {
                width: 50px;
                margin-left: 12px;
              }
            }
            .screen-full {
              margin-left: 12px;
              display: flex;
              align-items: center;
              height: 40px;
              width: 32px;
              justify-content: center;
              background: lighten;
              .full-screen-icon {
                width: 16px;
                height: 16px;
                cursor: pointer;
                background: url(../../assets/img/full_screen.png) no-repeat
                  center center;
              }
            }
          }
        }
      }
    }

    // 右侧布局云台
    .direct-right-content {
      flex: 1;
      min-width: 304px;
      background-color: #2a313e;
    }
  }

  .direct-foot-scrollbar {
    padding-top: 0.07407rem;
    background: #000000;
  }

  // 底部窗口列表
  .direct-foot-wrap {
    min-height: 220px;

    .el-scrollbar__wrap    {
      overflow-x: hidden;
    }
  }

  .direct-foot-players {
    display: flex;
  }
}
</style>
