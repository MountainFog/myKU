<template>
  <div class="player-modal">
    <div class="video-list">
      <div class="video-list-title">视频列表</div>
      <div class="video-list-course">
        <div
          v-for="(item, index) in videoList"
          :key="item.FileFullName"
          :class="['video-course-item', {'item__active': index === active}]"
          @click="handleVideoclick(item, index)"
        >
          <el-tooltip
            class="item"
            effect="light"
            :content="videoNameFilter(item.FileFullName)"
            placement="top"
          >
            <span>{{ videoNameFilter(item.FileFullName) }}</span>
          </el-tooltip>
        </div>
      </div>
    </div>
    <div class="player-wrap-container">
      <div class="play-wrap-container">
        <div
          id="kmPlayer"
          class="player-wrap"
          @dblclick="exitFullScreen"
        />
        <div class="self-progress" @mousedown="lockProgress = true">
          <el-slider
            v-model="progressS"
            :show-tooltip="false"
            @change="changePlayProgress"
          />
        </div>
      </div>
      <div class="play-control">
        <div class="play-control-left">
          <!-- <span id="stop" class="ToolBorder stop" title="停止" @click="changePlayState('stop')"></span> -->
          <span
            id="full_screen"
            class="ToolBorder full-screen-icon"
            title="全屏"
            @click="fullScreen"
          />
          <span
            v-show="!isPlaying"
            id="play"
            key="play"
            class="ToolBorder play"
            title="播放"
            @click="changePlayState('play')"
          />
          <span
            v-show="isPlaying"
            id="pause"
            key="pause"
            class="ToolBorder pause"
            title="暂停"
            @click="changePlayState('pause')"
          />
          <span class="ToolBorder timeing">{{ duration }}</span>
        </div>
        <div
          class="play-control-right"
          style="padding-right: 8px;"
        >
          <span
            id="volume"
            :class="{ 'volume_mute': isMuted }"
            class="ToolBorder volume"
            title="音量"
            @click="changeVolume()"
          />
          <span class="volume-control">
            <el-slider
              v-model="volume"
              :step="1"
              :show-tooltip="false"
              @change="volumeSet"
            />
          </span>
        </div>

      </div>
    </div>
  </div>
</template>
<script>
import moment from 'moment'
import store from '@/store'
import {
  Create,
  Start,
  getWebsocketAccess,
  getRtspUrlReplay,
  vcrCtrl
} from '@/api/resourceManage'
import { KMediaUni } from 'kmedia-uni'
window.KMediaUni = KMediaUni
export default {
  props: {
    videoList: {
      type: Array,
      default() {
        return []
      }
    },
    baseUrl: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      progressS: 0,
      volume: 0, // 音量
      isMuted: false,
      active: 0,
      playDuration: 0,
      durationTime: 0,
      // 上次seek时的已播放时间
      lastSeekCurrentTime: 0,
      currentTime: '', // 视频当前时间
      beginTime: '', // 视频开始时间
      endTime: '', // 视频结束时间
      playDate: '',
      taskid: 0, // 任务id
      nvrId: 7, // 通道id
      isPlaying: false, // 播放状态 默认为播放
      playProgTime: null,
      // 操作锁定
      lockOperate: false,
      // 播放结束
      playStatusText: '',
      kmPlayer: undefined,
      lockProgress: false
    }
  },
  computed: {
    duration() {
      return this.formatTimeMinAndSec(this.currentTime) + ' / ' + this.formatTimeMinAndSec(this.durationTime)
    }
  },
  destroyed() {
    this.destoryKmediaUni()
  },
  mounted() {
    this.creatKmediaUni()
  },
  methods: {
    // 处理视频列表项点击
    handleVideoclick(data, index) {
      this.active = index
      clearTimeout(this.playProgTime)
      this.loadVideoResource(data)
    },
    // 视频名称过滤
    videoNameFilter(data) {
      let name = ''
      name = data.substring(data.lastIndexOf('/') + 1, data.lastIndexOf('.'))
      return name
    },
    // 改变播放状态
    changePlayState(status) {
      if (status === 'play') {
        // 开启播放
        this.kmPlayer.play()
        this.lockOperate = false
      }
      if (status === 'pause') {
        // 暂停播放
        this.kmPlayer.pause()
      }
      this.isPlaying = status === 'play'
    },

    // 实例化播放器
    creatKmediaUni() {
      this.kmPlayer = this.initKmediauni()
      // 元数据加载完成
      this.kmPlayer.addEventListener('loadedmetadata', () => {
        this.isPlaying = true
        this.volume = this.kmPlayer.volume()
      })
      // 播放结束
      this.kmPlayer.addEventListener('ended', () => {
        clearTimeout(this.playProgTime)
      })
      // 当前播放时间change
      this.kmPlayer.addEventListener('currentTimeChange', this.currentTimeChange)
      if (this.videoList[0]) {
        this.loadVideoResource(this.videoList[0])
      }
    },
    // 加载视频资源
    loadVideoResource(data) {
      this.beginTime = data.StartTime
      this.endTime = data.EndTime
      const start = data.StartTime.replace(/\//g, '-').split(' ')
      const end = data.EndTime.replace(/\//g, '-').split(' ')
      this.durationTime = this.getDuration(data)
      // 初始化播放任务
      if (this.taskid > 0) {
        this.lastSeekCurrentTime = 0
        // this.destroyTask(this.initVideoPlayTask, start, end)
      }
      this.initVideoPlayTask(start, end)
    },
    // 初始化播放任务
    initVideoPlayTask(start, end) {
      // 创建任务
      this.createPlay().then((res) => {
        const id = res.PlayTaskCreateResp.TaskID
        this.taskid = Number(id)
        this.startPlay(id).then((resp) => {
          this.getUrlPlay(id, start, end).then((respose) => {
            const url = respose.GetRtspUrlReplayResp.RtspUrl
            getWebsocketAccess({}).then((respo) => {
              const rtspUrl = respo.GetWebsocketAccessResp.Url
              let websocket = ''
              if (rtspUrl.match(/(ws+:\/\/(.+):\d{0,4})/)) websocket = RegExp.$1
              this.kmPlayer.loadVideo({
                src: {
                  websocketUrl: websocket,
                  rtspUrl: url,
                  username: this.$store.getters.username,
                  password: this.$store.getters.pwd
                },
                transport: KMediaUni.MODE.MSE,
                autoplay: true
              })
            })
          })
        })
      })
    },
    startPlay(id) {
      return new Promise((resolve, reject) => {
        let szXml = '<contentroot>'
        szXml += '<authenticationinfo type="7.0">'
        szXml += '<username>' + store.getters.username + '</username>'
        szXml += '<password>' + store.getters.password + '</password>'
        szXml +=
          '<authenticationid>' + store.getters.authId + '</authenticationid>'
        szXml += '</authenticationinfo>'
        szXml += '<PlayTaskStartReq>'
        szXml += '<TaskID>' + id + '</TaskID>'
        szXml += '<NvrChnID>7</NvrChnID>'
        szXml += '</PlayTaskStartReq>'
        szXml += '</contentroot>'
        Start(szXml)
          .then((res) => {
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    createPlay() {
      return new Promise((resolve, reject) => {
        let szXml = '<contentroot>'
        szXml += '<authenticationinfo type="7.0">'
        szXml += '<username>' + store.getters.username + '</username>'
        szXml += '<password>' + store.getters.password + '</password>'
        szXml +=
          '<authenticationid>' + store.getters.authId + '</authenticationid>'
        szXml += '</authenticationinfo>'
        szXml += '<PlayTaskCreateReq>'
        szXml += '<PBType>by_time</PBType>'
        szXml += '<AddChnPlayCondType>more</AddChnPlayCondType>'
        szXml += '</PlayTaskCreateReq>'
        szXml += '</contentroot>'
        Create(szXml)
          .then((res) => {
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    getUrlPlay(id, startTime, endTime) {
      return new Promise((resolve, reject) => {
        let sXml = '<contentroot>'
        sXml += '<authenticationinfo type="7.0">'
        sXml += '<username>' + store.getters.username + '</username>'
        sXml += '<password>' + store.getters.password + '</password>'
        sXml +=
          '<authenticationid>' + store.getters.authId + '</authenticationid>'
        sXml += '</authenticationinfo>'
        sXml += '<GetRtspUrlReplayReq>'
        sXml += '<TaskID>' + id + '</TaskID>'
        sXml += '<NvrChnID>7</NvrChnID>'
        sXml +=
          '<StartTime>' + startTime[0] + 'T' + startTime[1] + '</StartTime>'
        sXml += '<EndTime>' + endTime[0] + 'T' + endTime[1] + '</EndTime>'
        sXml += '<VideoList num="1"><EncID>1</EncID></VideoList>'
        sXml += '<AudioList num="1"><SrcID>1</SrcID></AudioList>'
        sXml += '</GetRtspUrlReplayReq>'
        sXml += '</contentroot>'
        getRtspUrlReplay(sXml)
          .then((res) => {
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    initKmediauni() {
      return new KMediaUni({
        selector: document.querySelector('#kmPlayer'),
        loading: true,
        control: {
          tools: ['timings', 'play', 'volume', 'requestFullscreen'],
          hideControlsBar: true
        },
        request: {
          restore: 10,
          timeout: 5
        },
        autoplay: true,
        muted: true,
        FILL_TYPE: 'HORIZONTAL'
      })
    },
    // 播放器当前已播放时长
    currentTimeChange(time) {
      this.currentTime = time + this.lastSeekCurrentTime
      if (!this.lockProgress) {
        this.progressS = Number((this.currentTime / this.durationTime * 100).toFixed(2))
      }
      // durationTime - 1 是为了解决播放over后，无法seek的问题,因此-1不会触发over
      if (this.currentTime >= this.durationTime - 1 && !this.lockOperate) {
        // 锁定seek操作
        this.lockOperate = true
        // seek到录像起始位置
        this.changePlayProgress(0)
        // 并暂停住
        this.changePlayState('pause')
      }
    },
    // 获取视频时长
    getDuration(data) {
      const sec =
        (new Date(data.EndTime).getTime() -
          new Date(data.StartTime).getTime()) /
        1000
      this.playDuration = sec
      this.playDate = data.StartTime
      return sec
    },
    // 销毁播放器实例
    destoryKmediaUni() {
      clearTimeout(this.playProgTime)
      if (this.kmPlayer) {
        this.kmPlayer.destroy()
        this.kmPlayer = null
      }
    },
    // seek进度
    changePlayProgress(val) {
      this.lockProgress = false
      // 获取seek到的目标位置的进度 单位秒
      let seekTarget = this.durationTime * val / 100

      // 至少seek1秒
      if (!seekTarget) seekTarget = 1
      // if (seekTarget === this.durationTime) seekTarget = seekTarget - 1

      // seek时，记录当前已播放时长
      this.lastSeekCurrentTime = seekTarget - this.kmPlayer.currentTime()

      // 将目标位置进度转为视频录制时间的 年/月/日/ 时：分：秒
      let targetDateTime = new Date(this.beginTime).getTime() + seekTarget * 1000
      targetDateTime = moment(targetDateTime).format('yyyy-MM-DDTHH:mm:ss')

      // 无任务ID 则不进行后台操作
      if (this.taskid === -1) return
      this.seek(this.taskid, this.nvrId, targetDateTime)
    },
    // 调用后台seek接口
    seek(taskId, nvrId, timeStr) {
      return new Promise((resolve, reject) => {
        let szXml = '<contentroot>'
        szXml += '<authenticationinfo type="7.0">'
        szXml += '<username>' + store.getters.username + '</username>'
        szXml += '<password>' + store.getters.password + '</password>'
        szXml +=
          '<authenticationid>' + store.getters.authId + '</authenticationid>'
        szXml += '</authenticationinfo>'
        szXml += '<PlayTaskVcrCtrlReq>'
        szXml += '<TaskID>' + taskId + '</TaskID>'
        szXml += '<NvrChnID>' + nvrId + '</NvrChnID>'
        szXml += '<PlyReverse>false</PlyReverse>'
        szXml += '<CtrlCmd>'
        szXml += '<CmdType>drag</CmdType>'
        szXml += '<SeekTime>' + timeStr + '</SeekTime>'
        szXml += '<FrameMode>all</FrameMode>'
        szXml += '</CtrlCmd>'
        szXml += '</PlayTaskVcrCtrlReq>'
        szXml += '</contentroot>'
        vcrCtrl(szXml)
          .then((res) => {
            this.lockOperate = false
            console.log('seek成功', timeStr)
            resolve(res)
          })
          .catch((err) => {
            this.lockOperate = false
            reject(err)
          })
      })
    },
    // 改变声音
    changeVolume() {
      if (this.kmPlayer) {
        this.isMuted = !this.isMuted
        this.kmPlayer.muted(this.isMuted)
        this.volume = this.kmPlayer.volume()
      }
    },
    volumeSet() {
      if (this.kmPlayer) {
        this.kmPlayer.volume(this.volume)
      }
    },
    fullScreen() {
      if (this.kmPlayer) {
        this.kmPlayer.requestFullscreen()
      }
    },
    exitFullScreen() {
      if (this.kmPlayer) {
        this.kmPlayer.exitFullscreen()
      }
    },
    // 格式化时间为时分秒
    formatTimeMinAndSec(time) {
      const { hours, minutes, seconds } = moment.duration(time, 'seconds')._data
      // 时分秒补0
      const addZero = (time) => {
        return time < 10 ? '0' + time : time
      }
      const text = `${addZero(hours)}:${addZero(minutes)}:${addZero(seconds)}`
      return text
    }
  }
}
</script>
<style lang="scss">
.player-modal {
  display: flex;
  justify-content: space-between;
  align-items: center;

  // 视频列表
  .video-list {
    width: 208px;
    height: 378px;

    &-title {
      line-height: 32px;
      font-size: 16px;
      font-weight: bold;
    }

    &-course {
      height: calc(100% - 40px);
      overflow-y: auto;
    }

    // 视频列表 - 项
    .video-course-item {
      margin-top: 8px;
      padding-left: 8px;
      border-radius: 2px;
      line-height: 32px;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      transition: all 0.2s linear;
      cursor: pointer;

      &:hover {
        background-color: #1f75ff;
      }
    }

    // 视频列表 - 项 选中
    .item__active {
      background-color: #1f75ff;
    }
  }
  .player-wrap-container {
    .play-wrap-container {
      position: relative;
      height: 378px;
      // 播放器容器
      .player-wrap {
        width: 672px;
        height: 378px;
        background: rgba(0, 0, 0, 0.5);

        // 视频信息
        .video-info {
          margin-right: 24px;
        }
      }
      .self-progress {
        position: absolute;
        left: 0px;
        bottom: 0px;
        right: 0px;
        width: 100%;
        height: 28px;
        line-height: 28px;
        background: rgba(0, 0, 0, 0.4);
      }
    }
    .play-control {
      height: 38px;
      border: 1px solid rgba(0, 0, 0, 0.4);
      background: rgba(0, 0, 0, 0.4);
      padding: 0 5px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .ToolBorder {
        margin: 4px 2px;
        float: left;
        width: 30px;
        height: 30px;
        line-height: 30px;
        &.timeing {
          width: 160px;
          margin-left: 16px;
        }
        cursor: pointer;
        &.full-screen-icon {
          background: url(../../../assets/img/full_screen.png) no-repeat center
            center;
        }
        &.stop {
          background: url(../../../assets/img/playback.png) no-repeat -23px 0px;
          &:hover {
            background: url(../../../assets/img/playback.png) no-repeat -23px -33px;
          }
        }
        &.play {
          background: url(../../../assets/img/playback.png) no-repeat -130px 0px;
          &:hover {
            background: url(../../../assets/img/playback.png) no-repeat -130px -33px;
          }
        }
        &.pause {
          background: url(../../../assets/img/playback.png) no-repeat -471px 0px;
          &:hover {
            background: url(../../../assets/img/playback.png) no-repeat -471px -33px;
          }
        }
        &.volume {
          background: url(../../../assets/img/playback.png) no-repeat -436px 0;
          &:hover {
            background: url(../../../assets/img/playback.png) no-repeat -436px -33px;
          }
          &.volume_mute {
            background: url(../../../assets/img/playback.png) no-repeat -651px 0;
            &:hover {
              background: url(../../../assets/img/playback.png) no-repeat -651px
                0;
            }
          }
        }
      }
      .volume-control {
        display: flex;
        width: 105px;
        margin-left: 36px;
        > div {
          width: 105px;
          background: transparent;
        }
      }
    }
  }
}
</style>
