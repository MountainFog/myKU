<template>
  <div class="video-config">
    <div class="kd-main-title">资源管理 / 录像管理</div>
    <div class="video-config-query">
      <div class="query-item">
        <div class="query-title">开始时间：</div>
        <el-date-picker
          v-model="startTime"
          type="datetime"
          size="small"
          value-format="yyyy/MM/dd HH:mm:ss"
          placeholder="选择开始日期时间"
        />
      </div>
      <div class="query-item">
        <div class="query-title">结束时间：</div>
        <el-date-picker
          v-model="endTime"
          type="datetime"
          size="small"
          value-format="yyyy/MM/dd HH:mm:ss"
          placeholder="选择结束日期时间"
        />
      </div>
      <div class="query-item">
        <div class="query-title">课程名称：</div>
        <el-input v-model="courseName" />
      </div>
      <div class="query-item">
        <div class="query-title">主讲教师：</div>
        <el-input v-model="teacherName" />
      </div>
      <div class="query-item">
        <el-button
          type="primary"
          :loading="loading"
          @click="queryTable(true)"
        >查询</el-button>
        <el-button
          :loading="delLoading"
          @click="delMp4RecTask"
        >删除</el-button>
      </div>
    </div>
    <!-- <div class="batch-func">
      <el-button
        :loading="delLoading"
        @click="delMp4RecTask"
      >删除</el-button>
    </div> -->
    <el-table
      class="video-config-table"
      :data="tableData"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column
        type="selection"
        width="55"
      />
      <el-table-column
        prop="StartTime"
        label="开始时间"
      >
        <template slot-scope="scope">
          {{ scope.row.StartTime | timeFormat }}
        </template>
      </el-table-column>
      <el-table-column
        prop="EndTime"
        label="结束时间"
      >
        <template slot-scope="scope">
          {{ scope.row.EndTime | timeFormat }}
        </template>
      </el-table-column>
      <el-table-column
        prop="CourseName"
        label="课程名称"
      />
      <el-table-column
        prop="TeacherName"
        label="主讲教师"
        width="120"
      />
      <el-table-column
        prop="FileTotalSize"
        label="文件大小"
        width="120"
      >
        <template slot-scope="scope">
          {{ scope.row.FileTotalSize + 'M' }}
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
      >
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="play(scope.row)"
          >播放</el-button>
          <el-button
            type="text"
            :disabled="downloading"
            @click="download(scope.row)"
          >下载</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pages-container">
      <el-pagination
        :current-page="pages.currentPage"
        :page-sizes="[10, 20]"
        :page-size="pages.size"
        layout="total, sizes, prev, pager, next, jumper"
        :total="pages.total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
    <!-- 播放器弹出框 -->
    <div v-if="visible">
      <el-dialog
        title="高等数学-张老师"
        width="944px"
        :close-on-click-modal="false"
        :visible.sync="visible"
        @close="destoryKmediaUni"
      >
        <player
          ref="kmPlayer"
          :video-list="videoList"
          :base-url="baseUrl"
        />
      </el-dialog>
    </div>
    <!-- 下载列表弹出框 -->
    <el-dialog
      title="下载列表"
      width="400px"
      :close-on-click-modal="false"
      :visible.sync="visibleDownload"
    >
      <el-link
        v-for="item in downloadList"
        :key="item.fileUrl"
        type="primary"
        :href="item.fileUrl"
        :download="item.fileName"
      >{{ item.fileName }}</el-link>
      <div class="btn-align__right">
        <el-button @click="visibleDownload = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { creatVideoQuery, getVideoResult, delMp4RecTask } from '@/api/resourceManage'
import moment from 'moment'
import Player from './components/playerModal.vue'
export default {
  components: {
    Player
  },
  filters: {
    timeFormat(value) {
      const time = new Date(value)
      return moment(time).format('YYYY-MM-DD HH:mm:ss')
    }
  },
  data() {
    return {
      // 查询 加载状态
      loading: false,
      // 删除 加载状态
      delLoading: false,
      // 下载列表弹出框
      visibleDownload: false,
      // 下载 加载状态
      downloading: false,
      visible: false,
      startTime: moment().format('YYYY/MM/DD 00:00:00'),
      endTime: moment().format('YYYY/MM/DD HH:mm:ss'),
      courseName: '',
      teacherName: '',
      // 表格数据
      tableData: [],
      // 表格选中项
      selection: [],
      // 分页参数
      pages: {
        currentPage: 1,
        size: 20,
        total: 0
      },
      // 播放弹框的录像列表
      videoList: [],
      // 下载列表
      downloadList: []
    }
  },
  computed: {
    // 查询录像列表时的开始下标
    startIndex() {
      const index = (this.pages.currentPage - 1) * this.pages.size
      return index
    },
    baseUrl() {
      // return 'http://172.18.1.133'
      const origin = window.location.origin
      return origin
    }
  },
  mounted() {
    this.queryTable()
  },
  methods: {
    destoryKmediaUni() {
      this.$refs.kmPlayer.destoryKmediaUni()
    },
    // 表格 多选项改变
    handleSelectionChange(val) {
      this.selection = val
    },
    // 分页器-当前页改变
    handleCurrentChange(current) {
      this.pages.currentPage = current
      this.queryTable()
    },
    // 分页器-每页条数改变
    handleSizeChange(size) {
      this.pages.size = size
      this.queryTable()
    },
    // 查询
    queryTable(reset) {
      // 判断loading 防止连续点击
      if (this.loading) return
      if (!this.startTime || !this.endTime) {
        this.$message({
          type: 'warning',
          message: '请选择开始时间和结束时间'
        })
        return
      }
      if (reset) {
        this.pages.currentPage = 1
      }
      // 查询参数
      const params = {
        StartTime: this.startTime,
        EndTime: this.endTime,
        StartInx: this.startIndex,
        Count: this.pages.size
      }
      if (this.courseName) {
        params.CourseName = this.courseName
      }
      if (this.teacherName) {
        params.TeacherName = this.teacherName
      }
      this.loading = true
      // 创建查询任务
      creatVideoQuery({
        QueryMp4RecTaskReq: params
      }).then(res => {
        this.getVideoResult(res.QueryMp4RecTaskResp.SessionID)
      }).catch(_ => {
        this.loading = false
      })
    },
    // 根据任务ID 开始查询结果
    getVideoResult(id) {
      getVideoResult({
        GetMp4RecTaskQueryResultExReq: {
          SessionID: id
        }
      }).then(res => {
        const state = res.GetMp4RecTaskQueryResultResp.QueryState
        // 查询超时
        if (state === 'idle') {
          this.loading = false
          this.$message({
            type: 'error',
            message: '查询超时'
          })
          return
        }
        // 处于查询队列 等待
        if (state === 'ready' || state === 'inoperation') {
          setTimeout(() => {
            this.getVideoResult(id)
          }, 1000)
          return
        }
        // 查询成功返回数据
        this.loading = false
        const list = res.GetMp4RecTaskQueryResultResp.Mp4TaskItemList.Mp4TaskItem || []
        this.pages.total = Number(res.GetMp4RecTaskQueryResultResp.Mp4TaskItemList.TaskTotalNum)
        this.tableData = []
        if (list.length || list.length === 0) {
          this.tableData.push(...list)
        } else {
          this.tableData.push(list)
        }
      }).catch(_ => {
        this.loading = false
      })
    },
    // 批量删除
    delMp4RecTask() {
      const idList = []
      this.selection.forEach(element => {
        idList.push(element.TaskId)
      })
      this.delLoading = true
      delMp4RecTask({
        DelMp4RecTaskReq: {
          TaskIdList: {
            K_E_Y: 'TaskId',
            V_A_L_U_E: idList
          }
        }
      }).then(_ => {
        this.delLoading = false
        this.queryTable()
      }).catch(_ => {
        this.delLoading = false
      })
    },
    // 表格 - 播放
    play(data) {
      this.videoList = []
      if (typeof data.FileItem === 'object' && data.FileItem.length) {
        this.videoList = data.FileItem
      } else {
        this.videoList = [data.FileItem]
      }
      this.visible = true
    },
    // 表格 - 下载
    download(data) {
      const files = []
      if (typeof data.FileItem === 'object' && data.FileItem.length === undefined) {
        data.FileItem = [data.FileItem]
      }
      data.FileItem.forEach(item => {
        files.push({
          fileName: this.videoNameFilter(item.FileFullName),
          fileUrl: encodeURI(`${this.baseUrl}/tmp/disk/${item.FileFullName}`)
        })
      })
      this.downloadList = files
      this.visibleDownload = true
    },
    // 过滤出视频名称
    videoNameFilter(data) {
      let name = ''
      name = data.substring(data.lastIndexOf('/') + 1)
      return name
    }
  }
}
</script>
<style lang="scss">
.video-config {
  padding: 8px 40px;
  background-color: #1d222c;

  &-query {
    display: flex;
    flex-wrap: wrap;
    font-size: 14px;

    .query-item {
      display: flex;
      align-items: center;
      margin-top: 16px;
      margin-right: 40px;
    }

  .query-item:last-child {
    margin-right: 0;
  }

    .query-title {
      display: inline-block;
      margin-right: 8px;
    }

    .el-input {
      width: 216px;
      height: 32px;
    }
  }

  .batch-func {
    display: flex;
    justify-content: flex-end;
    padding-top: 8px;
  }

  &-table {
    margin-top: 16px;
  }

  .pages-container {
    padding: 24px 0;
    text-align: right;
  }

  .el-dialog {
    border-radius: 4px;

    .el-link.el-link--primary {
      margin: 0 0 24px 32px;

    }
  }

  .el-dialog .el-dialog__header {
    padding: 16px 24px 0;
    font-size: 24px;
    font-weight: 600;
    border: none;
  }

  .btn-align__right {
    text-align: right;
  }

}
</style>
