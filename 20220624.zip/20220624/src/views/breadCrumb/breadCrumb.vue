<template>
  <div class="breadCrumbContainer">
    <el-breadcrumb separator="/" >
      <el-breadcrumb-item class="breadCrumbItem" :to="{ path: item.path }" v-for="(item, index) in breadList" :key="index" :class="{'active':index == (breadList.length - 1)}">{{item.meta.title}}</el-breadcrumb-item>
    </el-breadcrumb>
  </div>
</template>

<script>
  export default {
    name: "bread-crumb",
    data(){
      return {
        breadList:[]
      }
    },
    mounted() {
      this.getRouterInfo()
    },
    watch:{
      $route(){
        this.getRouterInfo()
      }
    },
    methods:{
      getRouterInfo() {
        if (this.$route.matched) {
          let matched = this.$route.matched.filter(item => item.meta && item.meta.title);
          this.breadList = matched;
        }
      }
    }
  }
</script>

<style>
  .breadCrumbContainer {
    border-bottom: 1px solid rgba(216,222,234,0.20);
    font-size: 32px;
    padding: 16px 0px;
  }
  .el-breadcrumb__inner a, .el-breadcrumb__inner.is-link {
    font-weight: normal;
  }
  .breadCrumbContainer .breadCrumbItem .el-breadcrumb__inner,
  .breadCrumbContainer .breadCrumbItem .el-breadcrumb__inner:hover,
  .el-breadcrumb__separator,
  .el-breadcrumb__separator:hover{
    color: #FFFFFF;
    font-size: 24px;
    font-weight: normal;
  }
</style>
