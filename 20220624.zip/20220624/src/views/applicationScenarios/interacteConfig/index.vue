<template>
  <div class="interracte-config">
    <div class="icon-title">互动输出配置</div>
    <div class="interracte-config-content">
      <el-form
        ref="form"
        :model="form"
        label-width="150px"
        label-position="left"
      >
        <el-form-item label="双流：">
          <el-select v-model="form.SecVideoSrc" :disabled="disabled">
            <el-option
              v-for="item in channelList"
              :key="item.id"
              :label="item.label"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="音频格式：">
          <el-select v-model="form.AudType" :disabled="disabled">
            <el-option
              v-for="item in audioFormats"
              :key="item"
              :label="item"
              :value="item"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="发送双流：">
          <el-checkbox v-model="form.IsSendSec" :disabled="disabled" />
        </el-form-item>
        <el-form-item label=" ">
          <el-button
            type="primary"
            :loading="loading"
            @click="saveConfig"
          >保存</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import { getInteractConfig, setInteractConfig } from '@/api/application'
import { getInteractList } from '@/api/interactive'
import { getChannel } from '../getChannel'
export default {
  mixins: [getChannel],
  data() {
    return {
      // 互动时禁止修改互动配置
      disabled: false,
      // 保存按钮加载
      loading: false,
      // 音频格式列表
      audioFormats: ['PCMU', 'PCMA', 'G722.1.C', 'AACLC_16K', 'AACLC_32K', 'AACLC_48K'],
      // 配置信息
      config: {},
      // 表单绑定数据
      form: {
        SecVideoSrc: '1_0',
        AudType: '',
        IsSendSec: false
      },
      channelIds: ['1', '2', '3', '4', '5', '6', '7', '8', '9']
    }
  },
  mounted() {
    this.getConfig()
    this.getInteractList()
  },
  methods: {
    // 获取互动状态 互动中禁止修改任何参数
    getInteractList() {
      getInteractList({}).then(res => {
        const interactListInfo = res.GetInteractListResp.InteractList
        if (interactListInfo) {
          const status = interactListInfo.InteractItem.Status
          this.disabled = ['connected', 'calling'].indexOf(status) > -1
        }
      })
    },
    getConfig() {
      // 获取互动配置
      getInteractConfig().then(res => {
        this.config = res.GetInteractOutChnCfgResp
        this.form.AudType = this.config.AudType
        this.form.SecVideoSrc = this.config.SecVideoSrc.ChnId + '_' + this.config.SecVideoSrc.EncId
        this.form.IsSendSec = this.config.IsSendSec === 'true'
      })
    },
    // 保存配置
    saveConfig() {
      // 拆解 NvrChnId_EncId
      const ids = this.form.SecVideoSrc.split('_')
      this.loading = true
      setInteractConfig({
        SetInteractOutChnCfgReq: {
          MainVideoSrc: this.config.MainVideoSrc,
          SecVideoSrc: {
            ChnId: ids[0],
            EncId: ids[1]
          },
          AudType: this.form.AudType,
          IsSendSec: this.form.IsSendSec
        }
      }).then(_ => {
        this.$message({
          type: 'success',
          message: '保存成功!'
        })
        this.loading = false
        // 保存成功刷新数据
        this.getConfig()
      })
    }
  }
}
</script>
<style lang="scss">
.interracte-config {
  &-content {
    margin: 16px 32px;
  }
}
</style>
