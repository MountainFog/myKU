<template>
  <div :class="['mode-container', (data.key === mode ? 'mode-container__active' : '')]">
    <div class="mode-icon" @click="selectMode">
      <svg-icon :icon-class="`mode_${data.key}`" class-name="mode-active-bg" />
    </div>
    <div class="mode-name">{{ data.modeName }}</div>
    <el-button
      v-for="operate in operations"
      v-show="!($store.getters.devType.indexOf('-V') < 0 && operate.key === 'InteracteConfig')"
      :key="operate.name"
      type="primary"
      :disabled="disabled"
      @click="toPage(operate.key)"
    >{{ operate.name }}</el-button>
  </div>
</template>
<script>
export default {
  props: {
    data: {
      type: Object,
      default() {
        return {}
      }
    },
    mode: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      index: 1,
      operations: [
        { name: '视频输出', key: 'VideoOutput' },
        { name: '音频矩阵', key: 'AudioMatrix' },
        { name: '导播指令', key: 'DirectorInstruct' },
        { name: '中控配置', key: 'CentralDev' },
        { name: '互动配置', key: 'InteracteConfig' }
      ]
    }
  },
  computed: {
    disabled() {
      return this.data.key !== this.mode
    }
  },
  methods: {
    selectMode() {
      this.$emit('checkedChange', this.data)
    },
    toPage(mode) {
      this.$router.push({
        path: '/systemManage/modeConfig',
        query: {
          mode
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.mode-container {
  display: inline-block;
  padding: 56px;
  background: #2A313E;
  border-radius: 8px;
  transition: background 0.2s;

  &:hover {
    background: #373F4F;
  }

  // 模式图标
  .mode-icon {
    width: 84px;
    height: 84px;
    margin: 0 auto;
    color: #a9b4c9;
    border-radius: 28px;
    border: 2px solid #151A23;
    background: linear-gradient(138deg, #242A36 0%, #2A313D 100%);
    box-shadow: -8px -8px 17px -2px rgba(115,127,152,0.22), 8px 8px 17px -2px rgba(0,0,0,0.50);
    cursor: pointer;
  }

  .mode-active-bg {
    margin: 16px;
    width: 50px;
    height: 50px;
    fill: linear-gradient(138deg, #242A36 0%, #2A313D 100%);
  }

  // 模式名称
  .mode-name {
    margin: 24px 0 40px;
    text-align: center;
    font-size: 24px;
  }

  &.mode-container__active {
    background: #373F4F;

    .mode-icon {
      color: #ffdbcd;
      background: linear-gradient(180deg, #FE2C29 0%, #FF8958 100%);
      border: 2px solid #FF7E5E;
      box-shadow: -8px -8px 17px -2px rgba(115,127,152,0.22), 8px 8px 17px -2px rgba(0,0,0,0.50);
    }
  }
}

  // 模式按钮
  .el-button {
    display: block;
    width: 200px;
    height: 40px;
    margin: 24px 0 0 0;
    background: rgba(29,34,44,0.65);
    border: none;

    &:hover {
      background: rgba(31, 117, 255, 1);
    }

    &:active {
      background: rgba(31, 117, 255, 0.8);
    }
  }

  .el-button.is-disabled {
    background: #1D222C;
  }
</style>
