<template>
  <div class="table-item">
    <el-checkbox
      v-if="type === 'checkbox'"
      v-model="rowData[property]"
      :disabled="disabled"
    />
    <el-slider
      v-if="type === 'slider' || type === 'slider-vertical'"
      v-model="rowData[property]"
      :min="-100"
      :max="0"
      disabled
      height="104px"
      :class="type === 'slider-vertical' ? 'slider-vertical' : 'slider-horizontal'"
      :vertical="type === 'slider-vertical'"
    />
    <el-select
      v-if="type === 'select'"
      v-model="rowData[property]"
      placeholder=""
    >
      <el-option
        v-for="num in 101"
        :key="num"
        :label="num - 1"
        :value="num - 1"
      />
    </el-select>
    <el-select
      v-if="type === 'delaySelect'"
      v-model="rowData[property]"
      placeholder=""
    >
      <el-option
        v-for="num in 101"
        :key="num"
        :label="(num - 1) * 10"
        :value="(num - 1) * 10"
      />
    </el-select>
    <el-button
      v-if="type === 'button'"
      class="equb-setting"
      type="text"
      @click="openEqubDialog"
    >
      <svg-icon
        icon-class="setting"
        width="16"
      />
    </el-button>
  </div>
</template>
<script>
export default {
  props: {
    checked: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: ''
    },
    property: {
      type: String,
      default: ''
    },
    rowData: {
      type: Object,
      default() {
        return {}
      }
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {}
  },
  methods: {
    openEqubDialog() {
      this.$emit('openEqubDialog', this.rowData[this.property], this.property)
    }
  }
}
</script>
<style lang="scss">
.table-item {
  .el-slider {
    margin: 0 auto;
  }

  .el-slider__runway.disabled .el-slider__bar {
    background: #1F75FF;
  }

  .el-slider__runway.disabled .el-slider__button {
    border-color: #1F75FF;
  }

  .equb-setting {
    padding: 0;
    font-size: 20px;
  }

  // 水平方向
  .slider-vertical {
    width: 36px;
  }

  // 垂直方向
  .slider-horizontal {
    width: 100px;
  }
}
</style>
