<template>
  <div class="mode-config-tab">
    <el-tabs v-model="activeName">
      <el-tab-pane label="视频输出" name="VideoOutput" />
      <el-tab-pane label="音频矩阵" name="AudioMatrix" />
      <el-tab-pane label="导播指令" name="DirectorInstruct" />
      <el-tab-pane label="中控配置" name="CentralDev" />
      <el-tab-pane v-if="$store.getters.devType.indexOf('-V') > -1" label="互动配置" name="InteracteConfig" />
    </el-tabs>
    <keep-alive exclude="AudioMatrix">
      <component :is="activeName" />
    </keep-alive>
  </div>
</template>
<script>
import VideoOutput from './videoOutput'
import AudioMatrix from './audioMatrix'
import InteracteConfig from './interacteConfig'
import CentralDev from './centralDev'
import DirectorInstruct from './directorInstruct'
export default {
  name: 'ModeConfig',
  components: {
    VideoOutput,
    AudioMatrix,
    DirectorInstruct,
    InteracteConfig,
    CentralDev
  },
  data() {
    return {
      activeName: 'VideoOutput'
    }
  },
  mounted() {
    this.activeName = this.$route.query.mode
  }
}
</script>
<style lang="scss">
.mode-config-tab {
  padding: 16px 40px;

  .el-tabs__item {
    height: 50px;
    line-height: 50px;
    color: $-fff-85;
    font-size: 18px;
  }

  .el-tabs__item.is-active {
    color: #3884FF;
  }

  .el-tabs__nav-wrap::after {
    height: 1px;
    background-color: rgba(216,222,234,0.20);
  }

  .el-tabs__active-bar {
    background-color: #1F75FF;
  }
}

</style>
