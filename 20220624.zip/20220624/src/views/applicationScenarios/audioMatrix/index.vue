<template>
  <div class="audio-matrix">
    <div class="icon-title">音频参数配置</div>
    <div class="audio-matrix-content">
      <div class="params-item">
        <span class="params-item-title">音频编码格式：</span>
        <el-select
          v-model="audioCodeValue"
          :disabled="isRecording"
          type="primary"
        >
          <el-option
            v-for="item in audioFormat"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </div>
      <div class="params-item">
        <span class="params-item-title">混音复制：</span>
        <el-select
          v-model="mixingCopy"
          class="mix-sound spacing_8"
          @change="resetIpcIn"
        >
          <el-option
            :value="false"
            label="关闭"
          />
          <el-option
            :value="true"
            label="开启"
          />
        </el-select>
        <el-button @click="openRemixConfigForm">
          <svg-icon
            icon-class="setting"
            class-name="spacing_8"
          />
          混音设置
        </el-button>
      </div>
      <div class="params-item">
        <span class="params-item-title">参考源音量(DB)：</span>
        <el-select v-model="refVolume">
          <el-option
            label="0"
            value="0"
          />
          <el-option
            v-for="index in 100"
            :key="index"
            :value="index"
            :label="index"
          />
        </el-select>
      </div>
      <div class="params-item">
        <span class="params-item-title">参考源：</span>
        <el-select v-model="refSource">
          <el-option
            v-for="item in refSourceList"
            :key="item.item"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </div>
    </div>
    <div class="icon-title">互动输入参数配置</div>
    <div class="audio-matrix-content">
      <div class="params-item">
        <span class="params-item-title">静音：</span>
        <el-select
          v-model="inputIsMuted"
          type="primary"
        >
          <el-option
            :value="false"
            label="关闭"
          />
          <el-option
            :value="true"
            label="开启"
          />
        </el-select>
      </div>
      <div class="params-item">
        <span class="params-item-title">音量设定：</span>
        <div class="volume-bar">
          <el-slider v-model="inputVolume" />
        </div>
      </div>
    </div>
    <div class="icon-title">互动输出参数配置</div>
    <div class="audio-matrix-content">
      <div class="params-item">
        <span class="params-item-title">静音：</span>
        <el-select
          v-model="outputIsMuted"
          type="primary"
        >
          <el-option
            :value="false"
            label="关闭"
          />
          <el-option
            :value="true"
            label="开启"
          />
        </el-select>
      </div>
      <div class="params-item">
        <span class="params-item-title">音量设定：</span>
        <div class="volume-bar">
          <el-slider v-model="outputVolume" />
        </div>
      </div>
      <div class="params-item">
        <span class="params-item-title">延时：</span>
        <el-select
          v-model="timeDelay"
          class="spacing_8"
        >
          <el-option
            v-for="index in 101"
            :key="index"
            :value="(index - 1) * 10"
            :label="(index - 1) * 10"
          />
        </el-select>
        <span>ms</span>
      </div>
    </div>
    <div class="icon-title">当前音频状态</div>
    <div class="audio-matrix-content">
      <div class="status-item">
        <span>输入源：</span>
        <el-select
          v-model="inputSource"
          style="width: 118px;"
        >
          <el-option
            v-for="index in 11"
            :key="index"
            :label="tableMap[index - 1].label"
            :value="tableMap[index - 1].prop"
          />
        </el-select>
      </div>
      <div class="status-item">回声传输损耗（db）：{{ capPowerInfo.ERLValue }}</div>
      <div class="status-item">回声抑制比（db）：{{ capPowerInfo.ERLEValue }}</div>
      <div class="status-item">算法输入功率（dBm）：{{ capPowerInfo.CapPower }}</div>
      <div class="status-item">参考信号输入功率（dBm）：{{ capPowerInfo.RefPower }}</div>
    </div>
    <!-- 音频状态表格 -->
    <div class="audio-matrix-content">
      <el-table
        v-loading="tableLoading"
        :data="tableData"
        border
        header-align="center"
        element-loading-background="rgba(0, 0, 0, 0.8)"
      >
        <el-table-column
          fixed
          prop="key"
          label=""
          width="132"
        />
        <el-table-column
          v-for="column in tableMap"
          :key="column.prop"
          :prop="column.prop"
          :fixed="column.fixed"
          :label="column.label"
          align="center"
          :width="column.width"
        >
          <template slot-scope="scope">
            <tableItem
              v-if="(typeof scope.row[column.prop]) !== 'undefined'"
              :row-data="scope.row"
              :type="column.type || scope.row.type"
              :property="scope.column['property']"
              :disabled="setDisabled(scope.column.property)"
              @openEqubDialog="openEqubDialog"
            />
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="audio-matrix-save">
      <el-button
        type="primary"
        :loading="saveLoading"
        @click="saveVmtParams"
      >保存</el-button>
    </div>
    <!-- 均衡配置弹出框 -->
    <el-dialog
      :visible.sync="visible"
      title="3A&均衡参数配置"
      width="492px"
    >
      <el-form label-position="right">
        <el-form-item
          label="当前混音设备："
          label-width="120px"
        >
          {{ dialogData.name }}
        </el-form-item>
        <el-form-item
          label="自动增益："
          label-width="120px"
        >
          <el-checkbox v-model="dialogData.AGCEnabled" />
        </el-form-item>
        <el-form-item
          label="AEC回音消除："
          label-width="120px"
        >
          <el-checkbox v-model="dialogData.AECEnabled" />
          <el-select
            v-model="dialogData.AECLv"
            :disabled="!dialogData.AECEnabled"
            class="width__304"
          >
            <el-option
              v-for="index in 5"
              :key="index"
              :label="index"
              :value="index"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          label="降噪："
          label-width="120px"
        >
          <el-checkbox v-model="dialogData.ANSEnabled" />
          <el-select
            v-model="dialogData.ANSLv"
            :disabled="!dialogData.ANSEnabled"
            class="width__304"
          >
            <el-option
              v-for="index in 4"
              :key="index"
              :label="index - 1"
              :value="index - 1"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          label="均衡配置："
          label-width="120px"
        >
          <el-select
            v-model="dialogData.EquType"
            style="width: 100%;"
            @change="setEqubConfig"
          >
            <el-option
              v-for="item in EquTypeList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <div class="equb-wrapper">
        <div class="equb-scale__y">
          <div>12</div>
          <div>6</div>
          <div>0</div>
          <div>-6</div>
          <div>-12</div>
        </div>
        <div class="equb-slider">
          <div
            v-for="(item, index) in equbList"
            :key="index"
            class="equb-slider-item"
          >
            <el-slider
              v-model="dialogData.EqubConfigList[index]"
              :disabled="dialogData.EquType === 'unable'"
              :vertical="true"
              :min="-12"
              :max="12"
            />
            <span class="equb-scale__x">{{ item }}</span>
          </div>
        </div>
      </div>
      <div class="equb-dialog__func">
        <el-button
          type="primary"
          @click="saveEqub"
        >确认</el-button>
        <el-button @click="visible = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 混音设置一级弹出框 -->
    <el-dialog
      :visible.sync="mixVisible"
      title="混音设置"
      width="410px"
      class="mix-dialog"
    >
      <div class="mix-dialog-item">
        <div class="item-title">AutoMix混音深度：</div>
        <el-select
          v-model="remixConfig.MixDepth"
          class="mixing-select"
          @change="changeMixDepth"
        >
          <el-option
            v-for="index in 4"
            :key="index"
            :value="index"
            :label="index"
          />
        </el-select>
      </div>
      <div class="mix-dialog-item">
        <div class="item-title">闪避功率设定(DB)：</div>
        <el-select
          v-model="remixConfig.DuckRefPower"
          class="mixing-select"
        >
          <el-option
            v-for="index in 101"
            :key="index"
            :value="index - 101"
            :label="index - 101"
          />
        </el-select>
      </div>
      <div class="mix-dialog-item">
        <div class="item-title">闪避算法参数：</div>
        <el-button @click="openMixDuckForm">配置</el-button>
      </div>
      <p>强制混音通道设置<span>混音优先级设置</span></p>
      <div class="channel-list">
        <el-checkbox-group
          v-model="mixingCheckeds"
          :max="remixConfig.MixDepth === 1 ? 1 : 2"
        >
          <div
            v-for="item in mixingOptions"
            :key="item.value"
            class="channel-list-item"
          >
            <el-checkbox
              :label="item.value"
            >{{ item.label }}</el-checkbox>
            <el-select
              v-model="item.mixingLevel"
              :disabled="mixingCheckeds.indexOf(item.value) < 0"
            >
              <el-option value="0" label="无" />
              <el-option value="1" />
              <el-option value="2" />
            </el-select>
          </div>
        </el-checkbox-group>
      </div>
      <div class="equb-dialog__func">
        <el-button
          type="primary"
          @click="saveAudioMixParams"
        >确认</el-button>
        <el-button @click="cancelAudioMixParams">取消</el-button>
      </div>
    </el-dialog>
    <!-- 混音闪避算法二级弹出框 -->
    <el-dialog
      :visible.sync="duckVisible"
      title="闪避算法设置"
      width="410px"
    >
      <el-form
        ref="remixChildForm"
        :model="remixChildForm"
        :rules="remixRules"
        label-width="110px"
        label-position="left"
        class="duck-config-form"
      >
        <el-form-item label="算法间隔时间" prop="DuckInterval">
          <el-input v-model.number="remixChildForm.DuckInterval" maxlength="5" /><span class="input-tips">1-20000（毫秒）</span>
        </el-form-item>
        <el-form-item label="检测次数" prop="DuckCheckCount">
          <el-input v-model.number="remixChildForm.DuckCheckCount" maxlength="2" /><span class="input-tips">1-10（次）</span>
        </el-form-item>
        <el-form-item label="检测间隔" prop="DuckCheckInterval">
          <el-input v-model.number="remixChildForm.DuckCheckInterval" maxlength="4" /><span class="input-tips">1-5000（毫秒）</span>
        </el-form-item>
      </el-form>
      <div class="equb-dialog__func">
        <el-button
          type="primary"
          @click="saveRemixChildForm"
        >确认</el-button>
        <el-button @click="duckVisible = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { getAmtParam, getAmtPowerAverage, setAmtParam } from '@/api/application'
import { getSvrState } from '@/api/deviceInfo'
import { jsonToXml } from '@/utils/dataParse'
import TableItem from '../components/tableItem.vue'
export default {
  components: {
    TableItem
  },
  data() {
    const limit_20000 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('不能为空'))
      } else if (value < 1 || value > 20000) {
        callback(new Error('超出可设置范围'))
      } else {
        callback()
      }
    }
    const limit_10 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('不能为空'))
      } else if (value < 1 || value > 10) {
        callback(new Error('超出可设置范围'))
      } else {
        callback()
      }
    }
    const limit_5000 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('不能为空'))
      } else if (value < 1 || value > 5000) {
        callback(new Error('超出可设置范围'))
      } else {
        callback()
      }
    }
    return {
      value: 1,
      // 录制状态
      isRecording: false,
      visible: false,
      mixVisible: false,
      // 闪避算法配置 弹窗
      duckVisible: false,
      saveLoading: false,
      // 原始数据
      GetAmtParamResp: {},
      GetAmtPowerAverageResp: {},
      // 音频编码格式选择列表
      audioFormat: [
        { label: 'PCMA', value: 'g711a' },
        { label: 'PCMU', value: 'g711u' },
        /* { label: 'G722', value: 'g722' }, */
        { label: 'AACLC_16(单声道)', value: 'aaclc16_mono' },
        { label: 'AACLC_32(单声道)', value: 'aaclc32_mono' },
        { label: 'AACLC_48(单声道)', value: 'aaclc48_mono' },
        { label: 'AACLC_16(双声道)', value: 'aaclc16_stereo' },
        { label: 'AACLC_32(双声道)', value: 'aaclc32_stereo' },
        { label: 'AACLC_48(双声道)', value: 'aaclc48_stereo' }
      ],
      // 参考源选择列表
      refSourceList: [
        { label: 'LINE OUT1', value: 'line_out,1' },
        { label: 'LINE OUT2', value: 'line_out,2' },
        { label: 'HDMI OUT1', value: 'hdmi_out,1' },
        { label: 'HDMI OUT2', value: 'hdmi_out,2' }
      ],
      // 均衡配置
      equbList: ['31.5', '63', '125', '250', '500', '1K', '2K', '3K', '4K'],
      // 音频编码格式选中值
      audioCodeValue: '',
      // 混音配置
      remixConfig: {
        // 混音深度
        MixDepth: 1,
        // 闪避功率
        DuckRefPower: -40,
        // 闪避算法间隔
        DuckInterval: 5000,
        // 闪避算法检测次数
        DuckCheckCount: 5,
        // 闪避算法检测间隔
        DuckCheckInterval: 1000
      },
      // 二级弹窗表单内容
      remixChildForm: {
        // 闪避算法间隔
        DuckInterval: 5000,
        // 闪避算法检测次数
        DuckCheckCount: 5,
        // 闪避算法检测间隔
        DuckCheckInterval: 1000
      },
      // 强制混音设备列表 - 可选项
      mixingOptions: [],
      // 强制混音 - 已选项
      mixingCheckeds: [],
      // 混音复制
      mixingCopy: true,
      // 参考源音量
      refVolume: 0,
      // 参考源
      refSource: '',
      // 输入 - 是否静音
      inputIsMuted: true,
      // 输入 - 音量设定
      inputVolume: 50,
      // 输出 - 是否静音
      outputIsMuted: true,
      // 输出 - 音量设定
      outputVolume: 75,
      // 延时
      timeDelay: 500,
      // 表格上方功率信息对应的输入源
      inputSource: 'mic_in1',
      // 表格上方功率信息
      capPowerInfo: {},
      // 加载动画
      tableLoading: true,
      // 表格列映射参数
      tableMap: [
        {
          prop: 'mic_in1',
          label: 'MIC IN1',
          width: '96'
        },
        {
          prop: 'mic_in2',
          label: 'MIC IN2',
          width: '96'
        },
        {
          prop: 'mic_in3',
          label: 'MIC IN3',
          width: '96'
        },
        {
          prop: 'mic_in4',
          label: 'MIC IN4',
          width: '96'
        },
        {
          prop: 'mic_in5',
          label: 'MIC IN5',
          width: '96'
        },
        {
          prop: 'mic_in6',
          label: 'MIC IN6',
          width: '96'
        },
        {
          prop: 'dmic_in1',
          label: 'DMIC IN1',
          width: '96'
        },
        {
          prop: 'line_in1',
          label: 'LINE IN1',
          width: '96'
        },
        {
          prop: 'line_in2',
          label: 'LINE IN2',
          width: '96'
        },
        {
          prop: 'hdmi_in1',
          label: 'HDMI IN1',
          width: '96'
        },
        {
          prop: 'hdmi_in2',
          label: 'HDMI IN2',
          width: '96'
        },
        {
          prop: 'ipc_in1',
          label: 'IPC IN1',
          width: '96'
        },
        {
          prop: 'ipc_in2',
          label: 'IPC IN2',
          width: '96'
        },
        {
          prop: 'ipc_in3',
          label: 'IPC IN3',
          width: '96'
        },
        {
          prop: 'ipc_in4',
          label: 'IPC IN4',
          width: '96'
        },
        {
          prop: 'ipc_in5',
          label: 'IPC IN5',
          width: '96'
        },
        {
          prop: 'ipc_in6',
          label: 'IPC IN6',
          width: '96'
        },
        {
          prop: 'Volume',
          label: '音量设定',
          fixed: 'right',
          width: '96',
          type: 'select'
        },
        {
          prop: 'Gain',
          label: '灵敏度',
          fixed: 'right',
          width: '96',
          type: 'select'
        },
        {
          prop: 'DelayTime',
          label: '延时',
          fixed: 'right',
          width: '96',
          type: 'delaySelect'
        },
        {
          prop: 'Mute',
          label: '静音',
          fixed: 'right',
          width: '96',
          type: ''
        },
        {
          prop: 'Power',
          label: '功率',
          fixed: 'right',
          width: '120',
          type: 'slider'
        }
      ],
      // 表格内数据
      tableData: [],
      // 均衡配置选项
      EquTypeList: [
        {
          label: '不支持',
          value: 'unable'
        },
        {
          label: '最佳男声',
          value: 'man'
        },
        {
          label: '最佳女声',
          value: 'woman'
        },
        {
          label: '用户自定义',
          value: 'usrdef'
        }
      ],
      // 3A&均衡配置
      dialogData: {
        Intfc: '',
        AGCEnabled: false,
        AECEnabled: false,
        AECLv: '1',
        ANSEnabled: false,
        ANSLv: '0',
        EquType: 'unable',
        EqubConfigList: [0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      // 功率定时器
      timer: null,
      remixRules: {
        DuckInterval: [{ validator: limit_20000, trigger: 'change' }],
        DuckCheckCount: [{ validator: limit_10, trigger: 'change' }],
        DuckCheckInterval: [{ validator: limit_5000, trigger: 'change' }]
      },
      // 提交时，参数错误提示
      errMessage: ''
    }
  },
  watch: {
    mixingCheckeds(nv) {
      this.mixingOptions.forEach(item => {
        if (nv.indexOf(item.value) < 0) {
          item.mixingLevel = '0'
        }
      })
    }
  },
  mounted() {
    this.getAudioMatrixData()
    // 获取录制状态
    getSvrState().then((res) => {
      this.isRecording = res.SvrStateResp.Mp4RecState === 'recording'
    })
  },
  beforeDestroy() {
    if (this.timer) {
      clearInterval(this.timer)
    }
  },
  methods: {
    // 获取音频矩阵数据
    getAudioMatrixData() {
      getAmtParam().then((res) => {
        const tableData = this.formatVmtParams(res.GetAmtParamResp)
        this.GetAmtParamResp = res.GetAmtParamResp
        tableData.push({})
        this.$set(this, 'tableData', tableData)
        this.tableLoading = false
        this.refreshPowerAverge()
      })
    },
    // 获取功率参数 每秒刷新一次
    refreshPowerAverge() {
      if (this.timer) {
        clearInterval(this.timer)
      }
      this.timer = setInterval(() => {
        getAmtPowerAverage().then((res) => {
          const powerList =
            res.GetAmtPowerAverageResp.CapPowerInfoList.CapPowerInfoItem
          const powers = this.findSpecifProperty('CapPower', powerList)
          const capPowerInfo = this.findCapPowerInfo(
            this.inputSource,
            powerList
          )
          this.$set(this.tableData, 9, powers)
          this.$set(this, 'capPowerInfo', capPowerInfo)
          // 设置功率列
          this.setTableOutPower(res.GetAmtPowerAverageResp)
        })
      }, 1000)
    },
    // 设置表格功率数据
    setTableOutPower(res) {
      if (!this.tableData.length) return
      const list = res.PlyPowerInfoList.PlyPowerInfoItem
      this.tableData[4].Power = Number(res.CmpPowerInfo.Power)
      for (let i = 0; i < list.length; i++) {
        switch (list[i].Intfc) {
          case 'line_out,1':
            this.$set(this.tableData[0], 'Power', Number(list[i].Power))
            break
          case 'line_out,2':
            this.$set(this.tableData[1], 'Power', Number(list[i].Power))
            break
          case 'hdmi_out,1':
            this.$set(this.tableData[2], 'Power', Number(list[i].Power))
            break
          case 'hdmi_out,2':
            this.$set(this.tableData[3], 'Power', Number(list[i].Power))
            break
          default:
            break
        }
      }
    },
    resetIpcIn(val) {
      if (val) {
        for (let i = 0; i < 5; i++) {
          const item = this.tableData[i]
          for (const key in item) {
            if (key.indexOf('ipc_in') > -1) {
              item[key] = false
            }
          }
        }
      }
    },
    setDisabled(property) {
      const isIpc = property.indexOf('ipc_in') > -1
      return isIpc && this.mixingCopy
    },
    // 均衡配置 - 保存
    saveEqub() {
      const tableEqubData = this.tableData[8]
      const data = tableEqubData[this.dialogData.key]
      const defaultEqubStr =
        this.dialogData.EqubConfigList.toString() +
        ',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
      for (const key in this.dialogData) {
        // 将dialog内的数据赋值给原始数据
        // name、key、eqbuConfigList等参数除外
        if (['name', 'key', 'EqubConfigList'].indexOf(key) < 0) {
          data[key] = this.dialogData[key]
        }
      }
      // 将被选中的均衡配置数组格式转为字符串
      switch (this.dialogData.EquType) {
        case 'man':
          data.EquBufMan = defaultEqubStr
          break
        case 'woman':
          data.EquBufWoman = defaultEqubStr
          break
        case 'usrdef':
          data.EquBufUsrdef = defaultEqubStr
          break
        default:
          break
      }
      this.visible = false
    },
    // 保存混音设置弹出框参数
    saveAudioMixParams() {
      const AutoMixParam = this.GetAmtParamResp.AutoMixParam
      // 混音深度及闪避算法
      for (const key in this.remixConfig) {
        if (Object.hasOwnProperty.call(this.remixConfig, key)) {
          AutoMixParam[key] = this.remixConfig[key]
        }
      }
      // 强制混音通道
      AutoMixParam.ForceChnList.Intfc = this.mixingCheckeds
      const mixingLevel = []
      // 根据通道已选项的顺序， 设置需要发送至后台的‘优先级’参数的拼接顺序
      for (let i = 0; i < this.mixingCheckeds.length; i++) {
        const value = this.mixingCheckeds[i]
        const data = this.mixingOptions.find(item => {
          return item.value === value
        })
        mixingLevel.push(data.mixingLevel)
      }
      // ‘优先级’数组字符串化
      AutoMixParam.ForecChnDuckLevel = mixingLevel.toString()
      this.mixVisible = false
      this.mixingCheckeds = []
    },
    // 关闭混音设置一级弹窗
    cancelAudioMixParams() {
      this.mixingCheckeds = []
      this.mixVisible = false
    },
    // 保存音频矩阵配置
    saveVmtParams() {
      // 此错误提示仅用来处理以下参数在xml化的过程中，检查参数是否正确
      this.errMessage = ''
      const AutoMixParam = this.getAutoMixParamXml()
      const CapParamList = this.getCapParamListXml()
      const CmpEncParam = this.getCmpEncParamXml()
      const IpcParamList = this.getIpcParamListXml()
      const { IntInParamList, IntOutParamList } = this.getInOutParamListXml()
      const RefParam = this.getRefParamXml()
      const PlayParamList = []
      const PlayParamName = [
        'line_out,1',
        'line_out,2',
        'hdmi_out,1',
        'hdmi_out,2'
      ]
      for (let i = 0; i < 4; i++) {
        PlayParamList.push(
          this.getPlayParamListXml(this.tableData[i], PlayParamName[i])
        )
      }
      // 以上参数xml化过程中，检查参数存在错误
      if (this.errMessage !== '') {
        this.$message({
          showClose: true,
          type: 'error',
          message: this.errMessage
        })
        return
      }
      const data = {
        SetAmtParamReq: {
          CabList: this.GetAmtParamResp.CabList,
          CapParamList,
          IpcParamList: IpcParamList,
          CmpEncParam,
          PlayParamList: {
            P_R_O_P: {
              num: 4,
              max: 10
            },
            K_E_Y: 'PlayParamItem',
            V_A_L_U_E: PlayParamList
          },
          IntInParamList,
          IntOutParamList,
          RefParam,
          AutoMixParam,
          MixDuplicate: this.mixingCopy
        }
      }
      this.saveLoading = true
      setAmtParam(data)
        .then((_) => {
          this.saveLoading = false
          this.$message({
            type: 'success',
            message: '保存成功!'
          })
          this.getAudioMatrixData()
        })
        .catch((_) => {
          this.saveLoading = false
        })
    },
    // 打开均衡配置弹出框
    openEqubDialog(data, key) {
      this.dialogData.key = key
      this.dialogData.name = this.formatDevName(data.Intfc)
      for (const key in data) {
        let value = data[key]
        if (value === 'true') {
          value = true
        }
        if (value === 'false') {
          value = false
        }
        this.dialogData[key] = value
      }
      this.setEqubConfig(data.EquType)
      this.visible = true
    },
    // 设置均衡配置
    setEqubConfig(type) {
      let defaultList = [0, 0, 0, 0, 0, 0, 0, 0, 0]
      switch (type) {
        case 'man':
          defaultList = this.formatEqubList(this.dialogData.EquBufMan)
          break
        case 'woman':
          defaultList = this.formatEqubList(this.dialogData.EquBufWoman)
          break
        case 'usrdef':
          defaultList = this.formatEqubList(this.dialogData.EquBufUsrdef)
          break
        default:
          break
      }
      this.$set(this.dialogData, 'EqubConfigList', defaultList)
    },
    // 把均衡配置参数的字符串格式化成数组
    formatEqubList(data) {
      const list = data.split(',').splice(0, 9)
      for (let i = 0; i < list.length; i++) {
        list[i] = Number(list[i])
      }
      return list
    },
    // 格式化音频参数数据
    // 后端数据结构不合理，导致数据清洗非常难处理，慎动！
    formatVmtParams(data) {
      const tableData = []
      const playParams = data.PlayParamList.PlayParamItem
      const capParams = data.CapParamList.CapParamItem
      const lineOut_1 = this.findVmtProperty(playParams[0])
      const lineOut_2 = this.findVmtProperty(playParams[1])
      const hdmiOut_1 = this.findVmtProperty(playParams[2])
      const hdmiOut_2 = this.findVmtProperty(playParams[3])
      const encOut_1 = this.findVmtProperty(data.CmpEncParam)
      const mutes = this.findSpecifProperty('Mute', capParams)
      const volumes = this.findSpecifProperty('Volume', capParams)
      const gains = this.findSpecifProperty('Gain', capParams)
      const equbParams = this.bindEqubParamsCell(capParams)
      const outputParams = data.IntOutParamList.IntOutParamItem[0]
      const inputParams = data.IntInParamList.IntInParamItem[0]
      // 输入 - 是否静音
      this.inputIsMuted = inputParams.Mute === 'true'
      // 输入 - 音量设定
      this.inputVolume = Number(inputParams.Volume)
      // 输出 - 是否静音
      this.outputIsMuted = outputParams.Mute === 'true'
      // 输出 - 音量设定
      this.outputVolume = Number(outputParams.Volume)
      // 延时
      this.timeDelay = Number(outputParams.DelayTime)
      // 参考源
      this.refSource = data.RefParam.Intfc
      // 音频编码格式
      this.audioCodeValue = data.CmpEncParam.AudType
      // 参考源音量
      this.refVolume = Number(data.RefParam.Volume)
      // 混音复制
      this.mixingCopy = data.MixDuplicate === 'true'
      tableData.push(
        lineOut_1,
        lineOut_2,
        hdmiOut_1,
        hdmiOut_2,
        encOut_1,
        mutes,
        volumes,
        gains,
        equbParams
      )
      // 表格数据双向绑定，每push一次，都会使表格重新渲染
      // so return出去，等表格数据加载完整，再向this.tableData赋值 节省性能
      return tableData
    },
    // 打开混音设置参数弹窗 - 数据回显
    openRemixConfigForm() {
      this.mixVisible = true
      const data = this.GetAmtParamResp.AutoMixParam
      const channelList = data.AutoMixChnList.Intfc
      this.mixingCheckeds = []
      this.mixingOptions = []
      // 混音深度
      this.remixConfig.MixDepth = Number(data.MixDepth)
      // 闪避功率
      this.remixConfig.DuckRefPower = Number(data.DuckRefPower)
      // 闪避算法间隔
      this.remixConfig.DuckInterval = Number(data.DuckInterval)
      // 闪避算法检测次数
      this.remixConfig.DuckCheckCount = Number(data.DuckCheckCount)
      // 闪避算法检测间隔
      this.remixConfig.DuckCheckInterval = Number(data.DuckCheckInterval)
      // 如果已选项列表为空字符串 则转化为空对象 方便后续赋值需要
      if (data.ForceChnList === '') {
        data.ForceChnList = {}
      } else if (data.ForceChnList.Intfc) {
        // 如果只有一项选中 是基本数据类型 直接push
        if (Array.isArray(data.ForceChnList.Intfc)) {
          this.mixingCheckeds.push(...data.ForceChnList.Intfc)
        } else {
          this.mixingCheckeds.push(data.ForceChnList.Intfc)
        }
      }
      const ForecChnDuckLevel = data.ForecChnDuckLevel.split(',')
      // 格式化成对象
      for (let i = 0; i < channelList.length; i++) {
        const item = {
          mixingLevel: '0',
          value: channelList[i],
          label: channelList[i]
            .replace(/_/, ' ')
            .replace(/,/, '')
            .toUpperCase()
        }
        // 如果当前通道为选中项，则优先级也要绑定选中值
        const idx = this.mixingCheckeds.indexOf(channelList[i])
        if (idx > -1) {
          // 获取选中项索引
          // 按照索引取值并赋值
          item.mixingLevel = ForecChnDuckLevel[idx]
        }
        this.mixingOptions.push(item)
      }
    },
    // 打开闪避算法参数表单 - 数据回显
    /*
      remixChildForm 为了解决：
      二级表单保存时，再打开应该为上次保存的数据。
      二级表单取消时，再打开，则为原始数据。
      一级表单保存时，将两个表单赋值给原始数据，
      一级表单取消时，再打开，则两个表格都是原始数据。
    */
    openMixDuckForm() {
      this.duckVisible = true
      for (const key in this.remixChildForm) {
        if (Object.hasOwnProperty.call(this.remixChildForm, key)) {
          this.remixChildForm[key] = this.remixConfig[key]
        }
      }
    },
    // 保存-闪避算法二级表单
    saveRemixChildForm() {
      this.$ref.remixChildForm.validate((valid) => {
        if (valid) {
          this.duckVisible = false
          for (const key in this.remixChildForm) {
            if (Object.hasOwnProperty.call(this.remixChildForm, key)) {
              this.remixConfig[key] = this.remixChildForm[key]
            }
          }
        }
      })
    },
    // 查找参数下的列表中属性
    findVmtProperty(object) {
      const lineOutObj = {}
      for (const key in object) {
        const value = object[key]
        if (typeof value === 'object' && value.MixChnItem) {
          value.MixChnItem.forEach((item) => {
            const name = item.Intfc.replace(/,/, '')
            lineOutObj[name] = item.MixEnabled === 'true'
          })
        } else if (key === 'Intfc') {
          // 设备名称
          lineOutObj.key = this.formatDevName(value)
        } else if (key === 'Mute') {
          lineOutObj[key] = value === 'true'
        } else {
          // 将字符串数字转化为Number类型
          var isNumber = Number(value)
          lineOutObj[key] = isNumber || isNumber === 0 ? isNumber : value
        }
      }
      lineOutObj.type = 'checkbox'
      return lineOutObj
    },
    // 查找功率相关属性和数据
    findSpecifProperty(prop, list) {
      const data = {}
      switch (prop) {
        case 'Mute':
          data.key = '静音'
          data.type = 'checkbox'
          break
        case 'Volume':
          data.key = '音量设定'
          data.type = 'select'
          break
        case 'Gain':
          data.key = '灵敏度'
          data.type = 'select'
          break
        case 'CapPower':
          data.key = '功率'
          data.type = 'slider-vertical'
          break
        default:
          break
      }
      list.forEach((item) => {
        const name = item.Intfc.replace(/,/, '')
        if (item[prop] === 'true' || item[prop] === 'false') {
          data[name] = item[prop] === 'true'
        } else {
          data[name] = Number(item[prop])
        }
      })
      return data
    },
    // 表格上方功率信息
    findCapPowerInfo(prop, list) {
      for (let i = 0; i < list.length; i++) {
        const name = list[i].Intfc.replace(/,/, '')
        if (prop === name) {
          return list[i]
        }
      }
    },
    // 在单元格内绑定均衡参数的数据
    bindEqubParamsCell(list) {
      const data = {}
      data.key = '3A&均衡参数'
      data.type = 'button'
      list.forEach((item) => {
        const name = item.Intfc.replace(/,/, '')
        data[name] = item
      })
      return data
    },
    // 格式化设备名称
    formatDevName(name) {
      const names = [
        'mic_in,1',
        'mic_in,2',
        'mic_in,3',
        'mic_in,4',
        'mic_in,5',
        'mic_in,6',
        'dmic_in,1',
        'hdmi_in,1',
        'hdmi_in,2',
        'ipc_in,1',
        'ipc_in,2',
        'ipc_in,3',
        'ipc_in,4',
        'ipc_in,5',
        'ipc_in,6',
        'line_out,1',
        'line_out,2',
        'hdmi_out,1',
        'hdmi_out,2',
        'enc_out,1'
      ]
      const labels = [
        'MIC IN1',
        'MIC IN2',
        'MIC IN3',
        'MIC IN4',
        'MIC IN5',
        'MIC IN6',
        'DMIC IN1',
        'HDMI IN1',
        'HDMI IN2',
        'IPC IN1',
        'IPC IN2',
        'IPC IN3',
        'IPC IN4',
        'IPC IN5',
        'IPC IN6',
        'LINE OUT1',
        'LINE OUT2',
        'HDMI OUT1',
        'HDMI OUT2',
        'ENCODER OUT'
      ]
      const index = names.indexOf(name)
      return labels[index]
    },
    // 混音设置 xml
    getAutoMixParamXml() {
      const AutoMixParam = this.GetAmtParamResp.AutoMixParam
      const obj = {
        Enabled: AutoMixParam.Enabled,
        MixDepth: AutoMixParam.MixDepth,
        DuckCheckCount: AutoMixParam.DuckCheckCount,
        DuckCheckInterval: AutoMixParam.DuckCheckInterval,
        DuckInterval: AutoMixParam.DuckInterval,
        DuckRefPower: AutoMixParam.DuckRefPower,
        AutoMixChnList: {
          P_R_O_P: {
            num: 11,
            max: 20
          },
          K_E_Y: 'Intfc',
          V_A_L_U_E: AutoMixParam.AutoMixChnList.Intfc
        },
        ForceChnList: {
          P_R_O_P: {
            num: 1,
            max: 4
          },
          K_E_Y: 'Intfc',
          V_A_L_U_E: AutoMixParam.ForceChnList.Intfc
            ? Array.isArray(AutoMixParam.ForceChnList.Intfc)
              ? AutoMixParam.ForceChnList.Intfc
              : [AutoMixParam.ForceChnList.Intfc]
            : []
        },
        ForecChnDuckLevel: AutoMixParam.ForecChnDuckLevel
      }
      return jsonToXml(obj)
    },
    // 表格(列) IPC输入 xml
    getIpcParamListXml() {
      const IpcParamList = this.GetAmtParamResp.IpcParamList.IpcParamItem
      let str = ''
      IpcParamList.forEach((item) => {
        const name = item.Intfc.replace(/_/, ' ').replace(/,/, '').toUpperCase()
        item.IntfcAlias = name
        str += `<IpcParamItem>${jsonToXml(item)}</IpcParamItem>`
      })
      return str
    },
    // 表格(行) 静音、音量、灵敏度 xml
    getCapParamListXml() {
      const mutes = this.tableData[5]
      const volumes = this.tableData[6]
      const gains = this.tableData[7]
      const object = this.tableData[8]
      let xml = ''
      for (const key in object) {
        if (['type', 'key'].indexOf(key) < 0) {
          const value = object[key]
          value.Volume = volumes[key]
          value.Mute = mutes[key]
          value.Gain = gains[key]
          value.IntfcAlias = value.Intfc.replace(/_/, ' ')
            .replace(/,/, '')
            .toUpperCase()
          xml += `<CapParamItem>${jsonToXml(value)}</CapParamItem>`
        }
      }
      return xml
    },
    // 表格(行) ENCODEROUT xml
    // 编码格式、参考源 xml
    getCmpEncParamXml() {
      const names = [
        'mic_in1',
        'mic_in2',
        'mic_in3',
        'mic_in4',
        'mic_in5',
        'mic_in6',
        'dmic_in1',
        'hdmi_in1',
        'hdmi_in2',
        'ipc_in1',
        'ipc_in2',
        'ipc_in3',
        'ipc_in4',
        'ipc_in5',
        'ipc_in6',
        'line_in1',
        'line_in2'
      ]
      const tableData = this.tableData[4]
      const list = []
      const obj = {
        Intfc: 'enc_out,1',
        IntfcAlias: 'ENCODER OUT',
        Volume: tableData.Volume,
        Mute: tableData.Mute,
        DelayTime: tableData.DelayTime,
        AudType: this.audioCodeValue,
        MixChnList: {
          K_E_Y: 'MixChnItem',
          V_A_L_U_E: list
        }
      }
      for (const key in tableData) {
        if (names.indexOf(key) > -1) {
          const value = tableData[key]
          const name = key.replace(/_in/, '_in,')
          // 开启混音复制时，禁止IPC进入混音
          if (this.mixingCopy && name.indexOf('ipc_in') > -1 && value) {
            this.errMessage = '保存失败！混音复制与IPC进入混音冲突！'
          }
          list.push({
            Intfc: name,
            MixEnabled: value,
            MixVolume: 255
          })
        }
      }
      return jsonToXml(obj)
    },
    // 互动输出 xml
    getInOutParamListXml() {
      const inlist = this.GetAmtParamResp.IntInParamList.IntInParamItem
      // IntfcAlias字段不能为空
      inlist.forEach((item) => {
        item.IntfcAlias = item.Intfc.replace(/_/, ' ')
          .replace(/,/, '')
          .toUpperCase()
      })
      // IntfcAlias字段不能为空
      const outlist = this.GetAmtParamResp.IntOutParamList.IntOutParamItem
      outlist.forEach((item) => {
        item.IntfcAlias = item.Intfc.replace(/_/, ' ')
          .replace(/,/, '')
          .toUpperCase()
      })
      const IntInParamList = {
        K_E_Y: 'IntInParamItem',
        V_A_L_U_E: inlist
      }
      const IntOutParamList = {
        K_E_Y: 'IntOutParamItem',
        V_A_L_U_E: outlist
      }
      inlist[0].Mute = this.inputIsMuted
      inlist[0].Volume = this.inputVolume
      outlist[0].Mute = this.outputIsMuted
      outlist[0].Volume = this.outputVolume
      outlist[0].DelayTime = this.timeDelay
      return { IntInParamList, IntOutParamList }
    },
    // 互动输入 xml
    getRefParamXml() {
      return {
        Intfc: this.refSource,
        Volume: this.refVolume,
        Mute: this.GetAmtParamResp.RefParam.Mute,
        DelayTime: this.GetAmtParamResp.RefParam.DelayTime
      }
    },
    // 表格(行) LINE12 HDMI12输出 xml
    getPlayParamListXml(tableData, Intfc) {
      const names = [
        'mic_in1',
        'mic_in2',
        'mic_in3',
        'mic_in4',
        'mic_in5',
        'mic_in6',
        'dmic_in1',
        'hdmi_in1',
        'hdmi_in2',
        'ipc_in1',
        'ipc_in2',
        'ipc_in3',
        'ipc_in4',
        'ipc_in5',
        'ipc_in6',
        'line_in1',
        'line_in2'
      ]
      const list = []
      const obj = {
        Intfc,
        IntfcAlias: Intfc.replace(/_/, ' ').replace(/,/, '').toUpperCase(),
        ChnMode: tableData.ChnMode,
        Gain: tableData.Gain,
        Volume: tableData.Volume,
        Mute: tableData.Mute,
        DelayTime: tableData.DelayTime,
        MixChnList: {
          K_E_Y: 'MixChnItem',
          V_A_L_U_E: list
        }
      }
      for (const key in tableData) {
        if (names.indexOf(key) > -1) {
          const value = tableData[key]
          const name = key.replace(/_in/, '_in,')
          list.push({
            Intfc: name,
            MixEnabled: value,
            MixVolume: 255
          })
        }
      }
      return jsonToXml(obj)
    },
    // 清除定时器
    clearTimer() {
      if (this.timer) {
        clearInterval(this.timer)
      }
    },
    // 改变混音深度
    changeMixDepth() {
      if (this.remixConfig.MixDepth === 1) {
        this.mixingCheckeds = this.mixingCheckeds.splice(0, 1)
      }
    }
  }
}
</script>
<style lang="scss">
.audio-matrix {
  &-content {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
    align-items: center;
    margin-left: 32px;
    font-size: 14px;
  }

  &-save {
    margin-top: 24px;
    text-align: center;
  }

  // 参数配置项布局
  .params-item {
    display: flex;
    flex-wrap: nowrap;
    align-items: center;
    margin: 0 40px 16px 0;

    .params-item-title {
      display: inline-block;
      min-width: 112px;
      text-align: right;
    }

    .spacing_8 {
      margin-right: 8px;
    }

    .volume-bar {
      width: 208px;
    }

    &:last-child {
      margin-right: 0;
    }
  }

  // 表格上方功率信息
  .status-item {
    margin-right: 40px;
  }

  .mix-sound {
    width: 98px;
  }

  .el-table {
    margin-top: 12px;
    min-height: 650px;
  }

  .el-table .cell {
    padding: 8px;
  }
  .width__304 {
    width: 304px;
    margin-left: 8px;
  }

  // 弹出框均衡配置滑块样式
  .equb-wrapper {
    display: flex;
    height: 172px;

    // 刻度
    .equb-scale__y {
      width: 80px;
      height: 100%;

      > div {
        height: 20%;
        text-align: center;
        line-height: 34.5px;
      }
    }
    .equb-slider {
      display: flex;
      flex-grow: 1;
      justify-content: flex-start;
      height: 100%;

      &-item {
        width: 40px;
        height: 100%;
        flex-grow: 1;
      }

      .equb-scale__x {
        display: inline-block;
        height: 20px;
        width: 100%;
        margin-top: 8px;
        text-align: center;
        line-height: 20px;
      }
    }

    .el-slider {
      height: 144px;
    }
  }

  // 混音设置弹出框
  .mix-dialog {
    .mix-dialog-item {
      display: flex;
      align-items: center;
      padding: 4px 0;

      .item-title {
        width: 160px;
      }
    }

    p {
      margin-top: 12px;
      padding: 12px 18px 12px 0;
      border-top: 1px solid #e6e6e6;
      // 混音优先级设置
      span {
        float: right;
      }
    }

    .mixing-select {
      width: 80px;
    }

    .channel-list .el-checkbox-group {
      .channel-list-item {
        display: flex;
        align-items: center;
        justify-content: space-around;
        margin-bottom: 8px;
      }

      .el-checkbox {
        width: 180px;
      }
      .el-select {
        width: 120px;
      }
    }
  }

  .duck-config-form {
    .el-input {
      width: 120px;
    }

    .input-tips {
      margin-left: 16px;
    }
  }
  .equb-dialog__func {
    margin-top: 24px;
    text-align: right;
  }
}
</style>
