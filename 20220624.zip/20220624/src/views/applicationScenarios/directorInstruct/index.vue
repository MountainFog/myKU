<template>
  <div class="direc-inst">
    <div class="icon-title">
      <span>导播指令</span>
      <div class="title-contain__msg">勾选复选框——开启指令。 单击指令名称——编辑指令内容</div>
    </div>
    <div class="direc-inst-list">
      <div
        v-for="item in direInstructList"
        :key="item.MacroInfo"
      >
        <el-checkbox
          v-model="item.IsValid"
          :value="item.MacroInfo"
        />
        <span :class="['list-item', {'list-item__active': direInstructVal === item.MacroInfo}]" @click="handleDireItemClick(item)">{{ item.MacroAlias }}</span>
      </div>
    </div>
    <div class="direc-inst-wrap">
      <div>
        <div class="icon-title">导播参数</div>
        <div class="direc-inst-params">
          <el-form
            ref="paramsForm"
            label-width="160px"
            label-position="left"
            :rules="paramsRules"
            :model="direParams"
          >
            <el-form-item label="优先级：">
              <el-select v-model="direParams.Priority">
                <el-option
                  v-for="index in 9"
                  :key="index"
                  :value="index"
                />
              </el-select>
              <span class="input-advice__after">数值越大优先级越高</span>
            </el-form-item>
            <el-form-item label="灵敏度：">
              <el-select v-model="direParams.Reserved1">
                <el-option
                  v-for="index in 5"
                  :key="index"
                  :value="index"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="保持时间：" prop="HoldTime">
              <el-input v-model.number="direParams.HoldTime" /><span class="input-advice__after">0-600s</span>
            </el-form-item>
            <el-form-item label="检查触发时间：" prop="TriggerTime">
              <el-input v-model.number="direParams.TriggerTime" /><span class="input-advice__after">0-120s</span>
            </el-form-item>
            <el-form-item label="最短保护时间：" prop="ProtectTime">
              <el-input v-model.number="direParams.ProtectTime" /><span class="input-advice__after">0-120s</span>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div>
        <div class="icon-title">
          <span>指令顺序</span>
          <div class="title-contain__func">
            <el-button @click="addOrderDire">新增</el-button>
            <el-button @click="orderTableMove(true)">上移</el-button>
            <el-button @click="orderTableMove(false)">下移</el-button>
          </div>
        </div>
        <div class="direc-inst-order">
          <el-table
            :data="tableData"
            border
            highlight-current-row
            style="width: 100%"
            @current-change="handleTableSelect"
          >
            <el-table-column
              type="index"
              label="顺序"
              width="50"
            />
            <el-table-column
              property="BasicAlias"
              label="指令类别"
            />
            <el-table-column
              property="BasicInfo"
              label="指令描述"
            />
            <el-table-column
              label="操作"
              width="120"
              align="center"
            >
              <template slot-scope="scope">
                <el-button type="text" @click="editOrderDire(scope.row)">编辑</el-button>
                <el-button type="text" @click="delDireOrder(scope.row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <div class="btn-align__center">
      <el-button
        type="primary"
        :loading="saveLoading"
        @click="saveParams"
      >保存</el-button>
    </div>
    <el-dialog
      :visible.sync="visible"
      title="指令类别"
      width="516px"
    >
      <el-tabs
        v-model="tabActive"
        :tab-position="'left'"
      >
        <el-tab-pane :disabled="isEidt" name="pictureMode">
          <span slot="label" class="el-tab-custom">设定画面模式</span>
          <div class="tab-content-title">指令设定</div>
          <div class="tabs-picture-mode">
            <div
              v-for="(item, index) in pictureList"
              :key="item.code"
              :class="['picture-item', {'picture-item__active': direTypeParams.pictureMode === item.code}]"
              @click="direTypeParams.pictureMode = item.code"
            >
              <div :class="`item-img item-img_${index + 1}`" />
              <span class="item-title">{{ item.title }}</span>
            </div>
          </div>
        </el-tab-pane>
        <el-tab-pane :disabled="isEidt" name="pictureChn">
          <span slot="label" class="el-tab-custom">设定主画面图像</span>
          <div class="tab-content-title">指令设定</div>
          <span>通道选择：</span>
          <el-select v-model="direTypeParams.pictureChn">
            <el-option
              v-for="(item, index) in channelList"
              :key="item.id"
              :label="item.label"
              :value="direChns[index]"
            />
          </el-select>
        </el-tab-pane>
        <el-tab-pane :disabled="isEidt" name="pictureSort">
          <span slot="label" class="el-tab-custom" @click="setPictureOrder">设定图像顺序</span>
          <div class="tab-content-title">指令设定</div>
          <div class="tabs-picture-order">
            <p>小画面对应图像选择</p>
            <div class="order-content">
              <div
                v-for="(item, index) in channelSort"
                :key="item.id"
                class="order-content-item"
                :style="orderActive.id === item.id ? 'background: #444E63;' : ''"
                @click="orderActive = item"
              >
                <span v-if="index < 5" class="input-advice__after">{{ `画面${index + 1}: ` }}</span>
                <span class="input-advice__after">{{ item.label }}</span>
              </div>
            </div>
            <div class="order-func">
              <el-button @click="orderPictureMove(true)">上移</el-button>
              <el-button @click="orderPictureMove(false)">下移</el-button>
            </div>
          </div>
        </el-tab-pane>
        <el-tab-pane :disabled="isEidt" name="recording">
          <span slot="label" class="el-tab-custom">课程录制控制</span>
          <div class="tab-content-title">指令设定</div>
          <div class="tab-content">
            <el-radio v-model="direTypeParams.recording" label="FE02020001FF">开始录制</el-radio>
            <el-radio v-model="direTypeParams.recording" label="FE02020002FF">停止录制</el-radio>
          </div>
        </el-tab-pane>
        <el-tab-pane v-if="isDoubleStreaming" :disabled="isEidt" name="videoOut">
          <span slot="label" class="el-tab-custom">切换视频输出</span>
          <div class="tab-content-title">指令设定</div>
          <div class="tab-content">
            <div class="video-out-item">
              <span style="margin-right: 4px;">HDMI OUT1</span>
              <el-select v-model="hdmiOut_1" @change="handleOutChange">
                <el-option
                  v-for="item in outList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </div>
            <div class="video-out-item">
              <span style="margin-right: 4px;">HDMI OUT2</span>
              <el-select v-model="hdmiOut_2" @change="handleOutChange">
                <el-option
                  v-for="item in outList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </div>
          </div>
        </el-tab-pane>
        <el-tab-pane :disabled="isEidt" name="appScenari">
          <span slot="label" class="el-tab-custom">切换应用场景</span>
          <div class="tab-content-title">指令设定</div>
          <div class="tab-content">
            <el-radio v-model="direTypeParams.appScenari" label="FE02380001FF">主讲模式</el-radio>
            <el-radio v-model="direTypeParams.appScenari" label="FE02380002FF">录播模式</el-radio>
            <el-radio v-model="direTypeParams.appScenari" label="FE02380003FF">听讲模式</el-radio>
            <el-radio v-model="direTypeParams.appScenari" label="FE02380004FF">自定义模式</el-radio>
          </div>
        </el-tab-pane>
      </el-tabs>
      <div class="btn-align__right">
        <el-button
          type="primary"
          @click="addDireData"
        >添加
        </el-button>
        <el-button @click="resetDireTypeParams">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { getMacroOrderList, setMacroOrderList } from '@/api/application'
import { isArray } from '@/utils'
import { getChannel } from '../getChannel'
export default {
  mixins: [getChannel],
  data() {
    return {
      // 需要显示的通道的id
      channelIds: ['1', '2', '3', '4', '5', '6', '8'],
      // 通道对应指令 与channelIds内id顺序保持一致。
      direChns: ['FE02030100FF', 'FE02030101FF', 'FE02030102FF', 'FE02030103FF', 'FE02030104FF', 'FE02030105FF', 'FE02030107FF'],
      // 指令顺序配置弹出框
      visible: false,
      // 指令顺序 - 是否重新编辑
      isEidt: false,
      saveLoading: false,
      // 当前等待配置的导播指令
      direInstructVal: 'FE00070005FF',
      // 导播指令列表
      direInstructList: [
        {
          MacroAlias: '教师走下讲台',
          MacroInfo: 'FE00070005FF',
          IsValid: false
        },
        {
          MacroAlias: '教师走出讲台',
          MacroInfo: 'FE00070004FF',
          IsValid: false
        },
        {
          MacroAlias: '学生起立',
          MacroInfo: 'FE00070010FF',
          IsValid: false
        },
        {
          MacroAlias: '学生坐下',
          MacroInfo: 'FE0007000FFF',
          IsValid: false
        },
        {
          MacroAlias: 'PPT切换',
          MacroInfo: 'FE00070008FF',
          IsValid: false
        },
        {
          MacroAlias: '开启互动',
          MacroInfo: 'FE0010000BFF',
          IsValid: false
        },
        {
          MacroAlias: '停止互动',
          MacroInfo: 'FE0010000CFF',
          IsValid: false
        },
        {
          MacroAlias: '发送双流',
          MacroInfo: 'FE0010000DFF',
          IsValid: false
        },
        {
          MacroAlias: '跟踪老师',
          MacroInfo: 'FE00070000FF',
          IsValid: false
        },
        {
          MacroAlias: '跟踪学生',
          MacroInfo: 'FE00070002FF',
          IsValid: false
        },
        {
          MacroAlias: '跟丢老师',
          MacroInfo: 'FE00070001FF',
          IsValid: false
        },
        {
          MacroAlias: '跟丢学生',
          MacroInfo: 'FE00070003FF',
          IsValid: false
        },
        {
          MacroAlias: '多人无法跟踪',
          MacroInfo: 'FE00070006FF',
          IsValid: false
        },
        {
          MacroAlias: '启动初始化',
          MacroInfo: 'FE0010000EFF',
          IsValid: false
        }
      ],
      // 指令顺序表格
      tableData: [],
      // 指令顺序表格选中项
      orderTableActive: {},
      // 导播参数
      direParams: {},
      // 服务端返回数据列表
      respList: [],
      tabActive: 'pictureMode',
      // 画面模式
      pictureList: [
        {
          code: 'FE02010100FF',
          title: '电影模式'
        },
        {
          code: 'FE02010101FF',
          title: '大小画面'
        },
        {
          code: 'FE02010107FF',
          title: '左一右二'
        },
        {
          code: 'FE02010109FF',
          title: '四等分'
        }
      ],
      // 通道排序 - 列表
      channelSort: [],
      // 图像顺序选中项
      orderActive: {},
      // ‘发送双流’ 显示 ‘切换视频输出’
      isDoubleStreaming: false,
      // 视频输出 - 选项列表
      outList: [{
        value: '05',
        label: 'HDMI IN1'
      }, {
        value: '06',
        label: 'HDMI IN2'
      }, {
        value: '03',
        label: '远端主流'
      }, {
        value: '04',
        label: '远端双流'
      }, {
        value: '02',
        label: '合成画面'
      }],
      // 视频输出下拉绑定值
      hdmiOut_1: '',
      hdmiOut_2: '',
      // 指令类别弹出框参数
      direTypeParams: {
        pictureMode: '',
        pictureChn: '',
        pictureSort: '',
        recording: '',
        videoOut: '',
        appScenari: ''
      },
      paramsRules: {
        Reserved1: [{ min: 0, max: 100, type: 'number', message: '请设置0~100之间的参数' }],
        HoldTime: [{ min: 0, max: 600, type: 'number', message: '请设置0~600之间的参数' }],
        TriggerTime: [{ min: 0, max: 120, type: 'number', message: '请设置0~120之间的参数' }],
        ProtectTime: [{ min: 0, max: 120, type: 'number', message: '请设置0~120之间的参数' }]
      }
    }
  },
  watch: {
    direInstructVal(nv) {
      this.direParams = this.respList.find(item => item.MacroOrder.MacroInfo === nv)
      if (!this.direParams.MacroOrder.BasicOrder) {
        this.direParams.MacroOrder.BasicOrder = []
      }
      this.tableData = this.direParams.MacroOrder.BasicOrder
    },
    channelList(nv) {
      if (nv) {
        this.channelSort = []
        this.channelList.forEach(item => {
          this.channelSort.push({
            id: item.id,
            chnId: item.chnId,
            label: item.label,
            state: item.state
          })
        })
      }
    }
  },
  mounted() {
    this.getMacroOrderList()
  },
  methods: {
    // 获取指令数据
    getMacroOrderList() {
      getMacroOrderList({
        GetMacroOrderListExReq: {
          LanguageType: 'Chinese'
        }
      }).then(res => {
        this.respList = res.GetMacroOrderListResp.MacroOrderList.MacroOrderItem
        this.formatRespList(this.respList)
      })
    },
    // 格式化后台返回的指令数据
    formatRespList(list) {
      for (let i = 0; i < this.direInstructList.length; i++) {
        const data = this.direInstructList[i]
        // 按照已知的导播指令列表 匹配对应指令的目标数据
        const target = list.find(item => data.MacroInfo === item.MacroOrder.MacroInfo)
        // 导播参数必须为Number类型
        target.HoldTime = Number(target.HoldTime)
        target.Reserved1 = Number(target.Reserved1)
        target.TriggerTime = Number(target.TriggerTime)
        target.ProtectTime = Number(target.ProtectTime)
        // 字符串转boolean类型
        data.IsValid = target.MacroOrder.IsValid === 'true'
        const basic = target.MacroOrder.BasicOrder
        // 如果存在“指令顺序”数据
        if (basic) {
          // 并且不是只有一条数据
          if (!isArray(basic)) {
            // 转化成数组形式
            target.MacroOrder.BasicOrder = [basic]
          }
        }
        // 默认展示 ‘教师走向讲台’ 指令的参数
        if (target.MacroOrder.MacroInfo === this.direInstructVal) {
          this.direParams = target
          // 指令顺序
          this.tableData = target.MacroOrder.BasicOrder || []
        }
      }
    },
    // 导播指令 列表项点击事件
    handleDireItemClick(item) {
      this.direInstructVal = item.MacroInfo
      this.isDoubleStreaming = item.MacroInfo === 'FE0010000DFF'
    },
    // 指令顺序 - 新增
    addOrderDire() {
      this.isEidt = false
      this.visible = true
      this.tabActive = 'pictureMode'
    },
    // 指令顺序 - 编辑
    editOrderDire(row) {
      this.isEidt = true
      const labels = {
        pictureMode: '设定画面模式',
        pictureChn: '设定主画面图像',
        pictureSort: '设定图像顺序',
        recording: '课程录制控制',
        videoOut: '切换视频输出',
        appScenari: '切换应用场景'
      }
      for (const key in labels) {
        const value = labels[key]
        if (row.BasicAlias === value) {
          this.tabActive = key
          if (key !== 'pictureSort') {
            this.direTypeParams[key] = row.BasicInfo
          }
          // 切换视频输出 数据回显
          if (key === 'videoOut') {
            this.hdmiOut_1 = row.BasicInfo.slice(8, 10)
            this.hdmiOut_2 = row.BasicInfo.slice(12, 14)
          }
          break
        }
      }
      this.visible = true
    },
    // 指令顺序 - 删除
    delDireOrder(row) {
      const index = this.tableData.findIndex(item => item.BasicInfo === row.BasicInfo)
      this.tableData.splice(index, 1)
    },
    // 指令顺序 - 表格选中行
    handleTableSelect(cur) {
      this.orderTableActive = cur
    },
    // 指令顺序表格 - 移动
    orderTableMove(isUp) {
      let index = this.tableData.findIndex(item => item.BasicInfo === this.orderTableActive.BasicInfo)
      // 无选中
      if (index < 0) return
      // 选中的为第一个且上移
      if (index < 1 && isUp) return
      // 选中为最后一个且下移
      if (index >= this.tableData.length - 1 && !isUp) return
      // 交换目标的下标
      const targetIndex = isUp ? index-- : index++
      // 位置互换
      const data = this.tableData[index]
      this.$set(this.tableData, index, this.tableData[targetIndex])
      this.$set(this.tableData, targetIndex, data)
    },
    // 设定图像顺序顺序 - 移动
    orderPictureMove(isUp) {
      let index = this.channelSort.findIndex(item => item.id === this.orderActive.id)
      // 无选中
      if (index < 0) return
      // 选中的为第一个且上移
      if (index < 1 && isUp) return
      // 选中为最后一个且下移
      if (index >= this.channelSort.length - 1 && !isUp) return
      // 交换目标的下标
      const targetIndex = isUp ? index-- : index++
      // 位置互换
      const data = this.channelSort[index]
      this.$set(this.channelSort, index, this.channelSort[targetIndex])
      this.$set(this.channelSort, targetIndex, data)
      this.setPictureOrder()
    },
    // 设定图像顺序指令
    setPictureOrder() {
      let code = ''
      for (let i = 0; i < this.channelSort.length; i++) {
        if (i >= 4) break
        const id = Number(this.channelSort[i].chnId) - 1
        code += (`0${id}00`)
      }
      this.direTypeParams.pictureSort = `FE0402${code}FF`
    },
    // 处理视频输出选中变化
    handleOutChange() {
      const out_1 = this.hdmiOut_1 !== '' ? `01${this.hdmiOut_1}` : ''
      const out_2 = this.hdmiOut_2 !== '' ? `02${this.hdmiOut_2}` : ''
      this.direTypeParams.videoOut = `FE0404${out_1}${out_2}FF`
    },
    // 添加到指令类别配置到表格
    addDireData() {
      const labels = {
        pictureMode: '设定画面模式',
        pictureChn: '设定主画面图像',
        pictureSort: '设定图像顺序',
        recording: '课程录制控制',
        videoOut: '切换视频输出',
        appScenari: '切换应用场景'
      }

      // 当前指令已经存在 且不是重新编辑
      const index = this.tableData.findIndex(item => item.BasicAlias === labels[this.tabActive])
      if (index > -1 && !this.isEidt) {
        this.$message({
          type: 'warning',
          message: '当前指令类别已存在，请勿重复设置！'
        })
        return
      }

      const value = this.direTypeParams[this.tabActive]
      // 当前选中指令未设置参数
      if (value === '') {
        this.$message({
          type: 'warning',
          message: '当前指令类别未设置参数！'
        })
        return
      }

      if (this.isEidt && index > -1) {
        // 编辑时 替换原对象
        // const index = this.tableData.findIndex(item => item.BasicAlias === this.orderTableActive.BasicInfo)
        this.$set(this.tableData, index, {
          BasicAlias: labels[this.tabActive],
          BasicInfo: value,
          IsManul: false
        })
      } else {
        // 新增时 添加到数组内
        this.tableData.push({
          BasicAlias: labels[this.tabActive],
          BasicInfo: value,
          IsManul: false
        })
      }
      this.resetDireTypeParams()
    },
    // 重置参数
    resetDireTypeParams() {
      this.visible = false
      this.isEidt = false
      this.direTypeParams = {
        pictureMode: '',
        pictureChn: '',
        pictureSort: 'FE04020000010002000300FF',
        recording: '',
        videoOut: '',
        appScenari: ''
      }
      this.tabActive = 'pictureMode'
      this.orderActive = {}
      this.channelSort = []
      this.channelList.forEach(item => {
        this.channelSort.push({
          id: item.id,
          chnId: item.chnId,
          label: item.label,
          state: item.state
        })
      })
    },
    // 保存参数
    saveParams() {
      this.$refs.paramsForm.validate((valid) => {
        if (valid) {
          this.saveLoading = true
          // 根据导播指令列表的选中项修改对应数据的IsValid参数
          this.direInstructList.forEach(item => {
            const data = this.respList.find(element => item.MacroInfo === element.MacroOrder.MacroInfo)
            data.MacroOrder.IsValid = item.IsValid
          })
          setMacroOrderList({
            SetMacroOrderListReq: {
              MacroOrderList: {
                K_E_Y: 'MacroOrderItem',
                V_A_L_U_E: this.respList
              }
            }
          }).then(_ => {
            this.$message({
              type: 'success',
              message: '保存成功！'
            })
            this.getMacroOrderList()
            this.saveLoading = false
          }).catch(_ => {
            this.saveLoading = false
          })
        }
      })
    }
  }
}
</script>
<style lang="scss">
.direc-inst {

  // 导播指令
  &-list {
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    align-items: flex-start;
    width: 1080px;
    height: 176px;
    margin: 0 30px;

    >div {
      height: 40px;
      line-height: 40px;
    }

    .el-checkbox-group {
      height: 100%;
    }

    .el-checkbox {
      color: $-fff-85;
      margin-bottom: 16px;
    }

    .list-item {
      display: inline-block;
      padding: 0 4px;
      margin-left: 8px;
      border-radius: 2px;
      line-height: 24px;
      text-align: center;
      cursor: pointer;
      transition: all 0.1s ease;
      font-size: 14px;
      &:hover {
        background-color: #1F75FF;
      }
    }

    .list-item.list-item__active {
      background-color: #1F75FF;
    }
  }

  // 导播参数&指令顺序
  &-wrap {
    display: flex;
    padding: 24px;
    background-color: #2A313E;

    >div {
      width: 50%;
    }

    .el-input {
      width: 208px;
    }
  }

  // 导播参数
  &-params {
    margin-left: 8px;
  }

  // 输入框后缀提示
  .input-advice__after {
    margin-left: 8px;
  }

  // 指令顺序 表格表头
  .el-table .el-table__header th {
    background-color: rgba(255, 255, 255, 0.08);
  }

  .el-table--border td, .el-table--border th, .el-table__body-wrapper .el-table--border.is-scrolling-left ~ .el-table__fixed {
    border-color: #4c5360;
  }

  .el-table--group {
    border: none;
  }

  .icon-title {
    position: relative;
  }

  // 标题提示小字部分样式
  .title-contain__msg {
    position: absolute;
    left: 122px;
    top: 4px;
    font-size: 14px;
    color: rgba(255, 255, 255, 0.45);
    text-indent: 0;
  }

  .title-contain__func {
    position: absolute;
    top: 0;
    right: 0;
  }

  .el-tabs__content {
    height: 100%;
  }

  .el-tab-pane {
    height: 100%;
    text-align: center;
  }

  // 内容标题 指令顺序
  .tab-content-title {
    height: 24px;
    margin: 0 0 16px 24px;
    line-height: 24px;
    text-align: left;
    font-size: 18px;
  }

  // 内容
  .tab-content {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    height: 252px;
    margin-left: 24px;

    .el-radio {
      margin-bottom: 24px;
    }
  }

  .order-title {
    text-align: left;
    font-size: 18px;
    line-height: 24px;
  }

  // 设定画面模式
  .tabs-picture-mode {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;

    // 画面选项
    .picture-item {
      padding: 24px 16px;
      cursor: pointer;
    }

    // 画面背景图片
    .item-img {
      width: 112px;
      height: 64px;
      margin-bottom: 16px;
      background-repeat: no-repeat;
      background-size: 110px 62px;
      box-sizing: border-box;
      border: 2px solid transparent;
    }

    // 画面设定的选中样式
    .picture-item__active {

      .item-img {
        border-color: #1F75FF;
      }

      >span {
        color: #1F75FF;
      }
    }
  }

  // 画面背景图片
  .item-img_1 {
    background-image: url(~@/assets/img/picture_1.png);
  }

  .item-img_2 {
    background-image: url(~@/assets/img/picture_2.png);
  }

  .item-img_3 {
    background-image: url(~@/assets/img/picture_3.png);
  }

  .item-img_4 {
    background-image: url(~@/assets/img/picture_4.png);
  }

  // 设定图像排序
  .tabs-picture-order {
    position: relative;
    padding-left: 24px;
    text-align: left;

    .order-content {
      width: 202px;
      height: 266px;
      margin-top: 8px;
      padding: 8px;
      background-color: rgba(13,16,22,0.48);
    }

    .order-content-item {
      height: 36px;
      line-height: 36px;
      text-indent: 8px;
      cursor: pointer;
      overflow: hidden;

      &:hover {
        background-color: #444E63;
      }
    }

    .order-func {
      position: absolute;
      right: 0;
      top: 50%;
      width: 60px;
      height: 80px;
    }

    .el-button+.el-button {
      margin: 0;
      margin-top: 16px;
    }
    .el-button {
      min-width: 60px;
      width: 60px;
      padding: 8px 0;
    }
  }

  // 切换视频输出 选项
  .video-out-item {
    margin-top: 24px;

    .el-select {
      margin-left: 8px;
      width: 160px;
    }
  }

  .btn-align__center {
    margin-top: 16px;
    text-align: center;
  }

  .btn-align__right {
    margin-top: 16px;
    text-align: right;
  }
}

// 覆盖tab标签的选中样式
.mode-config-tab .is-active .el-tab-custom {
  color: $-fff-85;
  background: #1F75FF;
}

// tab标签自定义样式
.el-tab-custom {
  display: inline-block;
  width: 122px;
  line-height: 32px;
  text-align: center;
  font-size: 14px;
  color: $-fff-85;
  border-radius: 2px;
}
</style>
