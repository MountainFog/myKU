<template>
  <div class="app-scenarios">
    <div class="kd-main-title">应用场景</div>
    <div
      v-loading="loading"
      class="app-scenarios-list"
      element-loading-background="rgba(0, 0, 0, 0.8)"
    >
      <modeCard
        v-for="mode in modeList"
        :key="mode.key"
        :data="mode"
        :mode="activeMode"
        @checkedChange="handleCheckedChange"
      />
    </div>
  </div>
</template>
<script>
import modeCard from './components/modeCard.vue'
import { getSceneParam, setSceneParam } from '@/api/application'
export default {
  components: {
    modeCard
  },
  data() {
    return {
      loading: true,
      activeMode: '',
      modeList: [
        {
          modeName: '录播模式',
          key: 'direct'
        },
        {
          modeName: '主讲模式',
          key: 'speak'
        },
        {
          modeName: '听讲模式 ',
          key: 'listen'
        },
        {
          modeName: '自定义模式',
          key: 'userdef'
        }
      ]
    }
  },
  mounted() {
    this.getSceneParam()
  },
  methods: {
    handleCheckedChange(data) {
      const params = {
        SetSceneParamReq: {
          Mode: data.key,
          Alias: data.modeName
        }
      }
      this.loading = true
      setSceneParam(params).then(res => {
        this.activeMode = data.key
        this.loading = false
      }).catch(_ => {
        this.loading = false
      })
    },
    getSceneParam() {
      getSceneParam().then(res => {
        this.activeMode = res.GetSceneParamResp.Mode
        this.loading = false
      }).catch(_ => {
        this.loading = false
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.app-scenarios {
  height: 100%;
  min-height: 686px;
  padding: 8px 40px;
  background-color: #1d222c;

  &-list {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: calc(100% - 56px);
    min-width: 1400px;
  }
}
</style>
