<template>
  <div class="central-dev">
    <div class="central-dev-item">
      <span class="item-title">中控监听设备：</span>
      <el-select v-model="serialValue">
        <el-option
          v-for="item in serialList"
          :key="item.ComId"
          :value="item.ComId"
          :label="`${item.ComAlias}`"
        />
      </el-select>
      <el-button
        class="alias-config"
        @click="aliasVisible = true"
      >别名配置</el-button>
    </div>
    <div class="central-dev-item">
      <span class="item-title">串口工作参数配置：</span>
      <div class="item-content">
        <span>波特率</span>
        <el-select v-model="serialparam.BitRate">
          <el-option
            v-for="num in BitRateList"
            :key="num"
            :value="num"
          />
        </el-select>
        <span>校验位</span>
        <el-select v-model="serialparam.Parity">
          <el-option
            v-for="item in ParityList"
            :key="item.value"
            :value="item.value"
            :label="item.label"
          />
        </el-select>
        <span>停止位</span>
        <el-select v-model="serialparam.StopBit">
          <el-option
            v-for="num in 2"
            :key="num"
            :value="num.toString()"
          />
        </el-select>
        <span>数据位</span>
        <el-select v-model="serialparam.DataBit">
          <el-option
            v-for="num in 4"
            :key="num"
            :value="(num + 4).toString()"
          />
        </el-select>
      </div>
    </div>
    <div class="central-dev-func">
      <el-button
        type="primary"
        @click="copyVisible = true"
      >复制</el-button>
      <el-button
        type="primary"
        @click="delSerial"
      >删除</el-button>
      <el-button
        type="primary"
        @click="serialSwitch"
      >{{ isEnable === '1' ? '关' : '开' }}</el-button>
    </div>
    <el-table
      v-loading="loading"
      :data="tableData"
      @select="handleSelect"
      @select-all="handleSelect"
    >
      <el-table-column
        type="selection"
        width="55"
      />
      <el-table-column
        type="index"
        label="编号"
        align="center"
        width="90"
      />
      <el-table-column
        property="OrderAlias"
        align="center"
        label="指令名称"
      />
      <el-table-column
        property="OrderContent"
        align="center"
        label="指令代码"
      />
      <el-table-column
        align="center"
        label="操作"
        width="200"
      >
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="tableEdit(scope)"
          >编辑</el-button>
          <el-button
            type="text"
            :disabled="isEnable === '0'"
            @click="listenTest(scope)"
          >测试</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="central-dev-save">
      <el-button
        type="primary"
        :loading="loading"
        @click="setMonitorComParam"
      >保存</el-button>
    </div>
    <el-dialog
      title="指令编辑"
      :visible.sync="instructVisible"
      width="400px"
    >
      <el-form label-position="left" label-width="80px">
        <el-form-item label="指令名称">
          <el-select
            v-model="instructData.OrderAlias"
            style="width: 100%;"
          >
            <el-option
              v-for="item in instructList"
              :key="item.OrderAlias"
              :value="item.OrderAlias"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="指令代码">
          <el-input v-model="instructData.OrderContent" />
        </el-form-item>
      </el-form>
      <div class="btn-align__right">
        <el-button
          type="primary"
          @click="saveInstructEdit"
        >保存</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="别名配置"
      :visible.sync="aliasVisible"
      width="400px"
    >
      <el-form label-position="left" label-width="80px">
        <el-form-item label="RE232-1">
          <el-input v-model="serialAlias.serial_1" />
        </el-form-item>
        <el-form-item label="RE232-2">
          <el-input v-model="serialAlias.serial_2" />
        </el-form-item>
      </el-form>
      <div class="btn-align__right">
        <el-button
          type="primary"
          @click="saveAlias"
        >保存</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="复制到..."
      width="300px"
      :visible.sync="copyVisible"
    >
      <span class="dialog-label">串口</span>
      <el-select
        v-model="copyTarget"
        style="width: 200px;"
      >
        <el-option
          v-for="item in serialList"
          :key="item.ComId"
          :value="item.ComId"
          :label="`${item.ComAlias}`"
        />
      </el-select>
      <div class="btn-align__right">
        <el-button
          type="primary"
          @click="copySerial"
        >确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { getMonitorOrder, setMonitorComParam, listenTest, getBasicOrderListEx, getMonitorComParam } from '@/api/application'
export default {
  data() {
    return {
      loading: true,
      // 指令编辑弹出框显示/隐藏
      instructVisible: false,
      // 别名配置弹出框 显示/隐藏
      aliasVisible: false,
      // 复制指令操作弹出框 显示/隐藏
      copyVisible: false,
      // 串口列表详细数据
      serialList: [],
      // 中控监听设备
      serialValue: '0',
      // 指令选项列表
      instructList: [],
      // 波特率选项列表
      BitRateList: ['110', '300', '600', '1200', '2400', '4800', '9600', '19200', '38400', '57600', '115200'],
      // 校验位选项列表
      ParityList: [
        {
          label: '无校验',
          value: 'none'
        },
        {
          label: '奇校验',
          value: 'odd'
        },
        {
          label: '偶校验',
          value: 'even'
        }
      ],
      // 指令表格数据
      selection: [],
      // 弹出框数据
      instructData: {
        OrderContent: '',
        OrderAlias: ''
      },
      // 表格当前被编辑行数据
      rowData: {},
      // 串口别名配置项
      serialAlias: {
        serial_1: '',
        serial_2: ''
      },
      // 复制到的目标
      copyTarget: ''
    }
  },
  computed: {
    // 当前串口开关状态
    isEnable() {
      let isEnable = ''
      if (this.serialList.length) {
        isEnable = this.serialList.find(item => item.ComId === this.serialValue).IsEnable
      }
      return isEnable
    },
    // 当前串口对应参数
    serialparam() {
      let param = {}
      if (this.serialList.length) {
        param = this.serialList.find(item => item.ComId === this.serialValue).ComParam
      }
      return param
    },
    // 当前串口指令列表
    tableData: {
      get() {
        let tableData = []
        if (this.serialList.length) {
          tableData = this.serialList.find(item => item.ComId === this.serialValue).OrderList.OrderItem
        }
        return tableData
      },
      set() {}
    }
  },
  mounted() {
    this.getBasicOrderListEx()
    this.getMonitorComParam()
  },
  methods: {
    // 获取串口信息的列表
    getMonitorComParam() {
      for (let i = 0; i < 2; i++) {
        getMonitorComParam({
          GetMonitorComParamReq: {
            ComId: i,
            LanguageType: 'Chinese'
          }
        }).then(res => {
          this.loading = false
          const item = res.GetMonitorComParamResp.ComItem
          if (item.OrderList === '') {
            item.OrderList = {
              OrderItem: []
            }
          }else if (item.OrderList.OrderItem && typeof item.OrderList.OrderItem === 'object' && item.OrderList.OrderItem.length === undefined) {
            item.OrderList = {
              OrderItem: [list[i].OrderList.OrderItem]
            }
          }
          this.$set(this.serialList, i, item)

          if(i === 0) {
            this.serialAlias.serial_1 = res.GetMonitorComParamResp.ComItem.ComAlias
          } else {
            this.serialAlias.serial_2 = res.GetMonitorComParamResp.ComItem.ComAlias
          }
        })
      }
    },
    // 表格 - 编辑
    tableEdit(data) {
      this.instructVisible = true
      this.instructData.OrderContent = data.row.OrderContent
      this.instructData.OrderAlias = data.row.OrderAlias
      this.rowData = data.row
    },
    // 表格编辑 - 保存
    saveInstructEdit() {
      this.instructVisible = false
      this.rowData.OrderContent = this.instructData.OrderContent
      this.rowData.OrderAlias = this.instructData.OrderAlias
    },
    // 保存别名配置
    saveAlias() {
      this.serialList[0].ComAlias = this.serialAlias.serial_1
      this.serialList[1].ComAlias = this.serialAlias.serial_2
      this.aliasVisible = false
    },
    // 指令列表
    getBasicOrderListEx() {
      getBasicOrderListEx({
        GetBasicOrderListExReq: {
          LanguageType: 'Chinese'
        }
      }).then(res => {
        this.instructList = []
        const list = res.GetBasicOrderListResp.OrderList.OrderListItem
        // 数组长度为1时，会被解析成对象 因此需要判断是数组还是对象
        if (typeof list === 'object' && list.length) {
          this.instructList = res.GetBasicOrderListResp.OrderList.OrderListItem
        } else {
          this.instructList.push(list)
        }
      })
    },
    // 开/关按钮
    serialSwitch() {
      const serialData = this.serialList.find(item => item.ComId === this.serialValue)
      serialData.IsEnable = serialData.IsEnable === '1' ? '0' : '1'
      this.setMonitorComParam()
    },
    // 测试按钮
    listenTest(scope) {
      listenTest({
        ListenTestReq: {
          ComId: this.serialValue,
          OrderContent: scope.row.OrderContent
        }
      }).then(_ => {
        this.$message({
          type: 'success',
          message: '测试完成！'
        })
      })
    },
    // 复制指令
    copySerial() {
      if (this.copyTarget === '' || this.serialValue === this.copyTarget) {
        this.$message({
          type: 'wraing',
          message: '请选择其它串口'
        })
        return
      }
      const currentData = this.serialList.find(item => item.ComId === this.serialValue)
      const targetData = this.serialList.find(item => item.ComId === this.copyTarget)
      targetData.OrderList.OrderItem = currentData.OrderList.OrderItem
      this.copyVisible = false
    },
    // 表格 - 删除
    tableDel(scope) {
      this.$confirm('此操作将永久删除该指令, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const index = this.tableData.findIndex(item => item.OrderContent === scope.row.OrderContent)
        this.tableData.splice(index, 1)
        this.$message({
          type: 'success',
          message: '删除成功!'
        })
      })
    },
    // 批量删除
    delSerial() {
      this.$confirm('此操作将永久删除该指令, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        for (let i = 0; i < this.selection.length; i++) {
          const data = this.selection[i]
          const index = this.tableData.findIndex(item => item.OrderContent === data.OrderContent)
          this.tableData.splice(index, 1)
        }
        this.selection = []
        this.$message({
          type: 'success',
          message: '删除成功!'
        })
      })
    },
    // 处理表格选中事件
    handleSelect(selection, row) {
      if (!selection.length) return
      this.selection = selection
    },
    // 设置中控监听参数配置
    setMonitorComParam() {
      this.loading = true
      for (let i = 0; i < this.serialList.length; i++) {
        const item = this.serialList[i]
        setMonitorComParam({
          SetMonitorComParamReq: {
            ComItem: {
              ComId: item.ComId,
              ComType: item.ComType,
              ComAlias: item.ComAlias,
              ComParam: item.ComParam,
              IsEnable: item.IsEnable,
              OrderList: {
                K_E_Y: 'OrderItem',
                P_R_O_P: {
                  num: item.OrderList.OrderItem.length
                },
                V_A_L_U_E: item.OrderList.OrderItem
              }
            }
          }
        }).then(res => {
          this.$message({
            type: 'success',
            message: `${item.ComAlias}保存成功`
          })
          this.loading = false
        }).catch(_ => {
          this.loading = false
        })
      }
    }
  }
}
</script>
<style lang="scss">
.central-dev {
  margin: 16px;

  .item-title {
    display: inline-block;
    width: 210px;
    height: 48px;
    line-height: 48px;
    font-size: 14px;
  }

  .item-content {
    display: inline-block;

    .el-select {
      margin: 0 40px 0 16px;
    }
  }

  .el-select {
    width: 100px;
  }

  .alias-config {
    margin-left: 16px;
  }

  &-func {
    margin: 16px 0;
  }

  &-save {
    padding: 16px;
    text-align: center;
  }

  .btn-align__right {
    margin-top: 16px;
    text-align: right;
  }
}

.dialog-label {
  display: inline-block;
  width: 56px;
}
</style>
