import { getNvrChnList, getSvrChnList } from '@/api/application'

export const getChannel = {
  data() {
    return {
      svrList: [],
      nvrList: [],
      channelList: []
    }
  },
  mounted() {
    this.getChnList()
  },
  methods: {
    getChnList() {
      getSvrChnList().then(res => {
        this.svrList = res.GetSvrChnListResp.SvrChnItemList.SvrChnItem
        getNvrChnList({
          GetNvrChnListReq: {
            ChnIDStart: '1',
            ChnIDEnd: '17',
            NeedMask: {
              ChnAlias: true,
              DevSrcID: false,
              ChnState: true
            }
          }
        }).then(res => {
          this.nvrList = res.GetNvrChnListResp.ChnList.ChnInfo
          // 映射nvr通道别名
          this.mapChannelAlias(this.svrList, this.nvrList)
          if (this.channelIds && this.channelIds.length) {
            // 映射指定的通道状态
            this.matchingChannel(this.svrList, this.nvrList)
          }
        })
      })
    },
    // 通道列表根据id匹配对应通道状态
    matchingChannel(svr, nvr) {
      const list = []
      // channelIds 定义了需要渲染到选项的通道列表
      for (let i = 0; i < this.channelIds.length; i++) {
        const svrItem = svr.find(item => item.NvrChnId === this.channelIds[i])
        const nvrItem = nvr.find(item => item.ChnID === this.channelIds[i])
        const state = this.findChannlState(nvrItem.ChnState)
        list.push({
          // 通道列表value = NvrChnId_EncId
          id: svrItem.NvrChnId + '_' + svrItem.EncId,
          chnId: svrItem.NvrChnId,
          label: `D${svrItem.NvrChnId} ${svrItem.SvrChnAlias} (${state})`,
          state
        })
      }
      this.channelList = list
    },
    mapChannelAlias(svr, nvr) {
      for (let i = 0; i < svr.length; i++) {
        const svrItem = svr[i]
        const nvrItem = nvr.find(item => svrItem.NvrChnId === item.ChnID)
        nvrItem.ChnAlias = svrItem.SvrChnAlias
      }
    },
    // 根据状态英文查找中文
    findChannlState(state) {
      const name = state ? state.Connect : ''
      switch (name) {
        case 'online':
          return '在线'
        case 'off_unknown':
          return '下线'
        case 'off_linking':
          return '上线中'
        case 'off_unreach':
          return '网络不通'
        case 'off_autherr':
          return '认证失败'
        case 'off_paramerr':
          return '参数错误'
        case 'off_abnormal_err':
          return '通信失败'
        case 'no_stream_err':
          return '取流失败'
        default:
          return '空闲'
      }
    }
  }
}
