<template>
  <div class="video-output">
    <div class="icon-title">输出源选择</div>
    <div class="video-output-content">
      <span>HDMI OUT1：</span>
      <el-radio-group v-model="config_1.DviSrcType">
        <el-radio v-for="item in out_list" :key="item.label" :label="item.label">{{ item.value }}</el-radio>
        <el-radio label="chn">通道输出</el-radio>
        <el-select
          v-model="outChannel"
          class="out-channel"
          :disabled="config_1.DviSrcType !== 'chn'"
          @change="outChannelChange"
        >
          <el-option
            v-for="item in channelList"
            :key="item.id"
            :label="item.label"
            :value="item.id"
          />
        </el-select>
      </el-radio-group>
    </div>
    <div class="video-output-content">
      <span>HDMI OUT2：</span>
      <el-radio-group v-model="config_2.DviSrcType">
        <el-radio v-for="item in out_list" :key="item.label" :label="item.label">{{ item.value }}</el-radio>
      </el-radio-group>
    </div>
    <div class="icon-title">输出参数配置</div>
    <div class="video-output-config">
      <el-form
        label-width="96px"
        label-position="left"
      >
        <el-form-item label="端口名称：">
          <el-select v-model="configValue">
            <el-option label="HDMI OUT1" value="1" />
            <el-option label="HDMI OUT2" value="2" />
          </el-select>
        </el-form-item>
        <el-form-item label="显示分辨率：">
          <el-select v-model="currentConfig.resolution" @change="refresChange">
            <el-option v-for="item in resolutionList" :key="item" :value="item" />
          </el-select>
        </el-form-item>
        <el-form-item label="显示刷新率：">
          <el-select v-model="currentConfig.RefreshRate" :disabled="refresDisabled">
            <el-option v-for="item in refresList" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
        </el-form-item>
        <el-form-item label="颜色空间：">
          <el-select v-model="currentConfig.ColorSpace" :disabled="colorDisabled">
            <el-option label="YUV422" value="YUV422" />
            <el-option label="RGB444" value="RGB444" />
          </el-select>
        </el-form-item>
        <el-form-item label="显示模式：">
          <el-select v-model="currentConfig.DisMode">
            <el-option label="自定义" :value="0" />
            <el-option label="标准" :value="1" />
            <el-option label="明亮" :value="2" />
            <el-option label="柔和" :value="3" />
            <el-option label="鲜艳" :value="4" />
          </el-select>
        </el-form-item>
        <el-form-item label="亮度：">
          <el-slider v-model="currentConfig.Brightness" :disabled="isSelfDefined" />
        </el-form-item>
        <el-form-item label="对比度：">
          <el-slider v-model="currentConfig.Contast" :disabled="isSelfDefined" />
        </el-form-item>
        <el-form-item label="饱和度：">
          <el-slider v-model="currentConfig.Saturation" :disabled="isSelfDefined" />
        </el-form-item>
        <el-form-item label="色度：">
          <el-slider v-model="currentConfig.Hue" :disabled="isSelfDefined" />
        </el-form-item>
        <el-form-item label=" ">
          <el-button
            type="primary"
            :loading="loading"
            @click="saveVmtParams"
          >保存</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import { getVmtParam, setVmtParam, getSceneParam } from '@/api/application'
import { jsonToXml } from '@/utils/dataParse'
import { getChannel } from '../getChannel'
export default {
  name: 'VideoOutput',
  mixins: [getChannel],
  data() {
    return {
      loading: false,
      out_list: [
        { label: 'cmp', value: '合成画面' },
        { label: 'rmt_main', value: '远端主流' },
        { label: 'rmt_second', value: '远端双流' },
        { label: 'hdmi_in1', value: 'HDMI IN1' },
        { label: 'hdmi_in2', value: 'HDMI IN2' }
      ],
      // 需要渲染到列表的通道id
      channelIds: ['1', '2', '3', '4', '5', '6'],
      configValue: '1',
      // 通道输出
      outChannel: '',
      resolutionList: [
        '1024*768',
        '1280*720',
        '1280*800',
        '1280*1024',
        '1366*768',
        '1440*900',
        '1920*1080',
        '2560*1440',
        '3840*2160'
      ],
      isSelfDefined: true,
      // 刷新率禁选
      refresDisabled: false,
      refresList: [
        { label: '30HZ', value: 30 },
        { label: '60HZ', value: 60 }
      ],
      // 色值禁选
      colorDisabled: false,
      currentConfig: {},
      config_1: {},
      config_2: {}
    }
  },
  watch: {
    configValue(nv) {
      if (nv === '1') {
        this.currentConfig = this.config_1
        this.colorDisabled = false
      } else {
        // HDMI OUT2 色值仅可设置为YUV422
        this.currentConfig = this.config_2
        this.colorDisabled = true
        this.currentConfig.ColorSpace = 'YUV422'
      }
      this.refresChange()
    }
  },
  mounted() {
    this.getSceneParamActive()
    this.getVmtParam()
  },
  methods: {
    // 通道输出
    outChannelChange(val) {
      const ary = val.split('_')
      this.config_1.DviSrcChnId = ary[0]
      this.config_1.DviSrcChnEncId = ary[1]
    },
    getSceneParamActive() {
      getSceneParam().then(res => {
        this.isSelfDefined = res.GetSceneParamResp.Mode === 'userdef'
      })
    },
    refresChange() {
      // HDMI OUT2支持3840*2160p30/60，
      // HDMI OUT1支持3840*2160p30，
      // 其他分辨率都是60hz
      this.refresDisabled = true
      if (this.currentConfig.resolution === '3840*2160') {
        if (this.configValue === '1') {
          this.currentConfig.RefreshRate = 30
        } else {
          this.refresDisabled = false
        }
      } else {
        this.currentConfig.RefreshRate = 60
      }
    },
    // 获取视频参数
    getVmtParam() {
      getVmtParam().then(res => {
        this.formatVmtParams(res.GetVmtParamResp.DviOutPortList.DviOutPort)
        this.currentConfig = this[`config_${this.configValue}`]
      })
    },
    // 格式化成前端所需数据结构
    formatVmtParams(list) {
      list.forEach((item, i) => {
        const config = this['config_' + (i + 1)]
        for (const key in item) {
          const value = item[key]
          if (key === 'Heigth' || key === 'Width') {
            this.$set(config, 'resolution', `${item.Width}*${item.Heigth}`)
          } else {
            this.$set(config, key, isNaN(value) ? value : Number(value))
          }
        }
        if (i === 0) {
          this.outChannel = item.DviSrcChnId + '_' + item.DviSrcChnEncId
        }
      })
    },
    // 格式化成后台所需数据结构
    deformatVmtParams(params) {
      const data = {}
      for (const key in params) {
        if (key === 'resolution') {
          data.Width = params[key].split('*')[0]
          data.Heigth = params[key].split('*')[1]
        } else {
          data[key] = params[key]
        }
      }
      return data
    },
    // 保存
    saveVmtParams() {
      const config_1_xml = jsonToXml({
        DviOutPort: {
          P_R_O_P: {
            id: 0
          },
          V_A_L_U_E: this.deformatVmtParams(this.config_1)
        }
      })
      const config_2_xml = jsonToXml({
        DviOutPort: {
          P_R_O_P: {
            id: 1
          },
          V_A_L_U_E: this.deformatVmtParams(this.config_2)
        }
      })
      this.loading = true
      setVmtParam({
        SetVmtParamReq: {
          DviOutPortList: config_1_xml + config_2_xml,
          PptSrcType: 'hdmi_in1'
        }
      }).then(_ => {
        this.$message({
          type: 'success',
          message: '保存成功！'
        })
        this.loading = false
        this.getVmtParam()
      }).catch(_ => {
        this.loading = false
      })
    }
  }
}
</script>
<style lang="scss">
.video-output {
  &-content {
    margin: 16px 32px;
    line-height: 22px;
    font-size: 14px;

    >span {
      margin-right: 8px;
    }

    .out-channel {
      width: 150px;
    }
  }

  &-config {
    margin-left: 40px;

    .el-form-item__content {
      width: 312px;
    }

    .el-form-item__label {
      color: $-fff-85;
      font-weight: normal;
    }

    .el-select {
      width: 312px;
    }

    .el-button {
      width: 88px;
    }
  }
}
</style>
