import router from './router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { getToken, setToken } from '@/utils/auth'
import store from '@/store'
import getPageTitle from '@/utils/get-page-title'

// 进度条配置
NProgress.configure({ showSpinner: false })

// 不需要验证登录的界面
const whiteList = ['/login']

router.beforeEach(async(to, from, next) => {
  // 通过地址栏携带登录信息 进入系统
  if (to.query.username && to.query.password) {
    // 将登录信息记录到store
    const username = window.atob(to.query.username)
    const password = to.query.password
    const authId = to.query.authenticationid
    const pwd = window.atob(to.query.pwd)
    // 将登录信息记录到token
    setToken(`${username}_${password}_${authId}_${pwd}`)
    store.commit('app/SET_IS_WEB', false)
    store.commit('user/SET_PWD', pwd)
  }
  // 进度条
  NProgress.start()
  let hidden = store.state.app.hiddenPages
  // 设置网页title
  document.title = getPageTitle(to.meta.title) + ' ' + store.getters.devType

  // 判断是否登录
  const hasToken = getToken()

  if (hasToken) {
    if (to.path === '/login') {
      // 去往登录页 先重置token
      store.dispatch('user/resetToken').then(() => {
        location.reload()
      })
    } else {
      try {
        // 判断是否有登录信息
        const hasLogin = store.getters.username && store.getters.password && store.getters.authId
        if (hasLogin) {
          // 有登录信息
          // 重载轮询保活方法
          await store.dispatch('user/getState')
          // 根据版本信息隐藏菜单功能
          await store.dispatch('app/getVersionInfo')
          let promiseIndex = -1
          promiseIndex = hidden.findIndex(item => {
            let promiseItem = item.substr(0,1).toLowerCase() + item.substr(1)
            return to.path.indexOf(promiseItem) > -1
          })
          if(promiseIndex > -1) {
            console.log("to:::",to)
            next({ path: '/deviceOverview',query: to.query})
          }else {
            next()
          }
        } else {
          // 无登录信息
          // 通过token重新获取用户登录信息
          await store.dispatch('user/setUserInfo')
          let promiseIndex = -1
          promiseIndex = hidden.findIndex(item => {
            let promiseItem = item.substr(0,1).toLowerCase() + item.substr(1)
            return to.path.indexOf(promiseItem) > -1
          })
          if(promiseIndex > -1) {
            console.log("to:::",to)
            next({ path: '/deviceOverview',query: to.query})
          }else {
            next({ ...to, replace: true })
          }
        }
      } catch {
        // 无法获取到登录信息则返回到登录界面
        await store.dispatch('user/resetToken')
        next(`/login?redirect=${to.path}`)
        NProgress.done()
      }
    }
  } else {
    /* 没有token*/

    if (whiteList.indexOf(to.path) !== -1) {
      next()
    } else {
      // 其他没有访问权限的页面被重定向到登录页面
      next(`/login?redirect=${to.path}`)
      NProgress.done()
    }
  }
})

router.afterEach(() => {
  // 进度条 完成
  NProgress.done()
})
