<template>
  <div class="svr-top-bar">
    <div class="svr-top-nav">
      <div
        v-for="route in menus"
        v-show="hiddenPages.indexOf(route.name) < 0"
        :key="route.path"
      >
        <router-link
          :class="['top-nav-item', {'top-nav-item__active': $route.path.indexOf(route.path) > -1}]"
          :to="{name: route.name}"
        >
          <span class="top-nav-icon" :style="'background-image: url(' + icons[route.path] + ')'" />
          {{ route.meta.title }}
        </router-link>
      </div>
    </div>
    <div
      v-if="$store.getters.isWeb"
      class="svr-top-logout"
      @click="logout"
    >
      退出
    </div>
  </div>
</template>
<script>

export default {
  data() {
    return {
      // 导航图标
      icons: {
        deviceOverview: require('@/assets/img/nav_dev.png'),
        leadsBroadcasts: require('@/assets/img/nav_vdo.png'),
        interactive: require('@/assets/img/nav_inter.png'),
        resourcesManage: require('@/assets/img/nav_resource.png'),
        systemManage: require('@/assets/img/nav_system.png')
      }
    }
  },
  computed: {
    hiddenPages() {
      return this.$store.state.app.hiddenPages
    },
    menus() {
      const routes = this.$router.options.routes
      let menus = []
      for (let i = 0; i < routes.length; i++) {
        if (routes[i].path === '/') {
          menus = routes[i].children
          return menus
        }
      }
      return menus
    }
  },
  methods: {
    logout() {
      this.$router.push('/login')
    }
  }
}
</script>
<style lang="scss" scoped>
.svr-top-bar {
  position: relative;

  // 顶部导航栏
  .svr-top-nav {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 70px;
    background: #2A313E;

    // 导航单项基础样式
    .top-nav-item {
      display: block;
      height: 100%;
      width: 150px;
      margin: 0 16px;
      text-align: center;
      line-height: 70px;
      color: $-fff-85;
      font-size: 18px;
    }

    // 导航选中样式
    .top-nav-item__active {
      background-image: linear-gradient(180deg, rgba(31,117,255,0.00) 0%, rgba(31,117,255,0.37) 100%);
    }

    // 导航图标
    .top-nav-icon {
      display: inline-block;
      width: 30px;
      height: 30px;
      margin-right: 8px;
      vertical-align: middle;
      background-repeat: no-repeat;
      background-size: cover;
    }
  }

  // 退出按钮
  .svr-top-logout {
    position: absolute;
    right: 16px;
    top: 15px;
    height: 40px;
    width: 70px;
    text-align: center;
    line-height: 40px;
    border-radius: 4px;
    cursor: pointer;

    &:hover {
      background: #03142c;
    }
  }
}
</style>
