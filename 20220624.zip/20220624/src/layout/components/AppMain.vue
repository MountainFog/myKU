<template>
  <section class="app-main">
    <router-view :key="key" />
  </section>
</template>

<script>
export default {
  name: 'AppMain',
  computed: {
    key() {
      // 把路由的第一段作为key
      // 如果把整个path作为key，则嵌套下的路由也会改变path造成router-view刷新
      const paths = this.$route.path.split('/')
      return paths[1]
    }
  }
}
</script>

<style scoped>
.app-main {
  /* topNav = 70px */
  height: calc(100% - 70px);
  width: 100%;
  padding: 4px;
  overflow: auto;
}

</style>
