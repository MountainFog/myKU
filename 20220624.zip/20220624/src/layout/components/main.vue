<template>
  <div class="resource-main">
    <transition name="fade-transform" mode="out-in">
      <keep-alive>
        <router-view />
      </keep-alive>
    </transition>
  </div>
</template>
<script>
export default {
  data() {
    return {
    }
  }
}
</script>
<style lang="scss" scoped>
.resource-main {
  padding-left: 40px;
  flex: 1;
  background-color: #1d222c;
}
</style>
