<template>
  <div class="svr-wrapper">
    <topNav />
    <AppMain />
  </div>
</template>
<script>
import topNav from './components/TopNav.vue'
import AppMain from './components/AppMain.vue'
export default {
  components: {
    topNav,
    AppMain
  },
  data() {
    return {
      page: 'wrapper'
    }
  }
}
</script>
<style lang="scss" scoped>
.svr-wrapper {
  height: 100%;
  color: $-fff-85;
  background-color: black;
}
</style>
