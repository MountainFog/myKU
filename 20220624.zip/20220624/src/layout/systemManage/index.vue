<template>
  <div class="system-manage-container">
    <sidebar
      class="sidebar-container"
      :routes="routes"
    />
    <el-scrollbar id="systemManage">
      <div class="system-content">
        <!-- <keep-alive> -->
        <router-view :key="key" />
        <!-- </keep-alive> -->
      </div>
    </el-scrollbar>
  </div>
</template>
<script>
import Sidebar from '../components/Sidebar'
import routes from '@/router/systemManage'
export default {
  name: 'SystemManage',
  components: {
    Sidebar
  },
  computed: {
    routes() {
      return routes
    },
    key() {
      return this.$route.path
    }
  }
}
</script>
<style lang="scss">
.system-manage-container {
  display: flex;
  height: 100%;
  background-color: #1d222c;

  #systemManage.el-scrollbar {
    width: calc(100% - 200px);
  }

  .el-scrollbar__wrap {
    overflow-x: hidden;
  }

  .el-scrollbar__view {
    height: 100%;
  }

  .system-content {
    height: 100%;
  }
}
</style>
