<template>
  <div class="svr-resource-container">
    <sidebar
      class="sidebar-container"
      :routes="routes"
    />
    <el-scrollbar id="resourceContent">
      <div class="resource-content">
        <!-- <keep-alive> -->
        <router-view :key="key" />
        <!-- </keep-alive> -->
      </div>
    </el-scrollbar>
  </div>
</template>
<script>
import Sidebar from '../components/Sidebar'
import routes from '@/router/resourcesManage'
export default {
  name: 'ResourcesManage',
  components: {
    Sidebar
  },
  computed: {
    routes() {
      return routes
    },
    key() {
      return this.$route.path
    }
  }
}
</script>
<style lang="scss">
.svr-resource-container {
  display: flex;
  height: 100%;
  background-color: #1d222c;

  #resourceContent.el-scrollbar {
    width: calc(100% - 200px);
  }

  .el-scrollbar__wrap {
    overflow-x: hidden;
  }

  .el-scrollbar__view {
    height: 100%;
  }

  .resource-content {
    height: 100%;
  }
}
</style>
