var shell = require('shelljs');
function npmlogin() {
    var username = 'jysyb';
    var password = 'kedacom';
    var email = 'jysyb@kedacom.com';
    var inputArray = [
        username + "\n",
        password + "\n",
        email + "\n",
    ]

    var child = shell.exec('knpm login', { async: true })

    child.stdout.on('data', (chunk) => {
        // shell.echo(byteToString(chunk));
        var cmd = inputArray.shift();
        if (cmd) {
            shell.echo("input " + cmd);
            child.stdin.write(cmd);
        } else {
            child.stdin.end();
        }
    })
}
npmlogin()
