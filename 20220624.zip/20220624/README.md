## 一、准备：

+ ### cd "当前目录"

+ ### node编译环境假设已经安装在/opt/node-v14.17.5-linux-x64

+ ### 执行如下命令，配置环境变量：

```bash
	export NODE_HOME=/opt/node-v14.17.5-linux-x64
	export PATH=$PATH:$NODE_HOME/bin
```
<br/> 

## 二、编译环境搭建（执行一次后不需要重复执行）

+ ### 在当前目录执行如下命令：
   
```bash
	npm install --registry http://172.16.6.154:9081/repository/npmtaobao/
```
   
+ 会在当前目录生成一个node_modules目录，里面是当前工程的依赖包。

<br/>

## 三、编译
   
+ ### 执行如下命令（"npm run"是"npm run-script"的缩写，"build"是vue框架的编译命令）：

```bash
	npm run build
```

将在本目录内生成一个dist目录，该目录内的内容即为编译目标制品。
